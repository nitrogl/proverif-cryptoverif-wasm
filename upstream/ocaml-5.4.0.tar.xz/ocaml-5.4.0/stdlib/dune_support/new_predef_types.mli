type !+'a iarray
