(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
let stdout_channel = stdout

open Unix

let tmpdir = ref ""

let timeout = ref 0

type speed =
  | All 
  | Speed of float

let speed_check = ref All

let limit_very_fast = 60
let limit_fast = 300

type hist_loc_t =
  | NoHist
  | HistScript
  | HistDir of string

let hist_loc = ref NoHist

let additional_options = ref []
    
let error s =
  print_string s;
  exit 2
    
type error_t =
  | InfoNotFound
  | EmptyInfo
  | UnfinishedInfo
  | TimeNotFound
  | IncorrectTime
  | IncorrectResultHistory
  | IncorrectMTimeHistory
  | IncorrectRSS
  | TimeOut
      
type time_res_t =
  | Timeout of float (* timeout after the given number of seconds *)
  | Time of float (* time in seconds *)
  | NoTime
  | Error

type mode_t =
  | Test
  | TestAdd
  | Add
  | Update
  | Reset

(* This record is mutated by the primitive [get_resources] *)
type time_record =
  { mutable total : float;
    mutable user : float;
    mutable system : float }
     
external get_resources : time_record -> int = "get_resources"

(* Utility functions *)

let string_of_time nb_s = 
  let sec_total = int_of_float nb_s in
  let hours = sec_total / 3600 in
  let mins = (sec_total / 60) mod 60 in
  let sec = sec_total - hours * 3600 - mins * 60 in
  if hours = 0 && mins = 0 
  then string_of_float nb_s
  else if hours = 0
  then Printf.sprintf "%dmin %ds" mins sec
  else Printf.sprintf "%dh %dmin" hours mins

let string_of_float_nb_dec n nb_dec =
  let qmult = 10.**(float_of_int nb_dec) in
  string_of_float (Float.round (n *. qmult) /. qmult)

let string_of_memory nb_k = 
  let k = float_of_int nb_k in
  let tera = k /. 1000000000. in
  if tera >= 1.
  then (string_of_float_nb_dec tera 3)^" TB"
  else 
    let giga = k /. 1000000. in
    if giga >= 1.
    then (string_of_float_nb_dec giga 3)^" GB"
    else (string_of_float_nb_dec (k /. 1000.) 3)^" MB"

(* Configuration *)

(* [find_file filename dir_list] looks for the file [filename]
   in the list of directories [dir_list].
   Raises [Not_found] if [filename] does not exist in any
   directory in [dir_list]. *)
  
let rec find_file filename = function
  | [] -> raise Not_found
  | None :: l ->
      find_file filename l
  | (Some a)::l ->
      let full_name = Filename.concat a filename in
      if Sys.file_exists full_name then
        full_name
      else
        find_file filename l
  
let exe_extension = if Sys.os_type = "Unix" then "" else ".exe"
  
let exe_dir_opt = ref None

let find_exe dir_list exe_name =
  let exe_name_with_extension = exe_name ^ exe_extension in
  (* First, try to find the executable in the current directory,
     then in the directories mentioned in [dir_list],
     and as a last resort, in the PATH *)
  try
    find_file exe_name_with_extension ((!exe_dir_opt) :: (Some Filename.current_dir_name) :: dir_list)
  with Not_found ->
    (* as a last resort, try to find the executable in the PATH *)
    exe_name_with_extension

let home_dir_opt =
  try
    Some (Sys.getenv "HOME")
  with Not_found ->
    None
    
let cv_default_dir_opt =
  match home_dir_opt with
  | Some home_dir -> Some (Filename.concat home_dir "CryptoVerif")
  | None -> None

let pv_default_dir_opt =
  match home_dir_opt with
  | Some home_dir -> Some (Filename.concat (Filename.concat home_dir "proverif") "proverif")
  | None -> None

let default_user = "default"
let dev_version = "dev"
	
type config_t =
    { executable : string;
      expected_result_marker : string;
      expected_result_history_marker : string;
      expected_time_history_marker : string;
      is_result_line : string -> bool;
        (* [is_result_line l] is true iff [l] should be kept in the result *)
      get_result : string -> string option;
      build_option_table : string -> (string * string list) list;
        (* [build_option_table dirname] returns a list of [(ext_i, options_i)]
           such that the files that end with [ext_i] should be analyzed 
           with options [options_i]. *)
      useful_file : string -> bool;
        (* [useful_file file] returns true when the file is useful for the
	   considered program *)
      version : string;
        (** The default version is [dev_version]. *)
      user : string 
        (** The default user is [default_user]. *)}

let cv_config ~version_tag ~user_tag =
  let cv_file = find_exe [cv_default_dir_opt] "cryptoverif" in
  { executable = cv_file;
    expected_result_marker = "EXPECTED";
    expected_result_history_marker = "HISTORY RESULT";
    expected_time_history_marker = "HISTORY TIME";
    is_result_line = (fun l ->
      (StringPlus.starts_with l "RESULT Could not prove") ||
      (StringPlus.starts_with l "All queries proved") ||
      (StringPlus.contains l "Error") ||
      (StringPlus.contains l "Warning:"));
    get_result = (fun l ->
      if StringPlus.starts_with l "RESULT Could not prove" 
      || StringPlus.starts_with l "All queries proved"
      then Some l
      else None 
      );
    build_option_table = (fun dirname -> 
      let cv_options =
        let cv_lib_name = Filename.concat dirname "mylib.cvl" in
        if Sys.file_exists cv_lib_name then
          [ "-o"; !tmpdir; "-lib" ; cv_lib_name ]
        else
          [ "-o"; !tmpdir ]
      in
      let ocv_options =
        let cv_lib_name = Filename.concat dirname "mylib.ocvl" in
        if Sys.file_exists cv_lib_name then
          [ "-o"; !tmpdir; "-lib" ; cv_lib_name ]
        else
          [ "-o"; !tmpdir ]
      in
      [(".cv", cv_options); (".pcv", cv_options); (".ocv", ocv_options)]);
    useful_file = (fun file -> 
        StringPlus.ends_with file ".pcv" ||
        StringPlus.ends_with file ".cv" ||
        StringPlus.ends_with file ".ocv" || 
	"mylib.cvl" = file ||
	"mylib.ocvl" = file
      );
    version = version_tag;
    user = user_tag
  }      

let result_true = "RESULT .* is true"
let result_false = "RESULT .* is false"
let result_dontknow = "RESULT .* cannot be proved"
let reg_result_true = Str.regexp result_true
let reg_result_false = Str.regexp result_false
let reg_result_dontknow = Str.regexp result_dontknow
        
let pv_config ~version_tag ~user_tag = 
  let pv_file = find_exe [pv_default_dir_opt] "proverif" in
  let test_option = ["-test"] in
  let basic_options =
    [ (".pi", test_option); (".horn", test_option); (".horntype", test_option) ]
  in
  let is_main_result l =
    StringPlus.starts_with l "RESULT" &&
    not (StringPlus.starts_with l "RESULT (even" ||
         StringPlus.starts_with l "RESULT (but" ||
         StringPlus.starts_with l "RESULT (query")
  in
  let get_result l =
    if l = "No query in the input file."
    then Some "noquery"
    else if StringPlus.starts_with l "RESULT goal unreachable:"
    then Some "true"
    else if StringPlus.starts_with l "RESULT goal reachable:" 
    then Some "false"
    else if not (is_main_result l)
    then None
    else if Str.string_match reg_result_true l 0
    then Some "true"
    else if Str.string_match reg_result_false l 0
    then Some "false"
    else if (Str.string_match reg_result_dontknow l 0) || l = "RESULT no biprocess can be computed"
    then Some "dontknow"
    else None
  in
  { executable = pv_file;
    expected_result_marker = "EXPECTPV";
    expected_result_history_marker = "HISTORY RESULT";
    expected_time_history_marker = "HISTORY TIME";
    is_result_line = (fun l ->
      StringPlus.starts_with l "RESULT" ||
      l = "No query in the input file." ||
      (StringPlus.contains l "Error"));
    get_result = get_result;
    build_option_table = (fun dirname ->
      let pv_lib_name = Filename.concat dirname "mylib.pvl" in
      if Sys.file_exists pv_lib_name then
        let pv_options = [ "-test" ; "-lib" ; pv_lib_name ] in
        (".pcv", pv_options) :: (".pv", pv_options) :: basic_options
      else
        try 
          let cryptoverif_pvl =
            find_file "cryptoverif.pvl"
              [ Some Filename.current_dir_name; cv_default_dir_opt; pv_default_dir_opt ]
          in
          (".pcv", [ "-test" ; "-lib" ; cryptoverif_pvl ]) :: (".pv", test_option) :: basic_options
        with Not_found ->
          print_string "Error: cryptoverif.pvl not found. Cannot analyze *.pcv files.\n";
          (".pv", test_option) :: basic_options
                         );
    useful_file = (fun file -> 
        StringPlus.ends_with file ".pv" ||
        StringPlus.ends_with file ".pi" ||
        StringPlus.ends_with file ".horn" ||
        StringPlus.ends_with file ".horntype" ||
        StringPlus.ends_with file ".pcv" ||
	"mylib.pvl" = file
      );
    version = version_tag;
    user = user_tag
  }      

type result_status =
  | RSSuccess of string
  | RSError of string

let string_of_result_status = function
  | RSSuccess qrl -> qrl
  | RSError e -> e

type result_history =
  {
    rh_version : string;
    rh_queries : result_status
  }

type result_t =
  | RHistory of result_history
  | RExpected of string list
      
let string_of_result_history rh = 
  Printf.sprintf "Version %s - %s" rh.rh_version (string_of_result_status rh.rh_queries)

type mtime_history =
  {
    th_user : string;
    th_version : string;
    th_time : time_res_t; (* Total runtime information *)
    th_mem : int option; (* Memory usage in kb.
			    [None] when memory usage could not be determined *)
    th_mtime_str : string; (* Initial mtime string; used for writing in files *)
  }

let build_th config t mem mtime_line =
  { th_user = config.user;
    th_version = config.version;
    th_time = t;
    th_mem = mem;
    th_mtime_str = mtime_line }

let empty_th t =
  { th_user = "";
    th_version = "";
    th_time = t;
    th_mem = None;
    th_mtime_str = "" }
  
let string_of_mtime_history th = 
  th.th_user^" - "^th.th_version^" - "^th.th_mtime_str

type full_history_t =
    string list * mtime_history * result_history list * mtime_history list
(* [(expected_result, expected_mtime, history_result, history_time)]
   where
   - [expected_result: string list] is the result lines (for the latest
   version).
   - [expected_mtime: mtime_history] gives time and memory usage information
   for CryptoVerif or ProVerif (for the latest version and default user).
   - [history_result: result_history list] gives the history of results for
   various versions.
   - [history_time: mtime_history list] gives the history of time and memory
   usage information for various versions and users. *)

let compare_version v1 v2 = 
  (* [dev_version] is the most recent version *)
  if v1 = dev_version then
    if v2 = dev_version then 0 else -1
  else
    if v2 = dev_version then 1 else -(compare v1 v2) 

let compare_mtime_history th1 th2 = 
  let c = compare_version th1.th_version th2.th_version in
  if c <> 0 
  then c
  else compare th1.th_user th2.th_user

let compare_result_history rh1 rh2 = compare_version rh1.rh_version rh2.rh_version

(** Expected syntax : "xtime: timeout (XXX s)" *)
let get_time_from_timeout_error time_line = 
  int_of_string (String.sub time_line 16 (String.length time_line - 19))
 
let is_timeout_error time_line = 
  StringPlus.starts_with time_line "xtime: timeout" 

(* Interpretation *)

let (let>) s f  = Result.bind s f

(** A line in result_history should be of the form :
      "Version XXX - AAA BBB CCC DDD ..."   XXX should be without '-'. AAA, BBB, etc should only be true, false or dontknow 
    or 
      "Version XXX - xtime: ..."
    *)
let interpret_result_history res_line = 
  if StringPlus.starts_with res_line "Version "
  then 
    match String.index_opt res_line '-' with
    | None -> Result.Error IncorrectResultHistory
    | Some i ->
        try 
          let version = String.sub res_line 8 (i-9) in
          let size = String.length res_line in
          let remaining = String.sub res_line (i+2) (size-i-2) in
          let result = 
            if StringPlus.starts_with remaining "xtime:" 
            then RSError remaining
            else RSSuccess remaining
          in
          Result.Ok { rh_version = version; rh_queries = result }
        with Failure _ -> Result.Error IncorrectResultHistory
  else Result.Error IncorrectResultHistory

(* We assume here that [mtime_line] should not be an error message. It should also not contain user and version. *)
let interpret_mtime user version mtime_line =
  if is_timeout_error mtime_line
  then
    let th_mtime = 
      { th_user = user;
        th_version = version;
        th_time = Timeout (float_of_int (get_time_from_timeout_error mtime_line));
        th_mem = None;
        th_mtime_str = mtime_line
      }
    in
    Result.Ok th_mtime
  else if StringPlus.starts_with mtime_line "xtime:" 
  then Result.Error IncorrectMTimeHistory
  else if StringPlus.contains mtime_line "user" && StringPlus.contains mtime_line "system"
  then 
    let> time = 
      try 
	let l_time = String.index mtime_line 's' in
	let time_string = String.sub mtime_line 0 l_time in
	Result.Ok (float_of_string time_string)
      with Not_found | Failure _ -> Result.Error IncorrectTime
    in
    let> mem_op = 
      match StringPlus.pos mtime_line "max rss " with
      | None -> Result.Ok None
      | Some pos_rss ->
	  try 
            let end_rss = String.index_from mtime_line (pos_rss+8) 'K' in
            let rss_string = String.sub mtime_line (pos_rss+8) (end_rss-pos_rss-8) in
            Result.Ok (Some (int_of_string rss_string))
	  with Not_found | Failure _ ->
            Result.Error IncorrectRSS
    in
    let th_mtime = 
      { th_user = user;
        th_version = version;
        th_time = Time time;
        th_mem = mem_op;
        th_mtime_str = mtime_line
      }
    in
    Result.Ok th_mtime
  else Result.Error TimeNotFound
 
(** Should have a format of the form:
    "XXX - YYY - 0.029s BLABLABLA max rss ZZZK"*)
let interpret_mtime_history mtime_line =
  match String.index_opt mtime_line '-' with
  | None -> Result.Error IncorrectMTimeHistory
  | Some i1 ->
      let user = String.sub mtime_line 0 (i1 - 1) in
      let remaining1 = String.sub mtime_line (i1+2) (String.length mtime_line - i1 - 2) in
      match String.index_opt remaining1 '-' with
      | None -> Result.Error IncorrectMTimeHistory
      | Some i2 ->
          let version = String.sub remaining1 0 (i2 - 1) in
          let remaining2 = String.sub remaining1 (i2+2) (String.length remaining1 - i2 - 2) in
          interpret_mtime user version remaining2
	      
(* [interpret_mtime_xtime config reversed_result time_line] 
   interprets the time line [time_line].
   [reversed_result: string list] should be the result lines output by
   CryptoVerif or ProVerif, in reversed order.
   It returns [(errors, result', mtime)] where
   - [errors: error_t list] is a list of errors. 
   - [result': string list] is the result lines in the right order, including
   [time_line] when it is in fact an error message.
   - [mtime: mtime_history] is the runtime and memory usage information
     of CryptoVerif or ProVerif.
     [mtime.th_time] is [NoTime] when the runtime could not be determined and
     [Error] when [time_line] was in fact an error.
     [mtime.th_mem] is the maximum memory usage, in kb. It is [None] when the
     maximum memory usage could not be determined.
     [mtime.th_mtime_str] is empty when [time_line] is in fact an error 
     message ([time_line] is already included in [result']) and [time_line]
     otherwise. *)
let interpret_mtime_xtime config reversed_result time_line =
  match interpret_mtime config.user config.version time_line with
  | Result.Ok th ->
      begin
	match th.th_time with
	| Timeout f -> 
	    ([TimeOut],None,th)
	| _ ->
	    ([],Some (List.rev reversed_result), th)
      end
  | Result.Error IncorrectMTimeHistory -> 
      ([],Some (List.rev (time_line::reversed_result)), build_th config Error None "")
  | Result.Error TimeNotFound -> 
      ([TimeNotFound],Some (List.rev (time_line::reversed_result)),build_th config NoTime None "")
  | Result.Error e ->
      ([e],Some (List.rev reversed_result),build_th config NoTime None time_line)
    
(* [get_info_from_script config error_out script] gets the "expected result"
   information from the CryptoVerif or ProVerif file [script].
   [config: config_t] is the configuration associated to CryptoVerif or 
   ProVerif.
   [error_out: string -> unit] is a function that displays an error message.
   It returns
   - [Result.Error e] in case of error, with [e: error_t]
   - [Result.Ok hist] in case of success, with [hist: full_history_t] *)
      
let get_info_from_script config error_out script =
  let read_from_hist_file() =
    match !hist_loc with
    | HistDir d ->
	(* Read the history from a separate file in directory [d] *)
	begin try 
	  let f = open_in (Filename.concat d (script^".hist")) in
	  let rec collect_time_history accu_hist_r accu_hist_t =
	    try 
	      let l = input_line f in
	      collect_time_history accu_hist_r (l::accu_hist_t)
	    with End_of_file ->
	      (accu_hist_r, accu_hist_t)
	  in
	  let rec collect_result_history accu_hist_r =
	    try 
	      let l = input_line f in
	      if StringPlus.starts_with l config.expected_time_history_marker then
		collect_time_history accu_hist_r []
	      else 
		collect_result_history (l::accu_hist_r) 
	    with End_of_file ->
	      (accu_hist_r, [])
	  in
	  let r = 
	    let l = input_line f in
	    if StringPlus.starts_with l config.expected_result_history_marker then
              collect_result_history []
	    else if StringPlus.starts_with l config.expected_time_history_marker then
              collect_time_history [] []
	    else
	      [],[]
	  in
	  close_in f;
	  r
	with _ -> [],[]
	end
    | _ -> [],[]
  in
  
  let f = open_in script in

  let rec collect_time_history accu accu_hist_r accu_hist_t =
    try 
      let l = input_line f in
      if StringPlus.contains l "END" 
      then Result.Ok (accu,accu_hist_r,accu_hist_t)
      else collect_time_history accu accu_hist_r (l::accu_hist_t)
    with End_of_file ->
      Result.Error UnfinishedInfo
  in

  let rec collect_result_history accu accu_hist_r =
    try 
      let l = input_line f in
      if StringPlus.contains l "END" then Result.Ok (accu,accu_hist_r,[])
      else if StringPlus.starts_with l config.expected_time_history_marker then
        collect_time_history accu accu_hist_r []
      else 
        collect_result_history accu (l::accu_hist_r) 
    with End_of_file ->
      Result.Error UnfinishedInfo
  in

  let rec collect_result accu =
    try 
      let l = input_line f in
      if StringPlus.contains l "END" then
	let (accu_hist_r,accu_hist_t) = read_from_hist_file() in
	Result.Ok (accu,accu_hist_r,accu_hist_t)
      else if StringPlus.starts_with l config.expected_result_history_marker then
        collect_result_history accu []
      else if StringPlus.starts_with l config.expected_time_history_marker then
        collect_time_history accu [] []
      else 
        collect_result (l::accu) 
    with End_of_file ->
      Result.Error UnfinishedInfo
  in

  let rec look_for_expected() =
    let l = input_line f in
    if StringPlus.contains l config.expected_result_marker then
      Some (collect_result [])
    else
      look_for_expected()
  in

  let result =
    try
      look_for_expected()
    with End_of_file ->
      None				  
  in

  close_in f;
  match result with
  | None -> Result.Error InfoNotFound
  | Some Result.Error e -> Result.Error e
  | Some Result.Ok (res_l,res_h,time_h) ->
      (* When interpreting, if an error occurs while reading the history, we display the error but we do not
        abort, i.e. we consider the error line as if it did not exist in the history. *)
      let display_error = function
        | IncorrectResultHistory -> error_out "Incorrectly formatted result history in script file\n"
        | IncorrectMTimeHistory -> error_out "Incorrectly formatted memory-time history in script file\n"
        | TimeNotFound -> error_out "Expected runtime not found in script file\n"
        | IncorrectTime -> error_out "Incorrectly formatted runtime in script file\n"
        | IncorrectRSS -> error_out "Incorrectly formatted max rss in script file\n"
        | _ -> assert false
      in
      let res_l', expected_time =
	match res_l with
	| [] -> [], empty_th NoTime
	| time_line::reversed_result -> 
	    match interpret_mtime "" "old" time_line with
	    | Result.Ok th ->
		begin
		  match th.th_time with
		  | Timeout f -> 
		      [],th
		  | _ ->
		      (List.rev reversed_result), th
		end
	    | Result.Error IncorrectMTimeHistory -> 
		List.rev (time_line::reversed_result), empty_th Error
	    | Result.Error TimeNotFound -> 
		List.rev (time_line::reversed_result), empty_th NoTime
	    | Result.Error e ->
		display_error e;
		List.rev reversed_result, empty_th NoTime
      in
      let result_history = 
        List.filter_map (fun line -> match interpret_result_history line with
          | Result.Error e -> display_error e; None
          | Result.Ok rh -> Some rh
        ) (List.rev res_h) 
      in
      let time_history = 
        List.filter_map (fun line -> match interpret_mtime_history line with
          | Result.Error e -> display_error e; None
          | Result.Ok th -> Some th
        ) (List.rev time_h) 
      in
      if res_l' = [] && expected_time.th_time = NoTime && result_history = []
      then Result.Error EmptyInfo
      else Result.Ok ((res_l',expected_time,result_history,time_history) : full_history_t)

(* [update_expected_result_aux config expected_line_opt filename hist]
   updates the history included in the script file [filename: string].
   [hist: full_history_t] is the new history 
   [expected_line_opt = None] initially.
   [expected_line_opt = Some line] when the analyzed script contains a reference
   EXPECTED ... FILENAME: filename TAG: ...
   Then [line] is that line, and we update the result in the referenced file [filename].
   That's useful when scripts are generated (for instance by m4).
   [config: config_t] is the configuration associated to CryptoVerif or 
   ProVerif. *)

type state_t =
  | WaitEXPECTED
  | WaitEND
  | Found

let output_line f s =
  output_string f s;
  output_string f "\n"

let output_history f config ((_,_,result_history,time_history) : full_history_t) =
  if result_history <> []
  then 
    begin 
      output_line f config.expected_result_history_marker;
      List.iter (fun rh -> output_line f (string_of_result_history rh)) result_history;
    end;
  if time_history <> []
  then 
    begin 
      output_line f config.expected_time_history_marker;
      List.iter (fun th -> output_line f (string_of_mtime_history th)) time_history;
    end

let output_expected_history f config ((expected_result, expected_time,_,_) as hist : full_history_t) =
  List.iter (output_line f) expected_result;  
  if !hist_loc = HistScript then
    output_history f config hist
  else if expected_time.th_mtime_str <> "" then
    output_line f expected_time.th_mtime_str

let rec update_expected_result_aux config expected_line_opt filename (hist : full_history_t) =
  let f = open_in filename in
  let tmp_name = filename^".tmp" in
  let f_new = open_out tmp_name in
  let state = ref WaitEXPECTED in
  try
    let rec aux() =
      let line = input_line f in
      let expected_found =
        match expected_line_opt with
        | None -> StringPlus.contains line config.expected_result_marker
        | Some expected_line -> line = expected_line
      in
      match !state with
      | WaitEXPECTED ->
          if expected_found then
            begin
              let ref_initial_file =
                if expected_line_opt = None then
                  (* If we are not already in the initial file referred to by 
                     EXPECTED ... FILENAME: filename TAG: ...
                     check whether the current line is such a reference *)
                  let len_filename = String.length " FILENAME: " in
                  let pos_filename = StringPlus.pos line " FILENAME: " in
                  let pos_tag = StringPlus.pos line " TAG: " in
                  match pos_filename, pos_tag with
                  | Some n_filename, Some n_tag ->
                      let pos_end_filename = n_filename + len_filename in
                      if pos_end_filename < n_tag then
                        (* Line EXPECTED ...  FILENAME: filename TAG: ... *)
                        let initial_filename = String.sub line pos_end_filename (n_tag - pos_end_filename) in
                        close_out f_new;
                        Unix.unlink tmp_name;
                        close_in f;
                        update_expected_result_aux config (Some line) initial_filename hist;
                        true
                      else
                        false
                  | _ -> false
                else
                  false
              in
              if not ref_initial_file then
                begin
                  output_line f_new line;
		  output_expected_history f_new config hist;
                  state := WaitEND;
                  aux()
                end
            end
          else
            begin
              output_line f_new line;
              aux()
            end
      | _ when expected_found ->
          close_in f;
          close_out f_new;
          begin
            match expected_line_opt with
            | None ->
                error ("Error: script "^filename^" contains several expected results.\n")
            | Some expected_line ->
                error ("Error: script "^filename^" contains several times an expected result with line:\n"^expected_line^"\n")
          end
      | WaitEND ->
          if StringPlus.contains line "END" then
            begin
              output_line f_new line;
              state := Found
            end;
          aux()
      | Found ->
          output_line f_new line;
          aux()
    in
    aux()
  with End_of_file ->
    close_in f;
    begin
      match !state, expected_line_opt with
      | WaitEXPECTED, Some expected_line ->
          close_out f_new;
          error ("Error: expected result with line\n"^expected_line^"\nmissing in "^filename^ "\n")
      | WaitEXPECTED, None ->	  
          (* expected result not found, add it *)
          output_line f_new "";
          output_line f_new ("(* "^config.expected_result_marker);
          output_expected_history f_new config hist;
          output_line f_new "END *)"
      | Found, _ -> ()
      | WaitEND, _ ->
          close_out f_new;
          error ("Error: END marker missing in "^filename^ "\n")
    end;
    close_out f_new;
    Unix.rename tmp_name filename
        
(* [update_expected_result_aux config filename hist]
   updates the history included in the script file [filename: string]
   and/or a separate history file in directory [dir] when
   [!hist_loc = HistDir dir].
   [hist: full_history_t] is the new history.
   [config: config_t] is the configuration associated to CryptoVerif or 
   ProVerif. *)

let rec create_dir d =
  if Sys.file_exists d then
    if Sys.is_directory d then () else
    error ("Error: "^ d ^ " should be a directory\n")
  else
    begin
      create_dir (Filename.dirname d);
      Unix.mkdir d 0o755
    end
      
let output_separate_history filename config (hist : full_history_t) =
  match !hist_loc with
  | HistDir dir ->
      (* Write the history in a file in directory [dir] *)
      begin
	let hist_filename = Filename.concat dir (filename ^ ".hist") in
	try
	  create_dir (Filename.dirname hist_filename);
	  let f_hist = open_out hist_filename in
	  output_history f_hist config hist;	  
	  close_out f_hist
	with Sys_error s ->
	  error ("Error: could not write history file " ^ hist_filename ^ ": " ^ s ^ "\n")
      end
  | _ -> ()

let update_expected_result config filename (hist : full_history_t) =
  update_expected_result_aux config None filename hist;
  output_separate_history filename config hist  


(* [write descr s] writes the string [s] to the file descriptor [descr] *)
        
let write descr s =
  let len = String.length s in
  if Unix.write_substring descr s 0 len <> len then
    error "Error: cannot write file\n"
      
(* [extract_result config output_in_channel] extracts the result
   lines from the output of CryptoVerif or ProVerif. 
   This output is read via the input channel [output_in_channel].
   [config: config_t] is the configuration associated to CryptoVerif or 
   ProVerif. 
   The result lines are returned in reversed order. *)
      
let extract_result config output_in_channel =
  let accu = ref [] in
  let rec aux () =
    let l = input_line output_in_channel in
    if config.is_result_line l then
      accu := l::(!accu);
    aux ()
  in
  try 
    aux ()
  with End_of_file ->
    !accu

(* [equal_lists l1 l2] is true when the lists [l1] and [l2] are equal *)
      
let equal_lists l1 l2 =
  (List.length l1 == List.length l2) &&
  (List.for_all2 (=) l1 l2)

let config_already_recorded config = function
  | None -> false
  | Some (_,_,result_history,time_history) ->
      (!hist_loc = NoHist) ||
      List.exists (fun th -> 
        th.th_user = config.user && 
        th.th_version = config.version && 
        (match th.th_time with
	| Timeout th_timeout ->
	    !timeout > 0 && th_timeout >= float_of_int(!timeout)
	| _ -> true)
      ) time_history ||
      List.exists (fun rh -> match rh.rh_queries with
        | RSError str -> 
            rh.rh_version = config.version &&
            (not (is_timeout_error str) || 
              (!timeout > 0 && get_time_from_timeout_error str >= !timeout)
            )
        | _ -> false
      ) result_history

let result_status_of_result_list config actual_result actual_th = match actual_th.th_time with
  | NoTime | Time _ -> (* All elements of [actual_result] are part of the result *)
      let qresl = List.filter_map config.get_result actual_result in
      if qresl = []
      then RSSuccess "noquery"
      else RSSuccess (String.concat " " qresl)
  | Error -> (* The last element of [actual_result] is the error message *)
      let error_line = match List.rev actual_result with
        | [] -> assert false
        | x::_ -> x
      in
      RSError error_line
  | Timeout _ ->
      RSError actual_th.th_mtime_str
	
let simple_check = ref false

(** In order of preference, we compare with the same version, then the latest version before and then the earliest version after. *)

let get_closest_result config ((expected_result_list,_,result_history,_): full_history_t) =
  let rec get_closest_result config prev_rh = function
    | [] -> prev_rh
    | rh::q  ->
	let c = compare_version rh.rh_version config.version in
	if c >= 0
	then rh 
	else get_closest_result config rh q
  in
  match result_history with
  | [] -> RExpected expected_result_list
  | rh_min::q_hist ->
      if compare_version config.version rh_min.rh_version <= 0
      then 
        if !simple_check 
        then RHistory rh_min
	else RExpected expected_result_list
      else
	RHistory (get_closest_result config rh_min q_hist)
	      
let compare_result config actual_result_opt actual_th history_data = match actual_result_opt,history_data with
  | None, _ | _, None -> false
  | Some actual_result, Some hist ->
      (* The actual result lines are only checked against the earliest version *)
      match get_closest_result config hist with 
      | RExpected expected_result_list ->
	  equal_lists actual_result expected_result_list
      | RHistory rh ->
          let reduced_actual_result = result_status_of_result_list config actual_result actual_th in
          rh.rh_queries = reduced_actual_result

let show_expected_actual_results config mode res_out equal_result actual_result_opt history_data = match actual_result_opt, history_data with
  | None, _ -> ()
  | Some actual_result, None -> 
      if mode <> Test then
        res_out "Adding result to script. ";
      res_out "Actual result:\n";
      List.iter (fun s -> res_out s; res_out "\n") actual_result
  | Some actual_result, Some hist ->
      if not equal_result then
	begin
          if mode == Update then
            res_out "Updating expected result. Old"
          else
            res_out "RESULTS DIFFER! Expected";
	  begin
	    match get_closest_result config hist with
	    | RExpected expected_result_list ->
		res_out ":\n";
		List.iter (fun s -> res_out s; res_out "\n") expected_result_list
	    | RHistory rh ->
		res_out " summary of queries";
		if rh.rh_version <> config.version then
		  res_out (" in version "^rh.rh_version);
		res_out ":\n";
		res_out ((string_of_result_status rh.rh_queries)^"\n")
	  end;
          res_out "Actual:\n";
          List.iter (fun s -> res_out s; res_out "\n") actual_result
        end    
    
let rec add_result_in_sorted a = function
  | [] -> [a]
  | a'::q ->
      let c = compare_result_history a' a in
      if c < 0 then a'::(add_result_in_sorted a q)
      else if c = 0 then 
        begin match a.rh_queries with
        | RSError err when is_timeout_error err ->
            begin match a'.rh_queries with
            | RSError err' when is_timeout_error err' ->
                let nb_s = get_time_from_timeout_error err in
                let nb_s' = get_time_from_timeout_error err' in 
                if nb_s > nb_s' then a :: q else a' :: q
            | _ -> a' :: q
            end
        | _ -> a :: q
        end
      else a :: a' :: q

let rec add_time_in_sorted th = function
  | [] -> [th]
  | th'::q ->
      let c = compare_mtime_history th' th in
      if c < 0 then th'::(add_time_in_sorted th q)
      else if c = 0 then
	match th.th_time with
	| Timeout nb_s ->
	    begin
	      match th'.th_time with
	      | Timeout nb_s' ->
		  if nb_s' > nb_s 
		  then th'::q
		  else th::q
	      | _ -> th'::q
	    end
	| _ -> th::q
      else th :: th' :: q
      
let update_history config mode filename actual_result_opt actual_th time_line (history_data : full_history_t option) =
  if (mode == Update) || (mode <> Test && not (config_already_recorded config history_data)) then
  match actual_result_opt with
  | None -> ()
  | Some actual_result ->

      let new_latest_result = match history_data with
        | None -> actual_result
        | Some (expected_result_list,expected_time,result_history,_) ->
            if (mode == Update) && (match result_history with
	       | [] -> true
	       | rh_min::_ -> compare_version config.version rh_min.rh_version <= 0)
            then 
              match actual_th.th_time, expected_time.th_time with
	      | Timeout nb_s, Timeout nb_s' ->
		  if nb_s' > nb_s then expected_result_list else actual_result
              | Timeout _, _ -> expected_result_list
	      | _ -> actual_result
            else expected_result_list
      in
      let new_latest_time = match history_data with
        | None -> actual_th
        | Some(expected_result_list,expected_time,result_history,mtime_history) ->
	    if (mode == Update) && (config.user = default_user) &&
	      (let mtime_history_user = List.filter (fun th -> th.th_user = config.user) mtime_history in
	      match mtime_history_user with
	      | [] -> true
	      | th_min::_ -> compare_version config.version th_min.th_version <= 0)
	    then
              match actual_th.th_time, expected_time.th_time with
	      | Timeout nb_s, Timeout nb_s' ->
		  if nb_s' > nb_s then expected_time else actual_th
              | Timeout _, _ -> expected_time
	      | _ -> actual_th
            else expected_time
      in
      let reduced_actual_result = result_status_of_result_list config actual_result actual_th in
      let actual_result_history = 
        {
          rh_version = config.version;
          rh_queries = reduced_actual_result
        }
      in
      let new_result_history = match history_data with 
        | None -> [actual_result_history]
        | Some (_,_,result_history,_) -> add_result_in_sorted actual_result_history result_history 
      in

      let old_mtime_history = match history_data with
        | None -> []
        | Some(_,_,_,l) -> l
      in
      let new_mtime_history = match actual_th.th_time with
        | Error | NoTime -> old_mtime_history
        | Timeout _ | Time _ ->
            add_time_in_sorted actual_th old_mtime_history
      in

      update_expected_result config filename (new_latest_result, new_latest_time, new_result_history, new_mtime_history)

type mtime_comparison =
  {
    compared_version:string;
    mutable cur_time:float;
    mutable cur_mem:int;
    mutable stored_time:float;
    mutable stored_mem:int;
  }

let dir_mtime_comparison = ref []

let add_in_mtime_comparison config time mem_opt time_history =
  List.iter (fun th ->
    if th.th_user = config.user 
    then
      let (cur_mem,stored_mem) = match mem_opt,th.th_mem with
        | Some m, Some m' -> m,m'
        | _ -> 0,0
      in
      let (cur_time,stored_time) = match th.th_time with
        | Time t -> time, t
        | _ -> 0.0,0.0
      in
      begin match List.find_opt (fun mtime_cmp -> mtime_cmp.compared_version = th.th_version) !dir_mtime_comparison with
      | None -> 
          let mtime_cmp = 
            {
              compared_version = th.th_version;
              cur_time = cur_time;
              cur_mem = cur_mem;
              stored_time = stored_time;
              stored_mem = stored_mem
            }
          in 
          dir_mtime_comparison := mtime_cmp :: !dir_mtime_comparison
      | Some mtime_cmp ->
          mtime_cmp.cur_time <- mtime_cmp.cur_time +. cur_time;
          mtime_cmp.cur_mem <- mtime_cmp.cur_mem + cur_mem;
          mtime_cmp.stored_time <- mtime_cmp.stored_time +. stored_time;
          mtime_cmp.stored_mem <- mtime_cmp.stored_mem + stored_mem
      end
  ) time_history

let display_dir_mtime_comparison config res_out =
  let sorted_dir = List.sort (fun mt mt' -> compare_version mt.compared_version mt'.compared_version) !dir_mtime_comparison in

  res_out "Time and memory statistics:\n";
  List.iter (fun mtime_cmp ->
    let time_div = mtime_cmp.stored_time /. mtime_cmp.cur_time in
    let mem_div = (float_of_int mtime_cmp.stored_mem) /. (float_of_int mtime_cmp.cur_mem) in
    let str = Printf.sprintf "  new %s: %s and %s  -- old %s: %s and %s -- time ratio = %s -- memory ratio = %s\n" 
      config.version (string_of_time mtime_cmp.cur_time) (string_of_memory mtime_cmp.cur_mem)
      mtime_cmp.compared_version (string_of_time mtime_cmp.stored_time) (string_of_memory mtime_cmp.stored_mem)
      (string_of_float_nb_dec time_div 2) (string_of_float_nb_dec mem_div 2)
    in
    res_out str
  ) sorted_dir

let get_closest_time config ((_,expected_time,_,time_history): full_history_t) =
  let rec get_closest_time config prev_th = function
    | [] -> prev_th
    | th::q ->
	let c = compare_version th.th_version config.version in
	if c >= 0
	then th 
	else get_closest_time config th q
  in
  (* Consider only the times for the same user (that is, same machine, to have comparable speed) *)
  let time_history_user = List.filter (fun th -> th.th_user = config.user) time_history in
  match time_history_user with
  | [] -> expected_time
  | x::q -> get_closest_time config x time_history_user

let compare_time_memory config res_out actual_th (history_data : full_history_t option) = match actual_th.th_time,history_data with
  | Error,_ | NoTime,_ | Timeout _, _-> ()
  | Time time, None -> 
      res_out (Printf.sprintf "Actual time: %.3fs\n" time);
      begin match actual_th.th_mem with
      | None -> ()
      | Some actual_rss ->res_out (Printf.sprintf "Actual memory: %iK\n" actual_rss);
      end
  | Time time, Some ((_,expected_time,_,time_history) as hist) ->
      add_in_mtime_comparison config time actual_th.th_mem time_history;
      let th_user = get_closest_time config hist in
      begin match th_user.th_time with
      | Time expected_time -> 
	  if expected_time *. 1.2 +. 0.2 < time then
            res_out (Printf.sprintf "Slower: %s=%.3fs %s=%.3fs\n" th_user.th_version expected_time config.version time)
	  else if expected_time *. 0.8 -. 0.2 > time then
            res_out (Printf.sprintf "Faster: %s=%.3fs %s=%.3fs\n" th_user.th_version expected_time config.version time)
      | Timeout expected_timeout ->
	  if expected_timeout *. 0.8 -. 0.2 > time then
            res_out (Printf.sprintf "Faster: %s timeout=%.3fs %s=%.3fs\n" th_user.th_version expected_timeout config.version time)
      | _ ->
	  res_out (Printf.sprintf "Actual time: %.3fs\n" time)
      end;
      begin match actual_th.th_mem,th_user.th_mem with
      | None, _ -> ()
      | Some actual_rss, None ->
	  res_out (Printf.sprintf "Actual memory: %iK\n" actual_rss)
      | Some actual_rss, Some expected_rss ->
          if (float_of_int expected_rss) *. 1.2 +. 10000. < float_of_int actual_rss then
            res_out (Printf.sprintf "More memory: %s=%iK %s=%iK\n" th_user.th_version expected_rss config.version actual_rss)
          else if (float_of_int expected_rss) *. 0.8 -. 10000. > float_of_int actual_rss then
            res_out (Printf.sprintf "Less memory: %s=%iK %s=%iK\n" th_user.th_version expected_rss config.version actual_rss)  
      end

let is_file_too_slow config (history_data : full_history_t option) = 
  match !speed_check with
  | All -> false
  | Speed limit ->
      match history_data with
      | None -> false
      | Some hist ->
          let closest_th = get_closest_time config hist in
	  match closest_th.th_time with
	  | Time t | Timeout t -> t >= limit
	  | _ -> false

(* [files_t] contains the file descriptors and channels used for analyzing
   scripts *)

type files_t =
    { null_input_file_descr : Unix.file_descr;
         (* null input file descriptor, used as input for CryptoVerif or ProVerif *)
      output_file_descr : Unix.file_descr;
         (* output file descriptor, used to store the output of CryptoVerif or ProVerif *)
      output_in_channel : in_channel;
         (* input channel used to read the output of CryptoVerif or ProVerif.
            Points to the same file as [output_file_descr] *)
      res_out_channel : out_channel;
         (* output channel used to output the results of tests (for each test,
            whether it yields the expected result or not). The same output
            it also displayed on the standard output. *)
      sum_out_channel : out_channel
         (* output channel used to output a summary of the result 
            (for each test, the result lines and runtime of CryptoVerif 
            or ProVerif). *) }

(* [analyze_file config options filename files] analyzes the script
   stored in file [filename].
   [config: config_t] is the configuration associated to CryptoVerif or 
   ProVerif. 
   [options: string list] is a list of options passed to CryptoVerif or 
   ProVerif.
   [files: files_t] describes auxiliary files (see type [files_t])
   *)
      
let analyze_file config mode options filename files =
  let sum_out s =
    output_string files.sum_out_channel s
  in
  let res_out s =
    print_string s; flush stdout_channel;
    output_string files.res_out_channel s
  in
  let error_out s = 
    res_out (Printf.sprintf "Error in %s: %s" filename s)
  in
  
  let script_info = get_info_from_script config error_out filename in
  match script_info with 
  | Result.Error UnfinishedInfo -> error_out "END marker missing in script file\n"
  | _ ->
      let history_data = match script_info with 
        | Result.Error InfoNotFound -> 
            if mode == Test then error_out "Expected result missing in script file\n";
            None
        | Result.Error EmptyInfo -> 
            if mode == Test then error_out "Empty expected result in script file\n";
            None
        | Result.Error _ -> assert false
        | Result.Ok hist -> Some hist
      in

      if mode == Reset 
      then
        begin
          res_out ("PROTOCOL " ^ filename ^ " ");
          update_expected_result config filename ([],empty_th NoTime,[],[]);
          res_out ("RESET\n");
        end
      else
      if ((mode == Add) && config_already_recorded config history_data) || is_file_too_slow config history_data then () else
      begin 
        res_out ("PROTOCOL " ^ filename ^ " ");
        write files.output_file_descr ("PROTOCOL " ^ filename ^ "\n");
        let output_length = in_channel_length files.output_in_channel in
        let args = Array.make (List.length options + 2) filename in
        args.(0) <- config.executable;
        List.iteri (fun n s -> args.(n+1) <- s) options;

        let (actual_errors, actual_result_opt, actual_th, time_line) =
          if Sys.os_type <> "Unix" then
            let normal_result start_time end_time status =
              seek_in files.output_in_channel output_length;
              let reversed_result = extract_result config files.output_in_channel in
              match status with
              | WEXITED 0 ->
                  let time = end_time -. start_time in
                  let time_line = Printf.sprintf "%.3fs (elapsed: user + system + other processes)" time in
                  ([], Some (List.rev reversed_result), build_th config (Time time) None time_line, time_line)
              | _ -> 
                  let error_line =
                    match status with
                    | WEXITED status -> Printf.sprintf "xtime: error in child process (status : %i)" status
                    | WSIGNALED _ -> "xtime: killed by a signal"
                    | WSTOPPED _ -> "xtime: stopped"
                  in
                  ([], Some (List.rev (error_line::reversed_result)), build_th config Error None "", error_line)
            in	  
            let start_time = Unix.gettimeofday() in
	    try
              let child_pid = Unix.create_process config.executable args
                  files.null_input_file_descr files.output_file_descr files.output_file_descr in
              if (!timeout) > 0 then
		begin
                  let timeout_reached = ref false in
                  let (pipe_read, pipe_write) = Unix.pipe() in
                  let _ = Thread.create (fun () ->
                    let (read_ready, _, _) = Unix.select [pipe_read] [] [] (float_of_int (!timeout)) in
                    match read_ready with
                    | [] ->
			timeout_reached := true;
			begin
                          try
                            Unix.kill child_pid Sys.sigkill
                          with _ -> ()
			end;
			Unix.close pipe_read
                    | _ ->
			Unix.close pipe_read
                          ) ()
                  in
                  let (_, status) = Unix.waitpid [] child_pid in
                  let end_time = Unix.gettimeofday() in
                  if (!timeout_reached) then
                    begin
                      Unix.close pipe_write;
                      let time_line = "xtime: timeout ("^(string_of_int (!timeout))^" s)" in
		      
                      ([TimeOut], None,build_th config (Timeout (float_of_int (!timeout))) None time_line, time_line)
                    end
                  else
                    begin
                      begin
			try
                          ignore (Unix.single_write_substring pipe_write "f" 0 1)
			with _ -> ()
                      end;
                      Unix.close pipe_write;		
                      normal_result start_time end_time status
                    end
		end
              else
		begin
                  let (_, status) = Unix.waitpid [] child_pid in
                  let end_time = Unix.gettimeofday() in
                  normal_result start_time end_time status
		end
	    with
	    | Unix.Unix_error(error_code, "create_process", arg) ->
		error ("Error: could not run "^config.executable^", "^(Unix.error_message error_code)^"\n")
	    | e ->
		error ("Error: problem in child process ("^ (Printexc.to_string e) ^")\n")
          else
            let time_record = { total = -1.; user = -1.; system = -1. } in
            let time_filename = Filename.concat (!tmpdir) "time" in
            let time_out_channel = open_out time_filename in
            flush files.res_out_channel; (* flush before the fork to avoid double outputs; 
              sum_out_channel is flushed immediately after the outputs are made, no need to flush again. *)
            let fork_res = Unix.fork() in
            if fork_res = 0 then
              begin
              (* Child process *)
              try
                let child_pid = Unix.create_process config.executable args
                    files.null_input_file_descr files.output_file_descr files.output_file_descr
                in
                let normal_result status =
                  begin
                    match status with
                    | WEXITED 0 ->
                        let max_rss = get_resources(time_record) in
                        Printf.fprintf time_out_channel "%.3fs (user %.3fs + system %.3fs), max rss %iK\n" time_record.total time_record.user time_record.system max_rss
                    | WEXITED 127 ->
                    (* Could not execute the program *)
                        exit 3
                    | WEXITED status ->
                        Printf.fprintf time_out_channel "xtime: error in child process (status : %i)\n" status
                    | WSIGNALED _ ->
                        output_string time_out_channel "xtime: killed by a signal\n"
                    | WSTOPPED _ ->
                        output_string time_out_channel "xtime: stopped\n"
                  end;
                  flush time_out_channel;
                  exit 0
                in
                if (!timeout) > 0 then
                  begin
                    let fork_res_sleep = Unix.fork() in
                    if fork_res_sleep = 0 then
                      begin
                        (* Child process *)
                        Unix.sleep (!timeout);
                        exit 0
                      end
                    else
                      begin
                        (* Parent process *)
                        let (pid_finished, status) = Unix.waitpid [] (-1) in
                        if pid_finished == fork_res_sleep then
                          begin
                            (* Timeout *)
                            begin
                              try
                                Unix.kill child_pid Sys.sigkill
                              with _ -> ()
                            end;
                            let _ = Unix.waitpid [] child_pid in
                            output_string time_out_channel ("xtime: timeout ("^(string_of_int (!timeout))^" s)\n");
                            flush time_out_channel;
                            exit 0
                          end
                        else
                          begin
                            assert (pid_finished == child_pid);
                            begin
                              try 
                                Unix.kill fork_res_sleep Sys.sigkill
                              with _ -> ()
                            end;
                            let _ = Unix.waitpid [] fork_res_sleep in
                            normal_result status
                          end
                      end
                  end
                else
                  begin
                    let (_, status) = Unix.waitpid [] child_pid in
                    normal_result status
                  end
              with
	      | Unix.Unix_error(error_code, "create_process", arg) ->
		  print_string ("Error: could not run "^config.executable^", "^(Unix.error_message error_code)^"\n");
		  exit 4
	      | e ->
		  print_string ((Printexc.to_string e) ^"\n");
		  exit 4
              end
            else
              begin
                (* Parent process *)
                close_out time_out_channel;
                      let (_, status) = Unix.waitpid [] fork_res in
                begin
                  match status with
                  | WEXITED 0 -> () (* child process ran fine *)
                  | WEXITED 3 -> error ("Error: cannot execute "^config.executable^"\n")
		  | WEXITED 4 -> error ("Error: problem in child process (see message above)\n")
		  | WEXITED n -> error ("Error: problem in child process (status "^ string_of_int n^")\n")
		  | WSIGNALED n -> error ("Error: problem in child process (killed by signal "^ string_of_int n^")\n")
		  | WSTOPPED n -> error ("Error: problem in child process (stopped by signal "^ string_of_int n^")\n")
                end;
                let time_in_channel = open_in time_filename in
                let time_line = input_line time_in_channel in
                close_in time_in_channel;
                seek_in files.output_in_channel output_length;
                let reversed_result = extract_result config files.output_in_channel in

                let (actual_errors, actual_result_opt, actual_th) =	
                  interpret_mtime_xtime config reversed_result time_line
                in
                (actual_errors, actual_result_opt, actual_th, time_line)
              end
        in
        let equal_result = compare_result config actual_result_opt actual_th history_data in
        begin
          if equal_result then
            res_out "OK\n"
          else if List.mem TimeOut actual_errors then
            res_out "TIMEOUT\n"
          else
            res_out "\n"
        end;
        List.iter (function
          | TimeNotFound -> res_out "ERROR: Expected runtime not found in output of xtime\n"
          | IncorrectTime -> res_out "ERROR: Incorrectly formatted runtime in output of xtime\n" 
          | IncorrectRSS -> res_out "ERROR: Incorrectly formatted max rss in output of xtime\n"
          | TimeOut -> ()
          | _ -> assert false
        ) actual_errors;
        show_expected_actual_results config mode res_out equal_result actual_result_opt history_data;
        update_history config mode filename actual_result_opt actual_th time_line history_data;
        compare_time_memory config res_out actual_th history_data;
        write files.output_file_descr time_line;
        write files.output_file_descr "\n";
        sum_out "PROTOCOL ";
        sum_out filename;
        sum_out "\n";
        begin
          match actual_result_opt with
          | Some actual_result -> List.iter (fun s -> sum_out s; sum_out "\n") actual_result
          | None -> ()
        end;
	if actual_th.th_mtime_str <> "" then
          sum_out (actual_th.th_mtime_str ^"\n");
        flush files.sum_out_channel;
        flush files.res_out_channel
      end
    
(* [get_date()] returns the current date as a string (for use in filenames) *)
    
let get_date() =
  let tm = Unix.localtime(Unix.time()) in
  Printf.sprintf "%04i.%02i.%02i-%02i_%02i_%02i" (tm.tm_year+1900)
    (tm.tm_mon+1) tm.tm_mday tm.tm_hour tm.tm_min tm.tm_sec

(* [open_files prefix] opens auxiliary files.
   [prefix: string] is a string used a prefix in the filenames.
   It returns a record [files_t]. *)
    
let open_files prefix =
  let output = prefix ^ (get_date()) in
  let output_file_descr = Unix.openfile (Filename.concat "tests" output) [O_WRONLY;O_APPEND;O_CREAT] 0o640 in
  let output_in_channel = open_in (Filename.concat "tests" output) in
  { null_input_file_descr = Unix.openfile (Filename.concat (!tmpdir) "null") [O_RDONLY;O_CREAT;O_TRUNC] 0o600;
    output_file_descr = output_file_descr;
    output_in_channel = output_in_channel;
    res_out_channel = open_out_gen [Open_append; Open_creat] 0o640 (Filename.concat "tests" ("res-"^output));
    sum_out_channel = open_out_gen [Open_append; Open_creat] 0o640 (Filename.concat "tests" ("sum-"^output)) }

(* [close_files files] closes the files in [files: files_t] *)
    
let close_files files =
  Unix.close files.null_input_file_descr;
  Unix.close files.output_file_descr;
  close_in files.output_in_channel;
  close_out files.res_out_channel;
  close_out files.sum_out_channel

(* [analyze_dir config dirname files filename_opt] analyzes files
   in the directory [dirname]. 
   When [filename_opt = None], it analyzes all suitable files in 
   [dirname] and subdirectories.
   When [filename_opt = Some filename], it analyzes only the file [filename].
   [config: config_t] is the configuration associated to CryptoVerif or 
   ProVerif. 
   [files: files_t] describes auxiliary files (see type [files_t]) *)
    
let show_stat = ref false

let analyze_dir config mode dirname files filename_opt =
  let res_out s =
    print_string s; flush stdout_channel;
    output_string files.res_out_channel s
  in
  dir_mtime_comparison := [];
  res_out "\nDirectory ";
  res_out dirname;
  res_out "\n\n";
  let all_options = config.build_option_table dirname in
  let analyze_one_file full_filename filename =
    let rec find_options = function
        [] -> ()
      | (ext, options)::rest -> 
          if StringPlus.case_insensitive_ends_with filename ext then
            analyze_file config mode ((!additional_options) @ options) full_filename files
          else
            find_options rest
    in
    find_options all_options
  in
  let rec aux dirname =
    let file_array = Sys.readdir dirname in
    Array.sort compare file_array;
    Array.iter (fun filename ->
      let full_filename = Filename.concat dirname filename in
      try 
        if Sys.is_directory full_filename then
          aux full_filename
        else if StringPlus.case_insensitive_contains filename ".m4." ||
                StringPlus.case_insensitive_contains filename ".out." then
          ()
        else
          try 
            analyze_one_file full_filename filename
          with Sys_error s ->
            error ("Error: "^s^"\n")
      with Sys_error _ ->
        res_out ("Warning: File "^full_filename^" was probably removed.\n")
            ) file_array
  in
  begin
    match filename_opt with
    | None -> 
	aux dirname
    | Some filename ->
	let full_filename = Filename.concat dirname filename in
	analyze_one_file full_filename filename
  end;
  if !show_stat
  then 
    begin
      res_out "\n";
      display_dir_mtime_comparison config res_out
    end

(* [usage()] displays an help message. Called when the arguments are 
   incorrect *)
        
let usage() =
  print_string
    "Incorrect arguments
Usage: 
  analyze [options] <prog> <mode> <tmp_directory> <prefix for output files> dirs <directories>
  analyze [options] <prog> <mode> <tmp_directory> <prefix for output files> file <directory> <filename>
where 
* [options] can be 
  - -timeout <n>: sets the time out to <n> seconds.
  - -progopt <arguments to pass to the tested program> -endprogopt
  - -version <str>: sets the version to <str> (default is \"dev\")
  - -user <str>: sets the user to <str> (default is \"default\")
  - -exedir <str>: indicates the directory where the executable can be found
  - -vfast: limits to files that can be verified within 60 seconds
  - -fast: limits to files that can be verified within 300 seconds
  - -speed <n>: limits to files that can be verified within <n> seconds
  - -simple: equality of results is only done on the summary of results instead of the exact output
  - -stat: display some time and memory statistics
  - -hist: include history of statistics in the script file
  - -histdir <dir>: include history of statistics in separate files in directory <dir>
* <prog> is either CV for CryptoVerif or PV for ProVerif
* and <mode> can be
  - test: test the mentioned scripts
  - test_add: test the mentioned scripts and add the 
    expected result in the script when it is missing
  - add: add the expected result in the script when it is missing, 
    do not test scripts that already have an expected result
  - update: test the mentioned scripts and update the expected
    result in the script.
  - reset: reset the history stored in the scripts.";
  exit 0

let is_directory s =
  try Sys.is_directory s with Sys_error _ -> false
  
let retrieve_main_dirs config dirname =
  let acc_file = ref [] in

  let rec explore dirname = 
    let files = Sys.readdir dirname in
    Array.sort (fun s1 s2 -> String.compare (String.lowercase_ascii s1) (String.lowercase_ascii s2)) files;
    if 
      Array.exists (fun file ->
	config.useful_file file ||
        "prepare" = file
      ) files
    then acc_file := dirname :: !acc_file
    else 
      Array.iter (fun file ->
        let full_file = Filename.concat dirname file in
        if is_directory full_file then explore full_file
      ) files 
  in

  explore dirname;
  List.rev !acc_file

(* Main function. Parses command-line arguments. *)

let set_speed limit =
  timeout := limit;
  speed_check := Speed (float_of_int limit)
			  
let _ =
  let user = ref default_user in
  let version = ref dev_version in
  let rec parse_options n =
    if Array.length Sys.argv < (n+1) then
      usage();
    match Sys.argv.(n) with
    | "-timeout" ->
        if Array.length Sys.argv < (n+2) then
          usage();
        begin
          try
            timeout := int_of_string (Sys.argv.(n+1))
          with Failure _ ->
            usage()
        end;
        parse_options (n+2)
    | "-exedir" ->
        if Array.length Sys.argv < (n+2) then
          usage();
        begin
          try
            exe_dir_opt := Some (Sys.argv.(n+1))
          with Failure _ ->
            usage()
        end;
        parse_options (n+2)
    | "-version" ->
        if Array.length Sys.argv < (n+2) then
          usage();
        begin
          try
            version := Sys.argv.(n+1)
          with Failure _ ->
            usage()
        end;
        parse_options (n+2)
    | "-speed" ->
        if Array.length Sys.argv < (n+2) then
          usage();
        begin
          try
	    let limit = int_of_string (Sys.argv.(n+1)) in
	    if limit <= 0 then
	      error "Error: The time limit for -speed should be positive\n";
            set_speed limit
          with Failure _ ->
            usage()
        end;
        parse_options (n+2)
    | "-fast" ->
        set_speed limit_fast;
        parse_options (n+1)
    | "-vfast" ->
        set_speed limit_very_fast;
        parse_options (n+1)
    | "-user" ->
        if Array.length Sys.argv < (n+2) then
          usage();
        begin
          try
            user := Sys.argv.(n+1)
          with Failure _ ->
            usage()
        end;
        parse_options (n+2)
    | "-simple" ->
        simple_check := true;
        parse_options (n+1)
    | "-stat" ->
        show_stat := true;
        parse_options (n+1)
    | "-hist" ->
	hist_loc := HistScript;
	parse_options (n+1)
    | "-histdir" ->
        if Array.length Sys.argv < (n+2) then
          usage();
	hist_loc := HistDir (Sys.argv.(n+1));
	parse_options (n+2)
    | "-progopt" ->
        let rec aux accu n =
          if Array.length Sys.argv < (n+1) then
            usage();
          match Sys.argv.(n) with
          | "-endprogopt" ->
              additional_options := List.rev accu;
              parse_options (n+1)
          | s -> aux (s::accu) (n+1)
        in
        aux [] (n+1)
    | _ -> n
  in
  let n = parse_options 1 in
  try 
    if Array.length Sys.argv < (n+6) then
      usage();
    let config =
      match Sys.argv.(n) with
      | "CV" -> cv_config ~user_tag:!user ~version_tag:!version 
      | "PV" -> pv_config ~user_tag:!user ~version_tag:!version
      | _ -> usage()
    in
    let mode =
      match Sys.argv.(n+1) with
      | "test" -> Test
      | "test_add" -> TestAdd
      | "add" -> Add
      | "update" -> Update
      | "reset" -> Reset
      | _ -> usage()
    in
    tmpdir := Sys.argv.(n+2);
    let prefix = Sys.argv.(n+3) in
    match Sys.argv.(n+4) with
    | "dirs" ->
        let files = open_files prefix in
        for i = n+5 to Array.length Sys.argv-1 do
          let s = Sys.argv.(i) in
          if is_directory s then
            List.iter (fun dirname -> 
              analyze_dir config mode dirname files None
            ) (retrieve_main_dirs config s)
        done;
        close_files files
    | "file" ->
        if Array.length Sys.argv <> n+7 then
          usage();
        let files = open_files prefix in
        analyze_dir config mode Sys.argv.(n+5) files (Some (Sys.argv.(n+6)));
        close_files files
    | _ ->
        usage()
  with
   | Unix.Unix_error(e, fct, arg) ->
      error ("Error: "^(Unix.error_message e)^", found in fct "^fct^
        (if arg = "" then "\n" else "("^arg^", ...)\n"))
   | Sys_error s ->
      error ("Error: "^s^"\n")
   | e -> 
      error ("Error: "^(Printexc.to_string e)^"\n")
