This directory contains examples for the translation from
CryptoVerif assumptions to EasyCrypt.

- To generate the EasyCrypt files, run `make ec`. The files are put
  in directory `generated`.

- To check the generated files / proofs, you can you run `make
  test-$x` where $x can take the following values:

    - common: check the core EasyCrypt files located in common/

    - generated: check the generated files located in generated/

    - proofs: check the proofs located in proofs/

    - proofs-fast: same as `proofs` with the exception of GDH_RSR.
      (The checking time of this example is very long)

    - all: common+generated+proofs

    - all-fast: common+generated+proofs-fast

  The proofs have been verified with EasyCrypt release 2026.05 [1] that was
  configured with the 4 following provers:

    - Alt-Ergo@2.6.0
    - Z3@4.13.3
    - CVC4@1.8
    - CVC5@1.1.2

  using Why3@1.8.2
  
[1] https://github.com/EasyCrypt/easycrypt.git#r2026.05
To install that version of EasyCrypt, follow the instructions at
https://github.com/EasyCrypt/easycrypt
using opam with the command:
opam pin -yn add easycrypt https://github.com/EasyCrypt/easycrypt.git#r2026.05


