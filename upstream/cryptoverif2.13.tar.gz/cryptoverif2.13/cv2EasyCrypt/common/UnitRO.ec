(*************************************************************
 *                                                           *
 *       Translation from CryptoVerif to EasyCrypt           *
 *                                                           *
 *       Bruno Blanchet, Pierre Boutry, Christian Doczkal,   *
 *       and Pierre-Yves Strub                               *
 *                                                           *
 *       Copyright INRIA, MPI-SP, Ecole Polytechnique,       *
 *	 2019-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA, MPI-SP, Ecole Polytechnique
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Pierre Boutry, Pierre.Boutry@inria.fr
                  Christian Doczkal, Christian.Doczkal@mpi-sp.org
                  Pierre-Yves Strub, pierre-yves@strub.nu

This software is a computer program whose purpose is to translate
CryptoVerif security assumptions into EasyCrypt.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
require import AllCore List Distr FinType PROM FMap.

clone FinType.FinType as UnitFinType with
  type t = unit,
  op enum = [tt]
  proof*.
realize enum_spec by case.

abstract theory UnitRO.
clone include FullRO with
  type in_t <- unit.

clone include FinEager with
  theory FinFrom <- UnitFinType
  proof*.

module ERO : RO = {
  var m : out_t

  proc init () = {
    m <$ dout ();
  }

  proc get() = {
    return m;
  }

  proc set(x : unit, y : out_t) = {
    m <- y;
  }

  proc sample(x : unit) = { }

  proc rem(x : unit) = { }
}.

section.
declare axiom dout_ll x: is_lossless (dout x).

declare module D <: FinRO_Distinguisher{-RO, -FRO, -ERO}.

local equiv RO_ERO_init : FinRO.init ~ ERO.init :
  true ==> RO.m{1}.[tt] = Some ERO.m{2}.
proof.
proc; inline*.
rcondt{1} 3; 1: by auto.
rcondt{1} 6; 1: by auto; smt(mem_empty).
rcondf{1} 8; 1: by auto.
auto; move => _ _ _ /=.
by case ((head witness UnitFinType.enum)); smt(get_setE).
qed.

equiv Unit_RO_ERO : MainD(D,RO).distinguish ~ MainD(D,ERO).distinguish :
  ={glob D, arg} ==> ={res, glob D}.
proof.
transitivity MainD(D,FinRO).distinguish
  (={glob D, arg} ==> ={res, glob D}) (={glob D, arg} ==> ={res, glob D}) => //.
  - move => &1 &2 [A B]; exists (glob D){2} x{2}; smt().
  - by proc*; call (RO_FinRO_D _ D) => //; exact: dout_ll.
proc.
call (: RO.m{1}.[tt] = Some ERO.m{2}).
- by proc*; call RO_ERO_init; auto.
- proc; auto; smt().
- proc; auto. move => &1 &2 />; case (x{1}); smt(get_setE).
- proc; auto.
- by call RO_ERO_init; auto.
qed.

end section.

end UnitRO.
