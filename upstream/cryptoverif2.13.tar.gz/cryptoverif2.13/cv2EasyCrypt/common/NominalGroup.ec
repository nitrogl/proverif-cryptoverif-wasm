(*************************************************************
 *                                                           *
 *       Translation from CryptoVerif to EasyCrypt           *
 *                                                           *
 *       Bruno Blanchet, Pierre Boutry, Christian Doczkal,   *
 *       and Pierre-Yves Strub                               *
 *                                                           *
 *       Copyright INRIA, MPI-SP, Ecole Polytechnique,       *
 *	 2019-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA, MPI-SP, Ecole Polytechnique
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Pierre Boutry, Pierre.Boutry@inria.fr
                  Christian Doczkal, Christian.Doczkal@mpi-sp.org
                  Pierre-Yves Strub, pierre-yves@strub.nu

This software is a computer program whose purpose is to translate
CryptoVerif security assumptions into EasyCrypt.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
(* -------------------------------------------------------------------- *)
require import AllCore Distr List IntMin IntDiv.
require import FinType FSet.
require (*--*) Ring Number StdOrder ZModP.

import Ring.IntID StdOrder.IntOrder.

(* -------------------------------------------------------------------- *)

op injective_on (A : 'a fset) (f : 'a -> 'b) : bool =
  forall (x y : 'a), x \in A => y \in A => f x = f y => x = y.

abstract theory NominalGroup.

type G.
type Z.

(*
clone include FinType
  with type t <- G
  rename "card" as "order"
  rename "enum" as "elems".
*)

op f     : Z.
op g     : G.
op ( ^ ) : G -> Z -> G.
op ( * ) : Z -> Z -> Z.
op inv   : Z -> Z.

op exp (a, x) = a ^ (x * inv f).

op EU : Z fset.
op dZ : Z distr.

op e : Z.
axiom e_EU : e \in EU.

axiom dZ_ll : is_lossless dZ.
hint exact random : dZ_ll.

axiom mulA       : associative ( * ).
axiom mulC       : commutative ( * ).

axiom powM       : forall a x y, a ^ (x * y) = (a ^ x) ^ y.
axiom pow_inv    : forall x, x \in EU \/ x = f => g ^ (x * inv x) = g.

axiom exp_inj    : injective_on EU (exp g).
axiom exp_inj'   : forall x, x \in EU =>
                             injective_on EU (fun z => exp g (x * z)).

axiom img_exp    : forall x, x \in EU =>
                             image (fun z => exp g (x * z)) EU =
                             image (exp g) EU.

lemma expM a x y : exp a (x * y) = (exp a x) ^ y.
proof. by rewrite /exp -!powM -!mulA (mulC y). qed.

lemma exp_inv x y : x \in EU => exp g (x * inv x * y) = exp g y.
proof.
move => x_EU; rewrite /exp.
have -> : x * inv x * y * inv f = (x * inv x) * (y * inv f) by smt(mulA mulC).
by smt(powM pow_inv).
qed.

end NominalGroup.
