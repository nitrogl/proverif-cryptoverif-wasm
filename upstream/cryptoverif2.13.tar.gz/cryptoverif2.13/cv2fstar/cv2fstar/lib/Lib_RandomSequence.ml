(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Cryptokit

let my_rng =
  try
    Random.hardware_rng ()
  with Error No_entropy_source ->
    Random.secure_rng
  
type entropy = int

let uint8s_to_bytes s =
  let b = Bytes.create (List.length s) in
  List.iteri (fun i c -> Bytes.set b i (Char.chr c)) s;
  b

let uint8s_from_bytes: bytes -> (FStar_UInt8.t, unit) Lib_Sequence.lseq =
  fun s ->
  let rec exp i l =
    if i < 0 then l else exp (i - 1) ((Char.code (Bytes.get s i)) :: l) in
  FStar_Seq_Base.seq_of_list (exp (Bytes.length s - 1) [])

let entropy0 = 0

let crypto_random : entropy -> Prims.int -> (entropy * (FStar_UInt8.t, unit) Lib_Sequence.lseq) =
  fun _ ->
    fun len ->
      let buf = Bytes.create (Z.to_int len) in
      my_rng#random_bytes buf 0 (Z.to_int len);
      0,(uint8s_from_bytes buf)


let unsound_crypto_random1 : Prims.int -> (FStar_UInt8.t, unit) Lib_Sequence.lseq
                                  FStar_Pervasives_Native.option =
  fun len ->
    let buf = Bytes.create (Z.to_int len) in
    my_rng#random_bytes buf 0 (Z.to_int len);
    FStar_Pervasives_Native.Some (uint8s_from_bytes buf)

let unsound_crypto_random2 : Prims.int -> (FStar_UInt8.t, unit) Lib_Sequence.lseq =
  fun len ->
    let buf = Bytes.create (Z.to_int len) in
    my_rng#random_bytes buf 0 (Z.to_int len);
    (uint8s_from_bytes buf)
