(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module State

open CVTypes
open Random
open FStar.Ghost

module Map = SidMap
module Set = FStar.Set

(* Preliminary declarations for sessions *)

noeq
type session_type =
  (* oracle name *)
  (* session state entry *)
  (* following_oracles *)
  (* session_entry_to_name *)
  | SessionType : on: eqtype -> se: Type0 -> fo: (on -> list on) -> se2on: (se -> on)
    -> session_type

let oracle_name (st: session_type) = match st with | SessionType on _ _ _ -> on

let session_entry (st: session_type) = match st with | SessionType _ se _ _ -> se

let is_valid_entry (#st: session_type) (on: oracle_name st) (se: session_entry st) =
  match st with | SessionType _ _ _ se2on -> (se2on se = on)

let is_valid_next_entry (#st: session_type) (on: oracle_name st) (se: session_entry st) =
  match st with
  | SessionType _ _ fo se2on ->
    let nsn = se2on se in
    FStar.List.Tot.Base.mem nsn (fo on)

let session_entry_to_name (#st: session_type) (se: session_entry st) : oracle_name st =
  match st with | SessionType _ _ _ se2on -> se2on se

val sessions (st: session_type) : Type0
let sessions (st: session_type) = m:Map.t (list (session_entry st)){Map.inv m}

val init_sessions (st: session_type) : sessions st
let init_sessions st = Map.lem_empty #(list (session_entry st)) []; Map.empty []

// each protocol instantiates this type and uses it with state
noeq
type state_type =
  { tt: Type0; 
    tt_init: tt;
    local_tt: Type0;
    vt: Type0; 
    vt_init: vt;
    st: session_type;
    cv_event_type: Type0;
    fs_event_type: Type0;
    debug: bool }

let tt_of (stt: state_type) : Type0 = stt.tt

let tt_init_of (stt: state_type) : (tt_of stt) = stt.tt_init

let local_tt_of (stt: state_type) : Type0 = stt.local_tt

let vt_of (stt: state_type) : Type0 = stt.vt

let vt_init_of (stt: state_type) : (vt_of stt) = stt.vt_init

let st_of (stt: state_type) : session_type = stt.st

let cvet_of (stt: state_type) : Type0 = stt.cv_event_type

let fsev_of (stt: state_type) : Type0 = stt.fs_event_type

let db_of (stt: state_type) : bool = stt.debug

(* Erase if not debug *)

let opt_erased (stt: state_type) (ty: Type0) : Type0 =
  if db_of stt then ty else Ghost.erased ty

let opt_hide (stt: state_type) (#ty: Type0) (v: ty) : opt_erased stt ty =
  if db_of stt then v else Ghost.hide v

let opt_reveal (stt: state_type) (#ty: Type0) (v: opt_erased stt ty) : GTot ty =
  if db_of stt then v else Ghost.reveal v

noeq
type event_type (stt: state_type) =
  | CVEvent: cvet_of stt -> event_type stt
  | FStarEvent: fsev_of stt -> event_type stt

noeq
type _state (stt: state_type) =
  { ent: entropy;
    tabs: tt_of stt;
    local_tabs: FStar.Map.t Map.sidt (list (local_tt_of stt));
    vars: vt_of stt;
    sessions: sessions (st_of stt);
    events: opt_erased stt (list (event_type stt));
    local: erased (Set.set Map.sidt) }

type state (stt: state_type) = (st: _state stt { (forall sid. Set.mem sid st.local ==> ~ (Map.available st.sessions sid)) })

val entropy_of: #stt: state_type -> state stt -> entropy
let entropy_of st = st.ent

val tables_of: #stt: state_type -> state stt -> tt_of stt
let tables_of st = st.tabs

val local_tables_of: #stt: state_type -> state stt -> FStar.Map.t Map.sidt (list (local_tt_of stt))
let local_tables_of st = st.local_tabs

val variables_of: #stt: state_type -> state stt -> vt_of stt
let variables_of st = st.vars

val sessions_of: #stt: state_type -> state stt -> sessions (st_of stt)
let sessions_of st = st.sessions

val events_of: #stt: state_type -> state stt -> GTot (list (event_type stt))
let events_of #stt st = opt_reveal stt st.events

val local_of: #stt: state_type -> state stt -> GTot (Set.set Map.sidt)
let local_of st = st.local

val is_init_state (#stt: state_type) (s0: state stt): prop
let is_init_state #stt s0 =
  sessions_of s0 == init_sessions (st_of stt) /\
  events_of s0 == [] /\
  tables_of s0 == tt_init_of stt /\
  FStar.Map.has_dom (local_tables_of s0) (Set.empty #SidMap.sidt) /\
  variables_of s0 == vt_init_of stt /\
  local_of s0 == Set.empty #SidMap.sidt

(* Sessions *)

val get_session_entry (#stt: state_type) (st: state stt) (on: oracle_name (st_of stt)) (id: Map.sidt)
    : Tot (option (s: (session_entry (st_of stt)){is_valid_entry on s}))

let get_session_entry #stt st sn id =
  let seso = Map.get (sessions_of st) id in
  match seso with
  | None -> None
  | Some ses -> List.Tot.find (is_valid_entry sn) ses


val get_and_remove_session_entry
      (#stt: state_type)
      (st: state stt)
      (on: oracle_name (st_of stt))
      (id: Map.sidt)
    : Tot (state stt * option (s: (session_entry (st_of stt)){is_valid_entry on s}))

let get_and_remove_session_entry #stt st sn id =
  let seso = Map.get (sessions_of st) id in
  match seso with
  | None -> st, None
  | Some ses ->
      let seo = List.Tot.find (is_valid_entry sn) ses in
      // construct a list without the entry
      let ses_new = List.Tot.filter (fun se -> not (is_valid_entry sn se)) ses in
      let m = Map.upd (sessions_of st) id ses_new in
      { st with sessions = m }, seo

val state_reserve_session_id (#stt: state_type) (st0: state stt) : state stt * Map.sidt

let state_reserve_session_id st0 =
  let m = sessions_of st0 in
  let id, m = Map.reserve m in
  { st0 with sessions = m; local = Set.add id (local_of st0) }, id

val state_add_to_session
      (#stt: state_type)
      (st0: state stt)
      (id: Map.sidt{ ~(Map.available (sessions_of st0) id) } )
      (ses: list (session_entry (st_of stt)))
    : Tot (state stt)

let state_add_to_session st id ses =
  let m = sessions_of st in
  match Map.get m id with
  | None ->
    let m = Map.upd m id ses in
    { st with sessions = m }
  | Some old_ses ->
    let new_ses = List.Tot.append old_ses ses in
    let m = Map.upd m id new_ses in
    { st with sessions = m }

(* There is no way to iterate over all keys on which the map is defined,
   so we require the caller to tell us which session id they want. *)
val print_session
      (#stt: state_type)
      (st: state stt)
      (pe: (session_entry (st_of stt) -> FStar.All.ML unit))
      (id: Map.sidt)
    : FStar.All.ML unit

let print_session st print_entry id =
  Map.print_sid id;
  IO.print_string ".";
  let seso = Map.get (sessions_of st) id in
  match seso with
  | None
  | Some [] ->
    IO.print_string "session does not exist";
    IO.print_newline ()
  | Some ses -> List.iter (fun se -> print_entry se) ses

(* Entropy *)

val call_with_entropy: #stt: state_type -> #a: Type -> st0: state stt -> (entropy -> entropy * a)
  -> state stt * a

let call_with_entropy st0 f =
  let ent0 = entropy_of st0 in
  let ent1, res = f ent0 in
  { st0 with ent = ent1 }, res

(* For tables and variables *)

noeq
type accessor (r: Type0) (tv: Type0) =
  { get: r -> tv; set: r -> tv -> r }

(* Tables *)

// Abbreviations:
// tt: table type
// tn: table name
// tns: table names
// te: table entry

val table (t: Type0) : Type0
let table t = list t

val table_empty (t: Type0) : table t
let table_empty t = []

type table_name (r: Type0) (te: Type0) = accessor r (table te)

noeq
type local_table_name (d: Type0) (te: Type0) =
  { local_get: d -> option (table te); local_set: table te -> d }

let return_table (#stt: state_type) (#te: Type0) (st: state stt) (tn: table_name (tt_of stt) te) : table te =
  tn.get (tables_of st)

let return_local_table (#stt: state_type) (#te: Type0) (st: state stt) (id: Map.sidt) (tn: local_table_name (local_tt_of stt) te) : table te =
    let loc_tbl = local_tables_of st in
    if FStar.Map.contains loc_tbl id then
      let l = FStar.Map.sel loc_tbl id in
      match List.Tot.tryPick tn.local_get l with
      | None -> []
      | Some tbl -> tbl
    else
      []

type table_filter_simple (te: Type0) (rt: Type0) =
   te -> option rt

type table_filter_full (stt: state_type) (te: Type0) (rt: Type0) =
   state stt -> te -> state stt * option rt

noeq
type table_filter (stt: state_type) (te: Type0) (rt: Type0) =
  | TableFilterSimple : table_filter_simple te rt -> table_filter stt te rt
  | TableFilterFull : table_filter_full stt te rt -> table_filter stt te rt

val insert:
    #stt: state_type -> #te: Type0 ->
    st0: state stt ->
    tn: table_name (tt_of stt) te ->
    te
  -> state stt

let insert #stt st tn te =
  let tab = return_table st tn in
  let new_tab = te :: tab in
  { st with tabs = tn.set (tables_of st) new_tab }

val local_insert:
    #stt: state_type -> #te: Type0 ->
    st0: state stt ->
    i: Map.sidt ->
    tn: local_table_name (local_tt_of stt) te ->
    te
  -> state stt

let local_insert #stt st i tn te =
  let loc_tbl = local_tables_of st in
  if FStar.Map.contains loc_tbl i then
      let l = FStar.Map.sel loc_tbl i in
      let tab =
        match List.Tot.tryPick tn.local_get l with
        | None -> []
        | Some tbl -> tbl
      in
      let new_tab = te :: tab in
      { st with local_tabs = FStar.Map.upd loc_tbl i
        ((tn.local_set new_tab) ::
	 List.Tot.filter (fun t ->
	   match tn.local_get t with
	   | None -> true
	   | Some _ -> false) l) }
  else
      { st with local_tabs = FStar.Map.upd loc_tbl i [tn.local_set [te]] }

val get_inner_simple
      (#te: Type0)
      (#rt: Type0)
      (matches: Seq.seq rt)
      (tab: table te)
      (filter: table_filter_simple te rt)
    : Tot (Seq.seq rt) (decreases tab)

let rec get_inner_simple matches tab f =
  match tab with
  | [] -> matches
  | x :: r ->
    match f x with
    | Some e -> get_inner_simple (Seq.cons e matches) r f
    | None -> get_inner_simple matches r f

val get_inner_full
      (#stt: state_type) (#te: Type0)
      (#rt: Type0)
      (st0: state stt)
      (matches: Seq.seq rt)
      (tab: table te)
      (filter: table_filter_full stt te rt)
    : Tot (state stt * Seq.seq rt)
      (decreases tab)

let rec get_inner_full st matches tab f =
  match tab with
  | [] -> st, matches
  | x :: r ->
    match f st x with
    | st, Some e -> get_inner_full st (Seq.cons e matches) r f
    | st, None -> get_inner_full st matches r f

val get:
    #stt: state_type -> #te: Type0 ->
    #rt: Type0 ->
    st0: state stt ->
    tab: table te ->
    table_filter stt te rt
  -> state stt * option rt

let get #stt st tab tf =
  let st, matches =
    (match tf with
      | TableFilterSimple f -> st, get_inner_simple Seq.empty tab f
      | TableFilterFull f -> get_inner_full st Seq.empty tab f)
  in
  match Seq.length matches with
  | 0 -> st, None
  | 1 -> st, Some (Seq.head matches)
  | _ ->
    let st, rand_i = call_with_entropy st (gen_nat (Seq.length matches - 1)) in
    st, Some (Seq.index matches rand_i)

val get_unique
      (#te: Type0)
      (#rt: Type0)
      (tab: table te)
      (filter: table_filter_simple te rt)
    : Tot (option rt) (decreases tab)

let rec get_unique tab f =
  match tab with
  | [] -> None
  | x :: r ->
    match f x with
    | Some e -> Some e
    | None -> get_unique r f

val get_unique_full
      (#stt: state_type) (#te: Type0)
      (#rt: Type0)
      (st0: state stt)
      (tab: table te)
      (filter: table_filter_full stt te rt)
    : Tot (state stt * option rt)
      (decreases tab)

let rec get_unique_full st tab f =
  match tab with
  | [] -> st, None
  | x :: r ->
    match f st x with
    | st, Some e -> st, Some e
    | st, None -> get_unique_full st r f

(* if on the CV side we do not use the entry but only its existence *)
val entry_exists_full:
    #stt: state_type -> #te: Type0 ->
    #rt: Type0 ->
    st0: state stt ->
    tab: table te ->
    table_filter_full stt te rt
  -> state stt * bool

let entry_exists_full st tab f =
  match get_unique_full st tab f with
  | st, None -> st, false
  | st, Some _ -> st, true

val entry_exists:
    #te: Type0 ->
    #rt: Type0 ->
    tab: table te ->
    table_filter_simple te rt
  -> bool

let entry_exists tab f =
  match get_unique tab f with
  | None -> false
  | Some _ -> true

val print_table:
    #stt: state_type -> #te: Type0 ->
    state stt ->
    tn: table_name (tt_of stt) te ->
    tns: string ->
    (te -> FStar.All.ML unit)
  -> FStar.All.ML unit

let print_table #stt st tn tns print_entry =
  let tab = return_table st tn in
  IO.print_string (tns ^ " [");
  IO.print_newline ();
  List.iter print_entry tab;
  IO.print_string "]";
  IO.print_newline ();
  IO.print_newline ()

(* Variables *)

val var (t: Type0) : Type0
let var t = FStar.PartialMap.t Map.sidt t

val var_empty (t: Type0) : var t
let var_empty t = FStar.PartialMap.empty Map.sidt t

type var_name (r: Type0) (te: Type0) = accessor r (var te)

val var_bool_set : (#stt: state_type) -> state stt -> (accessor (vt_of stt) bool) -> state stt
let var_bool_set st vn =
  { st with vars = vn.set (variables_of st) true }

val var_def (#stt: state_type) (#t: Type0) (st: state stt) (vn: var_name (vt_of stt) t) (idx: Map.sidt) (v: t) : state stt
let var_def st vn idx v =
  let vars = variables_of st in
  { st with vars = vn.set vars (FStar.PartialMap.upd (vn.get vars) idx v) }

val var_bool_get : (#stt: state_type) -> state stt -> (accessor (vt_of stt) bool) -> bool
let var_bool_get st vn =
  vn.get (variables_of st)

val var_get (#stt: state_type) (#t: Type0) (st: state stt) (vn: var_name (vt_of stt) t) (idx:Map.sidt) : option t
let var_get st vn idx =
  let m = vn.get (variables_of st) in
  FStar.PartialMap.sel m idx

val indist_real (#stt: state_type) (#t: Type0) (st: state stt) (vn: var_name (vt_of stt) t) (idx:Map.sidt) : state stt * option t
let indist_real st vn idx =
  (st, var_get st vn idx)

val indist_ideal (#stt: state_type) (#t: Type0) (st: state stt) (vn: var_name (vt_of stt) t) (vnqueried: var_name (vt_of stt) t) (rand: entropy -> entropy * t) (idx:Map.sidt) : state stt * option t
let indist_ideal st vn vnqueried rand idx =
  match var_get st vn idx with
  | None -> (st, None)
  | Some _ ->
      match var_get st vnqueried idx with
      | Some v -> (st, Some v)
      | None ->
          let (st', v) = call_with_entropy st rand in
          let st'' = var_def st' vnqueried idx v in
          (st'', Some v)

val indist_one_session_real (#stt: state_type) (#t: Type0) (st: state stt) (vn: var_name (vt_of stt) t) (vnqueried: accessor (vt_of stt) bool) (idx:Map.sidt) : state stt * option t
let indist_one_session_real st vn vnqueried idx =
  if var_bool_get st vnqueried then
    (* already queried *) (st, None)
  else
    let st' = var_bool_set st vnqueried in
    (st', var_get st' vn idx)

val indist_one_session_ideal (#stt: state_type) (#t: Type0) (st: state stt) (vn: var_name (vt_of stt) t) (vnqueried: accessor (vt_of stt) bool) (rand: entropy -> entropy * t) (idx:Map.sidt) : state stt * option t
let indist_one_session_ideal st vn vnqueried rand idx =
  if var_bool_get st vnqueried then
    (* already queried *) (st, None)
  else
    let st' = var_bool_set st vnqueried in
    match var_get st' vn idx with
    | Some _ ->
        let (st'', v) = call_with_entropy st' rand in
        (st'', Some v)
    | None -> (st', None)

val reach_reveal (#stt: state_type) (#t: Type0) (st: state stt) (vn: var_name (vt_of stt) t) (vnqueried: var_name (vt_of stt) unit) (idx: Map.sidt) : state stt * option t
let reach_reveal st vn vnqueried idx =
  match var_get st vn idx with
  | None -> (st, None)
  | Some v ->
      let st' = var_def st vnqueried idx () in
      (st', Some v)

val reach_test (#stt: state_type) (#t: Type0) (st: state stt) (vn: var_name (vt_of stt) t) (vnqueried: var_name (vt_of stt) unit) (idx: Map.sidt) : option t
let reach_test st vn vnqueried idx =
  match var_get st vnqueried idx with
  | Some _ -> (* already revealed *) None
  | None -> var_get st vn idx

(* Events *)

val state_add_event (#stt: state_type) (st: state stt) (ev: event_type stt) : Tot (state stt)
let state_add_event #stt st ev =
  if db_of stt then
    { st with events = List.append st.events [ev] }
  else
    { st with events = Ghost.bind st.events (fun l -> Ghost.hide (List.append l [ev])) }

let state_add_event_lemma (#stt: state_type) (st: state stt) (ev: event_type stt):
  Lemma (
      let r = state_add_event #stt st ev in
      (sessions_of r == sessions_of st) /\
   (local_of r == local_of st) /\
   (tables_of r == tables_of st) /\
   (local_tables_of r == local_tables_of st) /\
   (variables_of r == variables_of st) /\
   (events_of r == List.append (events_of st) [ev])
  ) = ()

val print_events (#stt: state_type) (st: state stt) 
  (cvpe: (cvet_of stt -> FStar.All.ML unit)) 
  (fspe: (fsev_of stt -> FStar.All.ML unit))
    : FStar.All.ML unit
let print_events #stt st cvpe fspe =
  if db_of stt then
    begin
      IO.print_string "Events: [\n";
      List.iter (fun e -> match e with
        | CVEvent e -> cvpe e
        | FStarEvent e -> fspe e) st.events;
      IO.print_string "]"
    end
  else
    IO.print_string "Events can be printed only in debug mode"

(* Local *)

val is_local: #stt: state_type -> Map.sidt -> state stt -> GTot bool
let is_local sid st = Set.mem sid (local_of st)

val is_session: #stt: state_type -> Map.sidt -> state stt -> bool
let is_session sid st = not (Map.available (sessions_of st) sid)

val non_local: #stt: state_type -> Map.sidt -> state stt -> GTot bool
let non_local sid st = is_session sid st && not (is_local sid st)

val remove_local: #stt: state_type -> state stt -> state stt
let remove_local st = { st with local = Set.empty #Map.sidt }

let is_session_inv #stt st sid = is_session #stt sid st

val inverse_local: #stt: state_type -> state stt -> state stt
let inverse_local #stt st = 
  let st' = { st with local = Set.intersect
    (Set.intension (is_session_inv #stt st))
    (Set.complement (local_of st)) }
  in
  let aux sid : Lemma (requires (Set.mem sid st'.local)) (ensures (is_session sid st)) = 
    Set.mem_intersect sid (Set.intension (is_session_inv st)) (Set.complement (local_of st));
    Set.mem_intension sid (is_session_inv st)
  in
  Classical.forall_intro (Classical.move_requires aux);
  st'

let lemma_inverse_local_involution (#stt: state_type) (st: state stt):
  Lemma (ensures (inverse_local (inverse_local st) == st)) =
  let aux (sid: SidMap.sidt) : Lemma
    (ensures (Set.mem sid (local_of (inverse_local (inverse_local st))) == Set.mem sid (local_of st))) =
    let st' = inverse_local st in
    Set.mem_intersect sid (Set.intension (is_session_inv st')) (Set.complement (local_of st'));
    Set.mem_complement sid (local_of st');
    Set.mem_intension sid (is_session_inv st');
    Set.mem_intersect sid (Set.intension (is_session_inv st)) (Set.complement (local_of st));
    Set.mem_complement sid (local_of st);
    Set.mem_intension sid (is_session_inv st)
  in
  Classical.forall_intro aux;
  assert (Set.equal (local_of (inverse_local (inverse_local st))) (local_of st))

let local_inverse_aux (#stt: state_type) (s0: state stt) (sid: Map.sidt):
  Lemma (is_local sid s0 <==> non_local sid (inverse_local s0)) =
    Set.mem_intersect sid (Set.intension (is_session_inv s0)) (Set.complement (local_of s0));
    Set.mem_complement sid (local_of s0);
    Set.mem_intension sid (is_session_inv s0)
  
let local_inverse (#stt: state_type) (s0: state stt):
  Lemma (forall (sid: Map.sidt). is_local sid s0 <==> non_local sid (inverse_local s0)) = 
  Classical.forall_intro (local_inverse_aux s0)

let local_inverse' (#stt: state_type) (s0: state stt):
  Lemma (forall (sid: Map.sidt). is_local sid (inverse_local s0) <==> non_local sid s0) = 
  local_inverse (inverse_local s0);
  lemma_inverse_local_involution s0

let sessions_included (#stt: state_type) (s0 s1: state stt) = 
  FStar.Set.subset (local_of s0) (local_of s1) /\
  (forall (x: Map.sidt). non_local x s0 ==> non_local x s1) /\
  (forall (x: Map.sidt). is_session x s0 ==> is_session x s1)

let lemma_sessions_included_inverse_local (#stt: state_type) (s0 s1: state stt) :
  Lemma (requires (sessions_included (inverse_local s0) (inverse_local s1)))
    (ensures (sessions_included s0 s1)) =
  local_inverse s0;
  local_inverse' s0;
  local_inverse s1;
  local_inverse' s1

let non_local_sessions_are_equal (#stt: state_type) (s0 s1: state stt) =
  (forall (sid: Map.sidt). non_local sid s0 <==> non_local sid s1) /\
  (forall (sid: Map.sidt). non_local sid s0 ==> 
    (Map.get (sessions_of s0) sid == Map.get (sessions_of s1) sid /\
    (FStar.Map.sel (local_tables_of s0) sid == FStar.Map.sel (local_tables_of s1) sid)))

let local_sessions_are_equal (#stt: state_type) (s0 s1: state stt) =
  local_of s0 == local_of s1 /\
  forall (sid: Map.sidt). is_local sid s0 ==> 
    (Map.get (sessions_of s0) sid == Map.get (sessions_of s1) sid /\
    (FStar.Map.sel (local_tables_of s0) sid == FStar.Map.sel (local_tables_of s1) sid))

let lemma_non_local_inverse_local  (#stt: state_type) (s0 s1: state stt):
  Lemma (requires (non_local_sessions_are_equal (inverse_local s0) (inverse_local s1)))
    (ensures (local_sessions_are_equal s0 s1)) 
    [SMTPat (non_local_sessions_are_equal (inverse_local s0) (inverse_local s1))] =
   local_inverse s0;
   local_inverse s1;
   assert (Set.equal (local_of s0) (local_of s1))
      
(* Init and finalize state *)

val init_state: stt: state_type -> Lib.RandomSequence.entropy -> state stt
let init_state stt ent =
  { ent = ent;
    tabs = tt_init_of stt;
    local_tabs = FStar.Map.restrict Set.empty (FStar.Map.const []);
    vars = vt_init_of stt;
    sessions = init_sessions (st_of stt);
    events = opt_hide stt [];
    local = Set.empty #Map.sidt }

val finalize_state: #stt: state_type -> state stt -> Lib.RandomSequence.entropy
let finalize_state state = entropy_of state

(* Remove a session from the state *)

val remove_session: #stt: state_type -> state stt -> Map.sidt -> state stt
let remove_session #stt state n =
  { state with
    local_tabs = FStar.Map.restrict (Set.complement (Set.singleton n)) state.local_tabs;
    sessions = Map.remove state.sessions n }
