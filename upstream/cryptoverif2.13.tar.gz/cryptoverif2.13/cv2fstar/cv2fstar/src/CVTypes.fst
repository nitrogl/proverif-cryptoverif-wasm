(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module CVTypes

open Lib.IntTypes
module B = Lib.ByteSequence
open Lib.Sequence
open Lib.PrintSequence

(* Equality *)

#push-options "--fuel 1 --ifuel 1 --z3rlimit 100"
let rec _eq_bytes (blocks_left blocks_right: FStar.Seq.seq uint8)
    : Pure bool
      (requires
        FStar.Seq.length blocks_left = FStar.Seq.length blocks_right /\
        FStar.Seq.length blocks_left >= Lib.IntTypes.max_size_t)
      (ensures fun b -> b = true <==> blocks_left == blocks_right)
      (decreases (FStar.Seq.length blocks_left)) =
  let block_left, rem_left = Lib.UpdateMulti.split_block Lib.IntTypes.max_size_t blocks_left 1 in
  let block_right, rem_right = Lib.UpdateMulti.split_block Lib.IntTypes.max_size_t blocks_right 1 in
  assert (FStar.Seq.length block_left = FStar.Seq.length block_right);
  assert (FStar.Seq.length rem_left = FStar.Seq.length rem_right);
  let front = B.lbytes_eq #(Seq.length block_left) block_left block_right in
  if (FStar.Seq.length rem_left <= Lib.IntTypes.max_size_t)
  then front && B.lbytes_eq #(Seq.length rem_left) rem_left rem_right
  else front && _eq_bytes rem_left rem_right
#pop-options

let eq_bytes b1 b2 =
  if not (Seq.length b1 = Seq.length b2)
  then false
  else
    if (Seq.length b1 <= Lib.IntTypes.max_size_t)
    then B.lbytes_eq #(Seq.length b1) b1 b2
    else _eq_bytes b1 b2

let eq_obytes ob1 ob2 =
  match ob1, ob2 with
  | None, None -> true
  | Some b1, Some b2 -> eq_bytes b1 b2
  | _ -> false

let eq_lbytes #l b1 b2 = B.lbytes_eq #l b1 b2

(* Lemmas for Equality *)

let rec lemma__eq_bytes_is_equal
      (b1: bytes)
      (b2: bytes{Seq.length b1 = Seq.length b2 /\ Seq.length b1 >= Lib.IntTypes.max_size_t})
    : Lemma (ensures _eq_bytes b1 b2 <==> b2 == b1) (decreases Seq.length b1) =
  let block_left, rem_left = Lib.UpdateMulti.split_block Lib.IntTypes.max_size_t b1 1 in
  let block_right, rem_right = Lib.UpdateMulti.split_block Lib.IntTypes.max_size_t b2 1 in
  assert (FStar.Seq.length block_left = FStar.Seq.length block_right);
  assert (FStar.Seq.length rem_left = FStar.Seq.length rem_right);
  if Seq.length rem_left <= Lib.IntTypes.max_size_t
  then
    (* in this case we rely on the property of lbytes_eq *)
    ()
  else lemma__eq_bytes_is_equal rem_left rem_right

let lemma_eq_bytes_equal b1 b2 =
  if not (Seq.length b1 = Seq.length b2)
  then ()
  else if (Seq.length b1 <= Lib.IntTypes.max_size_t) then () else lemma__eq_bytes_is_equal b1 b2

let lemma_eq_obytes_equal b1 b2 = ()

(* Serialization *)

open FStar.Mul

val char4_of_int (n: uint32) : Tot (B.lbytes 4)
let char4_of_int n = B.uint_to_bytes_le n

val int_of_char4 (s: B.bytes) (i: nat{Seq.length s >= i + 4}) : Tot (uint32)
let int_of_char4 s i =
  let length_bytes = FStar.Seq.slice s i (i + 4) in
  B.uint_from_bytes_le length_bytes

let lemma_append_ok sapp s1 s2 buf pos =
  Seq.append_slices s1 s2

let lemma_append_too_short1 sapp s1 s2 buf pos =
  Seq.append_slices s1 s2

let lemma_append_too_short2 sapp s1 s2 buf pos =
  let l1 = Seq.length s1 in
  Seq.slice_slice buf pos (Seq.length buf) 0 l1;
  // Seq.slice buf pos (pos+l1) == Seq.slice (Seq.slice buf pos (Seq.length buf)) 0 l1
  Seq.slice_slice buf pos (Seq.length buf) l1 (Seq.length buf - pos);
  // Seq.slice buf (pos+l1) (Seq.length buf) == Seq.slice (Seq.slice buf pos (Seq.length buf)) l1 (Seq.length buf - pos)
  Seq.slice_slice sapp 0 (Seq.length buf - pos) 0 l1;
  // Seq.slice sapp 0 l1 == Seq.slice (Seq.slice sapp 0 (Seq.length buf - pos)) 0 l1
  Seq.slice_slice sapp 0 (Seq.length buf - pos) l1 (Seq.length buf - pos);
  // Seq.slice sapp l1 (Seq.length buf - pos) == Seq.slice (Seq.slice sapp 0 (Seq.length buf - pos)) l1 (Seq.length buf - pos)
  Seq.append_slices s1 s2;
  // Seq.slice sapp 0 l1 == s1
  // Seq.slice sapp l1 (Seq.length sapp) == s2
  Seq.slice_slice sapp l1 (Seq.length sapp) 0 (Seq.length buf - pos - l1)
  // Seq.slice (Seq.slice sapp l1 (Seq.length sapp)) 0 (Seq.length buf - pos - l1) == Seq.slice sapp l1 (Seq.length buf - pos)
  // so
  // Seq.slice buf (pos+l1) (Seq.length buf)
  // == Seq.slice (Seq.slice buf pos (Seq.length buf)) l1 (Seq.length buf - pos)
  // == Seq.slice (Seq.slice sapp 0 (Seq.length buf - pos)) l1 (Seq.length buf - pos)
  // == Seq.slice sapp l1 (Seq.length buf - pos)
  // == Seq.slice (Seq.slice sapp 1 (Seq.length sapp)) 0 (Seq.length buf - pos - 1)
  // == Seq.slice s2 0 (Seq.length buf - pos - l1)
  // hence
  // Seq.slice buf (pos+l1) (Seq.length buf) == Seq.slice s2 0 (Seq.length buf - pos - l1)

let lemma_append_rev s1 s2 buf pos =
  let l1 = Seq.length s1 in
  let l2 = Seq.length s2 in
  let pos' = pos + l1 + l2 in
  Seq.slice_slice buf pos pos' 0 l1;
  // Seq.slice buf pos (pos + l1) == Seq.slice (Seq.slice buf pos pos') 0 l1
  Seq.slice_slice buf pos pos' l1 (l1 + l2);
  // Seq.slice buf (pos + l1) pos' == Seq.slice (Seq.slice buf pos pos') l1 (l1 + l2)
  Seq.lemma_split (Seq.slice buf pos pos') l1

(* Serializer for bytes *)

val serialize_bytes_rec (b: bytes): Tot bytes (decreases (Seq.length b))
let rec serialize_bytes_rec b =
  let len = Seq.length b in
  if len < maxint U32 then
    Seq.append (char4_of_int (u32 len)) b
  else
    let fst, rem = Seq.split b (maxint U32 - 1) in
    Seq.append (Seq.append (char4_of_int (u32 (maxint U32))) fst) (serialize_bytes_rec rem)

val deserialize_bytes_rec (buf: bytes) (pos: nat { pos <= Seq.length buf }):
  Tot (r: deserialize_res bytes { deser_is_ok bytes buf pos r }) (decreases (Seq.length buf - pos))
let rec deserialize_bytes_rec buf pos =
  if Seq.length buf < pos + 4 then
    DSTooShort (pos + 4 - Seq.length buf)
  else
    let len = uint_v (int_of_char4 buf pos) in
    if len = maxint U32 then
    begin
      let len' = maxint U32 - 1 in
      if Seq.length buf < pos + 4 + len' then
        DSTooShort (pos + 4 + len' - Seq.length buf)
      else
        let fst = Seq.slice buf (pos + 4) (pos + 4 + len') in
	match deserialize_bytes_rec buf (pos + 4 + len') with
	| DSOk(rem, pos') ->
	    if Seq.length rem = 0 then
	      DSFailure
	    else 
	      DSOk(Seq.append fst rem, pos')
	| DSTooShort l -> DSTooShort l
	| DSFailure -> DSFailure
    end  
    else
      if Seq.length buf < pos + 4 + len then
        DSTooShort (pos + 4 + len - Seq.length buf)
      else
        let fst = Seq.slice buf (pos + 4) (pos + 4 + len) in
        DSOk (fst, pos + 4 + len)

val lemma_deser_ok_bytes_rec (x: bytes)
  (buf: bytes) (pos: nat { pos <= Seq.length buf }) 
    : Lemma
        (requires (Seq.length buf >= pos + Seq.length (serialize_bytes_rec x) /\
	   Seq.slice buf pos (pos + Seq.length (serialize_bytes_rec x)) == serialize_bytes_rec x))
        (ensures (deserialize_bytes_rec buf pos == DSOk(x, pos + Seq.length (serialize_bytes_rec x))))
        (decreases (Seq.length buf - pos))      
let rec lemma_deser_ok_bytes_rec x buf pos =
  let len = Seq.length x in
  if len < maxint U32 then
    begin
      let ser = serialize_bytes_rec x in
      lemma_append_ok ser (char4_of_int (u32 len)) x buf pos;
      B.lemma_uint_to_from_bytes_le_preserves_value #U32 #SEC (u32 len)
    end
  else
    begin
      let len' = maxint U32 - 1 in
      let fstx, remx = Seq.split x len' in
      let fst = Seq.append (char4_of_int (u32 (maxint U32))) fstx in
      let ser = serialize_bytes_rec x in
      lemma_append_ok ser fst (serialize_bytes_rec remx) buf pos;
      lemma_append_ok fst (char4_of_int (u32 (maxint U32))) fstx buf pos;
      B.lemma_uint_to_from_bytes_le_preserves_value #U32 #SEC (u32 (maxint U32));
      lemma_deser_ok_bytes_rec remx buf (pos + 4 + len');
      Seq.lemma_split x len'
    end

val lemma_deser_too_short_bytes_rec (x: bytes)
  (buf: bytes) (pos: nat { pos <= Seq.length buf }) :
  Lemma (requires (Seq.length buf < pos + Seq.length (serialize_bytes_rec x) /\
                   Seq.slice buf pos (Seq.length buf) == Seq.slice (serialize_bytes_rec x) 0 (Seq.length buf - pos)))
    (ensures (match deserialize_bytes_rec buf pos with
              | DSTooShort n -> n <= pos + Seq.length (serialize_bytes_rec x) - Seq.length buf
	      | _ -> False))
    (decreases (Seq.length buf - pos))
let rec lemma_deser_too_short_bytes_rec x buf pos =
  if Seq.length buf < pos + 4 then
    ()
  else
    let ser = serialize_bytes_rec x in
    if Seq.length x >= maxint U32 then
    begin
      let len' = maxint U32 - 1 in
      let fst, rem = Seq.split x len' in
      let rem_seq = serialize_bytes_rec rem in
      let after_len = Seq.append fst rem_seq in
      Seq.append_assoc (char4_of_int (u32 (maxint U32))) fst rem_seq;
      lemma_append_too_short2 ser (char4_of_int (u32 (maxint U32))) after_len buf pos;
      B.lemma_uint_to_from_bytes_le_preserves_value #U32 #SEC (u32 (maxint U32));
      if Seq.length buf < pos + 4 + len' then
        ()
      else
        begin
          lemma_append_too_short2 after_len fst rem_seq buf (pos + 4);
	  lemma_deser_too_short_bytes_rec rem buf (pos + 4 + len')
	end
    end  
    else
    begin
      let len = Seq.length x in
      lemma_append_too_short2 ser (char4_of_int (u32 len)) x buf pos;
      B.lemma_uint_to_from_bytes_le_preserves_value #U32 #SEC (u32 len)
    end

val lemma_deser_rev_bytes_rec
  (buf: bytes) (pos: nat { pos <= Seq.length buf }) :
  Lemma
    (ensures (match deserialize_bytes_rec buf pos with
    | DSOk(x, end_pos) -> serialize_bytes_rec x == Seq.slice buf pos end_pos
    | _ -> True))
    (decreases (Seq.length buf - pos))
let rec lemma_deser_rev_bytes_rec buf pos =
  if Seq.length buf < pos + 4 then
    ()
  else
    let len = uint_v (int_of_char4 buf pos) in
    if len = maxint U32 then
    begin
      let len' = maxint U32 - 1 in
      if Seq.length buf < pos + 4 + len' then
        ()
      else
        let fst = Seq.slice buf (pos + 4) (pos + 4 + len') in
	match deserialize_bytes_rec buf (pos + 4 + len') with
	| DSOk(rem, pos') ->
	    if Seq.length rem = 0 then
	      ()
	    else
              let lenseq = Seq.slice buf pos (pos + 4) in
	      let remseq = Seq.slice buf (pos + 4 + len') pos' in
	      // returns DSOk(Seq.append fst rem, pos')
	      lemma_deser_rev_bytes_rec buf (pos + 4 + len');
	      // serialize_bytes_rec rem == Seq.slice buf (pos + 4 + len') pos'
              B.lemma_uint_from_to_bytes_le_preserves_value #U32 #SEC lenseq;
	      lemma_append_rev lenseq fst buf pos;
	      lemma_append_rev (Seq.append lenseq fst) remseq buf pos;
	      Seq.append_slices fst rem
	      // serialize_bytes_rec (Seq.append fst rem) == Seq.slice buf pos pos'
	| DSTooShort l -> ()
	| DSFailure -> ()
    end  
    else
      if Seq.length buf < pos + 4 + len then
        ()
      else
        let lenseq = Seq.slice buf pos (pos + 4) in
        let fst = Seq.slice buf (pos + 4) (pos + 4 + len) in
	// returns DSOk (fst, pos + 4 + len)
        B.lemma_uint_from_to_bytes_le_preserves_value #U32 #SEC lenseq;
	lemma_append_rev lenseq fst buf pos

let serializer_bytes : serializer bytes =
  { serialize = serialize_bytes_rec;
    deserialize = deserialize_bytes_rec;
    deser_ok = lemma_deser_ok_bytes_rec;
    deser_too_short = lemma_deser_too_short_bytes_rec;
    deser_rev = lemma_deser_rev_bytes_rec }

(* Serializer for lbytes *)

val deserialize_lbytes (l: Lib.IntTypes.size_nat) : deserialize_type (lbytes l)
let deserialize_lbytes l buf pos =
  if Seq.length buf >= pos + l then
    DSOk(Seq.slice buf pos (pos+l), pos+l)
  else
    DSTooShort(pos+l-Seq.length buf)

let serializer_lbytes (#l: Lib.IntTypes.size_nat) : serializer (lbytes l) =
  { serialize = (fun (lb: lbytes l) -> lb);
    deserialize = deserialize_lbytes l;
    deser_ok = (fun x buf pos -> ());
    deser_too_short = (fun x buf pos -> ());
    deser_rev = (fun buf pos -> ()) }

let size_lbytes_lemma #l x = ()

(* Serializer for option t *)

let obytes_none:uint8 = u8 0x00
let obytes_some:uint8 = u8 0x01
let obytes_none_l:lbytes 1 = (Seq.createL [obytes_none])
let obytes_some_l:lbytes 1 = (Seq.createL [obytes_some])

val serialize_option (#t: Type0) (ser: serializer t) : option t -> bytes
let serialize_option (#t: Type0) (ser: serializer t) ob =
  match ob with
  | None -> obytes_none_l
  | Some x ->
      Seq.append obytes_some_l (ser.serialize x)

val deserialize_option (#t: Type0) (ser: serializer t) : deserialize_type (option t)
let deserialize_option (#t: Type0) (ser: serializer t) buf pos =
  if Seq.length buf < pos + 1
  then DSTooShort 1
  else
    let fst = Seq.slice buf pos (pos+1) in
    if Lib.ByteSequence.lbytes_eq #1 obytes_none_l fst
    then DSOk(None, pos+1)
    else if Lib.ByteSequence.lbytes_eq #1 obytes_some_l fst then
      match ser.deserialize buf (pos+1) with
      | DSOk(x, pos') -> DSOk(Some x, pos')
      | DSTooShort l -> DSTooShort l
      | DSFailure -> DSFailure
    else DSFailure

val lemma_deser_ok_option (#t: Type0) (ser: serializer t) : deser_ok_type (option t) (serialize_option ser) (deserialize_option ser)
let lemma_deser_ok_option (#t: Type0) (ser: serializer t) x buf pos =
  match x with
  | Some b ->
      lemma_append_ok (serialize_option #t ser x) obytes_some_l (ser.serialize b) buf pos;
      ser.deser_ok b buf (pos+1)
  | None -> ()

val lemma_deser_too_short_option (#t: Type0) (ser: serializer t) : deser_too_short_type (option t) (serialize_option ser) (deserialize_option ser)
let lemma_deser_too_short_option (#t: Type0) (ser: serializer t) x buf pos =
  // (Seq.length buf < pos + Seq.length (serialize_option ser x) /\
  // Seq.slice buf pos (Seq.length buf) == Seq.slice (serialize_option ser x) 0 (Seq.length buf - pos))
  match x with
  | Some b ->
     let some_s2 = serialize_option #t ser x in
     let s2 = ser.serialize b in
     Seq.lemma_len_append obytes_some_l s2;
     // Seq.length some_s2 == 1 + Seq.length s2
     if Seq.length buf < pos + 1 then
       ()
     else
       begin
         lemma_append_too_short2 some_s2 obytes_some_l s2 buf pos;
         ser.deser_too_short b buf (pos+1)
       end
  | None ->
      ()

val lemma_deser_rev_option (#t: Type0) (ser: serializer t) : deser_rev_type (option t) (serialize_option ser) (deserialize_option ser)
let lemma_deser_rev_option (#t: Type0) (ser: serializer t) buf pos = 
  if Seq.length buf < pos + 1
  then ()
  else
    let fst = Seq.slice buf pos (pos+1) in
    if Lib.ByteSequence.lbytes_eq #1 obytes_none_l fst
    then
      // DSOk(None, pos+1)
      // show serialize_option ser None == fst
      ()
    else if Lib.ByteSequence.lbytes_eq #1 obytes_some_l fst then
      match ser.deserialize buf (pos+1) with
      | DSOk(b, pos') ->
          let b' = ser.serialize b in
          // DSOk(Some b, pos')
	  // show serialize_option ser (Some b) == Seq.slice buf pos pos'
	  ser.deser_rev buf (pos+1);
	  // ser.serialize b == Seq.slice buf (pos+1) pos'
	  lemma_append_rev obytes_some_l b' buf pos
      | DSTooShort l -> ()
      | DSFailure -> ()
    else
      ()

let serializer_option (#t: Type0) (ser: serializer t) : serializer (option t) =
  { serialize = serialize_option ser;
    deserialize = deserialize_option ser;
    (* Lemmas that show the correctness of serialize/deserialize functions *)
    deser_ok = lemma_deser_ok_option ser;
    deser_too_short = lemma_deser_too_short_option ser;
    deser_rev = lemma_deser_rev_option ser }

let size_option_lemma #t ser x =
  match x with
  | None -> ()
  | Some y ->
     Seq.lemma_len_append obytes_some_l (ser.serialize y)

(* Serializer for bool *)

inline_for_extraction
let size_bytes_bool:size_nat = 1
let bytes_true_list:l: list uint8 {List.Tot.length l == size_bytes_bool} =
  [@@ inline_let ]let l = [u8 0xFF] in
  assert_norm (List.Tot.length l == size_bytes_bool);
  l
let bytes_true:lbytes size_bytes_bool = Seq.createL bytes_true_list

let bytes_false_list:l: list uint8 {List.Tot.length l == size_bytes_bool} =
  [@@ inline_let ]let l = [u8 0x00] in
  assert_norm (List.Tot.length l == size_bytes_bool);
  l
let bytes_false:lbytes size_bytes_bool = Seq.createL bytes_false_list

val serialize_bool : serialize_type bool
let serialize_bool b =
  match b with
  | true -> bytes_true
  | false -> bytes_false

val deserialize_bool : deserialize_type bool
let deserialize_bool buf pos =
  if Seq.length buf < pos + 1
  then
    DSTooShort 1
  else
    let fst = Seq.slice buf pos (pos+1) in
    if B.lbytes_eq fst bytes_true
    then DSOk(true, pos+1)
    else if B.lbytes_eq fst bytes_false
    then DSOk(false, pos+1) else DSFailure

let serializer_bool : serializer bool =
  { serialize = serialize_bool;
    deserialize = deserialize_bool;
    deser_ok = (fun x buf pos -> ());
    deser_too_short = (fun x buf pos -> ());
    deser_rev = (fun buf pos -> ()) }

let size_bool_lemma x = ()

(* Serializer for nat *)

val pow2log (n:nat{ n > 0 }) :
   Lemma(pow2((FStar.Math.Lib.log_2 n) + 1) >= n +1)

let rec pow2log n =
  if n = 1 then () else
  pow2log (n / 2)

val serialize_nat: serialize_type nat
let serialize_nat n =
  let len = if n > 0 then (FStar.Math.Lib.div (FStar.Math.Lib.log_2 n) 8) + 1 else 0 in
  if n > 0 then
    begin
      FStar.Math.Lemmas.pow2_le_compat (op_Multiply 8 len) ((FStar.Math.Lib.log_2 n) + 1);
      pow2log n
    end;
  assert (n < pow2 (op_Multiply 8 len));
  serializer_bytes.serialize (Lib.ByteSequence.nat_to_intseq_be #U8 #SEC len n)

val deserialize_nat: deserialize_type nat
let deserialize_nat buf pos =
  match serializer_bytes.deserialize buf pos with
  | DSOk(b, new_pos) -> 
    let n = Lib.ByteSequence.nat_from_intseq_be #U8 #SEC b in
    let len = if n > 0 then (FStar.Math.Lib.div (FStar.Math.Lib.log_2 n) 8) + 1 else 0 in
    if len = Seq.length b then
      DSOk(n, new_pos)
    else
      DSFailure
  | DSTooShort n -> DSTooShort n
  | DSFailure -> DSFailure

val lemma_deser_ok_nat: deser_ok_type nat serialize_nat deserialize_nat
let lemma_deser_ok_nat n buf pos =
  let len = if n > 0 then (FStar.Math.Lib.div (FStar.Math.Lib.log_2 n) 8) + 1 else 0 in
  if n > 0 then
    begin
      FStar.Math.Lemmas.pow2_le_compat (op_Multiply 8 len) ((FStar.Math.Lib.log_2 n) + 1);
      pow2log n
    end;
  assert (n < pow2 (op_Multiply 8 len));
  let x = Lib.ByteSequence.nat_to_intseq_be #U8 #SEC len n in
  serializer_bytes.deser_ok x buf pos;
  ()

val lemma_deser_too_short_nat: deser_too_short_type nat serialize_nat deserialize_nat
let lemma_deser_too_short_nat n buf pos = 
  let len = if n > 0 then (FStar.Math.Lib.div (FStar.Math.Lib.log_2 n) 8) + 1 else 0 in
  if n > 0 then
    begin
      FStar.Math.Lemmas.pow2_le_compat (op_Multiply 8 len) ((FStar.Math.Lib.log_2 n) + 1);
      pow2log n
    end;
  assert (n < pow2 (op_Multiply 8 len));
  let x = Lib.ByteSequence.nat_to_intseq_be #U8 #SEC len n in
  serializer_bytes.deser_too_short x buf pos;
  ()

val lemma_deser_rev_nat: deser_rev_type nat serialize_nat deserialize_nat
let lemma_deser_rev_nat buf pos =
  match serializer_bytes.deserialize buf pos with
  | DSOk(b, new_pos) ->
      serializer_bytes.deser_rev buf pos;
      assert (serializer_bytes.serialize b == Seq.slice buf pos new_pos);
      assert (new_pos == pos + Seq.length (serializer_bytes.serialize b));
      let n = Lib.ByteSequence.nat_from_intseq_be #U8 #SEC b in
      let len = if n > 0 then (FStar.Math.Lib.div (FStar.Math.Lib.log_2 n) 8) + 1 else 0 in
      if len = Seq.length b then
        begin
          let c = Lib.ByteSequence.nat_to_intseq_be #U8 #SEC len n in
          Lib.ByteSequence.nat_from_intseq_be_inj #U8 #SEC b c;
          serializer_bytes.deser_ok b buf pos
        end
      else
        ()
  | DSTooShort n -> ()
  | DSFailure -> ()

let serializer_nat : serializer nat =
  { serialize = serialize_nat;
    deserialize = deserialize_nat;
    deser_ok = lemma_deser_ok_nat;
    deser_too_short = lemma_deser_too_short_nat;
    deser_rev = lemma_deser_rev_nat }

(* Serializer for bbytes *)

val serialize_bbytes: #l: Lib.IntTypes.size_nat -> serialize_type (bbytes l)
let serialize_bbytes b =
  let len = Seq.length b in
  Seq.append (char4_of_int (u32 len)) b

val deserialize_bbytes: l: Lib.IntTypes.size_nat -> deserialize_type (bbytes l)
let deserialize_bbytes l buf pos =
  if Seq.length buf < pos + 4 then
    DSTooShort (pos + 4 - Seq.length buf)
  else
    let len = uint_v (int_of_char4 buf pos) in
    if len <= l then
      let end_pos = pos + 4 + len in
      if Seq.length buf < end_pos then
        DSTooShort (end_pos - Seq.length buf)
      else
        let b = Seq.slice buf (pos + 4) end_pos in
        DSOk (b, end_pos)
    else
      DSFailure

val lemma_deser_ok_bbytes (#l: Lib.IntTypes.size_nat)
    : deser_ok_type (bbytes l) (serialize_bbytes #l) (deserialize_bbytes l)
let lemma_deser_ok_bbytes #l x buf pos = 
(* (Seq.length buf >= pos + Seq.length (serialize_bbytes x) /\
   Seq.slice buf pos (pos + Seq.length (serialize_bbytes x)) == serialize_bbytes x)) *)
  let len = Seq.length x in
  lemma_append_ok (serialize_bbytes x) (char4_of_int (u32 len)) x buf pos;
  B.lemma_uint_to_from_bytes_le_preserves_value #U32 #SEC (u32 len)
  // uint_from_bytes_le (uint_to_bytes_le (u32 len)) == len
  // len == uint_v (int_of_char4 buf pos)

val lemma_deser_too_short_bbytes (#l: Lib.IntTypes.size_nat)
    : deser_too_short_type (bbytes l) (serialize_bbytes #l) (deserialize_bbytes l)
let lemma_deser_too_short_bbytes x buf pos =
  // (Seq.length buf < pos + Seq.length (serialize_bbytes x) /\
  // Seq.slice buf pos (Seq.length buf) == Seq.slice (serialize_bbytes x) 0 (Seq.length buf - pos))
  let len = Seq.length x in
  Seq.lemma_len_append (char4_of_int (u32 len)) x;
  // Seq.length (serialize_bbytes x) = 4 + Seq.length x = 4 + len
  if Seq.length buf < pos + 4 then
    ()
  else
    begin
      lemma_append_too_short2 (serialize_bbytes x) (char4_of_int (u32 len)) x buf pos;
      B.lemma_uint_to_from_bytes_le_preserves_value #U32 #SEC (u32 len)
      // uint_from_bytes_le (uint_to_bytes_le (u32 len)) == len
      // len == uint_v (int_of_char4 buf pos)
    end

val lemma_deser_rev_bbytes (#l: Lib.IntTypes.size_nat)
    : deser_rev_type (bbytes l) (serialize_bbytes #l) (deserialize_bbytes l)
let lemma_deser_rev_bbytes #l buf pos =
  if Seq.length buf < pos + 4 then
    ()
  else
    let len = uint_v (int_of_char4 buf pos) in
    if len <= l then
      let end_pos = pos + 4 + len in
      if Seq.length buf < end_pos then
        ()
      else
        let lenseq = Seq.slice buf pos (pos + 4) in
        let b = Seq.slice buf (pos + 4) end_pos in
        B.lemma_uint_from_to_bytes_le_preserves_value #U32 #SEC lenseq;
	// char4_of_int (int_of_char4 buf pos) == lenseq
	lemma_append_rev lenseq b buf pos
    else
      ()

let serializer_bbytes (#l: Lib.IntTypes.size_nat) : serializer (bbytes l) =
  { serialize = serialize_bbytes #l;
    deserialize = deserialize_bbytes l;
    deser_ok = lemma_deser_ok_bbytes #l;
    deser_too_short = lemma_deser_too_short_bbytes #l;
    deser_rev = lemma_deser_rev_bbytes #l }

let size_bbytes_lemma #l x = ()

(* Serializer for (x:a{filter x}) *)

val deserialize_filter (#a: Type0) (filter: a -> bool) (ser: serializer a): deserialize_type (x:a{filter x})
let deserialize_filter #a filter ser buf pos =
  match ser.deserialize buf pos with
  | DSOk(x,new_pos) ->
      if filter x then
        DSOk(x,new_pos)
      else
        DSFailure
  | DSTooShort l -> DSTooShort l
  | DSFailure -> DSFailure

let serializer_filter (#a: Type0) (filter: a -> bool) (ser: serializer a) : serializer (x:a{filter x}) =
  { serialize = (fun (x:a{filter x}) -> ser.serialize x);
    deserialize = deserialize_filter #a filter ser;
    deser_ok = (fun x buf pos -> ser.deser_ok x buf pos);
    deser_too_short = ser.deser_too_short;
    deser_rev = ser.deser_rev }

let size_filter_lemma #a filter ser x = ()

(* Serializer for min_max_bytes *)

let serializer_min_max_bytes (#lmin #lmax: Lib.IntTypes.size_nat) : serializer (min_max_bytes lmin lmax) =
  serializer_filter (fun (x:bbytes lmax) -> Seq.length x >= lmin) (serializer_bbytes #lmax)

let size_min_max_bytes_lemma (#lmin #lmax: Lib.IntTypes.size_nat) (x: min_max_bytes lmin lmax) =
  size_filter_lemma #(bbytes lmax) (fun (x:bbytes lmax) -> Seq.length x >= lmin) (serializer_bbytes #lmax) x;
  size_bbytes_lemma #lmax x
  
(* Serializer for unit *)

let serializer_ghost : serializer unit =
  { serialize = (fun () -> Seq.empty);
    deserialize = (fun buf pos -> DSOk((),pos));
    deser_ok = (fun x buf pos -> ());
    deser_too_short = (fun x buf pos -> ());
    deser_rev = (fun buf pos -> ()) }

let size_ghost_lemma x = ()

(* Serializer for pairs *)

val serialize_pair (#t1 #t2: Type0) (ser1: serializer t1) (ser2: serializer t2) : serialize_type (t1 & t2)
let serialize_pair ser1 ser2 (x,y) =
  Seq.append (ser1.serialize x) (ser2.serialize y)

val deserialize_pair (#t1 #t2: Type0) (ser1: serializer t1) (ser2: serializer t2) : deserialize_type (t1 & t2)
let deserialize_pair ser1 ser2 b pos =
  match ser1.deserialize b pos with
  | DSTooShort l -> DSTooShort l
  | DSFailure -> DSFailure
  | DSOk (pk, new_pos) ->
     match ser2.deserialize b new_pos with
     | DSOk(ct, new_pos') ->
         DSOk((pk,ct), new_pos')
     | DSTooShort l -> DSTooShort l
     | DSFailure -> DSFailure

val lemma_deser_ok_pair (#t1 #t2: Type0) (ser1: serializer t1) (ser2: serializer t2) :
  deser_ok_type (t1 & t2) (serialize_pair ser1 ser2) (deserialize_pair ser1 ser2)
let lemma_deser_ok_pair #t1 #t2 ser1 ser2 (x,y) buf pos =
  lemma_append_ok (serialize_pair ser1 ser2 (x,y)) (ser1.serialize x) (ser2.serialize y) buf pos;
  ser1.deser_ok x buf pos;
  ser2.deser_ok y buf (pos + Seq.length (ser1.serialize x))

val lemma_deser_too_short_pair (#t1 #t2: Type0) (ser1: serializer t1) (ser2: serializer t2) :
  deser_too_short_type (t1 & t2) (serialize_pair ser1 ser2) (deserialize_pair ser1 ser2)
let lemma_deser_too_short_pair #t1 #t2 ser1 ser2 (x,y) buf pos =
  let s12 = serialize_pair ser1 ser2 (x,y) in
  let s1 = ser1.serialize x in
  let s2 = ser2.serialize y in
  Seq.lemma_len_append s1 s2;
  if Seq.length buf < pos + Seq.length s1 then
    begin
      lemma_append_too_short1 s12 s1 s2 buf pos;
      ser1.deser_too_short x buf pos
    end
  else
    begin
      lemma_append_too_short2 s12 s1 s2 buf pos;
      ser1.deser_ok x buf pos;
      ser2.deser_too_short y buf (pos + Seq.length s1)
    end

val lemma_deser_rev_pair (#t1 #t2: Type0) (ser1: serializer t1) (ser2: serializer t2) :
  deser_rev_type (t1 & t2) (serialize_pair ser1 ser2) (deserialize_pair ser1 ser2)
let lemma_deser_rev_pair #t1 #t2 ser1 ser2 buf pos =
  match ser1.deserialize buf pos with
  | DSTooShort _ | DSFailure -> ()
  | DSOk (x, new_pos) ->
     match ser2.deserialize buf new_pos with
     | DSOk(y, new_pos') ->
         let s1 = ser1.serialize x in
	 let s2 = ser2.serialize y in
	 ser1.deser_rev buf pos;
	 ser2.deser_rev buf new_pos;
	 lemma_append_rev s1 s2 buf pos
     | DSTooShort _ | DSFailure -> ()

let serializer_pair (#t1 #t2: Type0) (ser1: serializer t1) (ser2: serializer t2) :
  serializer (t1 & t2) =
  { serialize = serialize_pair ser1 ser2;
    deserialize = deserialize_pair ser1 ser2;
    deser_ok = lemma_deser_ok_pair ser1 ser2;
    deser_too_short = lemma_deser_too_short_pair ser1 ser2;
    deser_rev = lemma_deser_rev_pair ser1 ser2 }

let size_pair_lemma  (#t1 #t2: Type0) (ser1: serializer t1) (ser2: serializer t2) (x: t1 & t2) =
  Seq.lemma_len_append (ser1.serialize x._1) (ser2.serialize x._2)

(* Serializer for dependent pairs *)

val serialize_dep_pair (#t1: Type0) (#t2: t1 -> Type0) (ser1: serializer t1) (ser2: (x:t1) -> serializer (t2 x)) : serialize_type (x: t1 & t2 x)
let serialize_dep_pair ser1 ser2 (|x,y|) =
  Seq.append (ser1.serialize x) ((ser2 x).serialize y)

val deserialize_dep_pair (#t1: Type0) (#t2: t1 -> Type0) (ser1: serializer t1) (ser2: (x:t1) -> serializer (t2 x)) : deserialize_type (x: t1 & t2 x)
let deserialize_dep_pair ser1 ser2 b pos =
  match ser1.deserialize b pos with
  | DSTooShort l -> DSTooShort l
  | DSFailure -> DSFailure
  | DSOk (x, new_pos) ->
     match (ser2 x).deserialize b new_pos with
     | DSOk(y, new_pos') ->
         DSOk((|x,y|), new_pos')
     | DSTooShort l -> DSTooShort l
     | DSFailure -> DSFailure

val lemma_deser_ok_dep_pair (#t1: Type0) (#t2: t1 -> Type0)
  (ser1: serializer t1) (ser2: (x:t1) -> serializer (t2 x)) :
  deser_ok_type (x: t1 & t2 x) (serialize_dep_pair ser1 ser2) (deserialize_dep_pair ser1 ser2)
let lemma_deser_ok_dep_pair #t1 #t2 ser1 ser2 (|x,y|) buf pos =
  lemma_append_ok (serialize_dep_pair ser1 ser2 (|x,y|)) (ser1.serialize x) ((ser2 x).serialize y) buf pos;
  ser1.deser_ok x buf pos;
  (ser2 x).deser_ok y buf (pos + Seq.length (ser1.serialize x))

val lemma_deser_too_short_dep_pair (#t1: Type0) (#t2: t1 -> Type0)
  (ser1: serializer t1) (ser2: (x:t1) -> serializer (t2 x)) :
  deser_too_short_type (x: t1 & t2 x) (serialize_dep_pair ser1 ser2) (deserialize_dep_pair ser1 ser2)
let lemma_deser_too_short_dep_pair #t1 #t2 ser1 ser2 (|x,y|) buf pos =
  let s12 = serialize_dep_pair ser1 ser2 (|x,y|) in
  let s1 = ser1.serialize x in
  let s2 = (ser2 x).serialize y in
  Seq.lemma_len_append s1 s2;
  if Seq.length buf < pos + Seq.length s1 then
    begin
      lemma_append_too_short1 s12 s1 s2 buf pos;
      ser1.deser_too_short x buf pos
    end
  else
    begin
      lemma_append_too_short2 s12 s1 s2 buf pos;
      ser1.deser_ok x buf pos;
      (ser2 x).deser_too_short y buf (pos + Seq.length s1)
    end

val lemma_deser_rev_dep_pair (#t1: Type0) (#t2: t1 -> Type0)
  (ser1: serializer t1) (ser2: (x:t1) -> serializer (t2 x)) :
  deser_rev_type (x: t1 & t2 x) (serialize_dep_pair ser1 ser2) (deserialize_dep_pair ser1 ser2)
let lemma_deser_rev_dep_pair #t1 #t2 ser1 ser2 buf pos =
  match ser1.deserialize buf pos with
  | DSTooShort _ | DSFailure -> ()
  | DSOk (x, new_pos) ->
     match (ser2 x).deserialize buf new_pos with
     | DSOk(y, new_pos') ->
         let s1 = ser1.serialize x in
	 let s2 = (ser2 x).serialize y in
	 ser1.deser_rev buf pos;
	 (ser2 x).deser_rev buf new_pos;
	 lemma_append_rev s1 s2 buf pos
     | DSTooShort _ | DSFailure -> ()


let serializer_dep_pair (#t1: Type0) (#t2: (t1 -> Type0))
  (ser1: serializer t1) (ser2: ((x: t1) -> serializer (t2 x))) :
    serializer (x : t1 & t2 x) =
  { serialize = serialize_dep_pair ser1 ser2;
    deserialize = deserialize_dep_pair ser1 ser2;
    deser_ok = lemma_deser_ok_dep_pair ser1 ser2;
    deser_too_short = lemma_deser_too_short_dep_pair ser1 ser2;
    deser_rev = lemma_deser_rev_dep_pair ser1 ser2 }

let size_dep_pair_lemma (#t1: Type0) (#t2: (t1 -> Type0)) (ser1: serializer t1) (ser2: ((x: t1) -> serializer (t2 x))) (v: (x: t1 & t2 x)) =
  Seq.lemma_len_append (ser1.serialize v._1) ((ser2 v._1).serialize v._2)

(* Serializer for t2 from a serializer for t1, when there is a bijection between t1 and t2 *)

let serializer_bij (#t1 #t2: Type0) (bij: (t1 -> t2) & (t2 -> t1) { (forall (x:t1). bij._2(bij._1(x)) == x) /\ (forall (x:t2).bij._1(bij._2(x)) == x) }) (ser: serializer t1) : serializer t2 =
  { serialize = (fun x -> ser.serialize (bij._2 x));
    deserialize = (fun buf pos -> match ser.deserialize buf pos with
                   | DSOk(x, new_pos) -> DSOk(bij._1 x, new_pos)
		   | DSTooShort l -> DSTooShort l
		   | DSFailure -> DSFailure);
    deser_ok = (fun x buf pos -> ser.deser_ok (bij._2 x) buf pos);
    deser_too_short = (fun x buf pos -> ser.deser_too_short (bij._2 x) buf pos);
    deser_rev = (fun buf pos -> ser.deser_rev buf pos) }

let size_bij_lemma (#t1 #t2: Type0)
  (bij: (t1 -> t2) & (t2 -> t1)
    { (forall (x:t1). bij._2(bij._1(x)) == x) /\
      (forall (x:t2).bij._1(bij._2(x)) == x) })
  (ser: serializer t1) (x: t2) = ()

(* Serializer for triples *)

let serializer_triple (#t1 #t2 #t3: Type0)
  (ser1: serializer t1) (ser2: serializer t2) (ser3: serializer t3):
  serializer (t1 & t2 & t3) =
  serializer_bij ((fun ((x,y),z) -> (x,y,z)), (fun (x,y,z) -> ((x,y),z)))
    (serializer_pair (serializer_pair ser1 ser2) ser3)

let size_triple_lemma (#t1 #t2 #t3: Type0)
  (ser1: serializer t1) (ser2: serializer t2) (ser3: serializer t3) (x: t1 & t2 & t3) = ()

(* Serializer for natural numbers of length [n] *)

open Lib.ByteSequence

let bytes_to_natn (n: size_nat) (x: lbytes n): nat_n n =
  nat_from_bytes_le #SEC x

let natn_to_bytes (n: size_nat) (x: nat_n n): lbytes n =
  nat_to_bytes_le #SEC n x

let bytes_natn_lemma (n: size_nat) (x:lbytes n) :
  Lemma (natn_to_bytes n (bytes_to_natn n x) == x) =
   lemma_nat_from_to_bytes_le_preserves_value #SEC x n

let natn_bytes_lemma (n: size_nat) (x:nat_n n) :
  Lemma (bytes_to_natn n (natn_to_bytes n x) == x) =
   lemma_nat_to_from_bytes_le_preserves_value #SEC (natn_to_bytes n x) n x

let bij_bytes_nat_n (n: size_nat) :
  (bij: ((lbytes n -> nat_n n) &
        (nat_n n -> lbytes n))
  { (forall (x:lbytes n). bij._2(bij._1(x)) == x) /\
    (forall (x:nat_n n). bij._1(bij._2(x)) == x) }) =
    Classical.forall_intro (bytes_natn_lemma n);
    Classical.forall_intro (natn_bytes_lemma n);
  (bytes_to_natn n, natn_to_bytes n)

let serializer_nat_n (n: size_nat) : serializer (nat_n n) =
  serializer_bij (bij_bytes_nat_n n) (serializer_lbytes #n)

let size_nat_n_lemma n x = ()

(* Serializer for HACL* integers *)

let bytes_to_int (#t: byteintt) (x: lbytes (numbytes t)): pub_int_t t =
  mk_int #t #PUB (nat_from_bytes_le #SEC x)

let int_to_bytes (#t: byteintt) (x: pub_int_t t): lbytes (numbytes t) =
  nat_to_bytes_le #SEC (numbytes t) (v #t #PUB x)

let bytes_lemma (#t: byteintt) (x:lbytes (numbytes t)) :
  Lemma (int_to_bytes #t (bytes_to_int #t x) == x) =
   lemma_nat_from_to_bytes_le_preserves_value #SEC x (numbytes t);
   v_mk_int #t #PUB (nat_from_bytes_le #SEC x)

let int_lemma (#t: byteintt) (x:pub_int_t t) :
  Lemma (bytes_to_int #t (int_to_bytes #t x) == x) =
   v_injective #t #PUB x;
   lemma_nat_to_from_bytes_le_preserves_value #SEC (int_to_bytes #t x) 
     (numbytes t) (v #t #PUB x)

let bij_bytes_int (#t: byteintt) :
  (bij: ((lbytes (numbytes t) -> pub_int_t t) &
        (pub_int_t t -> lbytes (numbytes t)))
  { (forall (x:lbytes (numbytes t)). bij._2(bij._1(x)) == x) /\
    (forall (x:pub_int_t t). bij._1(bij._2(x)) == x) }) =
    Classical.forall_intro (bytes_lemma #t);
    Classical.forall_intro (int_lemma #t);
  (bytes_to_int #t, int_to_bytes #t)

let serializer_int (#t: byteintt) : serializer (pub_int_t t) =
  serializer_bij (bij_bytes_int #t) (serializer_lbytes #(numbytes t))

let size_int_lemma (#t: byteintt) (x: pub_int_t t) = ()

(* Serializer for lists of fixed length *)

open FStar.List

(* In principle, [serializer_empty_list] could also be defined as
[serializer_bij ... serializer_ghost] but it causes a bug in F* OCaml
extraction, so we use the definition below to workaround this bug. *)
let serializer_empty_list (#a: Type0): serializer (llist a 0) =
  { serialize = (fun ([]: llist a 0) -> Seq.empty);
    deserialize = (fun buf pos -> DSOk([],pos));
    deser_ok = (fun x buf pos -> ());
    deser_too_short = (fun x buf pos -> ());
    deser_rev = (fun buf pos -> ()) }

let rec serializer_llist (#a: Type0) (ser: serializer a) (n: nat) :
  serializer (llist a n)=
    if n = 0 then
      serializer_empty_list #a
    else
      serializer_bij ((fun ((x,y) : a & llist a (n-1)) -> x::y <: llist a n),
                      (fun (x::y : llist a n) -> (x,y) <: a & llist a (n-1)))
        (serializer_pair ser (serializer_llist ser (n-1)))

(* Serializer for lists *)

let list_as_dep_pair (a: Type0) = (x: nat & llist a x)

let serializer_list (#a: Type0) (ser: serializer a) :
  serializer (list a) =
    serializer_bij ((fun ((|x,y|): list_as_dep_pair a) -> y <: list a),
    		    (fun (x: list a) -> (|List.length x, x|) <: list_as_dep_pair a))
      (serializer_dep_pair serializer_nat (serializer_llist #a ser))

(* Printing *)

let bool_to_str b =
  match b with
  | true -> "true"
  | false -> "false"

let print_bytes bytes = List.iter (fun a -> print_uint8_hex_pad a) (to_list bytes)

let print_bool b = IO.print_string (bool_to_str b)

let print_label_bytes l b separator =
  IO.print_string ("  " ^ l ^ ": ");
  print_bytes b;
  IO.print_string (if separator then "," else "");
  IO.print_newline ()

let print_label_bool l b separator =
  IO.print_string ("  " ^ l ^ ": ");
  IO.print_string (bool_to_str b);
  IO.print_string (if separator then "," else "");
  IO.print_newline ()

