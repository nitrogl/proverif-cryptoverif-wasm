(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module SidMap

open CVTypes
open Lib.IntTypes
open Lib.Sequence
open Lib.PrintSequence

(* Type for session ids *)
type sidt = nat

let serializer_sidt = serializer_nat

(* Printing session ids *)

let print_sid n = IO.print_string (string_of_int n)

let print_label_sid l n separator = print_label_bytes l (serializer_sidt.serialize n) separator

(* Map session id -> value: The main type provided by this module *)

module Map = FStar.Map

noeq type t value =
 { sid: nat;
   m: Map.t nat value }

let available t id = (id >= t.sid)

let get t id = if Map.contains t.m id then Some (Map.sel t.m id) else None

let empty v =
  let m = Map.const v in
  { sid = 0;
    m = Map.restrict Set.empty m }

let reserve t = t.sid, { sid = t.sid + 1; m = t.m }

let upd t n v =
  let t' = { sid = t.sid; m = Map.upd t.m n v } in
  (introduce forall (id:nat { id <> n }). get t' id == get t id
  with
     (
     Map.lemma_InDomUpd2 t.m id n v;
     Map.lemma_SelUpd2 t.m id n v
     ));
  t'

let remove t n =
  { t with m = Map.restrict (Set.complement (Set.singleton n)) t.m }

let lem_empty v = ()

let lem_reserve t = ()

let lem_upd t n v =
   introduce forall (id:nat). available (upd t n v) id ==> get (upd t n v) id == None
   with
      Map.lemma_InDomUpd2 t.m id n v 

let lem_remove t n = ()
