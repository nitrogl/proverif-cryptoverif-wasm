(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module Crypto

open CVTypes

module HPKE = Spec.Agile.HPKE
module DH = Spec.Agile.DH
module AEAD = Spec.Agile.AEAD
module Hash = Spec.Agile.Hash
module HKDF = Spec.Agile.HKDF

open Lib.IntTypes
module B = Lib.ByteSequence
open Lib.Sequence
open Lib.PrintSequence
open FStar.All

let aead_alg = AEAD.CHACHA20_POLY1305
let cs:HPKE.ciphersuite = (DH.DH_Curve25519, Hash.SHA2_256, HPKE.Seal aead_alg, Hash.SHA2_256)

(* Types *)

let plaintext = AEAD.plain aead_alg
let pkey = HPKE.key_dh_secret_s cs
let skey = HPKE.key_dh_public_s cs
let ciphertext = HPKE.key_dh_public_s cs * AEAD.cipher aead_alg
let keypair = pkey * skey

#set-options "--z3rlimit 75"

(* Asymmetric encryption / decryption *)

val get_pk: skey -> pkey

let get_pk sk = match DH.secret_to_public DH.DH_Curve25519 sk with | Some pk -> pk

val enc: plaintext -> pkey -> skey -> option ciphertext

let enc plain pk skE =
  match HPKE.sealBase cs skE pk B.lbytes_empty B.lbytes_empty plain with
  | None -> None
  | Some (pkE, c) -> Some (pkE, c)

val dec: ciphertext -> skey -> option bytes

let dec ciphertext sk =
  let enc, c = ciphertext in
  match HPKE.openBase cs enc sk B.lbytes_empty B.lbytes_empty c with
  | None -> None
  | Some p -> Some p
