(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module FiniteMap

module List = FStar.List.Tot
module FMap = FStar.FiniteMap.Base
module FSet = FStar.FiniteSet.Base

noeq
type _t (key_t: eqtype) (value_t: Type): Type = {
  map:          FMap.map key_t value_t;
  list_of_keys: list key_t;
}

(*
  The domains of the map and the list represent the same set.
*)
let list_of_keys_is_map_domain #key_t #value_t (m: _t key_t value_t) =
  forall (k: key_t). List.mem k m.list_of_keys <==> FMap.mem k m.map

(*
  The list of keys is not repeating.
*)
let list_of_keys_is_not_repeating #key_t #value_t
  (m: _t key_t value_t) =
  List.noRepeats m.list_of_keys == true

let state_is_consistent #key_t #value_t (m: _t key_t value_t) =
  list_of_keys_is_map_domain m
  /\ list_of_keys_is_not_repeating m

let t (key_t: eqtype) (value_t: Type u#value_t): Type u#value_t = (a: _t key_t value_t{state_is_consistent a})

let domain #key_t #value_t (m: t key_t value_t): FSet.set key_t = FMap.domain m.map

let emptymap #key_t #value_t: t key_t value_t =
  FMap.all_finite_map_facts_lemma () ;
  {
    map = FMap.emptymap ;
    list_of_keys = [] ;
  }

let is_empty #key_t #value_t (x:t key_t value_t) : bool =
  (x.list_of_keys = [])

let mem #key_t #value_t (m: t key_t value_t) (k: key_t) =
  List.mem k m.list_of_keys

let listdomain #key_t #value_t (m: t key_t value_t): list key_t = m.list_of_keys

let lookup #key_t #value_t (m: t key_t value_t) (k: key_t{mem m k}) =
  FMap.lookup k m.map

let insert #key_t #value_t (m: t key_t value_t) (k: key_t) (v: value_t): t key_t value_t =
  FMap.all_finite_map_facts_lemma () ;
  FSet.all_finite_set_facts_lemma () ;
  if mem m k then
    {
      m with
      map = FMap.insert k v m.map;
    }
  else
    {
      map = FMap.insert k v m.map;
      list_of_keys = k::m.list_of_keys
    }

let rec no_repeats_filter (#a: eqtype) f (l: list a) : Lemma (List.noRepeats l ==> List.noRepeats (List.filter f l)) =
  match l with
    | [] -> ()
    | h::t ->
      no_repeats_filter f t ;
      ()

let remove #key_t #value_t (m: t key_t value_t) (k: key_t): t key_t value_t =
  FMap.all_finite_map_facts_lemma () ;
  FSet.all_finite_set_facts_lemma () ;
  no_repeats_filter (fun a -> a <> k) m.list_of_keys ;
  {
    map = FMap.remove k m.map;
    list_of_keys = List.filter (fun a -> a <> k) m.list_of_keys;
  }

let value_lookup_exists #key_t #value_t (m: t key_t value_t) (k: key_t{mem m k}): Lemma (ensures value_exists m (lookup m k)) = ()

let rec map_aux
  #key_t
  #value_t
  (m: t key_t value_t)
  (f: (v: value_t{value_exists m v}) -> value_t)
  (list_of_keys': list key_t{List.subset list_of_keys' m.list_of_keys /\ List.noRepeats list_of_keys'})
  (new_m: FMap.map key_t value_t{FSet.equal (FMap.domain new_m) (domain m)}):
  res_m: FMap.map key_t value_t
    {FSet.equal (FMap.domain res_m) (domain m) /\
    (forall (k: key_t{not (List.mem k list_of_keys') /\ FMap.mem k new_m}).
      FSet.all_finite_set_facts_lemma () ;
      FMap.lookup k res_m == FMap.lookup k new_m) /\
    (forall (k: key_t{List.mem k list_of_keys'}).
      FSet.all_finite_set_facts_lemma () ;
      FMap.lookup k res_m == f (lookup m k)) } =
  FMap.all_finite_map_facts_lemma () ;
  FSet.all_finite_set_facts_lemma () ;
  match list_of_keys' with
    | [] -> new_m
    | k::t ->
      let modified_map = FMap.insert k (f (lookup m k)) new_m in
      map_aux m f t modified_map


let map
  #key_t
  #value_t
  (m: t key_t value_t)
  (f: (v: value_t{value_exists m v}) -> value_t):
  t key_t value_t =
  FSet.all_finite_set_facts_lemma () ;
  let new_set_of_keys = map_aux m f m.list_of_keys m.map in
  {
    m with
    map = new_set_of_keys
  }

let rec fold_aux
  #key_t
  #value_t
  (m: t key_t value_t)
  (list_of_keys: list key_t{List.subset list_of_keys m.list_of_keys /\ List.noRepeats list_of_keys})
  #a
  (f: a -> (v: value_t{value_exists m v}) -> a)
  (starter: a):
  a =
  match list_of_keys with
    | [] -> starter
    | h::t ->
      fold_aux m t f (f starter (lookup m h))

let fold
  #key_t
  #value_t
  (m: t key_t value_t)
  #a
  (f: a -> (v: value_t{value_exists m v}) -> a)
  (starter: a):
  a =
  fold_aux m m.list_of_keys f starter

let emptymap_no_mem_lemma (_: unit): Lemma (ensures emptymap_no_mem_fact) =
  ()

let lookup_insert_lemma (_: unit): Lemma (ensures lookup_insert_fact) =
  FMap.all_finite_map_facts_lemma ()

let lookup_map_lemma (_: unit): Lemma (ensures lookup_map_fact) =
  FSet.all_finite_set_facts_lemma ()

let remove_mem_lemma (_: unit): Lemma (ensures remove_mem_fact) =
  ()

let lookup_remove_lemma (_: unit): Lemma (ensures lookup_remove_fact) =
  FMap.all_finite_map_facts_lemma ()

let all_finite_map_facts_lemma (_: unit) =
  emptymap_no_mem_lemma () ;
  lookup_insert_lemma () ;
  lookup_map_lemma () ;
  remove_mem_lemma () ;
  lookup_remove_lemma ()
