(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module FiniteMap

module FSet = FStar.FiniteSet.Base

val t (key_t: eqtype) (value_t: Type u#value_t): Type u#value_t

val domain: (#key_t: eqtype) -> (#value_t: Type) -> (m: t key_t value_t) -> FSet.set key_t

val emptymap: (#key_t: eqtype) -> (#value_t: Type) -> t key_t value_t

val is_empty: (#key_t: eqtype) -> (#value_t: Type) -> t key_t value_t -> bool

val mem: (#key_t: eqtype) -> (#value_t: Type) -> (m: t key_t value_t) -> (k: key_t) -> bool

val listdomain: (#key_t: eqtype) -> (#value_t: Type) -> (m: t key_t value_t) -> (r: list key_t { List.noRepeats r /\ forall (k:key_t). List.mem k r <==> mem m k })

val lookup: (#key_t: eqtype) -> (#value_t: Type) -> (m: t key_t value_t) -> (k: key_t{mem m k}) -> value_t

val insert: (#key_t: eqtype) -> (#value_t: Type) -> (m: t key_t value_t) -> (k: key_t) -> (v: value_t) -> t key_t value_t

val remove: (#key_t: eqtype) -> (#value_t: Type) -> (m: t key_t value_t) -> (k: key_t) -> t key_t value_t

let value_exists #key_t #value_t (m: t key_t value_t) (v: value_t): Type = exists (k: key_t{mem m k}). lookup m k == v

val map:
  (#key_t: eqtype)
  -> (#value_t: Type)
  -> (m: t key_t value_t)
  -> (f: (v: value_t{value_exists m v}) -> value_t)
  -> t key_t value_t

val fold:
  (#key_t: eqtype)
  -> (#value_t: Type)
  -> (m: t key_t value_t)
  -> (#a: Type)
  -> (f: a -> (v: value_t{value_exists m v}) -> a)
  -> (starter: a)
  -> a

let emptymap_no_mem_fact =
  forall (#key_t: eqtype) (#value_t: Type).
  forall (k: key_t). not (mem (emptymap #key_t #value_t) k)

let lookup_insert_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m: t key_t value_t) (k: key_t) (v: value_t).
  forall (k': key_t).
    (k = k' ==> mem (insert m k v) k' /\ lookup (insert m k v) k' == v) /\
    (k <> k' ==> mem (insert m k v) k' = mem m k' /\ (mem m k' ==> lookup (insert m k v) k' == lookup m k'))

let lookup_map_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m: t key_t value_t) (f: (v: value_t{value_exists m v}) -> value_t).
  forall (k: key_t).
    mem m k = mem (map m f) k
    /\ (mem m k ==> lookup (map m f) k == f (lookup m k))

let remove_mem_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m: t key_t value_t) (k: key_t).
    not (mem (remove m k) k)

let lookup_remove_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m: t key_t value_t) (k: key_t).
  forall (k': key_t).
    (k <> k' ==> mem (remove m k) k' = mem m k' /\ (mem m k' ==> lookup (remove m k) k' == lookup m k'))

let domain_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m: t key_t value_t) (k: key_t).
    List.memP k (FSet.set_as_list (domain m)) ==> mem m k

let all_finite_map_facts =
  emptymap_no_mem_fact
  /\ lookup_insert_fact
  /\ lookup_map_fact
  /\ remove_mem_fact
  /\ lookup_remove_fact
  /\ domain_fact

val all_finite_map_facts_lemma: unit -> Lemma (ensures all_finite_map_facts)
