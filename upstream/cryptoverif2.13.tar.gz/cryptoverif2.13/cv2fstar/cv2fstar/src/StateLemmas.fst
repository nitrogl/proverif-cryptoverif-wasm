(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module StateLemmas

open CVTypes
open Random
open State
module Map = SidMap
module Set = FStar.Set


let same_sessions (#stt: state_type) (st0 st1: state stt) =
  (sessions_of st0 == sessions_of st1) /\
  (local_of st0 == local_of st1)

let same_tables (#stt: state_type) (st0 st1: state stt) =
  (tables_of st0 == tables_of st1) /\
  (local_tables_of st0 == local_tables_of st1)

let same_variables (#stt: state_type) (st0 st1: state stt) =
  (variables_of st0 == variables_of st1)

let same_events (#stt: state_type) (st0 st1: state stt) =
  (events_of st0 == events_of st1)

let same_state_except_entropy (#stt: state_type) (st0 st1: state stt) =
  same_sessions st0 st1 /\ same_tables st0 st1 /\ 
  same_variables st0 st1 /\ same_events st0 st1

(* Lemmas about various state functions *)

val call_with_entropy_lemma (#stt: state_type) (#a: Type) (st0: state stt) (f: entropy -> entropy * a)
    : Lemma (same_state_except_entropy st0 (call_with_entropy st0 f)._1)

let call_with_entropy_lemma st0 f = ()

val insert_lemma (#stt: state_type) (#te: Type0) (st0: state stt) (tn: table_name (tt_of stt) te) (x:te)
    : Lemma (same_sessions st0 (insert st0 tn x) /\
      	     same_variables st0 (insert st0 tn x) /\
	     same_events st0 (insert st0 tn x))

let insert_lemma st0 tn x = ()

type table_filter_full_same_state (stt: state_type) (te: Type0) (rt: Type0) =
  filter: table_filter_full stt te rt
  { forall (st0: state stt) (x:te) . same_state_except_entropy st0 (filter st0 x)._1 }

type table_filter_same_state (stt: state_type) (te: Type0) (rt: Type0) =
  f : table_filter stt te rt
  { match f with
    | TableFilterSimple _ -> True
    | TableFilterFull filter ->
        forall (st0: state stt) (x:te) . same_state_except_entropy st0 (filter st0 x)._1 }

val get_inner_full_lemma (#stt: state_type) (#te: Type0)
      (#rt: Type0)
      (st0: state stt)
      (matches: Seq.seq rt)
      (tab: table te)
      (filter: table_filter_full_same_state stt te rt)
      : Lemma
      (ensures (same_state_except_entropy st0 (get_inner_full st0 matches tab filter)._1))
      (decreases tab)

let rec get_inner_full_lemma st matches tab f = 
  match tab with
  | [] -> ()
  | x :: r -> 
    match f st x with
    | st, Some e -> get_inner_full_lemma st (Seq.cons e matches) r f
    | st, None -> get_inner_full_lemma st matches r f

val get_lemma (#stt: state_type) (#te: Type0)
      (#rt: Type0)
      (st0: state stt)
      (tab: table te)
      (f: table_filter_same_state stt te rt)
      : Lemma (same_state_except_entropy st0 (get st0 tab f)._1)

let get_lemma st tab tf =
  match tf with
  | TableFilterSimple _ -> ()
  | TableFilterFull f -> get_inner_full_lemma st Seq.empty tab f

val get_unique_full_lemma (#stt: state_type) (#te: Type0)
      (#rt: Type0)
      (st0: state stt)
      (tab: table te)
      (filter: table_filter_full_same_state stt te rt)
      : Lemma 
      (ensures (same_state_except_entropy st0 (get_unique_full st0 tab filter)._1))
      (decreases tab)

let rec get_unique_full_lemma st tab f =
  match tab with
  | [] -> ()
  | x :: r -> 
    match f st x with
    | st, Some e -> ()
    | st, None -> get_unique_full_lemma st r f

val entry_exists_full_lemma
    (#stt: state_type) (#te: Type0)
    (#rt: Type0)
    (st0: state stt)
    (tab: table te)
    (filter: table_filter_full_same_state stt te rt)
    : Lemma (same_state_except_entropy st0 (entry_exists_full st0 tab filter)._1)

let entry_exists_full_lemma st tab f = 
  get_unique_full_lemma st tab f

