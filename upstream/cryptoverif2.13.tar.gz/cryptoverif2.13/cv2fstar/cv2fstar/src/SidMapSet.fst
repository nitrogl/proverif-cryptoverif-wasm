(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module SidMapSet

module FSet = FStar.FiniteSet.Base
friend FiniteMap

let rec fold_map_set' (#key_t: eqtype) (#value_t: Type) (l: list key_t)
  (m: FMap.t key_t value_t{forall k. List.mem k l ==> FMap.mem m k})
  (f: value_t -> GTot (Set.set SidMap.sidt))
  : GTot (Set.set SidMap.sidt)
  = match l with
  | [] -> Set.empty
  | d :: tl -> Set.union (f (FMap.lookup m d)) (fold_map_set' tl m f)


let fold_map_set m f =
  FMap.all_finite_map_facts_lemma ();
  let keys = FSet.set_as_list (FMap.domain m) in
  fold_map_set' keys m f

let rec extract_lemma  (#key_t: eqtype) (#value_t: Type) (l: list key_t)
  (m: FMap.t key_t value_t{forall k. List.mem k l ==> FMap.mem m k})
  (f: value_t -> GTot (Set.set SidMap.sidt))
  (sid: SidMap.sidt) : Lemma
  (requires Set.mem sid (fold_map_set' l m f))
  (ensures exists k. List.mem k l /\ Set.mem sid (f (FMap.lookup m k)))
  = match l with
    | [] -> ()
    | hd :: tl ->
      if Set.mem sid (f (FMap.lookup m hd)) then ()
      else extract_lemma tl m f sid

let set_mem_implies_exists (#key_t: eqtype) (#value_t: Type)
  (m: FMap.t key_t value_t)
  (f: value_t -> GTot (Set.set SidMap.sidt))
  (sid: SidMap.sidt) : Lemma
  (requires Set.mem sid (fold_map_set m f))
  (ensures exists k. FMap.mem m k /\ Set.mem sid (f (FMap.lookup m k)))
  = extract_lemma (FSet.set_as_list (FMap.domain m)) m f sid

let rec extract_lemma2 (#key_t: eqtype) (#value_t: Type) (l: list key_t)
  (m: FMap.t key_t value_t{forall k. List.mem k l ==> FMap.mem m k})
  (f: value_t -> GTot (Set.set SidMap.sidt))
  (sid: SidMap.sidt)
  (k: key_t)
  : Lemma
  (requires List.mem k l /\ Set.mem sid (f (FMap.lookup m k)))
  (ensures Set.mem sid (fold_map_set' l m f))
  = match l with
    | [] -> ()
    | hd :: tl -> if k = hd then () else extract_lemma2 tl m f sid k

let rec fold_map_set_aux1 (#key_t: eqtype) (#value_t: Type) (l: list key_t)
  (m1: FMap.t key_t value_t{forall k. List.mem k l ==> FMap.mem m1 k})
  (m2: FMap.t key_t value_t{forall k. List.mem k l ==> FMap.mem m2 k})
  (f: value_t -> GTot (Set.set SidMap.sidt))
  : Lemma
    (requires FMap.domain m1 == FMap.domain m2 /\ forall (k: key_t{FMap.mem m1 k}). FMap.lookup m1 k == FMap.lookup m2 k)
    (ensures fold_map_set' l m1 f == fold_map_set' l m2 f)
  = match l with
    | [] -> ()
    | hd :: tl -> fold_map_set_aux1 tl m1 m2 f

let fold_map_set_lemma1 (#key_t: eqtype) (#value_t: Type)
  (m: FMap.t key_t value_t)
  (f: value_t -> GTot (Set.set SidMap.sidt))
  (id: key_t)
  : Lemma
    (requires FMap.mem m id)
    (ensures
      fold_map_set m f == Set.union (fold_map_set (FMap.remove m id) f) (f (FMap.lookup m id)))
  = let m' = FMap.remove m id in
    let s = fold_map_set m f in
    let s0 = fold_map_set (FMap.remove m id) f in
    let s1 = f (FMap.lookup m id) in
    FStar.FiniteMap.Base.all_finite_map_facts_lemma ();
    let aux1 sid : Lemma
      (requires Set.mem sid s)
      (ensures Set.mem sid (Set.union s0 s1))
      = extract_lemma (FSet.set_as_list (FMap.domain m)) m f sid;
        eliminate exists k. List.mem k (FSet.set_as_list (FMap.domain m)) /\ Set.mem sid (f (FMap.lookup m k))
        returns Set.mem sid (Set.union s0 s1)
        with _.
          if k = id then ()
          else extract_lemma2 (FSet.set_as_list (FMap.domain m')) m' f sid k
    in
    let aux2 sid : Lemma
      (requires Set.mem sid s0)
      (ensures Set.mem sid s)
      = let m0 = FMap.remove m id in
        extract_lemma (FSet.set_as_list (FMap.domain m0)) m0 f sid;
        eliminate exists k. List.mem k (FSet.set_as_list (FMap.domain m0)) /\ Set.mem sid (f (FMap.lookup m0 k))
        returns Set.mem sid s
        with _.
          extract_lemma2 (FSet.set_as_list (FMap.domain m)) m f sid k
    in
    let aux3 sid : Lemma
      (requires Set.mem sid s1)
      (ensures Set.mem sid s)
      = extract_lemma2 (FSet.set_as_list (FMap.domain m)) m f sid id
    in

    Classical.forall_intro (Classical.move_requires aux1);
    Classical.forall_intro (Classical.move_requires aux2);
    Classical.forall_intro (Classical.move_requires aux3);
    assert (Set.equal s (Set.union s0 s1))

let fold_map_set_lemma2 (#key_t: eqtype) (#value_t: Type)
  (m: FMap.t key_t value_t)
  (f: value_t -> GTot (Set.set SidMap.sidt))
  (id: key_t)
  : Lemma
    (requires not (FMap.mem m id))
    (ensures fold_map_set m f == fold_map_set (FMap.remove m id) f)
  = let m' = FMap.remove m id in
    let s = fold_map_set m f in
    let s' = fold_map_set m' f in
    FStar.FiniteMap.Base.all_finite_map_facts_lemma ();
    FStar.FiniteSet.Base.all_finite_set_facts_lemma ();
    assert (FSet.equal (FMap.domain m) (FMap.domain m'));
    fold_map_set_aux1 (FSet.set_as_list (FMap.domain m)) m m' f

let fold_map_set_lemma3 (#key_t: eqtype) (#value_t: Type)
  (m: FMap.t key_t value_t)
  (f: value_t -> GTot (Set.set SidMap.sidt))
  (id: key_t)
  : Lemma
    (requires all_disjoint_sets m f /\ FMap.mem m id)
    (ensures FMap.mem m id /\ Set.disjoint (fold_map_set (FMap.remove m id) f) (f (FMap.lookup m id)))
  = let m' = FMap.remove m id in
    let s = fold_map_set m' f in
    let s0 = f (FMap.lookup m id) in
    FStar.FiniteMap.Base.all_finite_map_facts_lemma ();
    let aux1 sid : Lemma
      (requires Set.mem sid s)
      (ensures not (Set.mem sid s0))
      = extract_lemma (FSet.set_as_list (FMap.domain m')) m' f sid;
        eliminate exists k. List.mem k (FSet.set_as_list (FMap.domain m')) /\ Set.mem sid (f (FMap.lookup m' k))
        returns not (Set.mem sid s0)
        with _. assert (Set.disjoint s0 (f (FMap.lookup m k)))
    in
    let aux2 sid : Lemma
      (requires Set.mem sid s0)
      (ensures not (Set.mem sid s))
      = if Set.mem sid s then begin
           extract_lemma (FSet.set_as_list (FMap.domain m')) m' f sid;
           eliminate exists k. List.mem k (FSet.set_as_list (FMap.domain m')) /\ Set.mem sid (f (FMap.lookup m' k))
           returns not (Set.mem sid s0)
           with _. assert (Set.disjoint s0 (f (FMap.lookup m k)))
        end else ()
    in
    Classical.forall_intro (Classical.move_requires aux1);
    Classical.forall_intro (Classical.move_requires aux2)

let fold_map_set_lemma4 (#key_t: eqtype) (#value_t: Type)
  (m: FMap.t key_t value_t)
  (f: value_t -> GTot (Set.set SidMap.sidt))
  (id: key_t)
  (v: value_t)
  : Lemma (fold_map_set (FMap.insert (FMap.remove m id) id v) f == fold_map_set (FMap.insert m id v) f)
  = let m' = FMap.remove m id in
    let m1 = FMap.insert m id v in
    let m1' = FMap.insert m' id v in
    FStar.FiniteMap.Base.all_finite_map_facts_lemma ();
    FStar.FiniteSet.Base.all_finite_set_facts_lemma ();
    assert (FSet.equal (FMap.domain m1) (FMap.domain m1'));
    fold_map_set_aux1 (FSet.set_as_list (FMap.domain m1)) m1 m1' f


let fold_map_set_lemma5 (#key_t: eqtype) (#value_t: Type)
  (m: FMap.t key_t value_t)
  (f: value_t -> GTot (Set.set SidMap.sidt))
  (id: key_t)
  (v: value_t)
  : Lemma
    (requires not (FMap.mem m id))
    (ensures fold_map_set (FMap.insert m id v) f == Set.union (fold_map_set m f) (f v))
  = let m' = FMap.insert m id v in
    let s0 = fold_map_set m f in
    let s = fold_map_set m' f in
    let s1 = f v in
    FStar.FiniteMap.Base.all_finite_map_facts_lemma ();
    let aux1 sid : Lemma
      (requires Set.mem sid s)
      (ensures Set.mem sid (Set.union s0 s1))
      = extract_lemma (FSet.set_as_list (FMap.domain m')) m' f sid;
        eliminate exists k. List.mem k (FSet.set_as_list (FMap.domain m')) /\ Set.mem sid (f (FMap.lookup m' k))
        returns Set.mem sid (Set.union s0 s1)
        with _.
          if k = id then ()
          else extract_lemma2 (FSet.set_as_list (FMap.domain m)) m f sid k
    in
    let aux2 sid : Lemma
      (requires Set.mem sid s0)
      (ensures Set.mem sid s)
      = extract_lemma (FSet.set_as_list (FMap.domain m)) m f sid;
        eliminate exists k. List.mem k (FSet.set_as_list (FMap.domain m)) /\ Set.mem sid (f (FMap.lookup m k))
        returns Set.mem sid s
        with _. extract_lemma2 (FSet.set_as_list (FMap.domain m')) m' f sid k
    in
    let aux3 sid : Lemma
      (requires Set.mem sid s1)
      (ensures Set.mem sid s)
      = extract_lemma2 (FSet.set_as_list (FMap.domain m')) m' f sid id
    in

    Classical.forall_intro (Classical.move_requires aux1);
    Classical.forall_intro (Classical.move_requires aux2);
    Classical.forall_intro (Classical.move_requires aux3);
    assert (Set.equal s (Set.union s0 s1))

let fold_map_set_lemma6 (#key_t: eqtype) (#value_t: Type)
  (m: FMap.t key_t value_t)
  (f: value_t -> GTot (Set.set SidMap.sidt))
  (id: key_t)
  : Lemma
    (requires FMap.mem m id)
    (ensures Set.subset (f (FMap.lookup m id)) (fold_map_set m f))
  = FStar.FiniteSet.Base.all_finite_set_facts_lemma ();
    let s0 = f (FMap.lookup m id) in
    let s = fold_map_set m f in
    let aux sid : Lemma
      (requires Set.mem sid s0)
      (ensures Set.mem sid s)
      = extract_lemma2 (FSet.set_as_list (FMap.domain m)) m f sid id
    in
    Classical.forall_intro (Classical.move_requires aux)

let fold_map_set_lemma7 (#key_t: eqtype) (#value_t: Type)
  (m1 m2: FMap.t key_t value_t)
  (f: value_t -> GTot (Set.set SidMap.sidt))
  : Lemma
    (requires
      (forall (k: key_t). (FMap.mem m1 k <==> FMap.mem m2 k) /\
                     (FMap.mem m1 k ==> f (FMap.lookup m1 k) == f (FMap.lookup m2 k))
      )
    )
    (ensures fold_map_set m1 f == fold_map_set m2 f)
  = let s1 = fold_map_set m1 f in
    let s2 = fold_map_set m2 f in
    let aux1 sid : Lemma
        (requires Set.mem sid s1)
        (ensures Set.mem sid s2)
        = extract_lemma (FSet.set_as_list (FMap.domain m1)) m1 f sid;
          eliminate exists k. List.mem k (FSet.set_as_list (FMap.domain m1)) /\ Set.mem sid (f (FMap.lookup m1 k))
          returns Set.mem sid s2
          with _. extract_lemma2 (FSet.set_as_list (FMap.domain m2)) m2 f sid k
    in
    let aux2 sid : Lemma
        (requires Set.mem sid s2)
        (ensures Set.mem sid s1)
        = extract_lemma (FSet.set_as_list (FMap.domain m2)) m2 f sid;
          eliminate exists k. List.mem k (FSet.set_as_list (FMap.domain m2)) /\ Set.mem sid (f (FMap.lookup m2 k))
          returns Set.mem sid s1
          with _. extract_lemma2 (FSet.set_as_list (FMap.domain m1)) m1 f sid k
    in
    Classical.forall_intro (Classical.move_requires aux1);
    Classical.forall_intro (Classical.move_requires aux2);
    assert (Set.equal s1 s2)

let mem_union_remove_fact_lemma () : Lemma (mem_union_remove_fact) =
  introduce forall kt vt (m: FMap.t kt vt) f id. FMap.mem m id ==>
        fold_map_set m f == Set.union (fold_map_set (FMap.remove m id) f) (f (FMap.lookup m id))
  with fold_map_set_lemma1 m f id

let not_mem_remove_id_fact_lemma () : Lemma (not_mem_remove_id_fact) =
  introduce forall kt vt (m: FMap.t kt vt) f. forall id. not (FMap.mem m id) ==>
    fold_map_set m f == fold_map_set (FMap.remove m id) f
  with Classical.forall_intro (Classical.move_requires (fold_map_set_lemma2 #kt #vt m f))

let all_disjoint_sets_split_fact_lemma () : Lemma (all_disjoint_sets_split_fact) =
  introduce  forall kt vt (m: FMap.t kt vt) (f: vt -> GTot (Set.set SidMap.sidt)).
    forall id. (all_disjoint_sets m f /\ FMap.mem m id) ==>
      Set.disjoint (fold_map_set (FMap.remove m id) f) (f (FMap.lookup m id))
  with Classical.forall_intro (Classical.move_requires (fold_map_set_lemma3 m f))

let insert_remove_insert_fact_lemma () : Lemma (insert_remove_insert_fact) =
  introduce forall kt vt (m: FMap.t kt vt) f id v.
    fold_map_set (FMap.insert (FMap.remove m id) id v) f == fold_map_set (FMap.insert m id v) f
  with fold_map_set_lemma4 m f id v

let not_mem_insert_fact_lemma () : Lemma (not_mem_insert_fact) =
  introduce forall kt vt (m: FMap.t kt vt) f id. forall v. not (FMap.mem m id) ==>
        fold_map_set (FMap.insert m id v) f == Set.union (fold_map_set m f) (f v)
  with Classical.forall_intro (Classical.move_requires (fold_map_set_lemma5 m f id))

let mem_subset_fact_lemma () : Lemma (mem_subset_fact) =
  introduce forall kt vt (m: FMap.t kt vt) (f: vt -> GTot (Set.set SidMap.sidt)) id.
    FMap.mem m id ==> Set.subset (f (FMap.lookup m id)) (fold_map_set m f)
  with fold_map_set_lemma6 m f id

let equiv_equal_fold_map_set_fact_lemma () : Lemma (equiv_equal_fold_map_set_fact) =
  introduce forall kt vt (m1: FMap.t kt vt) (m2: FMap.t kt vt). forall (f: vt -> GTot (Set.set SidMap.sidt)).
    (forall (k: kt).
      (FMap.mem m1 k <==> FMap.mem m2 k) /\
      (FMap.mem m1 k ==> f (FMap.lookup m1 k) == f (FMap.lookup m2 k))) ==>
    fold_map_set m1 f == fold_map_set m2 f
  with Classical.forall_intro (Classical.move_requires (fold_map_set_lemma7 m1 m2))

let all_sidmapset_facts_lemma () =
  mem_union_remove_fact_lemma ();
  not_mem_remove_id_fact_lemma ();
  all_disjoint_sets_split_fact_lemma ();
  insert_remove_insert_fact_lemma ();
  not_mem_insert_fact_lemma ();
  mem_subset_fact_lemma ();
  equiv_equal_fold_map_set_fact_lemma ()
