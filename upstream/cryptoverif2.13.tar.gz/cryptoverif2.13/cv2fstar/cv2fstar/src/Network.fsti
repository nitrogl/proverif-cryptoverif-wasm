(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
(* Interface for network.
   Internally, net_channel is a reference to
   | ChOpen { out_ch: out_channel;
      	      in_ch: in_channel;
	      buf: bytes;
	      pos: nat }
   | ChClosed	    
*)

module Network

open CVTypes
open CVSTBasic

type net_res_t (a: Type0) (b: Type0) =
  | NTOk of a
  | NTError of b

type addr_err =
  | Eaddr_Not_found
  | Eaddr_Other of string

type recv_err_t =
  | Erecv_End_of_file
  | Erecv_Deserialization_failure
  | Erecv_Other of string

val inet_addr: Type0

val net_channel: Type0

let num_ports = 65536

type port = (x: nat { x < num_ports })

noeq type sockaddr =
  | ADDR_UNIX of string
  | ADDR_INET of inet_addr * port

val gethostname : unit -> CVSTBasic (net_res_t string string)

val inet_addr_any : inet_addr

val inet_addr_loopback : inet_addr

val getaddrfromname : (h: string) -> 
  CVSTBasic (net_res_t inet_addr addr_err)
  (* exception Not_found or Unix.Unix_error *)
  (* (Unix.gethostbyname s).h_addr_list.(0) *)

val open_connection : (a: sockaddr) ->
  CVSTBasic (net_res_t net_channel string)

val shutdown_connection : (ch: net_channel) ->
  CVSTBasic (net_res_t unit string)

val close_connection : (ch: net_channel) -> 
  CVSTBasic (net_res_t unit string)

val send : (ch: net_channel) -> (flush: bool) -> (msg: bytes) ->
  CVSTBasic (net_res_t unit string)

(* Assuming the following type for deserialization functions:
  deserialize_fun: bytes -> nat -> deserialize_res a
  [deserialize_fun b pos] tries to deserialize the sequence [b] from position
  [pos] and returns
  | DSOk(<deserialized value>: a, <new position>: nat)
  | DSTooShort(<missing length>: nat)
  | DSFailure
  *)

val receive (#a: Type0) (ch: net_channel) (ser: serializer a) :
  CVSTBasic (net_res_t a recv_err_t)

(* Functions that start network interaction
   They should not be called directly.
   They should be called via the <PROTOCOL>.Effect module *)

val establish_server : (a: sockaddr) -> 
  (ch: net_channel -> FStar.All.ML unit) ->
  FStar.All.ML string

val establish_server_no_fork (#a: Type0) (#s: Type0)
  (addr: sockaddr)
  (max_pending: nat) (timeout: nat)
  (serializer: serializer a)
  (f: (a -> s -> FStar.All.ML (s & CVTypes.bytes & bool(*close the channel*))))
  (state0: s): FStar.All.ML (s & string)
