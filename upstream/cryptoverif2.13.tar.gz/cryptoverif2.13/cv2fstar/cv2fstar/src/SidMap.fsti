(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module SidMap

open CVTypes

(* Type for session ids *)
val sidt: eqtype

(* Serialization for replication indices *)
val serializer_sidt : serializer sidt

(* Printing session ids *)
val print_sid: sidt -> FStar.All.ML unit
val print_label_sid: string -> sidt -> bool -> FStar.All.ML unit

(* Map session id -> value: The main type provided by this module *)
val t (value: Type u#a) : Type u#a

val available : #value: Type -> t value -> id: sidt -> Tot bool

(* [get m k] returns [Some v] when [m] maps [k] to [v];
   [None] when [m] has no mapping for [k] *)
val get: #value: Type -> t value -> sidt -> Tot (option value)

(* empty v : A map with empty domain. v is needed as a dummy value. *)
val empty: #value: Type -> value ->
  Tot (m: t value { forall (id: sidt). available m id })

(* reserve m returns an available entry and the new map *)
val reserve: #value: Type -> m: t value ->
  Tot (r:(sidt * t value) {available m r._1 /\ (forall (id: sidt). available r._2 id <==> id =!= r._1 /\ available m id) /\ (forall (id: sidt). get r._2 id == get m id) })

(* upd m k v : A map identical to `m` except mapping `k` to `v` *)
val upd: #value: Type -> m: t value -> x: sidt -> v: value -> Tot (m': t value { (forall (id: sidt). available m' id <==> available m id) /\ (get m' x == Some v) /\ (forall (id:sidt { id =!= x }). get m' id == get m id) })

(* remove m k : A map identical to `m` except the mapping of `k` is removed. *)
val remove: #value: Type -> m: t value -> x: sidt -> Tot(m': t value { (forall (id: sidt). available m' id <==> available m id)  /\ (get m' x == None) /\ (forall (id:sidt { id =!= x }). get m' id == get m id) })

type inv (#value: Type) (m: t value) =
  (forall (id:sidt). available m id ==> get m id == None)

val lem_empty (#value: Type) (v: value):
  Lemma (inv (empty v))

val lem_reserve (#value: Type) (m: t value { inv m }) :
  Lemma (inv (reserve m)._2)

val lem_upd (#value: Type) (m: t value { inv m }) (n: sidt { ~(available m n) }) (v: value) :
  Lemma (inv (upd m n v))

val lem_remove (#value: Type) (m: t value { inv m }) (n: sidt { ~(available m n) }) :
  Lemma (inv (remove m n))
