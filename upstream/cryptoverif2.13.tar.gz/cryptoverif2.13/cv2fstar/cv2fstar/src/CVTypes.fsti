(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module CVTypes

let bytes = Lib.ByteSequence.bytes
let lbytes (l: Lib.IntTypes.size_nat) = Lib.ByteSequence.lbytes l

(* Tags for types *)

open Lib.IntTypes

type tagt = uint32
let tag_from_nat = u32

(* Equality *)

val eq_bytes: bytes -> bytes -> bool
val eq_obytes: option bytes -> option bytes -> bool
val eq_lbytes: #l: Lib.IntTypes.size_nat -> (b1: lbytes l) -> (b2: lbytes l) -> b: bool{b <==> b1 == b2}

(* Lemmas for Equality *)

val lemma_eq_bytes_equal (b1 b2: bytes)
    : Lemma (eq_bytes b1 b2 <==> b1 == b2) [SMTPat (eq_bytes b1 b2)]

val lemma_eq_obytes_equal (b1 b2: option bytes)
    : Lemma (eq_obytes b1 b2 <==> b1 == b2) [SMTPat (eq_obytes b1 b2)]

(* Serialization *)

type deserialize_res (a: Type0) =
  | DSOk of a & nat
  | DSTooShort of (l:nat {l > 0})
  | DSFailure

let deser_is_ok (a: Type0) (b: bytes) (pos: nat) (x: deserialize_res a) =
  match x with
  | DSOk(y, new_pos) -> pos <= new_pos /\ new_pos <= Seq.length b
  | _ -> True

type serialize_type (a: Type0) = a -> bytes

type deserialize_type (a: Type0) = (buf: bytes) -> (pos: nat { pos <= Seq.length buf }) -> (r: deserialize_res a { deser_is_ok a buf pos r })

let deser_ok_type (a: Type0) (ser: serialize_type a) (deser: deserialize_type a) =
  (x: a) -> (buf: bytes) -> (pos: nat { pos <= Seq.length buf }) ->
  Lemma (requires (Seq.length buf >= pos + Seq.length (ser x) /\
                   Seq.slice buf pos (pos + Seq.length (ser x)) == ser x))
    (ensures (deser buf pos == DSOk(x, pos + Seq.length (ser x))))

let deser_too_short_type (a: Type0) (ser: serialize_type a) (deser: deserialize_type a) =
  (x: a) -> (buf: bytes) -> (pos: nat { pos <= Seq.length buf}) ->
  Lemma (requires (Seq.length buf < pos + Seq.length (ser x) /\
                   Seq.slice buf pos (Seq.length buf) == Seq.slice (ser x) 0 (Seq.length buf - pos)))
    (ensures (match deser buf pos with
              | DSTooShort n -> n <= pos + Seq.length (ser x) - Seq.length buf
	      | _ -> False))

let deser_rev_type (a: Type0) (ser: serialize_type a) (deser: deserialize_type a) =
  (buf: bytes) -> (pos: nat { pos <= Seq.length buf}) ->
  Lemma (match deser buf pos with
  | DSOk(x, end_pos) -> ser x == Seq.slice buf pos end_pos
  | _ -> True)

(* Intermediate lemmas useful when serialization is done by appending *)

val lemma_append_ok (sapp s1 s2 buf: bytes) (pos: nat { pos <= Seq.length buf }) :
  Lemma (requires (sapp == Seq.append s1 s2 /\
                   Seq.length buf >= pos + Seq.length sapp /\
                   Seq.slice buf pos (pos + Seq.length sapp) == sapp))
        (ensures (Seq.length buf >= pos + Seq.length s1 + Seq.length s2 /\
	          Seq.slice buf pos (pos + Seq.length s1) == s1 /\
		  Seq.slice buf (pos + Seq.length s1) (pos + Seq.length s1 + Seq.length s2) == s2))

val lemma_append_too_short1 (sapp s1 s2 buf: bytes) (pos: nat { pos <= Seq.length buf }) :
  Lemma (requires (sapp == Seq.append s1 s2 /\
         Seq.length buf < pos + Seq.length s1 /\
         Seq.slice buf pos (Seq.length buf) == Seq.slice sapp 0 (Seq.length buf - pos)))
	(ensures (Seq.slice buf pos (Seq.length buf) == Seq.slice s1 0 (Seq.length buf - pos)))

val lemma_append_too_short2 (sapp s1 s2 buf: bytes) (pos: nat { pos <= Seq.length buf }) :
  Lemma (requires (sapp == Seq.append s1 s2 /\
         Seq.length buf < pos + Seq.length sapp /\ Seq.length buf >= pos + Seq.length s1 /\
         Seq.slice buf pos (Seq.length buf) == Seq.slice sapp 0 (Seq.length buf - pos)))
	(ensures (Seq.slice buf pos (pos + Seq.length s1) == s1 /\
	          Seq.slice buf (pos + Seq.length s1) (Seq.length buf) == Seq.slice s2 0 (Seq.length buf - pos - Seq.length s1)))

val lemma_append_rev (s1 s2 buf: bytes) (pos: nat { pos <= Seq.length buf }) :
  Lemma (requires (Seq.length buf >= pos + Seq.length s1 + Seq.length s2 /\
                  s1 == Seq.slice buf pos (pos + Seq.length s1) /\
	          s2 == Seq.slice buf (pos + Seq.length s1) (pos + Seq.length s1 + Seq.length s2)))
        (ensures (Seq.append s1 s2 == Seq.slice buf pos (pos + Seq.length (Seq.append s1 s2))))


noeq type serializer (a:Type0) =
{
  serialize: serialize_type a;
  deserialize: deserialize_type a;
  (* Lemmas that show the correctness of serialize/deserialize functions *)
  deser_ok: deser_ok_type a serialize deserialize;
  deser_too_short: deser_too_short_type a serialize deserialize;
  deser_rev: deser_rev_type a serialize deserialize
}

let deserialize_full (#a: Type0) (ser: serializer a) (b: bytes) : option a =
  match ser.deserialize b 0 with
  | DSOk(x, pos) ->
      if pos = Seq.length b then Some x else None
  | DSTooShort _ | DSFailure -> None

val serializer_bytes : serializer bytes

val serializer_lbytes (#l: Lib.IntTypes.size_nat) : serializer (lbytes l)

val size_lbytes_lemma (#l: Lib.IntTypes.size_nat) (x: lbytes l):
  Lemma (Seq.length ((serializer_lbytes #l).serialize x) == l)
    [SMTPat (Seq.length ((serializer_lbytes #l).serialize x))]

val serializer_option (#t: Type0) (ser: serializer t) : serializer (option t)

val size_option_lemma (#t: Type0) (ser: serializer t) (x: option t):
  Lemma (Seq.length ((serializer_option #t ser).serialize x) ==
           (match x with
	   | None -> 1
	   | Some y -> 1 + Seq.length (ser.serialize y)))
	   [SMTPat (Seq.length ((serializer_option #t ser).serialize x))]

let serializer_obytes : serializer (option bytes) =
  serializer_option serializer_bytes

val serializer_bool : serializer bool

val size_bool_lemma (x: bool):
  Lemma (Seq.length (serializer_bool.serialize x) == 1)
    [SMTPat (Seq.length (serializer_bool.serialize x))]

val serializer_nat : serializer nat

let bbytes (l: Lib.IntTypes.size_nat)  = (x: bytes { Seq.length x <= l })

val serializer_bbytes (#l: Lib.IntTypes.size_nat) : serializer (bbytes l)

val size_bbytes_lemma (#l: Lib.IntTypes.size_nat) (x: bbytes l):
  Lemma (Seq.length ((serializer_bbytes #l).serialize x) <= l + 4)
    [SMTPat (Seq.length ((serializer_bbytes #l).serialize x))]

val serializer_filter (#a: Type0) (filter: a -> bool) (ser: serializer a) : serializer (x:a{filter x})

val size_filter_lemma (#a: Type0) (filter: a -> bool) (ser: serializer a) (x:a{filter x}):
  Lemma (Seq.length ((serializer_filter #a filter ser).serialize x) == Seq.length (ser.serialize x))
    (* Not accepted: [SMTPat (Seq.length ((serializer_filter #a filter ser).serialize x))] *)

let min_max_bytes (lmin lmax: Lib.IntTypes.size_nat)  = (x: bytes { Seq.length x <= lmax /\ Seq.length x >= lmin })

val serializer_min_max_bytes (#lmin #lmax: Lib.IntTypes.size_nat) : serializer (min_max_bytes lmin lmax)

val size_min_max_bytes_lemma (#lmin #lmax: Lib.IntTypes.size_nat) (x: min_max_bytes lmin lmax):
  Lemma (Seq.length ((serializer_min_max_bytes #lmin #lmax).serialize x) <= lmax + 4)
    [SMTPat (Seq.length ((serializer_min_max_bytes #lmin #lmax).serialize x))]

val serializer_ghost : serializer unit

val size_ghost_lemma (x: unit):
  Lemma (Seq.length (serializer_ghost.serialize x) == 0)
    [SMTPat (Seq.length (serializer_ghost.serialize x))]

val serializer_pair (#t1 #t2: Type0) (ser1: serializer t1) (ser2: serializer t2) :
  serializer (t1 & t2)

val size_pair_lemma (#t1 #t2: Type0) (ser1: serializer t1) (ser2: serializer t2) (x: t1 & t2):
  Lemma (Seq.length ((serializer_pair #t1 #t2 ser1 ser2).serialize x) ==
         Seq.length (ser1.serialize x._1) + Seq.length (ser2.serialize x._2))
    [SMTPat (Seq.length ((serializer_pair #t1 #t2 ser1 ser2).serialize x))]

val serializer_dep_pair (#t1: Type0) (#t2: (t1 -> Type0))
  (ser1: serializer t1) (ser2: ((x: t1) -> serializer (t2 x))) :
    serializer (x : t1 & t2 x)

val size_dep_pair_lemma (#t1: Type0) (#t2: (t1 -> Type0)) (ser1: serializer t1) (ser2: ((x: t1) -> serializer (t2 x))) (v: (x: t1 & t2 x)):
  Lemma (Seq.length ((serializer_dep_pair #t1 #t2 ser1 ser2).serialize v) ==
         Seq.length (ser1.serialize v._1) + Seq.length ((ser2 v._1).serialize v._2))
    (* Not accepted: [SMTPat (Seq.length ((serializer_dep_pair #t1 #t2 ser1 ser2).serialize v))] *)

val serializer_bij (#t1 #t2: Type0)
  (bij: (t1 -> t2) & (t2 -> t1)
    { (forall (x:t1). bij._2(bij._1(x)) == x) /\
      (forall (x:t2).bij._1(bij._2(x)) == x) })
  (ser: serializer t1) : serializer t2

val size_bij_lemma (#t1 #t2: Type0)
  (bij: (t1 -> t2) & (t2 -> t1)
    { (forall (x:t1). bij._2(bij._1(x)) == x) /\
      (forall (x:t2).bij._1(bij._2(x)) == x) })
  (ser: serializer t1) (x: t2):
  Lemma (Seq.length ((serializer_bij #t1 #t2 bij ser).serialize x) == Seq.length (ser.serialize (bij._2 x)))
    [SMTPat (Seq.length ((serializer_bij #t1 #t2 bij ser).serialize x))]

val serializer_triple (#t1 #t2 #t3: Type0)
  (ser1: serializer t1) (ser2: serializer t2) (ser3: serializer t3):
  serializer (t1 & t2 & t3)

val size_triple_lemma (#t1 #t2 #t3: Type0)
  (ser1: serializer t1) (ser2: serializer t2) (ser3: serializer t3) (x: t1 & t2 & t3):
  Lemma (Seq.length ((serializer_triple #t1 #t2 #t3 ser1 ser2 ser3).serialize x) ==
         Seq.length (ser1.serialize x._1) + Seq.length (ser2.serialize x._2) + Seq.length (ser3.serialize x._3))
    [SMTPat (Seq.length ((serializer_triple #t1 #t2 #t3 ser1 ser2 ser3).serialize x))]

open FStar.Mul

let nat_n (n: size_nat) = (x: nat{ x < pow2 (n * 8)})

val serializer_nat_n (n: size_nat) : serializer (nat_n n)

val size_nat_n_lemma (n: size_nat) (x: nat_n n):
  Lemma (Seq.length ((serializer_nat_n n).serialize x) == n)
    [SMTPat (Seq.length ((serializer_nat_n n).serialize x))]

let byteintt = (t: inttype {unsigned t /\ ~(U1? t)})

val serializer_int (#t: byteintt) : serializer (pub_int_t t)

val size_int_lemma (#t: byteintt) (x: pub_int_t t):
  Lemma (Seq.length ((serializer_int #t).serialize x) == numbytes t)
    [SMTPat (Seq.length ((serializer_int #t).serialize x))]

open FStar.List

val serializer_llist (#a: Type0) (ser: serializer a) (n: nat):
  serializer (llist a n)

val serializer_list (#a: Type0) (ser: serializer a):
  serializer (list a)

(* Printing *)

val bool_to_str: bool -> string

val print_bytes: bytes -> FStar.All.ML unit
val print_bool: bool -> FStar.All.ML unit

(* label, value, boolean indicating if separator should be printed *)
val print_label_bytes: string -> bytes -> bool -> FStar.All.ML unit
val print_label_bool: string -> bool -> bool -> FStar.All.ML unit
