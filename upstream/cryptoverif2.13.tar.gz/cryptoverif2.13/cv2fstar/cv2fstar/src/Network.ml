(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
type ('a, 'b) net_res_t =
  | NTOk of 'a
  | NTError of 'b

type addr_err =
  | Eaddr_Not_found
  | Eaddr_Other of Prims.string

type recv_err_t =
  | Erecv_End_of_file
  | Erecv_Deserialization_failure
  | Erecv_Other of Prims.string

type inet_addr = Unix.inet_addr

type fsbytes = FStar_UInt8.t Lib_Sequence.seq
      
type internal_channel =
    { out_ch: out_channel;
      in_ch: in_channel;
      buf: fsbytes;
      pos: Prims.nat }

type channel_state =
  | ChOpen of internal_channel
  | ChSocket
  | ChClosed

type channel_info =
    { display: string;
      ch_state: channel_state }
      
type net_channel = channel_info ref

let num_ports : Prims.nat = Z.of_int 65536

type port = Prims.nat
      
type sockaddr =
  | ADDR_UNIX of Prims.string
  | ADDR_INET of inet_addr * port

let available = ref Z.zero
      
let init_internal_channel in_ch out_ch =
  let ch_internal =
    { out_ch = out_ch;
      in_ch = in_ch;
      buf = FStar_Seq_Base.empty();
      pos = Z.zero }
  in
  let ch_num = !available in
  available := Z.succ ch_num;
  { display = Z.to_string ch_num;
    ch_state = ChOpen ch_internal }

let convert_sockaddr = function
  | ADDR_UNIX s -> Unix.ADDR_UNIX s
  | ADDR_INET(ip,port) -> Unix.ADDR_INET(ip,Z.to_int port)
	
let gethostname () () =
  try
    let n = Unix.gethostname() in
    NTOk n
  with Unix.Unix_error (e,f,p) ->
    NTError (Unix.error_message e ^ " in " ^ f ^ " " ^ p)

let inet_addr_any = Unix.inet_addr_any
    
let inet_addr_loopback = Unix.inet_addr_loopback 
    
let getaddrfromname h () =
  try
    NTOk (Unix.gethostbyname h).h_addr_list.(0)
  with
  | Not_found ->
      NTError Eaddr_Not_found
  | Unix.Unix_error (e,f,p) ->
      NTError (Eaddr_Other (Unix.error_message e ^ " in " ^ f ^ " " ^ p))

let open_connection (a0: sockaddr) () =
  try
    let a = convert_sockaddr a0 in
    let (in_ch,out_ch) = Unix.open_connection a in
    let ch = init_internal_channel in_ch out_ch in
    NTOk (ref ch)
  with
  | Unix.Unix_error (e,f,p) ->
      NTError (Unix.error_message e ^ " in " ^ f ^ " " ^ p)
  | Z.Overflow ->
      NTError ("Port too large in open_connection")
	
let shutdown_connection ch () =
  match (!ch).ch_state with
  | ChClosed -> NTError "Channel closed in shutdown_connection"
  | ChOpen c ->
      try
	Unix.shutdown_connection c.in_ch;
	NTOk()
      with Unix.Unix_error (e,f,p) ->
	NTError (Unix.error_message e ^ " in " ^ f ^ " " ^ p)

let close_connection ch () =
  match (!ch).ch_state with
  | ChClosed ->
      NTError "Channel closed in close_connection"
  | ChOpen c ->
      close_out c.out_ch;
      ch := { !ch with ch_state = ChClosed};
      NTOk()

let establish_server a0 f0 =
  try
    let a = convert_sockaddr a0 in
    let f in_ch out_ch =
      let ch = ref (init_internal_channel in_ch out_ch) in
      f0 ch
    in
    Unix.establish_server f a;
    assert false
  with
  | Unix.Unix_error (e,f,p) ->
      Unix.error_message e ^ " in " ^ f ^ " " ^ p
  | Z.Overflow ->
      "Port too large in establish_server"

let send ch flush_flag msg () =
  match (!ch).ch_state with
  | ChClosed -> NTError ("Channel closed in send")
  | ChOpen c ->
      try
	let l = FStar_Seq_Base.seq_to_list msg in
	List.iter (fun b -> output_char c.out_ch (char_of_int b)) l;
	if flush_flag then
	  flush c.out_ch;
	NTOk()
      with Sys_error s ->
	NTError s
      
let input_string in_ch =
  let buf = Bytes.create 1024 in
  let input_len = input in_ch buf 0 1024 in
  if input_len = 0 then
    raise End_of_file;
  Bytes.sub_string buf 0 input_len

let string_to_seq s =
  let rec aux pos =
    if pos = String.length s then [] else
    (int_of_char s.[pos]) :: (aux (pos+1))
  in
  FStar_Seq_Base.seq_of_list (aux 0)  
    
(* Assuming the following type for deserialization functions:
  deserialize_fun: bytes -> nat -> deserialize_res a
  [deserialize_fun b pos] tries to deserialize the sequence [b] from position
  [pos] and returns
  | DSOk(<deserialized value>: a, <new position>: nat)
  | DSTooShort(<missing length>: nat)
  | DSFailure
  *)

let rec deserialize_from_buf c deserialize_fun =
  match deserialize_fun c.buf c.pos with
  | CVTypes.DSOk(a, pos') ->
      { c with pos = pos'}, NTOk a
  | CVTypes.DSFailure ->
      c, NTError Erecv_Deserialization_failure
  | CVTypes.DSTooShort l ->
      let extension =
	let l =
	  try
	    let l' = Z.to_int l in
	    if l' > Sys.max_string_length then Sys.max_string_length else l'
	  with Z.Overflow ->
	    Sys.max_string_length
	in
        if l > 1 then
          really_input_string c.in_ch l
        else
	  input_string c.in_ch 
	in
      let c' =
	{ c with
	  buf = FStar_Seq_Base.append (FStar_Seq_Base.slice c.buf c.pos (FStar_Seq_Base.length c.buf)) (string_to_seq extension);
	  pos = Z.zero }
      in
      deserialize_from_buf c' deserialize_fun

let receive ch ser () =
  match (!ch).ch_state with
  | ChClosed ->
      NTError (Erecv_Other "Channel closed in receive") 
  | ChOpen c ->
      try
	let c' =
	  if Z.gt (FStar_Seq_Base.length c.buf) c.pos then
	    c
	  else
	    { c with
              buf = string_to_seq (input_string c.in_ch);
	      pos = Z.zero }
	in
	let c', r_ret = 
	    deserialize_from_buf c' ser.CVTypes.deserialize
	in
	ch := { (!ch) with ch_state = ChOpen c' };
	r_ret
      with
      | Sys_error e ->
	  NTError (Erecv_Other e) 
      | End_of_file ->
	  let c' = { c with buf = FStar_Seq_Base.empty(); pos = Z.zero } in
	  ch := { (!ch) with ch_state = ChOpen c' };
	  NTError Erecv_End_of_file

(* Single-threaded server, programmed using non-blocking sockets *)

type read_buffer = fsbytes
  
type write_buffer =
    { buffer: Bytes.t;
      pos: int }

type actions = read_buffer option * write_buffer option

exception CloseSocket

let internal_send socket write_buffer =
  let write_buffer' = 
    try 
      let written_len = Unix.single_write socket write_buffer.buffer write_buffer.pos (Bytes.length write_buffer.buffer - write_buffer.pos) in
      { write_buffer with pos = write_buffer.pos + written_len }
    with
    | Unix.Unix_error((EAGAIN | EWOULDBLOCK),_,_) ->
	write_buffer
    | Unix.Unix_error _ ->
	raise CloseSocket
  in
  (* Return [None] when the buffer is empty *)
  if write_buffer'.pos = Bytes.length write_buffer'.buffer then
    None
  else
    Some write_buffer'

let remove_first n seq =
  let rec aux n l =
    if Z.equal n Z.zero then l else
    match l with
    | [] -> assert false
    | _::l' -> aux (Z.pred n) l'
  in
  FStar_Seq_Base.seq_of_list (aux n (FStar_Seq_Base.seq_to_list seq))

(* [fill_buffer buffer pos l] fills bytes buffer [buffer]
   with the contents of int list [l], starting from position [pos] *)
let rec fill_buffer buffer pos = function
  | [] -> ()
  | a::l ->
      Bytes.set buffer pos (char_of_int a);
      fill_buffer buffer (pos+1) l

let buffer_from_seq seq =
  let l = FStar_Seq_Base.seq_to_list seq in
  let buffer = Bytes.create (List.length l) in
  fill_buffer buffer 0 l;
  { buffer; pos = 0 }

let add_write_buffer { buffer; pos } seq =
  let l = FStar_Seq_Base.seq_to_list seq in
  let buffer' = Bytes.extend buffer (-pos) (List.length l) in
  fill_buffer buffer' (Bytes.length buffer - pos) l;
  { buffer = buffer'; pos = 0 }
    
let act_from_bufopt = function
  | None, None -> 
      raise CloseSocket
  | x ->
      x

(* Runs function [f], ignoring Unix errors *)
let catch_error f =
  try
    f()
  with Unix.Unix_error _ -> ()
    
let establish_server_no_fork (addr0: sockaddr) (max_pending: Z.t) 
    (timeout: Z.t) (serializer: 'a CVTypes.serializer)
    (f: 'a -> 'b -> 'b * CVTypes.bytes * bool) (state: 'b) :
    'b * string =
  let deser_fun = serializer.CVTypes.deserialize in
  let state_ref = ref state in
  let max_pending =
    try
      Z.to_int max_pending
    with Z.Overflow ->
      max_int
  in
  let timeout =
    try
      float_of_int (Z.to_int timeout)
    with Z.Overflow ->
      -1.0
  in
  try
    let addr = convert_sockaddr addr0 in
    let server_socket = Unix.socket PF_INET SOCK_STREAM 0 in
    Unix.bind server_socket addr;
    Unix.listen server_socket max_pending;
    
    let wait = ref [] in
      
    let rec read socket ch read_buffer write_buffer_opt =
      let buffer = Bytes.create 1024 in
      try
	let read_len = Unix.read socket buffer 0 1024 in
	if read_len = 0 then
	  (* End of file, stop reading *)
	  None, write_buffer_opt
	else
	  let rec aux pos =
	    if pos = read_len then [] else
	    (int_of_char (Bytes.get buffer pos)) :: (aux (pos+1))
	  in
	  let extension = FStar_Seq_Base.seq_of_list (aux 0) in
	  let read_buffer' = FStar_Seq_Base.append read_buffer extension in
	  match deser_fun read_buffer' Z.zero with
	  | CVTypes.DSOk (x, pos) ->
              let deserialized_bitstring = FStar_Seq_Base.slice read_buffer' Z.zero pos in
	      let state', reply, close_channel = f x (!state_ref) in
	      state_ref := state';
	      let read_buffer' = remove_first pos read_buffer' in
	      let write_buffer_opt' =
		match write_buffer_opt with
		| None ->
		    internal_send socket (buffer_from_seq reply)
		| Some old_write_buffer ->
		    Some (add_write_buffer old_write_buffer reply)
	      in
	      if close_channel then
		None, write_buffer_opt'
	      else
		read socket ch read_buffer' write_buffer_opt'
	  | CVTypes.DSFailure ->
	      None, write_buffer_opt
	  | CVTypes.DSTooShort _ ->
	      read socket ch read_buffer' write_buffer_opt
      with
      | Unix.Unix_error((EAGAIN | EWOULDBLOCK),_,_) ->
	  (Some read_buffer), write_buffer_opt
      | Unix.Unix_error _ ->
	  raise CloseSocket
    in

    while true do
      let wait_read = server_socket ::
	(List.filter_map (fun (socket, _, _, action) ->
	  match action with
	  | (Some _, _) -> Some socket
	  | (None,_) -> None) (!wait)) in
      let wait_write = List.filter_map (fun (socket, _, _, action) ->
	match action with
	| (_, Some _) -> Some socket
	| (_, None) -> None) (!wait) in
      let ready_read, ready_write, _ =
	Unix.select wait_read wait_write [] (-1.)
      in
      wait :=
	 List.filter_map (fun ((socket, ch, time_last_action, action) as entry) ->
	   try
	     (* Perform writes *)
	     let action' = 
	       if List.memq socket ready_write then
		 match action with
		 | (read_buffer_opt, Some write_buffer) ->
		     act_from_bufopt (read_buffer_opt, internal_send socket write_buffer)
		 | _ -> assert false
	       else
		 action
	     in

	     (* Perform reads *)
	     let action'' = 
	       if List.memq socket ready_read then
		 match action' with
		 | (Some read_buffer, write_buffer_opt) ->
		     act_from_bufopt (read socket ch read_buffer write_buffer_opt)
		 | _ -> assert false
	       else
		 action'
	     in
	     
	     if action'' == action then
	       if timeout > 0.0 && Unix.time() > time_last_action +. timeout then
	         (* time out *)
		 raise CloseSocket
	       else
		 Some entry
	     else
	       Some (socket, ch, Unix.time(), action'')
		 
	   with CloseSocket -> 
	     catch_error (fun () -> Unix.shutdown socket SHUTDOWN_ALL);
	     catch_error (fun () -> Unix.close socket);
	     None
	       ) (!wait);

      (* Accept new connections *)
      if List.memq server_socket ready_read then
	let socket, client_address = Unix.accept server_socket in
	Unix.set_nonblock socket;
	let ch_num = !available in
	available := Z.succ ch_num;
	let ch =
	  ref { display = Z.to_string ch_num;
		ch_state = ChSocket }
	in
	begin
	  try 
	    let action = act_from_bufopt (read socket ch (FStar_Seq_Base.empty()) None) in
	    wait := (socket, ch, Unix.time(), action) :: (!wait)
	  with CloseSocket ->
	    catch_error (fun () -> Unix.shutdown socket SHUTDOWN_ALL);
	    catch_error (fun () -> Unix.close socket)
	end

    done;
    assert false
  with
  | Unix.Unix_error (e,f,p) ->
      (!state_ref, Unix.error_message e ^ " in " ^ f ^ " " ^ p)
  | Z.Overflow ->
      (!state_ref, "Port too large in establish_server_no_fork")
