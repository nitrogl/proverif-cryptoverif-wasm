(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
(* This is valid even for UTF8 strings, since non-ASCII characters
will be rejected anyway *)
let int_of_string x =
  try
    Some (Z.of_string x)
  with Invalid_argument _ ->
    None
          
let bytes_of_utf8_string (s: string): CVTypes.bytes =
  let rec exp i l =
    if i < 0 then l else exp (i - 1) ((Char.code (String.get s i)) :: l) in
  FStar_Seq_Base.seq_of_list (exp (String.length s - 1) [])

let utf8_string_of_bytes (b: CVTypes.bytes): string option =
  let l = FStar_Seq_Base.seq_to_list b in
  let b = Bytes.create (List.length l) in
  List.iteri (fun i c -> Bytes.set b i (Char.chr c)) l;
  let s = Bytes.to_string b in
  try
    BatUTF8.validate s;
    Some s
  with BatUTF8.Malformed_code ->
    None
  
