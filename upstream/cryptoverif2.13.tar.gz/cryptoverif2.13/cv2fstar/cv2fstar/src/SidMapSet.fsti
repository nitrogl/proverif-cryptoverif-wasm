(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module SidMapSet

open SidMap
module FMap = FiniteMap

val fold_map_set (#key_t: eqtype) (#value_t: Type) (m: FMap.t key_t value_t) (f: value_t -> GTot (Set.set SidMap.sidt)) : GTot (Set.set SidMap.sidt)

val set_mem_implies_exists (#key_t: eqtype) (#value_t: Type)
  (m: FMap.t key_t value_t)
  (f: value_t -> GTot (Set.set SidMap.sidt))
  (sid: SidMap.sidt) : Lemma
  (requires Set.mem sid (fold_map_set m f))
  (ensures exists k. FMap.mem m k /\ Set.mem sid (f (FMap.lookup m k)))

let all_disjoint_sets (#key_t: eqtype) (#value_t: Type) (m: FMap.t key_t value_t)
  (f: value_t -> GTot (Set.set SidMap.sidt)) : prop =
  forall id1 id2. FMap.mem m id1 /\ FMap.mem m id2 ==> id1 <> id2 ==>
    Set.disjoint (f (FMap.lookup m id1)) (f (FMap.lookup m id2))

let mem_union_remove_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m: FMap.t key_t value_t)
    (f: value_t -> GTot (Set.set SidMap.sidt))
    (id: key_t).
      FMap.mem m id ==>
        fold_map_set m f == Set.union (fold_map_set (FMap.remove m id) f) (f (FMap.lookup m id))

let not_mem_remove_id_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m: FMap.t key_t value_t)
    (f: value_t -> GTot (Set.set SidMap.sidt))
    (id: key_t).
      not (FMap.mem m id) ==> fold_map_set m f == fold_map_set (FMap.remove m id) f

let insert_remove_insert_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m: FMap.t key_t value_t)
    (f: value_t -> GTot (Set.set SidMap.sidt))
    (id: key_t)
    (v: value_t).
      fold_map_set (FMap.insert (FMap.remove m id) id v) f == fold_map_set (FMap.insert m id v) f

let not_mem_insert_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m: FMap.t key_t value_t)
    (f: value_t -> GTot (Set.set SidMap.sidt))
    (id: key_t)
    (v: value_t).
      not (FMap.mem m id) ==>
        fold_map_set (FMap.insert m id v) f == Set.union (fold_map_set m f) (f v)

let mem_subset_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m: FMap.t key_t value_t)
    (f: value_t -> GTot (Set.set SidMap.sidt))
    (id: key_t).
      FMap.mem m id ==> Set.subset (f (FMap.lookup m id)) (fold_map_set m f)

let empty_map_fact =
  forall (#key_t: eqtype) (#value_t: Type)
    (f: value_t -> GTot (Set.set SidMap.sidt)).
    fold_map_set (FMap.emptymap #key_t #value_t) f == Set.empty

let all_disjoint_sets_split_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m: FMap.t key_t value_t)
    (f: value_t -> GTot (Set.set SidMap.sidt))
    (id: key_t).
    all_disjoint_sets m f ==> FMap.mem m id ==>
      Set.disjoint (fold_map_set (FMap.remove m id) f) (f (FMap.lookup m id))

let equiv_equal_fold_map_set_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m1 m2: FMap.t key_t value_t)
    (f: value_t -> GTot (Set.set SidMap.sidt)).
    (forall (k: key_t).
      (FMap.mem m1 k <==> FMap.mem m2 k) /\
      (FMap.mem m1 k ==> f (FMap.lookup m1 k) == f (FMap.lookup m2 k))
    ) ==>
    fold_map_set m1 f == fold_map_set m2 f

let all_sidmapset_facts =
  mem_union_remove_fact /\
  not_mem_remove_id_fact /\
  insert_remove_insert_fact /\
  not_mem_insert_fact /\
  mem_subset_fact /\
  empty_map_fact /\
  all_disjoint_sets_split_fact /\
  equiv_equal_fold_map_set_fact

val all_sidmapset_facts_lemma: unit -> Lemma (ensures all_sidmapset_facts)
