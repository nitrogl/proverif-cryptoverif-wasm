(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module SidMapSetBase

open SidMap
module FMap = FStar.FiniteMap.Base

(* This is a bit annoying, but different modules use either FiniteMap or FStar.FiniteMap.Base,
   so we need to duplicate this module to account for both *)

val fold_map_set (#key_t: eqtype) (#value_t: Type) (m: FMap.map key_t value_t) (f: value_t -> GTot (Set.set SidMap.sidt)) : GTot (Set.set SidMap.sidt)

val set_mem_implies_exists (#key_t: eqtype) (#value_t: Type)
  (m: FMap.map key_t value_t)
  (f: value_t -> GTot (Set.set SidMap.sidt))
  (sid: SidMap.sidt) : Lemma
  (requires Set.mem sid (fold_map_set m f))
  (ensures exists k. FMap.mem k m /\ Set.mem sid (f (FMap.lookup k m)))

let all_disjoint_sets (#key_t: eqtype) (#value_t: Type) (m: FMap.map key_t value_t)
  (f: value_t -> GTot (Set.set SidMap.sidt)) : prop =
  forall id1 id2. FMap.mem id1 m /\ FMap.mem id2 m ==> id1 <> id2 ==>
    Set.disjoint (f (FMap.lookup id1 m)) (f (FMap.lookup id2 m))

let mem_union_remove_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m: FMap.map key_t value_t)
    (f: value_t -> GTot (Set.set SidMap.sidt))
    (id: key_t).
      FMap.mem id m ==>
        fold_map_set m f == Set.union (fold_map_set (FMap.remove id m) f) (f (FMap.lookup id m))

let not_mem_remove_id_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m: FMap.map key_t value_t)
    (f: value_t -> GTot (Set.set SidMap.sidt))
    (id: key_t).
      not (FMap.mem id m) ==> fold_map_set m f == fold_map_set (FMap.remove id m) f

let insert_remove_insert_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m: FMap.map key_t value_t)
    (f: value_t -> GTot (Set.set SidMap.sidt))
    (id: key_t)
    (v: value_t).
      fold_map_set (FMap.insert id v (FMap.remove id m)) f == fold_map_set (FMap.insert id v m) f

let not_mem_insert_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m: FMap.map key_t value_t)
    (f: value_t -> GTot (Set.set SidMap.sidt))
    (id: key_t)
    (v: value_t).
      not (FMap.mem id m) ==>
        fold_map_set (FMap.insert id v m) f == Set.union (fold_map_set m f) (f v)

let insert_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m: FMap.map key_t value_t)
    (f: value_t -> GTot (Set.set SidMap.sidt))
    (id: key_t)
    (v: value_t)
    (sid: SidMap.sidt).
    Set.mem sid (fold_map_set (FMap.insert id v m) f) ==>
      (Set.mem sid (fold_map_set m f) \/ Set.mem sid (f v))

let mem_subset_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m: FMap.map key_t value_t)
    (f: value_t -> GTot (Set.set SidMap.sidt))
    (id: key_t).
      FMap.mem id m ==> Set.subset (f (FMap.lookup id m)) (fold_map_set m f)

let empty_map_fact =
  forall (#key_t: eqtype) (#value_t: Type)
    (f: value_t -> GTot (Set.set SidMap.sidt)).
    fold_map_set (FMap.emptymap #key_t #value_t) f == Set.empty

let all_disjoint_sets_split_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m: FMap.map key_t value_t)
    (f: value_t -> GTot (Set.set SidMap.sidt))
    (id: key_t).
    all_disjoint_sets m f ==> FMap.mem id m ==>
      Set.disjoint (fold_map_set (FMap.remove id m) f) (f (FMap.lookup id m))

let all_disjoint_sets_insert_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m: FMap.map key_t value_t)
    (f: value_t -> GTot (Set.set SidMap.sidt))
    (id: key_t)
    (v: value_t).
    all_disjoint_sets m f ==> Set.disjoint (f v) (fold_map_set m f) ==>
      all_disjoint_sets (FMap.insert id v m) f

let all_disjoint_sets_remove_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m: FMap.map key_t value_t)
    (f: value_t -> GTot (Set.set SidMap.sidt))
    (id: key_t).
    all_disjoint_sets m f ==> all_disjoint_sets (FMap.remove id m) f

let equiv_equal_fold_map_set_fact =
  forall (#key_t: eqtype) (#value_t: Type) (m1 m2: FMap.map key_t value_t)
    (f: value_t -> GTot (Set.set SidMap.sidt)).
    (forall (k: key_t).
      (FMap.mem k m1 <==> FMap.mem k m2) /\
      (FMap.mem k m1 ==> f (FMap.lookup k m1) == f (FMap.lookup k m2))
    ) ==>
    fold_map_set m1 f == fold_map_set m2 f

let all_sidmapset_facts =
  mem_union_remove_fact /\
  not_mem_remove_id_fact /\
  insert_remove_insert_fact /\
  not_mem_insert_fact /\
  insert_fact /\
  mem_subset_fact /\
  empty_map_fact /\
  all_disjoint_sets_split_fact /\
  all_disjoint_sets_insert_fact /\
  all_disjoint_sets_remove_fact /\
  equiv_equal_fold_map_set_fact

val all_sidmapset_facts_lemma: unit -> Lemma (ensures all_sidmapset_facts)
