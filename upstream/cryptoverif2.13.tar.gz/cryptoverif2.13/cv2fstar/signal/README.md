# Case study inspired from Signal

## Theorems

The CryptoVerif model of the message encryption protocol, with its
authentication proof, is in `signal.ocv`.

Our main security theorem (authentication) is in `src/signal/Theorem.fst`.

Our user-defined global invariant `inv` is in file `src/SIGNAL.Invariant.fst`. 

We also prove properties of cryptographic primitives:

* In `src/SIGNAL.Functions.fst`, we show that the clamping function `fun_convert` yields keys that are multiple of 8 and prime to `primeq * primeq'` (where `primeq` and `primeq'` are prime numbers such that the elliptic curve Curve25519 has cardinal `8 * primeq` and its twist has cardinal `4 * primeq'`). These properties show that the result of `fun_convert` is in type `ty_Zth`.

* In `src/SIGNAL.Equations.fst`, we show that the identity function `injbot: message -> option bytes` is injective and that the bitstring concatenation `pair: lbytes 32 -> lbytes 32 -> lbytes 64` is bijective, by providing explicit inverses and proving their correctness. These proofs are in lemmas `lemma_12` to `lemma_15`. (The statement of the lemmas is in `src/SIGNAL.Equations.fsti`).

## Running the CryptoVerif proof

One can verify that the proof of the secure channel goes through, by running `../../cryptoverif signal.ocv` (may take ~45 minutes).

## Parameterization

Two settings in file `src/signal/Constants.fst` determine which version of our code is compiled:

* `checkuid` determines whether the receiver and sender user ids are included in the plaintext.
  * When `checkuid` is true, they are included: in file `src/signal/MyTypes.fst`, the type of the plaintext, `message_record_t`, is `internal_message_record_t`, which contains the user ids and the plaintext.
  * When `checkuid` is false, `message_record_t` is simply `plaintext_t`; the user ids are absent.

* `uid_in_ad` determines whether receiver and sender user ids are included in the authenticated data of the AEAD.
  * When `uid_in_ad` is true, they are included: in file `src/SIGNAL.Types.fst`, the type of user ids used in the CryptoVerif model, `cv_user_id_t`, is `MyTypes.user_id_t`.
  * When `uid_in_ad` is false, `cv_user_id_t` is `unit`, that is, the user ids are removed from the CryptoVerif model and replaced with the void `unit` type.

### How to compile the version with the second fix (receiver and sender identifiers in the authenticated data of the AEAD)

* In file `src/signal/Constants.fst`, make sure that `checkuid` is false and `uid_in_ad` is true:
  ```
  let checkuid = false
  let uid_in_ad = true
  ```
  (These are the default values.)

* Run `OTHERFLAGS="--z3rlimit_factor 4" make -j6`. The `--z3rlimit_factor` option allows to increase the timeout of the underlying SMT solver used by F\*, whose running time might vary depending on machines.

### How to compile the version with the first fix (receiver and sender identifiers in the plaintext)

* In file `src/signal/Constants.fst`, make sure that `checkuid` is true and `uid_in_ad` is false:
  ```
  let checkuid = true
  let uid_in_ad = false
  ```

* Run `OTHERFLAGS="--z3rlimit_factor 4" make -j6`

### How to compile the version without fix

* In file `src/signal/Constants.fst`, make sure that `checkuid` and `uid_in_ad` are false:
  ```
  let checkuid = false
  let uid_in_ad = false
  ```

* [optional] Run `OTHERFLAGS="--z3rlimit_factor 4" make -j6`. The compilation fails at the file `src/signal/Theorem.fst`: our security theorem is wrong, so its proof fails.

* Comment out the whole content of the file `src/signal/Theorem.fst` except the first line "module Theorem"

* Run `OTHERFLAGS="--z3rlimit_factor 4" make -j6`

## Usage of the produced programs.

The server can be launched with `./server.exe`. By default, it listens on port 5555. You can choose a different port by `./server.exe -port <port number>`.

The client can be launched with `./client.exe` or `./client.exe <user id>`. By default, it contacts the server on the local machine (127.0.0.1), on port 5555. You can choose different settings by `./client.exe -server <server name> -port <port number>' or `./client.exe -server <server name> -port <port number> <user id>'.

When the client has no user id on the command line, it creates a new user, and a new device (with id 1) for that user. When the client has a user id on the command line, it creates a new device for the specified user. One can then interact with the client with the following commands:

* `send <user ids> : <message>` sends the given `<message>` to the given `<user ids>`. The `<user ids>` must be separated from each other by one space, and `<user ids>` must be separated from the `<message>` by space, colon, space.

* `poll` gets all messages received by the client from the server.

* `refresh_keys` generates a new signed prekey and one-time prekeys, and sends them to the server.

* `quit` removes the device corresponding to the current client and exits.

As a minimal example, you can do the following:

* Open 3 windows, and run the following programs:
  1) `./server.exe`
  2) `./client.exe` It creates user 1, device 1.
  3) `./client.exe` It creates user 2, device 1.

* In the window of user 1, enter `send 2 : MESSAGE` to send MESSAGE from user 1 to user 2 (actually stored on the server for now).

* In the window of user 2, enter `poll` to receive the previous message.

* Enter `quit` in the two client windows to remove the devices and users and terminate the clients.

* Stop the server with `C-c` (`Control-c`).

Additionally, we provide an attacker program that can be used to simulate an unreliable network as well as attacks. This program can be launched by `./attacker.exe`. Like the client, by default, it contacts the server on the local machine (127.0.0.1), on port 5555. You can choose different settings by `./attacker.exe -server <server name> -port <port number>'. One can then interact with the attacker program with the following commands:

* `CreateUser` creates a new user.

* `CreateDevice` creates a new device. The program asks for the user id and the public keys (identity key, signed prekey, one-time prekeys) to provide for that device. (Can be used to create a dishonest device that reuses the keys of another device, for instance.)

* `RemoveDevice` removes a device. The program asks for the user id and the device id to remove.

* `PreKeys` provides new prekeys (one signed prekey and one-time prekeys) for a device. The program asks for the user id and the device id of the considered device and the prekeys to provide.

* `PrekeyBundleRequest` obtains a prekey bundle (one signed prekey and one one-time prekey) from the server, for a certain device. The program asks for the user id and the device id of the considered device.

* `Messages` sends messages to the server, apparently coming from a certain device, for a certain user. The program asks for the sending user and device ids, for the receiving user id, and for the messages to send to each device of that user. (Can be used to replay or modify messages, for instance.)

* `Poll` gets one message from the server, sent to a certain device. The program asks for the user id and the device id of the considered device. (Can be used to simulate network loss, for instance, since the message will no longer be available to its real target device.)

* `Quit` quits the attacker program.

(Each command except `Quit` sends a packet to the server, and the name of the command corresponds to the identifier of the packet in question.)


## How to reproduce attacks

### First attack (wrong receiver id)

* Open 4 windows, and run the following programs:
  1) `./server.exe`
  2) `./client.exe` It creates user 1, device 1, which plays the role of A.
  3) `./client.exe` It creates user 2, device 1, which plays the role of B.
  4) `./attacker.exe`

* In the attacker window, enter `CreateUser`.
  It creates user 3, which plays the role of C.
  Then enter `CreateDevice`.
  Enter user id `3`, then copy all public keys of user 1 (displayed in the window of user 1) to answer the questions of the attacker program.
  Only the hex digits should be copied, not the spaces or other symbols.
  You do not have to enter all one-time prekeys, one suffices.
  Be careful to respect the id associated to each one-time prekey.
  When you are done, enter `q`. It creates device 1 for user 3.
  
* In the window of user 2, enter `send 3 : MESSAGE`.
  It sends MESSAGE to user 3 (actually stored on the server for now).

* In the attacker window, enter `Poll`.
  Enter user id `3`, device id `1`. The message sent previously is received (encrypted).

* In the attacker window, enter `Messages`.
  Enter sending user id `2`.
  Enter sending device id `1`.
  Enter receiving user id `1`.
  Enter receiving device id `1`.
  For the message, copy-paste the message that was displayed at the previous step.
  Enter receiving device id `q` to terminate.
  The message is resent to the server, now as if it was sent by user 2 to user 1 (while it was initially sent by user 2 for user 3).

* In the window of user 1, enter `poll`.
  In the version without fix, the message is accepted by user 1, as coming from user 2. But user 2 never sent a message to user 1.
  In the versions with fix, the message is rejected.

### Second attack (wrong sender id)

* The first two steps are as above.

* In the window of user 1, enter `send 2 : MESSAGE`.
  It sends MESSAGE to user 2 (actually stored on the server for now).

* In the attacker window, enter `Poll`.
  Enter user id `2`, device id `1`. The message sent previously is received (encrypted).

* In the attacker window, enter `Messages`.
  Enter sending user id `3`.
  Enter sending device id `1`.
  Enter receiving user id `2`.
  Enter receiving device id `1`.
  For the message, copy-paste the message that was displayed at the previous step.
  Enter receiving device id `q` to terminate.
  The message is resent to the server, now as if it was sent by user 3 to user 2 (while it was initially sent by user 1 for user 2).

* In the window of user 2, enter `poll`.
  In the version without fix, the message is accepted by user 2, as coming from user 3. But user 3 in fact does not know the content of the message. (The message was actually sent by user 1.)
  In the versions with fix, the message is rejected.
