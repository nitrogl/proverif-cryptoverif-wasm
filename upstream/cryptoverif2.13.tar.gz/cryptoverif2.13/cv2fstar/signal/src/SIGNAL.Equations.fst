(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module SIGNAL.Equations

open CVTypes
open SIGNAL.Types
open SIGNAL.Functions

open Lib.Sequence
open Lib.IntTypes
open Lib.ByteSequence
friend SIGNAL.Types
friend SIGNAL.Functions

(* PLEASE PROVE ALL EQUATIONS *)

// As mentioned in our "limitations" section, we do not prove
// the property that decrypt(encrypt(m,d,k,n),d,k,n) = injbot(m)
let lemma_0 (var_m_1:t_message) (var_d_0:t_data) (var_k_2:(lbytes 32)) (var_n_1:(lbytes 12))  = admit() 

let lemma_1 (var_x_1:t_message)  = ()

// As mentioned in our "limitations" section, we do not prove
// the property that checksign(m, pkgen(r), sign(m, skgen(r))) = true
let lemma_2 (var_m_1:(lbytes 32)) (var_r_1:(lbytes 32))  = admit()

let lemma_3 (var_x_0:bool)  = ()

let lemma_4 (var_x_0:bool)  = ()

let lemma_5 (var_x_0:bool)  = ()

let lemma_6 (var_x_0:bool)  = ()

let lemma_7 (_:unit)  = ()

let lemma_8 (_:unit)  = ()

let lemma_9 (var_x_0:bool) (var_y_0:bool)  = ()

let lemma_10 (var_x_0:bool) (var_y_0:bool)  = ()

let lemma_11 (var_x_0:bool)  = ()

let lemma_12 (x0:t_message)  = ()

let lemma_13 (x:(option bytes)) = ()

let lemma_14 (x0:(lbytes 32)) (x1:(lbytes 32))  = 
  Seq.append_slices x0 x1

let lemma_15 (x:(lbytes 64)) = 
  Seq.lemma_split x 32

let lemma_16 (a b:bool) = ()

let lemma_17 (a b c :bool) = ()

let lemma_18 (a:bool) = ()

let lemma_19 (a b:bool) = ()

let lemma_20 (a b c :bool) = ()

let lemma_21 (a:bool) = ()

let lemma_22 (a b:t_message) = ()

let lemma_23 (a b:cv_user_id_t) = ()
