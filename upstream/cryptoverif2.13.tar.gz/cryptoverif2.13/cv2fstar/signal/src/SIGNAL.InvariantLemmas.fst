(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module SIGNAL.InvariantLemmas

open CVTypes
open SIGNAL.Types
open SIGNAL.Sessions
open SIGNAL.Events
open SIGNAL.Events.FStar
open SIGNAL.Protocol
open SIGNAL.Invariant
open State

(* PLEASE ADD PROOFS FOR THE LEMMAS *)
let initial s = ()

let local_reflexivity s = ()

let local_transitivity s0 s1 s2 = ()

let reflexivity s = ()

let transitivity s0 s1 s2 = ()

let local_rel_implies_rel s0 s1 = ()

let parallel_rel_implies_rel s0 s1 = ()

#push-options "--z3rlimit 80"

let add_event s e =
  Classical.forall_intro (Classical.move_requires (List.append_memP (State.events_of s) [FStarEvent e]))

#pop-options

let remove_session s n = ()

let pre_add_event_lemma e s s' =
  // () is enough if we do not prove key injectivity
  match e with
  | Event_Recv_Message uid1 uid2 msg -> ()
  | Event_Sent_Key_for_User pk uid -> ()
  | Event_Valid_Key_for_User pk uid ->
      let pk' = Helpers.from_identity_key pk in
      assert (pk == Helpers.to_identity_key pk');
      let aux1 uid : Lemma (requires (is_valid_local_key pk uid s'))
        (ensures (bad_state pk' s')) =
          ()
      in
      Classical.forall_intro (Classical.move_requires aux1)
  | _ -> ()


let lemmapre_OH (var_x1_0: (lbytes 32)) (var_x2_0: (lbytes 32)) (var_x3_0: (lbytes 32)) (var_x4_0: (lbytes 32)) (var_x5_0: (lbytes 32)) (s s':signal_state) = ()

let lemmapre_OH__1 (var_x1_1: (lbytes 32)) (var_x2_1: (lbytes 32)) (var_x3_1: (lbytes 32)) (var_x4_1: (lbytes 32)) (s s':signal_state) = ()

let lemmapre_OCorrupt (sid: SidMap.sidt) (s s':signal_state) = ()

let lemmapre_Odec1 (sid: SidMap.sidt) (var_sstring_4: t_cipher) (var_n_4: (lbytes 12)) (s s':signal_state) = ()

let lemmapre_Odec2 (sid: SidMap.sidt) (var_sstring_9: t_cipher) (var_n_9: (lbytes 12)) (s s':signal_state) = ()

let lemmapre_Odec3 (sid: SidMap.sidt) (var_sstring_6: t_cipher) (var_n_6: (lbytes 12)) (s s':signal_state) = ()

let lemmapre_Odec4 (sid: SidMap.sidt) (var_sstring_11: t_cipher) (var_n_11: (lbytes 12)) (s s':signal_state) = ()

#push-options "--z3rlimit 20"

let lemmapre_Oenc1 (sid: SidMap.sidt) (var_sstring_8: t_message) (var_n_8: (lbytes 12)) (s s':signal_state) = ()

#restart-solver (* Workaround a Z3 bug *)

let lemmapre_Oenc2 (sid: SidMap.sidt) (var_sstring_5: t_message) (var_n_5: (lbytes 12)) (s s':signal_state) = ()

let lemmapre_Oenc3 (sid: SidMap.sidt) (var_sstring_10: t_message) (var_n_10: (lbytes 12)) (s s':signal_state) = ()

let lemmapre_Oenc4 (sid: SidMap.sidt) (var_sstring_7: t_message) (var_n_7: (lbytes 12)) (s s':signal_state) = ()

let lemmapre_Ogenprinc (var_uid_0: cv_user_id_t) (s s':signal_state) = ()

let lemmapre_Orecv1 (sid: SidMap.sidt) (var_x__pubB_1: (lbytes 32)) (var_x__pubBsign_1: (lbytes 32)) (var_sephPubAB_1: (lbytes 32)) (var_signature_1: (lbytes 64)) (var_ephPubAB_1: (lbytes 32)) (var_msg__start_1: t_message) (var_remote__uid_3: cv_user_id_t) (s s':signal_state) = ()

let lemmapre_Orecv2 (sid: SidMap.sidt) (var_x__pubB_2: (lbytes 32)) (var_x__pubBsign_2: (lbytes 32)) (var_sephPubAB_2: (lbytes 32)) (var_signature_2: (lbytes 64)) (var_msg__start_2: t_message) (var_remote__uid_4: cv_user_id_t) (s s':signal_state) = ()

let lemmapre_Osend1 (sid: SidMap.sidt) (s s':signal_state) = ()

let lemmapre_Osend2 (sid: SidMap.sidt) (s s':signal_state) = ()

let lemmapre_Osend3 (sid: SidMap.sidt) (var_x__pubA_1: (lbytes 32)) (var_x__pubAsign_1: (lbytes 32)) (var_ephPubBA_1: (lbytes 32)) (var_ephPubBA_27_1: (lbytes 32)) (var_msgenc__start_1: t_cipher) (var_remote__uid_1: cv_user_id_t) (var_n__start__recv_1: (lbytes 12)) (s s':signal_state) = ()

let lemmapre_Osend4 (sid: SidMap.sidt) (var_x__pubA_2: (lbytes 32)) (var_x__pubAsign_2: (lbytes 32)) (var_ephPubBA_2: (lbytes 32)) (var_ephPubBA2_0: (lbytes 32)) (var_msgenc__start_2: t_cipher) (var_remote__uid_2: cv_user_id_t) (var_n__start__recv_2: (lbytes 12)) (s s':signal_state) = ()

#pop-options

