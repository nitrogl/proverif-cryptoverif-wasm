(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
(**

    ---------------  Module Device ---------------

    Handles all communications for one destination device.

    This module uses the certified cryptographic functions given by cryptoverif
    to implement one-to-one communication between the host (device on which
    the module is running) and a recipient.

    In the future, the module will provide the following security properties :
    - authentification of the destination device
    - secrecy of the messages (when no keys are corrupted)
    - forward secrecy
    - backward secrecy

    It is not build to be used as-is. Prefer using the interfaces
    given by Client.fsti and Server.fsti.
*)

module Device

open Crypto.Abstraction
open CVTypes
open Network.Types
open Network
open SIGNAL.Effect
open SIGNAL.Protocol
open SIGNAL.Types
open SIGNAL.Events
open SIGNAL.Invariant

val t: Type0

val device_invariant: (device: t) -> (st: signal_state) -> Type0

val device_invariant_stable_under_event (_: unit): Lemma (
    forall s1 s2 d. SIGNAL.InvariantLemmas.rel' s1 s2 ==> State.local_sessions_are_equal s1 s2 ==> device_invariant d s1 ==> device_invariant d s2
)

val device_invariant_stable_under_parallel_rel (_: unit): Lemma (
    forall s1 s2 d. SIGNAL.InvariantLemmas.parallel_rel' s1 s2 ==> device_invariant d s1 ==> device_invariant d s2
)

(**** Utility functions *)

(**
    Returns the remote identifier of the device.
*)
val remote_identifier: (device: t) -> device_id_t

(**
    Returns the public identity key of the device.
*)
val remote_identity_key: (device: t) -> identity_key_t

(**
    Returns the remote user identifier of the device.
*)
val remote_user_identifier: (device: t) -> user_id_t

(**
    Returns the local user identifier of the device.
*)
val local_user_identifier: (device: t) -> GTot user_id_t

(**
    Returns the set of session ids in a given device
*)
val device_session_ids: (device: t) -> GTot (Set.set SidMap.sidt)

(**
    Returns true if the device is marked as stale.
*)
val is_stale: (device: t) -> bool

(**
    Returns the time at which the device was marked stale
*)
val stale_time: (device: t) -> option nat

(**
    Marks the device as stale.

    This device will never be used for encryption in the future.
*)
val stale (device: t):
    CVSTInv t
      (fun s1 -> device_invariant device s1)
      (fun s1 new_device s2 ->
        (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2) /\
        device_invariant new_device s2 /\
        remote_identifier device == remote_identifier new_device /\
        remote_user_identifier device == remote_user_identifier new_device /\
        local_user_identifier device == local_user_identifier new_device /\
        device_session_ids device == device_session_ids new_device /\
	is_stale new_device)

val device_invariant_stable_under_session_invariant (_: unit) : Lemma (
  forall s1 s2 d.
    rel s1 s2 ==>
    (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) ==>
    device_invariant d s1 ==>
    device_invariant d s2
  )

val device_invariant_implies_session () : Lemma (forall device st sid.
  device_invariant device st ==> Set.mem sid (device_session_ids device) ==> State.is_session sid st)

(**** Generators *)

(**
    Creates a new device.

    - `user_identifier`: unique identifier of the user associated to the device
    - `identifier`: unique identifier of the device
    - `identity`: public identity key of the device/user, used for encryption
                In case the public identity key is associated to the device,
                we still keep a copy in the device to lightened encryption functions.
*)
val make: (local_uid: Ghost.erased user_id_t)
  -> (remote_uid: user_id_t)
  -> (remote_device_identifier: device_id_t)
  -> (remote_id_key: identity_key_t)
  -> (device:t{
      local_user_identifier device == Ghost.reveal local_uid /\
      remote_user_identifier device == remote_uid /\
      remote_identifier device == remote_device_identifier /\
      remote_identity_key device == remote_id_key /\
      device_session_ids device == Set.empty /\
      not(is_stale device)
    })


(**** Session handlers *)


(**
    Checks if the device has an active session.

    In case the device is marked as stale, this function will always return false.
*)
val has_active_session: (device: t) -> bool

(**
    Encrypts the message using the active session, when it exists.

    If no active sessions is available or if the device is marked as stale, returns None.
*)
val encrypt:
    (ch: net_channel)
    -> (cryptographic_state: cryptographic_state_t)
    -> (device: t)
    -> (msg: t_message)
    -> CVSTInv
        (t & option (bbytes Constants.max_pre_packet_content_size))
        (fun st -> cryptographic_state_invariant cryptographic_state st
            /\ device_invariant device st
            /\ get_personal_user_id cryptographic_state == local_user_identifier device
            /\ msg_send_event msg (local_user_identifier device) (remote_user_identifier device) st
        )
        (fun s1 res s2 ->
        (forall (d: t). device_invariant d s1 ==> device_invariant d s2)
            /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
            /\ device_invariant res._1 s2
            /\ (forall sid. State.is_session sid s1 ==> not (Set.mem sid (device_session_ids device)) ==>
                 not (Set.mem sid (device_session_ids res._1)))
	    /\ remote_identifier device == remote_identifier res._1
	    /\ local_user_identifier device == local_user_identifier res._1
	    /\ remote_user_identifier device == remote_user_identifier res._1)

(**
    Tries to decrypt the cipher message.

    The session used to decrypt the message becomes the active session.

    The decryption can fail for several reasons :
      - the cipher was crafted/modified by an adversary
      - the cipher is so old that no session, active or not, can decrypt the message anymore
*)
val decrypt:
    (cryptographic_state: cryptographic_state_t)
    -> (device: t)
    -> (cipher: encrypted_message_t)
    -> CVSTInv (cryptographic_state_t & t & option t_message)
        (fun st ->
	    local_user_identifier device == get_personal_user_id cryptographic_state /\
            cryptographic_state_invariant cryptographic_state st /\
            Set.disjoint (cstate_session_ids cryptographic_state) (device_session_ids device) /\
            device_invariant device st)
        (fun s1 res s2 ->
            remote_identifier device == remote_identifier res._2
            /\ local_user_identifier device == local_user_identifier res._2
            /\ remote_user_identifier device == remote_user_identifier res._2
	    /\ get_personal_user_id res._1 == get_personal_user_id cryptographic_state
            /\ (forall (d: t). device_invariant d s1 ==> device_invariant d s2)
            /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
	    /\ cryptographic_state_invariant res._1 s2
            /\ device_invariant res._2 s2
            /\ Set.subset (cstate_session_ids res._1) (cstate_session_ids cryptographic_state)
            /\ Set.disjoint (cstate_session_ids res._1) (device_session_ids res._2)
            /\ (forall sid. State.is_session sid s1 /\ not (Set.mem sid (Set.union (cstate_session_ids cryptographic_state) (device_session_ids device))) ==>
                 not (Set.mem sid (Set.union (cstate_session_ids res._1) (device_session_ids res._2))))
            /\ (match res._3 with
              | Some msg -> msg_recv_event msg (local_user_identifier device) (remote_user_identifier device) s2
              | None -> True))

(** Remove all CryptoVerif sessions of the device
*)
val finalize_device (device: t):
    CVSTInv unit
      (fun s1 -> device_invariant device s1)
      (fun s1 res s2 ->
        (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2))

(**** Facts *)

let make_device_invariant_fact =
    forall
        (local_uid: user_id_t)
        (st: signal_state)
        (uid: user_id_t)
        (id: device_id_t)
        (id_key: identity_key_t).
        is_valid_remote_key id_key uid st ==>
        device_invariant (make local_uid uid id id_key) st

let all_device_facts =
    make_device_invariant_fact

val all_device_facts_lemma : unit -> Lemma (all_device_facts)
