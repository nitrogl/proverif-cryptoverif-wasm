(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module Helpers

open MyTypes
open SIGNAL.Types
open SIGNAL.Functions

val reveal_fun_mkidkey x y : Lemma (fun_mkidkey x y === mk_identity_key x y) [SMTPat (fun_mkidkey x y)]

val to_identity_key (k: ty_idkey) : (r: identity_key_t{r === k})

val from_identity_key (k: identity_key_t) : (r: ty_idkey{r === k})

val serialize_message_record (m: message_record_t) : t_message

val deserialize_message_record (m: t_message) : option message_record_t 

val lemma_serialize_message_record (m: message_record_t): Lemma
  (deserialize_message_record(serialize_message_record m) == Some m)

val get_cv_uid (uid: user_id_t) : cv_user_id_t

val lemma_get_cv_uid () : Lemma
  (forall uid1 uid2. Constants.uid_in_ad /\ get_cv_uid uid1 == get_cv_uid uid2 ==> uid1 == uid2)

val forall_intro_5
      (#a: Type)
      (#b: (a -> Type))
      (#c: (x: a -> y: b x -> Type))
      (#d: (x: a -> y: b x -> z: c x y -> Type))
      (#e: (x: a -> y: b x -> z: c x y -> w: d x y z -> Type))
      (#p: (x: a -> y: b x -> z: c x y -> w: d x y z -> v: e x y z w -> Type0))
      ($_: (x: a -> y: b x -> z: c x y -> w: d x y z -> v: e x y z w -> Lemma (p x y z w v)))
    : Lemma (forall (x: a) (y: b x) (z: c x y) (w: d x y z) (v: e x y z w). p x y z w v)

