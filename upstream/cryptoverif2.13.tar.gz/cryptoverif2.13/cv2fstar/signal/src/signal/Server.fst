(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module Server

module FMap = FiniteMap

open MyTypes
open Crypto.Abstraction
open Network.Types
open Network.Helper
open Network
open Lib.ByteSequence

noeq
type device_details_t = {
  public_key: identity_key_t ;
  list_of_one_time_prekeys: list (prekey_id_t & prekey_t) ;
  signed_prekey_bundle: signed_prekey_bundle_t ;
  mailbox: Queue.t packet_message_t ;
}

noeq
type user_details_t = {
  last_used_device_identifier: nat;
  devices_mail_box: FMap.t device_id_t device_details_t;
}

noeq
type t = {
  users_mail_box: FMap.t user_id_t user_details_t;
  last_used_user_identifier: nat;
}

let process_default
  (server: t):
  (t & packet_t & bool) =
    server, PacketError, true

let process_create_user
  (server: t):
  (t & packet_t & bool) =
  if server.last_used_user_identifier < Lib.IntTypes.maxint Lib.IntTypes.U64 then
    let new_last_used_user_identifier = server.last_used_user_identifier + 1 in
    let user_id = make_user_id new_last_used_user_identifier in
    let user =
      { last_used_device_identifier = 0;
        devices_mail_box = FMap.emptymap }
    in
    {
      server with
      users_mail_box = FMap.insert server.users_mail_box user_id user;
      last_used_user_identifier = new_last_used_user_identifier
    }, PacketCreateUser user_id, false
  else
    process_default server 

let rec find_available_device (i:nat{ i <= Constants.max_devices_per_user }) last_used map :
  (option (x:nat{x < Constants.max_devices_per_user})) =
  if i = 0 then None else
  let idx = (last_used + Constants.max_devices_per_user + 1 - i) % Constants.max_devices_per_user in
  if FMap.mem map (make_device_id idx) then
    find_available_device (i-1) last_used map
  else
    Some idx

let process_create_device
  (server: t)
  (user_id: user_id_t)
  (id_key: identity_key_t)
  (spk: signed_prekey_bundle_t)
  (otp: lbyte_list (prekey_id_t & prekey_t)):
  (t & packet_t & bool) =
  if FMap.mem server.users_mail_box user_id then
    let user_details = FMap.lookup server.users_mail_box user_id in
    match find_available_device Constants.max_devices_per_user user_details.last_used_device_identifier user_details.devices_mail_box with
    | Some new_last_used_device_identifier ->
	    let device_id = make_device_id new_last_used_device_identifier in
            (* Create device details *)
            let device_details = {
              public_key = id_key ;
              list_of_one_time_prekeys = otp ;
              signed_prekey_bundle = spk;
              mailbox = Queue.empty ;
            } in
            (* Add device detail to the user *)
            let new_user = {
	      last_used_device_identifier = new_last_used_device_identifier;
              devices_mail_box = FMap.insert user_details.devices_mail_box device_id device_details
            } in
            (* Send back the device id *)
            {
              server with
              users_mail_box = FMap.insert server.users_mail_box user_id new_user
            }, PacketCreateDevice device_id, false
    | None ->
       server, PacketError, false
  else
    server, PacketUserDoesntExist, false

let process_remove_device
  (server: t)
  (user_device_id: user_device_id_t):
  (t & packet_t & bool) =
  if FMap.mem server.users_mail_box user_device_id.user_id then
    let user_details = FMap.lookup server.users_mail_box user_device_id.user_id in
    if FMap.mem user_details.devices_mail_box user_device_id.device_id then
      let new_device_mailboxes = FMap.remove user_details.devices_mail_box user_device_id.device_id in
      let new_user_mailboxes = 
        if FMap.is_empty new_device_mailboxes then
          (* When there is no device left, remove the user *)
          FMap.remove server.users_mail_box user_device_id.user_id
        else
	  let new_user =
	    { user_details with
	      devices_mail_box = new_device_mailboxes }
	  in
	  FMap.insert server.users_mail_box user_device_id.user_id new_user
      in
	{ server with
	  users_mail_box = new_user_mailboxes }, PacketRemoveDeviceAccepted, true
    else
      server, PacketDeviceDoesntExist, false
  else
    server, PacketUserDoesntExist, false
  
let process_prekeys
  (server: t)
  (user_device_id: user_device_id_t)
  (spk: signed_prekey_bundle_t)
  (otp: lbyte_list (prekey_id_t & prekey_t)):
  (t & packet_t & bool) =
  if FMap.mem server.users_mail_box user_device_id.user_id then
    let u = FMap.lookup server.users_mail_box user_device_id.user_id in
    if FMap.mem u.devices_mail_box user_device_id.device_id then
      let d = FMap.lookup u.devices_mail_box user_device_id.device_id in
      let d' =
        { d with
          list_of_one_time_prekeys = otp ;
          signed_prekey_bundle = spk }
      in
      let u' =
	{ u with
	  devices_mail_box = FMap.insert u.devices_mail_box user_device_id.device_id d' }
      in
      { server with
        users_mail_box = FMap.insert server.users_mail_box user_device_id.user_id u' },
      PacketPrekeysAccepted, false
    else
      server, PacketDeviceDoesntExist, false
  else
    server, PacketUserDoesntExist, false

let process_prekey_bundle
  (server: t)
  (user_device_id: user_device_id_t):
  (t & packet_t & bool) =
  if FMap.mem server.users_mail_box user_device_id.user_id then
    let u = FMap.lookup server.users_mail_box user_device_id.user_id in
    if FMap.mem u.devices_mail_box user_device_id.device_id then
      let d = FMap.lookup u.devices_mail_box user_device_id.device_id in
      (* Now checks if there is a one-time prekey stored *)
        match d.list_of_one_time_prekeys with
          | [] -> 
            (* No one time prekey available, then we do without *)
            let prekey_bundle = make_prekey_bundle d.signed_prekey_bundle None in
            let packet: packet_t = PacketPrekeyBundle prekey_bundle in
            (* Server state does not change *)
            server, packet, false
          | h::t -> 
            let prekey_bundle = make_prekey_bundle d.signed_prekey_bundle (Some h) in
            let packet: packet_t = PacketPrekeyBundle prekey_bundle in
            (* We update server state *)
            let new_d = { d with list_of_one_time_prekeys = t } in
            let new_u = { u with devices_mail_box = FMap.insert u.devices_mail_box user_device_id.device_id new_d } in
            let new_server = { server with users_mail_box = FMap.insert server.users_mail_box user_device_id.user_id new_u } in
            new_server, packet, false
    else
      server, PacketDeviceDoesntExist, false
  else
    server, PacketUserDoesntExist, false

let rec add_messages (m: FMap.t device_id_t device_details_t) (sending_device: user_device_id_t) (l: list pre_packet_t {forall pp. List.memP pp l ==> FMap.mem m pp.receiving_device}) : Tot (FMap.t device_id_t device_details_t) (decreases l) =
  match l with
  | [] -> m
  | pre_packet::r ->
     let maccu = add_messages m sending_device r in
     let packet_message =
       { psending_device = sending_device;
         content = pre_packet.content }
     in
     assert (FMap.mem m pre_packet.receiving_device);
     let d = FMap.lookup m pre_packet.receiving_device in
     let new_d = { d with mailbox = Queue.add d.mailbox packet_message } in
     FMap.insert maccu pre_packet.receiving_device new_d 

let rec len_filter (#a: Type0) (f: a -> bool) (l: list a) :
  Lemma (List.length (List.Tot.filter f l) <= List.length l) =
  match l with
  | [] -> ()
  | _::r -> len_filter f r

let rec noRepeats_filter (#a: eqtype) (f: a -> bool) (l: list a) :
  Lemma (requires (List.noRepeats l))
    (ensures (List.noRepeats (List.Tot.filter f l))) =
   match l with
   | [] -> ()
   | _::l -> noRepeats_filter f l

let process_message
  (server: t)
  (sending_device: user_device_id_t)
  (receiving_user_opt: option user_id_t)
  (messages: lbyte_list pre_packet_t):
  (t & packet_t & bool) =
  if receiving_user_opt = Some sending_device.user_id then
    (* For PacketMessages, the receiving user cannot be the same as the sender *)
    server, PacketError, false    
  else
  (* We have to identify the receiver to put the message in the correct mailbox *)
  let receiving_user: user_id_t = 
    match receiving_user_opt with
    | None -> sending_device.user_id
    | Some r -> r
  in
  if FMap.mem server.users_mail_box receiving_user then
    let u = FMap.lookup server.users_mail_box receiving_user in
    let receiving_device pre_packet = pre_packet.receiving_device in
    let devices_in_msg_received = List.Tot.map receiving_device messages in
    let aux (x: pre_packet_t): Lemma (List.memP x messages ==> List.memP x.receiving_device devices_in_msg_received) =
      List.Tot.memP_map_intro receiving_device x messages
    in
    Classical.forall_intro aux;
    assert (forall pp. List.memP pp messages ==> List.memP pp.receiving_device devices_in_msg_received);
    let devices_in_server = FMap.listdomain u.devices_mail_box in
    assert (forall (x: device_id_t). List.memP x devices_in_server <==> FMap.mem u.devices_mail_box x);
    let devices_that_should_be_in_msg = 
      if receiving_user_opt = None then
        (* For PacketSyncMessages, the sender device should not appear
           in the list of receivers *)
        let not_sender device_id = (device_id <> sending_device.device_id) in
        List.Tot.mem_filter_forall not_sender devices_in_server;
        noRepeats_filter not_sender devices_in_server;
        List.Tot.filter not_sender devices_in_server
      else
        (* For PacketMessages, all devices registered in the server
           should appear in the list of receivers *)
        devices_in_server
    in
    assert (forall (x: device_id_t). List.memP x devices_that_should_be_in_msg ==> List.memP x devices_in_server);
    let not_in_mailbox d = not(FMap.mem u.devices_mail_box d) in
    let removed_devices = List.Tot.filter not_in_mailbox devices_in_msg_received in
    List.Tot.mem_filter_forall not_in_mailbox devices_in_msg_received;
    assert (forall (x: device_id_t). List.memP x devices_in_msg_received /\ not(FMap.mem u.devices_mail_box x) ==> List.memP x removed_devices);
    len_filter not_in_mailbox devices_in_msg_received;
    assert (List.length removed_devices <= List.length devices_in_msg_received);
    let not_received d = not(List.mem d devices_in_msg_received) in
    let added_devices = List.Tot.filter not_received devices_that_should_be_in_msg in
    List.Tot.mem_filter_forall not_received devices_that_should_be_in_msg;
    assert (forall (x: device_id_t). List.memP x added_devices ==> FMap.mem u.devices_mail_box x);
    if removed_devices = [] && added_devices = [] then
      (* The devices are up-to-date *)
      begin
        assert(forall pp. List.memP pp messages ==> FMap.mem u.devices_mail_box pp.receiving_device);
        let new_devices_map = add_messages u.devices_mail_box sending_device messages in
        let new_u = { u with devices_mail_box = new_devices_map } in
        let new_server = { server with users_mail_box = FMap.insert server.users_mail_box receiving_user new_u } in
        new_server, PacketMessagesAccepted, false
      end
    else
      begin
        let rec add_keys (l: list device_id_t { forall (x: device_id_t). List.memP x l ==> FMap.mem u.devices_mail_box x }) :
	    (l': list (device_id_t & identity_key_t) { List.length l' == List.length l })=
	  match l with
	  | [] -> []
	  | d::r -> 
	    (d, (FMap.lookup u.devices_mail_box d).public_key)::add_keys r 
	in
        let added_devices_with_key = add_keys added_devices in
        assert (List.length removed_devices < 256);
	noRepeats_filter not_received devices_that_should_be_in_msg;
	MyTypes.len_devices added_devices;
        let device_update =
	    { devices_removed = removed_devices;
	      devices_added = added_devices_with_key }
        in
        server, PacketListOfDevicesIncorrect device_update, false
      end
  else
    server, PacketUserDoesntExist, false

let process_poll
  (server: t)
  (user_device_id: user_device_id_t):
  (t & packet_t & bool) =
  if FMap.mem server.users_mail_box user_device_id.user_id then
    let u = FMap.lookup server.users_mail_box user_device_id.user_id in
    if FMap.mem u.devices_mail_box user_device_id.device_id then
      let d = FMap.lookup u.devices_mail_box user_device_id.device_id in
      match Queue.take d.mailbox with
      | _, None -> server, PacketNoMessage, false
      | r, Some m -> 
        let new_d = { d with mailbox = r } in
        let new_u = { u with devices_mail_box = FMap.insert u.devices_mail_box user_device_id.device_id new_d } in
        let new_server = { server with users_mail_box = FMap.insert server.users_mail_box user_device_id.user_id new_u } in
	new_server, PacketMessage m, false
    else
      server, PacketDeviceDoesntExist, false
  else
    server, PacketUserDoesntExist, false

let process_packet
  (server: t)
  (p: packet_t):
  (t & packet_t & bool)=
  match p with
    | PacketCreateUserRequest ->
        process_create_user server
    | PacketCreateDeviceRequest(user_id, id_key, spk, otk) ->
        process_create_device server user_id id_key spk otk
    | PacketRemoveDeviceRequest user_device_id ->
        process_remove_device server user_device_id
    | PacketPrekeys(user_device_id, spk, otk) ->
        process_prekeys server user_device_id spk otk
    | PacketPrekeyBundleRequest(user_device_id) ->
        process_prekey_bundle server user_device_id
    | PacketMessages packet_messages ->
        process_message server packet_messages.sending_device (Some packet_messages.receiving_user) packet_messages.messages
    | PacketSyncMessages packet_messages -> 
        process_message server packet_messages.sending_device None packet_messages.messages
    | PacketPoll user_device_id ->
        process_poll server user_device_id
    | _ -> process_default server

open SIGNAL.Effect

let command_syntax() =
  FStar.IO.print_string "Command-line syntax:\n  server.exe [-port <server port number>]\n"

let parse_args (args: list string) : FStar.All.ML (option port) =
  match args with
  | [] -> Some (Constants.server_port)
  | ["-port"; p] ->
   begin
     match Network.Helper.parse_port p with
     | Some p -> Some p
     | None -> 
         FStar.IO.print_string "Bad port\n";
      	 command_syntax();
	 None
   end
  | [s;_] ->
   FStar.IO.print_string ("Bad option: " ^ s ^ "\n");
   command_syntax();
   None
  | [_] | _::_::_::_ ->
   FStar.IO.print_string ("Too many or too few options\n");
   command_syntax();
   None
  
   

let main args : FStar.All.ML unit =
  match parse_args args with
  | None -> ()
  | Some server_port -> 
  init_and_run (fun () -> 
    let _, msg = establish_server_no_fork
      (ADDR_INET(inet_addr_any, server_port)) 10 5
      serializer_packet (fun p s ->
        if Constants.debug_level >= 2 then
	  ml_to_CVST(fun () -> 
	    FStar.IO.print_string "Received ";
	    print_packet p;
	    FStar.IO.print_string "\n");
        let (s', p', close) = process_packet s p in
        if Constants.debug_level >= 2 then
	  ml_to_CVST(fun () ->
	    FStar.IO.print_string "Answered ";
	    print_packet p';
	    FStar.IO.print_string "\n");	
        (s', serializer_packet.serialize p', close))
      { users_mail_box = FMap.emptymap;
        last_used_user_identifier = 0 }
    in
    print_string ("Could not establish server: "^msg^"\n"))
