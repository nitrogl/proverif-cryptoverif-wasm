(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module Client

module FSet = FStar.FiniteSet.Base
module FMap = FiniteMap

open SIGNAL.Effect

open SIGNAL.Types
friend SIGNAL.Types

open Lib.ByteSequence

open Network.Helper
open Crypto.Abstraction

noeq
type t' = {
  cryptographic_state: cryptographic_state_t;
  local_user_identifier: user_id_t;
  local_device_identifier: device_id_t;
  users: FMap.t user_id_t User.t
}

let client_session_ids_pre (users: FMap.t user_id_t User.t) : GTot (Set.set SidMap.sidt) =
  SidMapSet.fold_map_set users User.user_session_ids

let t = client:t'{
  Set.disjoint (client_session_ids_pre client.users) (cstate_session_ids client.cryptographic_state) /\
  SidMapSet.all_disjoint_sets client.users User.user_session_ids /\
  forall id. FMap.mem client.users id ==> remote_identifier (FMap.lookup client.users id) == id
}

let client_user_invariant
  (client: t)
  (st: signal_state):
  Type0 =
  get_personal_user_id client.cryptographic_state == client.local_user_identifier /\
  (forall sid. Set.mem sid (client_session_ids_pre client.users) ==> State.is_session sid st) /\
  forall (uid: user_id_t{FMap.mem client.users uid}).
    let user = FMap.lookup client.users uid in
    User.user_invariant user st /\ local_identifier user == client.local_user_identifier

let client_crypto_state_invariant
  (client: t)
  (st: signal_state):
  Type0 =
  cryptographic_state_invariant client.cryptographic_state st

let client_invariant
  (client: t)
  (st: signal_state):
  Type0 =
  client_user_invariant client st
  /\ client_crypto_state_invariant client st

let client_invariant_stable_under_event (_: unit): Lemma (
    forall s1 s2 c. SIGNAL.InvariantLemmas.rel' s1 s2 ==> State.local_sessions_are_equal s1 s2 ==> client_invariant c s1 ==> client_invariant c s2
) =
  FMap.all_finite_map_facts_lemma () ;
  User.user_invariant_stable_under_event ();
  Crypto.Abstraction.cryptographic_state_invariant_stable_under_event ()

let client_session_ids client = client_session_ids_pre client.users

#push-options "--split_queries always"

let make_from_user
  (ch: net_channel)
  (local_user_identifier: user_id_t):
  CVSTInv (option t)
    (fun _ -> True)
    (fun _ res s -> match res with | Some u -> client_invariant u s | None -> True) =
  FMap.all_finite_map_facts_lemma () ;
  SidMapSet.all_sidmapset_facts_lemma ();
  cryptographic_state_invariant_stable_under_event ();
  match make_device local_user_identifier with
  | None ->  None
  | Some (cryptographic_state, signed_prekey_bundle, one_time_prekeys) ->
          (* We then query the server for a fresh device id, transmitting our public key *)
          match query_device_id ch local_user_identifier (identity_key cryptographic_state) signed_prekey_bundle one_time_prekeys with
            | None -> None
            | Some local_device_identifier ->
              (* We finally creates an empty map of users *)
              let users = FMap.emptymap in
              Some {
                cryptographic_state ;
                local_user_identifier ;
                local_device_identifier ;
                users ;
              }

let make
  (ch: net_channel):
  CVSTInv (option t)
    (fun _ -> True)
    (fun _ res s -> match res with | Some u -> client_invariant u s | None -> True) =
  FMap.all_finite_map_facts_lemma () ;
  cryptographic_state_invariant_stable_under_event ();
 (* We query the server for a fresh user id *)
  match query_user_id ch with
  | None -> None
  | Some local_user_identifier ->
     make_from_user ch local_user_identifier

#pop-options

(* ---------- TOOLS ------------ *)

open SIGNAL.Events

let events_add_event_mem_pre (st: signal_state) e: Lemma (
    List.memP e (State.events_of (State.state_add_event st e))
) =
 List.append_memP (State.events_of st) [e] e ;
 ()

(*
    This lemma is used to prove the presence of events.
*)
let events_add_event_mem (_: unit): Lemma (
    forall (st: signal_state) e. List.memP e (State.events_of (State.state_add_event st e))
) = FStar.Classical.forall_intro
    (fun st -> FStar.Classical.forall_intro
    (fun e -> events_add_event_mem_pre st e))

(* --------------- END -------------------- *)

#restart-solver

let msg_ok (msg_opt: option t_message) (local_id: user_id_t) (remote_device_id: user_device_id_t):
  CVSTInv bool
    (fun s ->
       match msg_opt with
       | None -> True
       | Some msg -> msg_recv_event msg local_id remote_device_id.user_id s)
    (fun s1 res s2 ->
        (forall (u: User.t). user_invariant u s1 ==> user_invariant u s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)) =
    user_invariant_stable_under_event();
    crypto_invariant_stable_under_parallel_rel () ;
    cryptographic_state_invariant_stable_under_event () ;
    match msg_opt with
    | None ->
	debug_print "Decryption fails\n";
        false
    | Some msg ->
      match Helpers.deserialize_message_record msg with
      | None ->
        debug_print "Deserialization fails\n";
        false
      | Some msg_rec ->
        if checkuid local_id remote_device_id.user_id msg_rec then
          begin
            add_event (SIGNAL.Events.FStar.Event_Recv_Message local_id remote_device_id.user_id msg_rec);
            ml_to_CVST(fun () ->
    	      match Utils.utf8_string_of_bytes (get_plaintext msg_rec) with
    	      | Some msg_s ->
    	        FStar.IO.print_string "Received message from user ";
    	        print_user_id remote_device_id.user_id;
    	        FStar.IO.print_string "(device: ";
    	        print_device_id remote_device_id.device_id;
    	        FStar.IO.print_string "): ";
    	        FStar.IO.print_string msg_s;
    	        FStar.IO.print_string "\n"
    	      | None ->
    	        FStar.IO.print_string "Received incorrect UTF8 string\n");
            true
          end
        else
          begin
    	    debug_print "Received a message meant for another user or sent from an unexpected user\n";
            false
          end


#push-options "--z3rlimit 50"

let process_packet_message
  (client: t)
  (p: packet_message_t):
  CVSTInv
    t
    (fun s -> client_invariant client s)
    (fun _ c s -> client_invariant c s) =
  FMap.all_finite_map_facts_lemma () ;
  SidMapSet.all_sidmapset_facts_lemma ();
  user_invariant_stable_under_event () ;
  cryptographic_state_invariant_stable_under_event () ;
  user_invariant_implies_session ();
  let user_id = p.psending_device.user_id in
  let u =
        if FMap.mem client.users user_id then
          FMap.lookup client.users user_id
	else
	  begin
	    User.make_is_user_invariant_lemma();
	    User.make { user_id = client.local_user_identifier;
	              device_id = client.local_device_identifier }
	            user_id
          end
  in
  let cryptographic_state', new_u, msg = User.decrypt client.cryptographic_state u p in

  if msg_ok msg client.local_user_identifier p.psending_device then
    begin
      let new_users = FMap.insert client.users user_id new_u in
      (* Need this assertion to trigger the right pattern in sidmapset facts *)
      let users'' = FMap.remove client.users user_id in
      assert (client_session_ids_pre (FMap.insert (FMap.remove client.users user_id) user_id new_u) == client_session_ids_pre (FMap.insert client.users user_id new_u));
      let s1 = get_state () in
      assert (cryptographic_state_invariant cryptographic_state' s1);
      assert (user_invariant new_u s1);
      assert (forall u. FMap.mem users'' u ==> user_invariant (FMap.lookup users'' u) s1);
      {
        client with
    	cryptographic_state = cryptographic_state';
        users = new_users
      }
    end
  else
    begin
      assert (Set.subset (cstate_session_ids cryptographic_state') (cstate_session_ids client.cryptographic_state));
      { client with cryptographic_state = cryptographic_state' }
    end

#pop-options

(** Remove devices and users marked stale since more than
Constants.max_latency seconds *)

let remove_user
  (client: t)
  (user_id: user_id_t):
  t =
  FMap.all_finite_map_facts_lemma () ;
  SidMapSet.all_sidmapset_facts_lemma ();
  let new_client =
    {
        client with users = FMap.remove client.users user_id
    } in
  new_client

#push-options "--z3rlimit 10"

let remove_stale_user (time: nat) (client: t) (u: user_id_t):
    CVSTInv t
      (fun s1 -> client_invariant client s1 /\ FMap.mem client.users u)
      (fun s1 res s2 ->
        (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2) /\
        client_invariant res s2 /\
        (forall u'. FMap.mem client.users u' /\ u' <> u ==> FMap.mem res.users u')) =
  FMap.all_finite_map_facts_lemma () ;
  SidMapSet.all_sidmapset_facts_lemma ();
  let user = FMap.lookup client.users u in
  let remove =
    match User.stale_time user with
    | None -> false
    | Some t_stale ->
      t_stale + Constants.max_latency < time
  in
  if remove then
    begin
      (* Remove the user itself *)
      User.finalize_user user;
      user_invariant_stable_under_session_invariant();
      remove_user client u
    end
  else
    begin
      (* Remove stale devices from user *)
      let user' = User.remove_stale time user in
      user_invariant_stable_under_session_invariant();
      assert (client_session_ids_pre (FMap.insert (FMap.remove client.users u) u user') == client_session_ids_pre (FMap.insert client.users u user'));
      { client with users = FMap.insert client.users u user' }
    end

#pop-options

let rec remove_stale_users (time: nat) (client: t) (l: list user_id_t):
    CVSTInv t
      (fun s1 -> client_invariant client s1 /\ List.noRepeats l /\ (forall (u: user_id_t). List.mem u l ==> FMap.mem client.users u))
      (fun s1 res s2 ->
        (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2) /\
        client_invariant res s2) =
   match l with
   | [] -> client
   | u::l ->
     let client' = remove_stale_user time client u in
     remove_stale_users time client' l

let remove_stale (client: t):
    CVSTInv t
      (fun s1 -> client_invariant client s1)
      (fun s1 res s2 ->
        (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2) /\
        client_invariant res s2) =
  crypto_invariant_stable_under_parallel_rel ();
  session_invariant_stable_under_parallel_rel ();
  client_invariant_stable_under_event ();
  let time = Time.time() in
  remove_stale_users time client (FMap.listdomain client.users)


let rec poll_server
  (ch: net_channel)
  (client: t):
  CVSTInv
    t
    (fun s -> client_invariant client s)
    (fun _ c s -> client_invariant c s) =
  user_invariant_stable_under_event ();
  cryptographic_state_invariant_stable_under_event ();
  let p: packet_t =
    PacketPoll { user_id = client.local_user_identifier;
    	   	 device_id = client.local_device_identifier }
  in
  debug_print "Polling the server\n";
  match Network.Helper.send_packet ch p with
  | NTError s ->
      debug_print ("Network error: "^s^"\n");
      client
  | NTOk () ->
      let response = Network.Helper.recv_packet ch in
      match response with
      | NTError _ ->
         debug_print "Could not receive response\n";
         client
      | NTOk packet ->
         match packet with
	 | PacketMessage p ->
	    debug_print "Received message\n";
            let client' = process_packet_message client p in
	    poll_server ch client'
	 | PacketNoMessage ->
	    (* No more messages *)
	    debug_print "No more messages\n";
            (* The stale records can be safely deleted (without fear of message
               loss) after the next time the device fetches and processes all
               messages from its mailbox *)
	    remove_stale client
         | PacketUserDoesntExist ->
            debug_print "User does not exist\n";
	    client
         | PacketDeviceDoesntExist ->
            debug_print "Device does not exist\n";
	    client
	 | _ ->
	    (* Unexpected reply *)
	    debug_print "Unexpected reply from the server\n";
	    client

#restart-solver (* Workaround a Z3 bug *)
#push-options "--z3rlimit 300"

let send_message
  (ch: net_channel)
  (client: t)
  (target: user_id_t)
  (message: plaintext_t):
  CVSTInv
    t
    (fun s ->
      client_invariant client s /\
      exists uids. List.memP target uids /\
         List.memP (State.FStarEvent
            (Event_Send_Message_Users (client.local_user_identifier) uids message)) (State.events_of s)
    )
    (fun _ c s -> client_invariant c s /\
               client.local_user_identifier = c.local_user_identifier
    ) =
  FMap.all_finite_map_facts_lemma () ;
  SidMapSet.all_sidmapset_facts_lemma ();
  user_invariant_implies_session ();
  User.make_is_user_invariant_lemma () ;
  user_invariant_stable_under_event () ;
  cryptographic_state_invariant_stable_under_event () ;
    let u =
      if FMap.mem client.users target then
        FMap.lookup client.users target
      else
        User.make { user_id = client.local_user_identifier;
	            device_id = client.local_device_identifier }
	       target
    in
    if User.is_stale u then
      begin
        print_string ("User "^user_id_to_string target^" no longer exists. Cannot send a message to it.\n");
	client
      end
    else
      begin
        events_add_event_mem ();
        let tmessage = make_message_record target client.local_user_identifier message in
        add_event (SIGNAL.Events.FStar.Event_Send_Message client.local_user_identifier target tmessage);
        let msg = Helpers.serialize_message_record tmessage in
        let new_u = User.send ch u client.cryptographic_state msg in
        (* Need this assertion to trigger the right pattern in sidmapset facts *)
        assert (client_session_ids_pre (FMap.insert (FMap.remove client.users target) target new_u) == client_session_ids_pre (FMap.insert client.users target new_u));
        let client =
        {
          client with
          users = FMap.insert client.users target new_u;
        } in
    (**) let st2 = get_state_no_par () in
         assert client_invariant client st2;
         client
      end



let rec send_message_users_aux
   (ch:net_channel)
   (client:t)
   (ts: list user_id_t { List.noRepeats ts })
   (full_ts: list user_id_t { List.noRepeats full_ts })
   (message: plaintext_t):
    CVSTInv
     t
     (fun s -> client_invariant client s /\
            List.subset ts full_ts /\
            List.memP (State.FStarEvent
             (Event_Send_Message_Users (client.local_user_identifier) full_ts message)) (State.events_of s)
     )
     (fun _ c s -> client_invariant c s) =
        client_invariant_stable_under_event ();
        match ts with
        | [] -> client
        | hd::tl ->
          assert(List.memP hd full_ts);
          let c = send_message ch client hd message in
          assert (List.subset tl full_ts);
          assert (c.local_user_identifier == client.local_user_identifier);
          let client = send_message_users_aux ch c tl full_ts message in
          client

let send_message_users
  (ch: net_channel)
  (client: t)
  (targets: list user_id_t { List.noRepeats targets })
  (message: bytes):
  CVSTInv
    t
    (fun s -> client_invariant client s)
    (fun _ c s -> client_invariant c s) =
   user_invariant_stable_under_event () ;
   cryptographic_state_invariant_stable_under_event () ;
   if Seq.length message > Constants.max_message_size then
     begin
       print_string "Message too long. Cannot send.\n";
       client
     end
    else
      begin
        events_add_event_mem ();
        (* The recipient set always includes the user's own id *)
        let (targets: list user_id_t { List.noRepeats targets })  =
          if not (List.mem client.local_user_identifier targets) then
            begin
              List.noRepeats_cons client.local_user_identifier targets;
              client.local_user_identifier :: targets
            end
          else
            targets
        in
        add_event (SIGNAL.Events.FStar.Event_Send_Message_Users client.local_user_identifier targets message);
        send_message_users_aux ch client targets targets message
      end

#pop-options

let refresh_keys
  (ch: net_channel)
  (client: t):
  CVSTInv
    t
    (fun s -> client_invariant client s)
    (fun _ c s -> client_invariant c s) =
  FMap.all_finite_map_facts_lemma () ;
  User.make_is_user_invariant_lemma () ;
  user_invariant_stable_under_event () ;
  cryptographic_state_invariant_stable_under_event ();
  user_invariant_stable_under_session_invariant ();
  let st0 = get_state () in
  match regenerate_cryptographic_state client.cryptographic_state with
   | None ->
       debug_print "Could not generate prekeys\n";
       client
   | Some(state', signed_prekey_bundle, one_time_prekeys) ->
       let st = get_state () in
       assert (forall user. User.user_invariant user st0 ==> User.user_invariant user st);
       if Network.Helper.refresh_keys ch
         { user_id = client.local_user_identifier;
       	   device_id = client.local_device_identifier }
	 signed_prekey_bundle one_time_prekeys
       then
         { client with
	   cryptographic_state = state' }
       else
         client

#push-options "--z3rlimit 40"

let remove_device
  (ch: net_channel)
  (client: t):
  CVSTInv
    unit
    (fun s -> client_invariant client s)
    (fun _ _ s1 -> client_invariant client s1) =
  client_invariant_stable_under_event ();
  let _ = Network.Helper.remove_device ch
    { user_id = client.local_user_identifier;
      device_id = client.local_device_identifier }
  in
  ()

#pop-options
