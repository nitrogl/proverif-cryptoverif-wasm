(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
(**

    ---------------  Module Network.Types ---------------

    Defines several types used for Networking.

*)
module Network.Types

open CVTypes
open Lib.ByteSequence
open Lib.IntTypes
open Spec.Chacha20Poly1305
open SIGNAL.Types
open Constants
open FStar.Mul

include MyTypes

friend SIGNAL.Types

let serializer_nonce : serializer nonce_t = serializer_lbytes #12

let increase_nonce
    (n: nonce_t):
    nonce_t =
    (* It would be better to avoid modulo, start a new session if we overflow.
    With the current code, the CryptoVerif model refuses to encrypt
    when the nonce is reused, which protects against attacks but
    prevents sending messages.
    Ideally, we should declare the session stale if the incrementation
    overflows. A stale session is not active (and cannot be moved
    to the head of the list if it is not already at the head).
    It is used for receiving messages but not for sending.
    This mechanism is absent from the Sesame spec because Signal
    sessions can encrypt forever since the keys are renewed by
    ratcheting.
    Note that nonce overflow is unlikely to happen in practice: 
    even if we sent 2^30 messages per second in a single session,
    it would take 2^66 seconds ~ 2.10^12 years! The sun will very
    likely die before that. *)
    nat_to_bytes_le 12 ((nat_from_bytes_le n + 1) % pow2 96)

let serializer_prekey: serializer prekey_t = serializer_lbytes #32

val print_cipher : t_cipher -> FStar.All.ML unit
let print_cipher x =
   CVTypes.print_bytes x._1;
   FStar.IO.print_string ", mac: ";
   CVTypes.print_bytes x._2

let serializer_cipher : serializer t_cipher =
  serializer_pair (serializer_bbytes #max_ciphertext_size) (serializer_lbytes #size_tag)

val size_cipher_lemma (x: t_cipher):
  Lemma (Seq.length (serializer_cipher.serialize x) <= 4 + max_ciphertext_size + size_tag)
let size_cipher_lemma x = ()

val print_signed_prekey_bundle: signed_prekey_bundle_t -> FStar.All.ML unit
let print_signed_prekey_bundle x =
   FStar.IO.print_string "signed prekey: ";
   CVTypes.print_bytes x.prekey;
   FStar.IO.print_string "\nsignature: ";
   CVTypes.print_bytes x.signature

val serializer_signed_prekey_bundle: serializer signed_prekey_bundle_t
let serializer_signed_prekey_bundle : serializer signed_prekey_bundle_t =
    serializer_bij ((fun (x,y) -> { prekey = x; signature = y }), (fun x -> (x.prekey, x.signature)))
      (serializer_pair serializer_prekey (serializer_lbytes #64))

val print_prekey_bundle: prekey_bundle_t -> FStar.All.ML unit
let print_prekey_bundle x =
  print_signed_prekey_bundle x.signed_prekey_bundle;
  FStar.IO.print_string ", ";
  match x.one_time_prekey with
  | None -> FStar.IO.print_string "no one-time prekey"
  | Some (id, k) -> FStar.IO.print_string "one-time prekey: "; CVTypes.print_bytes k;
     FStar.IO.print_string ", id: "; print_prekey_id id

val serializer_prekey_bundle: serializer prekey_bundle_t
let serializer_prekey_bundle : serializer prekey_bundle_t =
    serializer_bij ((fun (x,y) -> { signed_prekey_bundle = x; one_time_prekey = y }),
                    (fun x -> (x.signed_prekey_bundle, x.one_time_prekey)))
      (serializer_pair serializer_signed_prekey_bundle
        (serializer_option (serializer_pair serializer_prekey_id serializer_prekey)))
  

let make_prekey_bundle
    (signed_prekey_bundle: signed_prekey_bundle_t)
    (prekey: option (prekey_id_t & prekey_t)):
    prekey_bundle_t =
    {
        signed_prekey_bundle;
        one_time_prekey = prekey;
    }

#push-options "--ifuel 10"

let imb_bij = ((fun (((x,y),z),t) -> { sender_identity_key = x; ephemeral_1 = y; ephemeral_2 = z; one_time_prekey = t }),
  	       (fun x -> (((x.sender_identity_key, x.ephemeral_1), x.ephemeral_2), x.one_time_prekey)))

val serializer_init_message_bundle: serializer init_message_bundle_t
let serializer_init_message_bundle : serializer init_message_bundle_t =
  serializer_bij imb_bij 
      (serializer_pair
          (serializer_pair
	     (serializer_pair serializer_identity_key serializer_prekey)
	     serializer_prekey)
	  (serializer_option serializer_prekey_id))

let make_init_message_bundle
    (sender_identity_key: identity_key_t)
    (ephemeral_1: prekey_t)
    (ephemeral_2: prekey_t)
    (one_time_prekey: option prekey_id_t):
    init_message_bundle_t =
    {
	sender_identity_key ;
        ephemeral_1 ;
        ephemeral_2 ;
        one_time_prekey ;
    }


val size_option_prekey_id_lemma (x: option prekey_id_t) :
  Lemma (Seq.length ((serializer_option serializer_prekey_id).serialize x) <= 2)
let size_option_prekey_id_lemma x =
  size_option_lemma serializer_prekey_id x;
  match x with
  | None -> ()
  | Some y -> size_prekey_id_lemma y

val size_init_message_bundle_lemma (x: init_message_bundle_t) :
    Lemma
    (ensures (Seq.length (serializer_init_message_bundle.serialize x) <= 130))
let size_init_message_bundle_lemma x =
  size_bij_lemma imb_bij
      (serializer_pair
          (serializer_pair
	     (serializer_pair serializer_identity_key serializer_prekey)
	     serializer_prekey)
	  (serializer_option serializer_prekey_id)) x;
  size_pair_lemma
          (serializer_pair
	     (serializer_pair serializer_identity_key serializer_prekey)
	     serializer_prekey)
	  (serializer_option serializer_prekey_id)
       (((x.sender_identity_key, x.ephemeral_1), x.ephemeral_2), x.one_time_prekey);
  size_pair_lemma
	     (serializer_pair serializer_identity_key serializer_prekey)
	     serializer_prekey
       ((x.sender_identity_key, x.ephemeral_1), x.ephemeral_2);
  size_pair_lemma serializer_identity_key serializer_prekey (x.sender_identity_key, x.ephemeral_1);
  size_identity_key_lemma x.sender_identity_key;
  size_lbytes_lemma #32 x.ephemeral_1;
  size_lbytes_lemma #32 x.ephemeral_2;
  size_option_prekey_id_lemma x.one_time_prekey

#pop-options

val size_option_init_message_bundle_lemma (x: option init_message_bundle_t) :
  Lemma (Seq.length ((serializer_option serializer_init_message_bundle).serialize x) <= 131)
let size_option_init_message_bundle_lemma x =
  size_option_lemma serializer_init_message_bundle x;
  match x with
  | None -> ()
  | Some y ->
      size_init_message_bundle_lemma y


let print_user_device_id x =
  FStar.IO.print_string "device ";
  print_device_id x.device_id;
  FStar.IO.print_string " of user ";
  print_user_id x.user_id

let serializer_user_device_id : serializer user_device_id_t =
  serializer_bij ((fun (x,y) -> { user_id = x; device_id = y }),
  		  (fun x -> (x.user_id, x.device_id)))
    (serializer_pair serializer_user_id serializer_device_id)
    
val print_list (#t: Type0) (f: t -> FStar.All.ML unit) (l: list t): FStar.All.ML unit
let rec print_list f = function
  | [] -> ()
  | [a] -> f a
  | a::l -> f a; FStar.IO.print_string ", "; print_list f l

open FStar.List

let list_as_dep_pair (a: Type0) = (x: nat_n 1 & llist a x)

let serializer_blist (#a: Type0) (ser: serializer a) :
  serializer (lbyte_list a) =
    serializer_bij ((fun ((|x,y|): list_as_dep_pair a) -> y <: lbyte_list a),
    		    (fun (x: lbyte_list a) -> (|List.length x, x|) <: list_as_dep_pair a))
      (serializer_dep_pair (serializer_nat_n 1) (serializer_llist #a ser))

let print_device_update x =
  FStar.IO.print_string "  devices removed: ";
  print_list print_device_id x.devices_removed;
  FStar.IO.print_string "\n  devices added:\n";
  List.iter (fun (id, key) ->
    print_device_id id;
    FStar.IO.print_string "(";
    print_identity_key key;
    FStar.IO.print_string ")\n"
    ) x.devices_added

let serializer_device_update : serializer device_update_t =
  serializer_bij ((fun (x,y) -> { devices_removed = x; devices_added = y }),
  		  (fun x -> (x.devices_removed, x.devices_added)))
    (serializer_pair (serializer_blist serializer_device_id)
    		     (serializer_blist (serializer_pair serializer_device_id serializer_identity_key)))

let serializer_encrypted_message : serializer encrypted_message_t =
  serializer_bij ((fun (x,y,z) -> { init_msg = x; counter = y; ciphertext = z }),
  		  (fun x -> (x.init_msg, x.counter, x.ciphertext)))
    (serializer_triple (serializer_option serializer_init_message_bundle)
       serializer_nonce serializer_cipher)

val size_encrypted_message_lemma (x: encrypted_message_t) :
    Lemma
    (ensures (Seq.length (serializer_encrypted_message.serialize x) <= 147 + Constants.max_ciphertext_size + Spec.Chacha20Poly1305.size_tag))
let size_encrypted_message_lemma x =
  size_bij_lemma ((fun (x,y,z) -> { init_msg = x; counter = y; ciphertext = z }),
  		  (fun x -> (x.init_msg, x.counter, x.ciphertext)))
    (serializer_triple (serializer_option serializer_init_message_bundle)
       serializer_nonce serializer_cipher) x;
  size_triple_lemma (serializer_option serializer_init_message_bundle) 
       serializer_nonce serializer_cipher (x.init_msg, x.counter, x.ciphertext);
  size_option_init_message_bundle_lemma x.init_msg;
  size_cipher_lemma x.ciphertext;
  size_lbytes_lemma #12 x.counter

let encrypted_message_not_too_big x = size_encrypted_message_lemma x

let print_prepacket x =
  FStar.IO.print_string "device ";
  print_device_id x.receiving_device;
  FStar.IO.print_string ": ";
  print_bytes x.content;
  FStar.IO.print_string "\n"

val serializer_pre_packet: serializer pre_packet_t
let serializer_pre_packet : serializer pre_packet_t =
  serializer_bij ((fun (x,y) -> { receiving_device = x; content = y }),
                  (fun (x: pre_packet_t) -> (x.receiving_device, x.content)))
    (serializer_pair serializer_device_id (serializer_bbytes #max_pre_packet_content_size))

let serializer_list_pre_packet: serializer (lbyte_list pre_packet_t) =
  serializer_blist serializer_pre_packet

let make_pre_packet (d: device_id_t) (c: bbytes max_pre_packet_content_size) = 
  { receiving_device = d ; content = c }

let print_packet_messages (x: packet_messages_t) =
  FStar.IO.print_string "from ";
  print_user_device_id x.sending_device;
  FStar.IO.print_string " to user ";
  print_user_id x.receiving_user;
  FStar.IO.print_string ":\n";
  List.iter print_prepacket x.messages

let serializer_packet_messages : serializer packet_messages_t =
  serializer_bij ((fun (x,y,z) -> { receiving_user = y; sending_device = x; messages = z }),
  		  (fun (x: packet_messages_t) -> (x.sending_device, x.receiving_user, x.messages)))
    (serializer_triple serializer_user_device_id serializer_user_id
       (serializer_blist serializer_pre_packet))

let print_packet_sync_messages (x: packet_sync_messages_t) =
  FStar.IO.print_string "from ";
  print_user_device_id x.sending_device;
  FStar.IO.print_string ":\n";
  List.iter print_prepacket x.messages

let serializer_packet_sync_messages : serializer packet_sync_messages_t =
  serializer_bij ((fun (x,y) -> { sending_device = x; messages = y }),
  		  (fun (x: packet_sync_messages_t) -> (x.sending_device, x.messages)))
    (serializer_pair serializer_user_device_id
       (serializer_blist serializer_pre_packet))

let print_packet_message x =
  FStar.IO.print_string "from ";
  print_user_device_id x.psending_device;
  FStar.IO.print_string ", ";
  print_bytes x.content

let serializer_packet_message : serializer packet_message_t =
  serializer_bij ((fun (x,y) -> { psending_device = x; content = y }),
  		  (fun x -> (x.psending_device, x.content)))
    (serializer_pair serializer_user_device_id (serializer_bbytes #max_pre_packet_content_size))

let max_tag = 19

let tag_t = (tag: nat { tag <= max_tag })

let serializer_tag : serializer tag_t =
  serializer_filter (fun (x: nat { x < 256 }) -> x <= max_tag)
    (serializer_nat_n 1)

let packet_snd_type (tag: tag_t) =
  match tag with
  | 1 | 6 | 8 | 12 | 13 | 17 | 18 | 0 -> unit
  | 2 -> user_id_t
  | 3 -> user_id_t & (identity_key_t & (signed_prekey_bundle_t & lbyte_list (prekey_id_t & prekey_t)))
  | 4 -> device_id_t
  | 5 | 9 | 15 -> user_device_id_t
  | 7 -> user_device_id_t & (signed_prekey_bundle_t & lbyte_list (prekey_id_t & prekey_t))
  | 10 -> prekey_bundle_t
  | 11 -> packet_messages_t
  | 19 -> packet_sync_messages_t
  | 14 -> device_update_t
  | 16 -> packet_message_t

let packet_dep_pair = tag: tag_t & packet_snd_type tag

let packet_to_dep_pair : packet_t -> packet_dep_pair =
  function
  | PacketCreateUserRequest -> (| 1, () |)
  | PacketCreateUser user_id -> (| 2, user_id |)
  
  | PacketCreateDeviceRequest(user_id, identity_key, signed_prekey_bundle, prekeys) -> (| 3, (user_id,  (identity_key, (signed_prekey_bundle, prekeys))) |)
  | PacketCreateDevice device_id -> (| 4, device_id |)

  | PacketRemoveDeviceRequest user_device_id -> (| 5, user_device_id |)
  | PacketRemoveDeviceAccepted -> (| 6, () |)

  | PacketPrekeys(user_device_id, signed_prekey_bundle, prekeys) ->
  (| 7, (user_device_id, (signed_prekey_bundle, prekeys)) |)
  | PacketPrekeysAccepted -> (| 8, () |)

  | PacketPrekeyBundleRequest user_device_id -> (| 9, user_device_id |)
  | PacketPrekeyBundle prekey_bundle -> (| 10, prekey_bundle |)

  | PacketMessages packet_messages -> (| 11, packet_messages |)
  | PacketSyncMessages packet_sync_messages -> (| 19, packet_sync_messages |)
  | PacketMessagesAccepted -> (| 12, () |)
  | PacketUserDoesntExist -> (| 13, () |)
  | PacketListOfDevicesIncorrect device_update -> (| 14, device_update |)

  | PacketPoll user_device_id -> (| 15, user_device_id |)
  | PacketMessage packet_message -> (| 16, packet_message |)
  | PacketNoMessage -> (| 17, () |)
  
  | PacketDeviceDoesntExist -> (| 18, () |)
  | PacketError -> (| 0, () |)

let dep_pair_to_packet : packet_dep_pair -> packet_t =
  function
  | (| 1, _ |) -> PacketCreateUserRequest
  | (| 2, y |) -> PacketCreateUser y
 
  | (| 3, y |) ->
    let (user_id,  (identity_key, (signed_prekey_bundle, prekeys))) = y in
    PacketCreateDeviceRequest(user_id, identity_key, signed_prekey_bundle, prekeys)
  | (| 4, y |) -> PacketCreateDevice y

  | (| 5, y |) -> PacketRemoveDeviceRequest y
  | (| 6, _ |) -> PacketRemoveDeviceAccepted 

  | (| 7, y |) ->
     let (user_device_id, (signed_prekey_bundle, prekeys)) = y in
     PacketPrekeys(user_device_id, signed_prekey_bundle, prekeys)
  | (| 8, _ |) -> PacketPrekeysAccepted

  | (| 9, y |) -> PacketPrekeyBundleRequest y
  | (| 10, y |) -> PacketPrekeyBundle y

  | (| 11, y |) -> PacketMessages y
  | (| 19, y |) -> PacketSyncMessages y
  | (| 12, _ |) -> PacketMessagesAccepted
  | (| 13, _ |) -> PacketUserDoesntExist
  | (| 14, y |) -> PacketListOfDevicesIncorrect y

  | (| 15, y |) -> PacketPoll y
  | (| 16, y |) -> PacketMessage y
  | (| 17, _ |) -> PacketNoMessage
  | (| 18, _ |) -> PacketDeviceDoesntExist

  | (| 0, _ |) -> PacketError

#push-options "--ifuel 10"

let serializer_packet : serializer packet_t =
  serializer_bij (dep_pair_to_packet, packet_to_dep_pair)
    (serializer_dep_pair #tag_t #packet_snd_type serializer_tag
       (function
         | 1 | 6 | 8 | 12 | 13 | 17 | 18 | 0 -> serializer_ghost
	 | 2 -> serializer_user_id
	 | 3 ->
	   serializer_pair serializer_user_id
	     (serializer_pair serializer_identity_key
	     (serializer_pair serializer_signed_prekey_bundle
	     (serializer_blist
	       (serializer_pair serializer_prekey_id serializer_prekey))))
	 | 4 -> serializer_device_id
	 | 5 | 9 | 15 -> serializer_user_device_id
	 | 7 ->
	   serializer_pair serializer_user_device_id
	     (serializer_pair serializer_signed_prekey_bundle
	     (serializer_blist
	       (serializer_pair serializer_prekey_id serializer_prekey)))
	 | 10 -> serializer_prekey_bundle
	 | 11 -> serializer_packet_messages
         | 19 -> serializer_packet_sync_messages
	 | 14 -> serializer_device_update
	 | 16 -> serializer_packet_message))
       
#pop-options

let print_packet p = 
  match p with
  | PacketCreateUserRequest ->
      FStar.IO.print_string "PacketCreateUserRequest"
  | PacketCreateUser user_id ->
      FStar.IO.print_string "PacketCreateUser ";
      print_user_id user_id
      
  | PacketCreateDeviceRequest(user_id, identity_key, signed_prekey_bundle, prekeys) ->
      FStar.IO.print_string "PacketCreateDeviceRequest for user ";
      print_user_id user_id;
      FStar.IO.print_string "\n";
      print_identity_key identity_key;
      FStar.IO.print_string "\n";
      print_signed_prekey_bundle signed_prekey_bundle;
      FStar.IO.print_string "\none-time prekeys:\n";
      List.iter (fun ((id,k): prekey_id_t & prekey_t) ->
	 FStar.IO.print_string "[id: ";
	 print_prekey_id id;
	 FStar.IO.print_string "] ";
         CVTypes.print_bytes k;
         FStar.IO.print_string "\n"
	 		     ) prekeys
      
  | PacketCreateDevice device_id ->
      FStar.IO.print_string "PacketCreateDevice ";
      print_device_id device_id

  | PacketRemoveDeviceRequest user_device_id ->
      FStar.IO.print_string "PacketRemoveDeviceRequest ";
      print_user_device_id user_device_id
  | PacketRemoveDeviceAccepted ->
      FStar.IO.print_string "PacketRemoveDeviceAccepted"
      
  | PacketPrekeys(user_device_id, signed_prekey_bundle, prekeys) ->
      FStar.IO.print_string "PacketPrekeys ";
      print_user_device_id user_device_id;
      FStar.IO.print_string "\n";
      print_signed_prekey_bundle signed_prekey_bundle;
      FStar.IO.print_string ",\n one-time prekeys:\n";
      List.iter (fun ((id,k): prekey_id_t & prekey_t) ->
         CVTypes.print_bytes k;
	 FStar.IO.print_string "[id: ";
	 print_prekey_id id;
	 FStar.IO.print_string "]\n"
	 		     ) prekeys
  | PacketPrekeysAccepted -> 
      FStar.IO.print_string "PacketPrekeysAccepted"
      
  | PacketPrekeyBundleRequest user_device_id -> 
      FStar.IO.print_string "PacketPrekeyBundleRequest";
      print_user_device_id user_device_id
  | PacketPrekeyBundle prekey_bundle -> 
      FStar.IO.print_string "PacketPrekeyBundle ";
      print_prekey_bundle prekey_bundle
      
  | PacketMessages packet_messages -> 
      FStar.IO.print_string "PacketMessages ";
      print_packet_messages packet_messages
  | PacketSyncMessages packet_messages -> 
      FStar.IO.print_string "PacketSyncMessages ";
      print_packet_sync_messages packet_messages
  | PacketMessagesAccepted -> 
      FStar.IO.print_string "PacketMessagesAccepted"
  | PacketUserDoesntExist -> 
      FStar.IO.print_string "PacketUserDoesntExist"
  | PacketListOfDevicesIncorrect device_update ->
      FStar.IO.print_string "PacketListOfDevicesIncorrect\n";
      print_device_update device_update

  | PacketPoll user_device_id ->
      FStar.IO.print_string "PacketPoll ";
      print_user_device_id user_device_id  
  | PacketMessage packet_message -> 
      FStar.IO.print_string "PacketMessage ";
      print_packet_message packet_message
  | PacketNoMessage -> 
      FStar.IO.print_string "PacketNoMessage"
      
  | PacketDeviceDoesntExist ->
      FStar.IO.print_string "PacketDeviceDoesntExist"
  | PacketError ->
      FStar.IO.print_string "PacketError"
  
