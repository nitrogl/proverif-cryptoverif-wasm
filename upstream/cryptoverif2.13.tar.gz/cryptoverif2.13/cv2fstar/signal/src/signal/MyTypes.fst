(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module MyTypes

open Lib.ByteSequence
open CVTypes
open Lib.IntTypes

let print_identity_key id =
  IO.print_string "id_key: ";
  CVTypes.print_bytes id.identity_key;
  IO.print_string "\nsign_key: ";
  CVTypes.print_bytes id.signature_key

let serializer_identity_key : serializer identity_key_t =
  serializer_bij ((fun (x,y) -> { identity_key = x; signature_key = y }), (fun x -> (x.identity_key, x.signature_key)))
    (serializer_pair (serializer_lbytes #32) (serializer_lbytes #32))

let size_identity_key_lemma x =
  size_bij_lemma ((fun (x,y) -> { identity_key = x; signature_key = y }), (fun x -> (x.identity_key, x.signature_key)))
    (serializer_pair (serializer_lbytes #32) (serializer_lbytes #32)) x;
  size_pair_lemma (serializer_lbytes #32) (serializer_lbytes #32) (x.identity_key, x.signature_key);
  size_lbytes_lemma #32 x.identity_key;
  size_lbytes_lemma #32 x.signature_key

let user_id_t: eqtype = pub_int_t U64
let equal_user_id_t : user_id_t -> user_id_t -> bool  = Lib.IntTypes.eq
let make_user_id n = mk_int #U64 #PUB n
let print_user_id id = IO.print_string (string_of_int (v id))
let user_id_to_string id = (string_of_int (v id))
let serializer_user_id: serializer user_id_t = serializer_int #U64
let size_user_id_lemma x = size_int_lemma #U64 x 

let device_id_t: eqtype = (x: pub_int_t U8 { v #U8 x < Constants.max_devices_per_user })
let make_device_id n = mk_int #U8 #PUB n
let print_device_id id = IO.print_string (string_of_int (v #U8 id))
let device_id_to_string id = (string_of_int (v #U8 id))
let serializer_device_id: serializer device_id_t =
  serializer_filter (fun x -> v #U8 x < Constants.max_devices_per_user)
    (serializer_int #U8)

let dev_v (x: device_id_t) : FStar.Fin.under Constants.max_devices_per_user = v #U8 x

let rec exhibit_same (#a: eqtype) (l: list a) (i1: nat {i1 < List.length l}) (i2: nat {i2 < List.length l}) :
  Lemma (requires (List.noRepeats l /\ List.Tot.index l i1 == List.Tot.index l i2 /\ i1 <> i2))
  (ensures False) =
  if i1 = 0 then
    match l with
    | h::r ->
       assert (h = List.Tot.index l i1);
       List.lemma_index_memP r (i2-1);
       assert (List.mem (List.Tot.index l i2) r);
       assert (List.mem h r)
  else if i2 = 0 then
    match l with
    | h::r ->
       assert (h = List.Tot.index l i2);
       List.lemma_index_memP r (i1-1);
       assert (List.mem (List.Tot.index l i1) r);
       assert (List.mem h r)
  else
    match l with
    | h::r ->
       exhibit_same r (i1-1) (i2-1)

let len_devices_contrap (l: list device_id_t) : Lemma
  (requires (List.length l > Constants.max_devices_per_user /\ List.noRepeats l))
  (ensures False) =
  let s = Seq.init #(FStar.Fin.under Constants.max_devices_per_user) (Constants.max_devices_per_user + 1) (fun i -> dev_v (List.Tot.index l i)) in
  let (i1,i2) = FStar.Fin.pigeonhole #Constants.max_devices_per_user s in
  assert(dev_v(List.Tot.index l i1) == dev_v(List.Tot.index l i2) /\ i1 <> i2);
  Lib.IntTypes.v_injective #U8 #PUB (List.Tot.index l i1);
  Lib.IntTypes.v_injective #U8 #PUB (List.Tot.index l i2);
  exhibit_same l i1 i2

let len_devices =
  Classical.move_requires len_devices_contrap

let prekey_id_t = pub_int_t U8
let make_prekey_id n = mk_int #U8 #PUB n
let print_prekey_id (x: prekey_id_t) : FStar.All.ML unit =
  FStar.IO.print_string (string_of_int (v #U8 #PUB x))
let serializer_prekey_id: serializer prekey_id_t = serializer_int #U8
let size_prekey_id_lemma x = size_int_lemma #U8 x

noeq
type internal_message_record_t = {
  receiver_uid: user_id_t;
  sender_uid: user_id_t;
  plaintext: plaintext_t;
}

let message_record_t = if Constants.checkuid then internal_message_record_t else plaintext_t

let make_message_record receiver_uid sender_uid plaintext = 
  if Constants.checkuid then
    { receiver_uid; sender_uid; plaintext }
  else 
    plaintext

let checkuid receiver_uid sender_uid msg =
  if Constants.checkuid then
    msg.receiver_uid = receiver_uid && msg.sender_uid = sender_uid
  else
    true

let get_plaintext msg =
  if Constants.checkuid then
    msg.plaintext
  else
    msg    

let checkuid_lemma receiver_uid' sender_uid' receiver_uid sender_uid msg = ()
let get_plaintext_lemma receiver_uid sender_uid msg = ()

let serializer_internal_message_record : serializer internal_message_record_t = 
  serializer_bij ((fun (x,y,z) -> { receiver_uid = x; sender_uid = y; plaintext = z }),
                 (fun x -> (x.receiver_uid, x.sender_uid, x.plaintext)))
    (serializer_triple serializer_user_id serializer_user_id (serializer_bbytes #Constants.max_message_size))

let serializer_message_record = 
  if Constants.checkuid then
    serializer_internal_message_record 
  else
    serializer_bbytes #Constants.max_message_size

let size_internal_message_record_lemma (x: internal_message_record_t) :
  Lemma (Seq.length (serializer_internal_message_record.serialize x) <= Constants.max_ciphertext_size) =
    size_bij_lemma ((fun (x,y,z) -> { receiver_uid = x; sender_uid = y; plaintext = z }),
                   (fun x -> (x.receiver_uid, x.sender_uid, x.plaintext)))
      (serializer_triple serializer_user_id serializer_user_id (serializer_bbytes #Constants.max_message_size))
      x;
    size_triple_lemma serializer_user_id serializer_user_id (serializer_bbytes #Constants.max_message_size)
      (x.receiver_uid, x.sender_uid, x.plaintext);
    size_int_lemma #U64 x.receiver_uid;
    size_int_lemma #U64 x.sender_uid;
    size_bbytes_lemma #Constants.max_message_size x.plaintext

let size_message_record_lemma x =
  if Constants.checkuid then
    size_internal_message_record_lemma x
  else
    size_bbytes_lemma #Constants.max_message_size x
