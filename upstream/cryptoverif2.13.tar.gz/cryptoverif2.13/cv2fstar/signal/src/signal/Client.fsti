(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
(**

    ---------------  Module Client ---------------

    Main interface with the library. It exposes functions to send and receive messsages and to create new clients.
*)
module Client

open User

open SIGNAL.Effect
open SIGNAL.Protocol
open SIGNAL.Queries
open SIGNAL.Events
open SIGNAL.Events.FStar

open Lib.ByteSequence

open Network.Types
open Network

(*** Client module *)

(**
  Type for client.
*)
val t: Type0

(**
  CVST type invariant.
*)
val client_invariant
  (client: t)
  (st: signal_state):
  Type0

val client_invariant_stable_under_event (_: unit): Lemma (
    forall s1 s2 c. SIGNAL.InvariantLemmas.rel' s1 s2 ==> State.local_sessions_are_equal s1 s2 ==> client_invariant c s1 ==> client_invariant c s2
)

(**
    Returns the set of session ids in a given client
*)
val client_session_ids: (client: t) -> GTot (Set.set SidMap.sidt)

(**
  Creates a fresh client, using the given user identifier.

  This is usefull when one wants to associate a new device with an existing user.
*)
val make_from_user
  (ch: net_channel)
  (local_user_identifier: user_id_t):
  CVSTInv (option t)
    (fun _ -> True)
    (fun _ res s -> match res with | Some u -> client_invariant u s | None -> True)

(**
  Creates a fresh user and device.
*)
val make
  (ch: net_channel):
  CVSTInv (option t)
    (fun _ -> True)
    (fun _ res s -> match res with | Some u -> client_invariant u s | None -> True)

(**
  Checks the server for updates.

  This include new messages in the
*)
val poll_server
  (ch: net_channel)
  (client: t):
  CVSTInv
    t
    (fun s -> client_invariant client s)
    (fun _ c s -> client_invariant c s)

(**
  Send a message to the list of targets.
*)
val send_message_users
  (ch: net_channel)
  (client: t)
  (targets: list user_id_t { List.noRepeats targets })
  (message: bytes):
  CVSTInv
    t
    (fun s -> client_invariant client s)
    (fun _ c s -> client_invariant c s)

(**
  Refresh the signed prekey and one-time prekeys
*)
val refresh_keys
  (ch: net_channel)
  (client: t):
  CVSTInv
    t
    (fun s -> client_invariant client s)
    (fun _ c s -> client_invariant c s)

(**
  Remove the local device
*)
val remove_device
  (ch: net_channel)
  (client: t):
  CVSTInv
    unit
    (fun s -> client_invariant client s)
    (fun _ _ s1 -> client_invariant client s1)
