(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module Crypto.Abstraction

(*
    Note: I will use only little endian for the representation of numbers as bytes in this module.
*)

open FStar.Option
open FStar.List.Tot

open CVTypes
open Lib.Sequence
open Lib.ByteSequence
open Lib.IntTypes
open Spec.Chacha20Poly1305
open MyTypes
open Network.Types
open Constants
open State

open SIGNAL.Tables
open SIGNAL.Types
open SIGNAL.Events
open SIGNAL.Events.FStar
open SIGNAL.Functions
open SIGNAL.Effect
open SIGNAL.Protocol
open SIGNAL.Sessions
open SIGNAL.Gen

friend SIGNAL.Types

module FMap = FStar.FiniteMap.Base

(*
    The scheme changes slightly depending on if
    we have a one-time prekey or not.
*)
type encryption_scheme_t =
    | WithOnetimePrekey
    | WithoutOnetimePrekey

(*
    The role determines if we are the initiator or the responder.
    The function names to apply differs depending on the case.
*)
type role_t =
    | Initiator
    | Responder

(**
    Sessions will be managed here and used as a black box.
*)
noeq
type session_t: Type0 = {
    sid:                SidMap.sidt ;
    last_used_nonce:    nonce_t ;
    encryption_scheme:  encryption_scheme_t ;
    role:               role_t ;
    local_identity_key:     Ghost.erased identity_key_t;
    local_user_id:          Ghost.erased user_id_t;
    remote_identity_key:    Ghost.erased identity_key_t;
    remote_user_id:         Ghost.erased user_id_t;
    (* The field [init_message] is [Some ...] when the session
       is "initial". In this case, the initial message is
       attached to every message sent.
       This field is cleared when we receive a message in the session *)
    init_message:           option init_message_bundle_t
}

let session_id session = session.sid
let local_user_id session = session.local_user_id
let remote_user_id session = session.remote_user_id

(** Utility functions *)

let get_sid
    (session: session_t):
    SidMap.sidt =
    session.sid

let session_sid_is_local_and_session
    (session: session_t)
    (st: signal_state):
    prop =
    State.is_local session.sid st /\
    State.is_session session.sid st

(**
    A key invariant: identity keys in all session entries match the ones specified in the session.
    This invariant is a bit hairy, and blows up Z3 reasoning. We make it opaque, and instead
    expose lemmas corresponding to each of the oracles
*)

let session_keys_match_session_entry (local_id: cv_user_id_t) (local: identity_key_t) (remote_id: cv_user_id_t) (remote: identity_key_t) (e: signal_session_entry) : prop = match e with
  | R1_Odec1 _ _ local_key local_signkey remote_uid local_uid remote_key remote_signkey
  | R1_Odec2 _ _ local_key local_signkey remote_uid local_uid remote_key remote_signkey
  | R1_Odec3 _ _ local_key local_signkey remote_uid local_uid remote_key remote_signkey
  | R1_Odec4 _ _ local_key local_signkey remote_uid local_uid remote_key remote_signkey
  | R1_Oenc1 _ _ local_key local_signkey remote_uid local_uid remote_key remote_signkey
  | R1_Oenc2 _ _ local_key local_signkey remote_uid local_uid remote_key remote_signkey
  | R1_Oenc3 _ _ local_key local_signkey remote_uid local_uid remote_key remote_signkey
  | R1_Oenc4 _ _ local_key local_signkey remote_uid local_uid remote_key remote_signkey ->
         remote == mk_identity_key remote_key remote_signkey /\
         local == mk_identity_key local_key local_signkey /\
         local_uid == local_id /\
         remote_uid == remote_id
  | _ -> True

let session_keys_match_session_entries' local_id local remote_id remote (es: list signal_session_entry) =
  List.Tot.for_allP (session_keys_match_session_entry local_id local remote_id remote) es

[@@"opaque_to_smt"]
let session_keys_match_session_entries (ssid: SidMap.sidt) (local_id: cv_user_id_t) (local: identity_key_t) (remote_id: cv_user_id_t) (remote: identity_key_t) (st: signal_state) =
  match SidMap.get (State.sessions_of st) ssid with
  | None -> True
  | Some es -> session_keys_match_session_entries' local_id local remote_id remote es

let session_invariant
    (session: session_t)
    (st: signal_state):
    prop =
    is_valid_local_key session.local_identity_key session.local_user_id st /\
    is_valid_remote_key session.remote_identity_key session.remote_user_id st /\
    session_sid_is_local_and_session session st /\
    session_keys_match_session_entries session.sid (Helpers.get_cv_uid session.local_user_id) session.local_identity_key (Helpers.get_cv_uid session.remote_user_id) session.remote_identity_key st

let session_invariant_stable_under_event (_: unit): Lemma (
    forall s1 s2 d. SIGNAL.InvariantLemmas.rel' s1 s2 ==> State.local_sessions_are_equal s1 s2 ==> session_invariant d s1 ==> session_invariant d s2
) = reveal_opaque (`%session_keys_match_session_entries) session_keys_match_session_entries

let session_invariant_stable_under_parallel_rel (_: unit): Lemma (
    forall s1 s2 s. SIGNAL.InvariantLemmas.parallel_rel' s1 s2 ==> session_invariant s s1 ==> session_invariant s s2
) = reveal_opaque (`%session_keys_match_session_entries) session_keys_match_session_entries

let session_keys_stable_under_parallel_rel (sid: SidMap.sidt)  (local_id: cv_user_id_t) (local: identity_key_t) (remote_id: cv_user_id_t) (remote: identity_key_t) : Lemma (forall s0 s1.
    is_local sid s0 /\ session_keys_match_session_entries sid local_id local remote_id remote s0 /\ SIGNAL.InvariantLemmas.parallel_rel' s0 s1 ==>
      session_keys_match_session_entries sid local_id local remote_id remote s1)
  = reveal_opaque (`%session_keys_match_session_entries) session_keys_match_session_entries

let session_invariant_implies_session () = ()

noeq
type cryptographic_state_t' = {
    one_time_prekey_id_to_sid:         FMap.map prekey_id_t SidMap.sidt ;
    signed_prekey_bundle:              signed_prekey_bundle_t ;
    principal_sid:                     SidMap.sidt ;
    long_time_prekey_sid:              SidMap.sidt ;
    personal_user_id:                  user_id_t;
    personal_identity_key:             identity_key_t;
}

let cstate_session_ids' (map: FMap.map prekey_id_t SidMap.sidt) =
  SidMapSetBase.fold_map_set map Set.singleton

let cryptographic_state_t = s:cryptographic_state_t'{
  SidMapSetBase.all_disjoint_sets s.one_time_prekey_id_to_sid Set.singleton /\
  Set.disjoint (Set.singleton s.long_time_prekey_sid) (cstate_session_ids' s.one_time_prekey_id_to_sid)
}

let get_personal_user_id s = s.personal_user_id

let long_time_prekey_sid_is_local_and_session (state: cryptographic_state_t) (st: signal_state) =
    State.is_local state.long_time_prekey_sid st /\
    State.is_session state.long_time_prekey_sid st

let principal_sid_is_local_and_session (state: cryptographic_state_t) (st: signal_state) =
    State.is_local state.principal_sid st /\
    State.is_session state.principal_sid st

let all_sid_in_one_time_prekey_id_to_sid_are_local_and_session (state: cryptographic_state_t) (st: signal_state) =
    forall sid. (FMap.values state.one_time_prekey_id_to_sid sid) ==> (State.is_local sid st /\ State.is_session sid st)

let crypto_keys_match_session_entry (local_id: cv_user_id_t) (local: identity_key_t) (e: signal_session_entry) : prop = match e with
  // If a session id is in a cryptographic_state, then it is not yet at the stage where both parties are known
  | R1_Odec1 _ _ _ _ _ _ _ _
  | R1_Odec2 _ _ _ _ _ _ _ _
  | R1_Odec3 _ _ _ _ _ _ _ _
  | R1_Odec4 _ _ _ _ _ _ _ _
  | R1_Oenc1 _ _ _ _ _ _ _ _
  | R1_Oenc2 _ _ _ _ _ _ _ _
  | R1_Oenc3 _ _ _ _ _ _ _ _
  | R1_Oenc4 _ _ _ _ _ _ _ _  -> False
  | R1_Osend1 local_key local_signkey _ _ local_uid 
  | R1_Osend2 local_key local_signkey _ _ local_uid 
  | R1_Osend3 _ local_key local_signkey _ _ local_uid 
  | R1_Osend4 local_key local_signkey _ _ local_uid 
  | R1_Orecv1 local_key local_signkey _ local_uid 
  | R1_Orecv2 local_key local_signkey _ local_uid ->
    local == mk_identity_key local_key local_signkey /\
    local_uid == local_id
  | _ -> True

let crypto_keys_match_session_entries' local_id local (st: signal_state) (es: list signal_session_entry) =
  List.Tot.for_allP (crypto_keys_match_session_entry local_id local) es

[@@"opaque_to_smt"]
let crypto_keys_match_session_entries (ssid: SidMap.sidt) (local_id: cv_user_id_t) (local: identity_key_t) (st: signal_state) =
  match SidMap.get (State.sessions_of st) ssid with
  | None -> True
  | Some es -> crypto_keys_match_session_entries' local_id local st es

let all_prekeys_sessions_match_keys (prekeys: FMap.map prekey_id_t SidMap.sidt) (local_id: cv_user_id_t) (local: identity_key_t) (st: signal_state) =
  forall sid. FMap.values prekeys sid ==> crypto_keys_match_session_entries sid local_id local st

let cryptographic_state_invariant (state: cryptographic_state_t) (st: signal_state) =
       is_valid_local_key state.personal_identity_key state.personal_user_id st
    /\ long_time_prekey_sid_is_local_and_session state st
    /\ principal_sid_is_local_and_session state st
    /\ all_sid_in_one_time_prekey_id_to_sid_are_local_and_session state st
    /\ crypto_keys_match_session_entries state.principal_sid (Helpers.get_cv_uid state.personal_user_id) state.personal_identity_key st
    /\ crypto_keys_match_session_entries state.long_time_prekey_sid (Helpers.get_cv_uid state.personal_user_id) state.personal_identity_key st
    /\ all_prekeys_sessions_match_keys state.one_time_prekey_id_to_sid (Helpers.get_cv_uid state.personal_user_id) state.personal_identity_key st

let cryptographic_state_invariant_stable_under_event (_: unit): Lemma (
    forall s1 s2 c. SIGNAL.InvariantLemmas.rel' s1 s2 ==>
    State.local_sessions_are_equal s1 s2 ==>
    cryptographic_state_invariant c s1 ==>
    cryptographic_state_invariant c s2
) = reveal_opaque (`%crypto_keys_match_session_entries) crypto_keys_match_session_entries

let crypto_invariant_stable_under_parallel_rel (_: unit): Lemma (
    forall s1 s2 c. SIGNAL.InvariantLemmas.parallel_rel' s1 s2 ==> cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2
) = reveal_opaque (`%crypto_keys_match_session_entries) crypto_keys_match_session_entries

let crypto_keys_stable_under_event (sid: SidMap.sidt) (local_id: cv_user_id_t) (local: identity_key_t) : Lemma (forall s0 s1.
    SIGNAL.InvariantLemmas.rel' s0 s1 /\
    State.local_sessions_are_equal s0 s1 /\ is_local sid s0 /\ 
    crypto_keys_match_session_entries sid local_id local s0 ==>
      crypto_keys_match_session_entries sid local_id local s1)
  = reveal_opaque (`%crypto_keys_match_session_entries) crypto_keys_match_session_entries

let crypto_keys_stable_under_parallel_rel (sid: SidMap.sidt) (local_id: cv_user_id_t) (local: identity_key_t) : Lemma (forall s0 s1.
    is_local sid s0 /\ crypto_keys_match_session_entries sid local_id local s0 /\ SIGNAL.InvariantLemmas.parallel_rel' s0 s1 ==>
      crypto_keys_match_session_entries sid local_id local s1)
  = reveal_opaque (`%crypto_keys_match_session_entries) crypto_keys_match_session_entries

let cstate_session_ids state =
  Set.add state.principal_sid (Set.add state.long_time_prekey_sid (cstate_session_ids' state.one_time_prekey_id_to_sid))

let crypto_invariant_implies_session () =
  let aux cstate (st: signal_state) sid : Lemma
    (requires cryptographic_state_invariant cstate st /\ Set.mem sid (cstate_session_ids cstate))
    (ensures State.is_session sid st)
    = if sid = cstate.long_time_prekey_sid then () else
      if sid = cstate.principal_sid then () 
      else begin
        SidMapSetBase.set_mem_implies_exists cstate.one_time_prekey_id_to_sid Set.singleton sid;
        FMap.all_finite_map_facts_lemma ()
      end
  in
  Classical.forall_intro_3 (fun x y -> Classical.move_requires (aux x y))


val crypto_invariant_framing (_: unit) : Lemma (
  forall s1 s2 c idset.
    SIGNAL.InvariantLemmas.rel' s1 s2 ==>
    (forall (s: session_t). Set.disjoint (Set.singleton (session_id s)) idset ==> session_invariant s s1 ==> session_invariant s s2) /\
    (forall ssid local_id local. Set.disjoint (Set.singleton ssid) idset ==> crypto_keys_match_session_entries ssid local_id local s1 ==> crypto_keys_match_session_entries ssid local_id local s2) ==>
    Set.disjoint idset (cstate_session_ids c) ==>
    cryptographic_state_invariant c s1 ==>
    cryptographic_state_invariant c s2
  )

let crypto_invariant_framing () =
  let aux s1 s2 c idset : Lemma
    (requires
        SIGNAL.InvariantLemmas.rel' s1 s2 /\
        (forall (s: session_t). Set.disjoint (Set.singleton (session_id s)) idset ==> session_invariant s s1 ==> session_invariant s s2) /\
        (forall ssid local_id local. Set.disjoint (Set.singleton ssid) idset ==> crypto_keys_match_session_entries ssid local_id local s1 ==> crypto_keys_match_session_entries ssid local_id local s2) /\
        Set.disjoint idset (cstate_session_ids c) /\
        cryptographic_state_invariant c s1
    )
    (ensures cryptographic_state_invariant c s2)
    =  let prekeys = c.one_time_prekey_id_to_sid in
      let local = c.personal_identity_key in
      let local_id = Helpers.get_cv_uid c.personal_user_id in
      let aux2 sid : Lemma
        (requires FMap.values prekeys sid)
        (ensures crypto_keys_match_session_entries sid local_id local s2)
        = FMap.all_finite_map_facts_lemma ();
          SidMapSetBase.all_sidmapset_facts_lemma ();
          assert (exists id. FMap.mem id prekeys /\ FMap.lookup id prekeys == sid);
          assert (Set.mem sid (cstate_session_ids c))
      in Classical.forall_intro (Classical.move_requires aux2)
  in Classical.forall_intro_4 (fun x y z -> Classical.move_requires (aux x y z))



(** Start session_keys_match_session_entries lemmas *)

(** General lemmas to reason about the preservation of session_invariant *)

(* Extending F*'s stdlib *)
let rec list_find_memP #a (f: a -> Tot bool) (l: list a) : Lemma
  (match List.Tot.find f l with
   | None -> True
   | Some e -> List.memP e l)
  = match l with
    | [] -> ()
    | hd :: tl -> list_find_memP f tl

let rec for_allP_append_implies #a (f1 f2: a -> Tot prop) (s1 s2: list a): Lemma
  (requires forall x. f1 x ==> f2 x)
  (ensures List.for_allP f1 s1 /\ List.for_allP f2 s2 ==> List.for_allP f2 (s1 @ s2))
= match s1 with
  | [] -> ()
  | hd1 :: tl1 -> for_allP_append_implies f1 f2 tl1 s2

let rec for_allP_append #a (f: a -> Tot prop) (s1 s2: list a): Lemma
  (ensures List.for_allP f (s1 @ s2) <==> List.for_allP f s1 /\ List.for_allP f s2)
= match s1 with
  | [] -> ()
  | hd1 :: tl1 -> for_allP_append f tl1 s2

let lemma_state_add_event (st: signal_state) (ev: signal_event) : 
  Lemma (List.memP ev (State.events_of (state_add_event st ev)))
  [SMTPat (state_add_event st ev)]
  = State.state_add_event_lemma st ev;
    List.Tot.append_memP (State.events_of st) [ev] ev

let lemma_add_to_session_update' (st: signal_state) sid (sel: list signal_session_entry) (ssid: SidMap.sidt) (local_id: cv_user_id_t) (local: identity_key_t) (remote_id: cv_user_id_t) (remote: identity_key_t) : Lemma
  (requires
     session_keys_match_session_entries ssid local_id local remote_id remote st /\ sid == ssid /\
     List.for_allP (session_keys_match_session_entry local_id local remote_id remote) sel
  )
  (ensures session_keys_match_session_entries ssid local_id local remote_id remote (State.state_add_to_session st sid sel))
  = let sess = State.sessions_of st in
    reveal_opaque (`%session_keys_match_session_entries) session_keys_match_session_entries;
    match SidMap.get sess ssid with
    | None -> ()
    | Some init -> for_allP_append (session_keys_match_session_entry local_id local remote_id remote) init sel

let lemma_add_to_session_framing' (st: signal_state) sid (sel: list signal_session_entry) : Lemma
  (forall ssid local_id local remote_id remote.
    (session_keys_match_session_entries ssid local_id local remote_id remote st /\ sid <> ssid) ==>
    (session_keys_match_session_entries ssid local_id local remote_id remote (State.state_add_to_session st sid sel)))
   [SMTPat (state_add_to_session st sid sel)]
  = reveal_opaque (`%session_keys_match_session_entries) session_keys_match_session_entries

let lemma_session_reserve' (st: signal_state) : Lemma
  (forall ssid local_id local remote_id remote.
    session_keys_match_session_entries ssid local_id local remote_id remote st ==>
    session_keys_match_session_entries ssid local_id local remote_id remote (fst (State.state_reserve_session_id st))
  ) [SMTPat (State.state_reserve_session_id st)]
  = reveal_opaque (`%session_keys_match_session_entries) session_keys_match_session_entries

let lemma_session_reserved_invariant (st: signal_state) local_id local remote_id remote : Lemma
  (let (st1, sid) = State.state_reserve_session_id st in
   session_keys_match_session_entries sid local_id local remote_id remote st1)
  =
  reveal_opaque (`%session_keys_match_session_entries) session_keys_match_session_entries
 
let lemma_get_session_entry (st: signal_state) sn sid local_id local remote_id remote : Lemma
  (requires session_keys_match_session_entries sid local_id local remote_id remote st)
  (ensures (match get_session_entry st sn sid with
    | None -> True
    | Some e -> session_keys_match_session_entry local_id local remote_id remote e)
  )
  = match SidMap.get (State.sessions_of st) sid with
    | None -> ()
    | Some ses ->
      list_find_memP (is_valid_entry sn) ses;
      reveal_opaque (`%session_keys_match_session_entries) session_keys_match_session_entries;
      Classical.forall_intro (List.Tot.for_allP_eq (session_keys_match_session_entry local_id local remote_id remote))

let lemma_get_session_entry' (st: signal_state) sn sid : Lemma
  (forall local_id local remote_id remote. 
    session_keys_match_session_entries sid local_id local remote_id remote st ==> 
    (match get_session_entry st sn sid with
    | None -> True
    | Some e -> session_keys_match_session_entry local_id local remote_id remote e))
  [SMTPat (get_session_entry st sn sid)]
  = 
  let aux local_id local remote_id remote : Lemma
    (session_keys_match_session_entries sid local_id local remote_id remote st ==> 
    (match get_session_entry st sn sid with
    | None -> True
    | Some e -> session_keys_match_session_entry local_id local remote_id remote e))
    = Classical.move_requires (lemma_get_session_entry st sn sid local_id local remote_id) remote
  in
  Classical.forall_intro_4 aux

let lemma_invariant_sessions () : Lemma
  (forall st1 st2 ssid local_id local remote_id remote. State.sessions_of st1 == State.sessions_of st2 ==> session_keys_match_session_entries ssid local_id local remote_id remote st1 ==> session_keys_match_session_entries ssid local_id local remote_id remote st2)
  = reveal_opaque (`%session_keys_match_session_entries) session_keys_match_session_entries

let lemma_add_to_session_update_crypto (st: signal_state) sid (sel: list signal_session_entry) local_id local : Lemma
  (requires
     crypto_keys_match_session_entries sid local_id local st /\
     List.for_allP (crypto_keys_match_session_entry local_id local) sel
  )
  (ensures crypto_keys_match_session_entries sid local_id local (State.state_add_to_session st sid sel))
  = let sess = State.sessions_of st in
    reveal_opaque (`%crypto_keys_match_session_entries) crypto_keys_match_session_entries;
    match SidMap.get sess sid with
    | None -> ()
    | Some init -> for_allP_append (crypto_keys_match_session_entry local_id local) init sel

let lemma_add_to_session_update_crypto_to_session (st: signal_state) sid (sel: list signal_session_entry) local_id local remote_id remote : Lemma
  (requires
     crypto_keys_match_session_entries sid local_id local st /\
     List.for_allP (session_keys_match_session_entry local_id local remote_id remote) sel
  )
  (ensures session_keys_match_session_entries sid local_id local remote_id remote (State.state_add_to_session st sid sel))
  = let sess = State.sessions_of st in
    reveal_opaque (`%session_keys_match_session_entries) session_keys_match_session_entries;
    reveal_opaque (`%crypto_keys_match_session_entries) crypto_keys_match_session_entries;
    match SidMap.get sess sid with
    | None -> ()
    | Some init -> for_allP_append_implies (crypto_keys_match_session_entry local_id local) (session_keys_match_session_entry local_id local remote_id remote) init sel

let lemma_add_to_session_framing_crypto (st: signal_state) sid (sel: list signal_session_entry) : Lemma
  (forall ssid local_id local.
   (crypto_keys_match_session_entries ssid local_id local st /\ sid <> ssid) ==>
   (crypto_keys_match_session_entries ssid local_id local (State.state_add_to_session st sid sel)))
   [SMTPat (State.state_add_to_session st sid sel)]
  = reveal_opaque (`%crypto_keys_match_session_entries) crypto_keys_match_session_entries

let lemma_get_session_entry_crypto (st: signal_state) sn sid (local_id: cv_user_id_t) (local: identity_key_t) : Lemma
  (requires crypto_keys_match_session_entries sid local_id local st)
  (ensures (match get_session_entry st sn sid with
    | None -> True
    | Some e -> crypto_keys_match_session_entry local_id local e)
  )
  = match SidMap.get (State.sessions_of st) sid with
    | None -> ()
    | Some ses ->
      list_find_memP (is_valid_entry sn) ses;
      reveal_opaque (`%crypto_keys_match_session_entries) crypto_keys_match_session_entries;
      Classical.forall_intro (List.Tot.for_allP_eq (crypto_keys_match_session_entry local_id local))

let lemma_get_session_entry_crypto' (st: signal_state) sn sid : Lemma
  (forall (local_id: cv_user_id_t) (local: identity_key_t). 
    crypto_keys_match_session_entries sid local_id local st ==>
    (match get_session_entry st sn sid with
    | None -> True
    | Some e -> crypto_keys_match_session_entry local_id local e)
  )
  [SMTPat (get_session_entry st sn sid)]
  = 
  let aux (local_id: cv_user_id_t) (local: identity_key_t): 
    Lemma (crypto_keys_match_session_entries sid local_id local st ==>
    (match get_session_entry st sn sid with
    | None -> True
    | Some e -> crypto_keys_match_session_entry local_id local e))
    = Classical.move_requires (lemma_get_session_entry_crypto st sn sid local_id) local
  in
  Classical.forall_intro_2 aux

let lemma_invariant_sessions_crypto () : Lemma
  (forall (st1 st2: signal_state) ssid local_id local.
    (State.sessions_of st1 == State.sessions_of st2 /\ crypto_keys_match_session_entries ssid local_id local st1) ==>
    (crypto_keys_match_session_entries ssid local_id local st2))
  = reveal_opaque (`%crypto_keys_match_session_entries) crypto_keys_match_session_entries

let lemma_session_reserve_crypto (st: signal_state) : Lemma
  (forall ssid local_id local.
   crypto_keys_match_session_entries ssid local_id local st ==>
   crypto_keys_match_session_entries ssid local_id local (fst (State.state_reserve_session_id st)))
   [SMTPat (State.state_reserve_session_id st)]
  = reveal_opaque (`%crypto_keys_match_session_entries) crypto_keys_match_session_entries

let lemma_session_reserved_crypto_invariant (st: signal_state) local_id local : Lemma
  (let (st1, sid) = State.state_reserve_session_id st in
   crypto_keys_match_session_entries sid local_id local st1)
  =
  reveal_opaque (`%crypto_keys_match_session_entries) crypto_keys_match_session_entries

(** Proving the preservation of session_invariant for all oracles *)

// The next 2 lemmas are useful only for proving key injectivity
let lemma_Ogenprinc_event_aux (var_uid_0: cv_user_id_t) (state: signal_state) : Ghost (signal_state & option (SidMap.sidt & lbytes 32 & lbytes 32))
  (requires SIGNAL.InvariantLemmas.inv' state)
  (ensures fun (s', res) -> match res with
    | Some(sid, identity_key, signature_key) ->
        let pk = SIGNAL.Functions.fun_mkidkey identity_key signature_key in
        (exists uid'. is_valid_local_key (Helpers.to_identity_key pk) uid' s') ==> bad_state pk s' /\
        is_local_pk var_uid_0 pk s'
    | None -> True) =
  (**) let state0 = state in
  let state, sid = state_reserve_session_id state in
   begin
     let state, var_secA0_0 = call_with_entropy state (Random.gen_lbytes 32) in
     let var_pubA_0 = (exp g var_secA0_0) in
     let state, var_signAseed_0 = call_with_entropy state (Random.gen_lbytes 32) in
     let var_secAsign_0 = (skgen var_signAseed_0) in
     let var_pubAsign_0 = (pkgen var_signAseed_0) in
     let pk = fun_mkidkey var_pubA_0 var_pubAsign_0 in
     let ev = CVEvent (Event_Honest sid var_uid_0 pk) in
     let state = state_add_event state ev in
     let sel = [R1_Osend1 var_pubA_0 var_pubAsign_0 var_secA0_0 var_secAsign_0 var_uid_0; 
                R1_Orecv1 var_pubA_0 var_pubAsign_0 var_secA0_0 var_uid_0; 
                R1_Orecv2 var_pubA_0 var_pubAsign_0 var_secA0_0 var_uid_0; 
                R1_OCorrupt var_pubA_0 var_pubAsign_0 var_secA0_0 var_secAsign_0 var_uid_0] in
     let state = state_add_to_session state sid sel in
     let state1 = state in
     let aux uid' : Lemma
        (requires (is_valid_local_key (Helpers.to_identity_key pk) uid' state1))
        (ensures (bad_state pk state1)) =
        assert (is_valid_local_key (Helpers.to_identity_key pk) uid' state0);
        assert (exists sid'. List.memP (CVEvent (Event_Honest sid' (Helpers.get_cv_uid uid') pk)) (State.events_of state0)); (* by inv *)
        eliminate exists sid'.
            List.memP (CVEvent (Event_Honest sid' (Helpers.get_cv_uid uid') pk)) (State.events_of state0)
        returns bad_state pk state1
        with _. (
           assert(State.is_session sid' state0);
           assert(~(State.is_session sid state0));
           assert(~(sid == sid' /\ var_uid_0 == (Helpers.get_cv_uid uid')));
           assert(List.memP (CVEvent (Event_Honest sid' (Helpers.get_cv_uid uid') pk)) (State.events_of state1));
           assert(List.memP (CVEvent (Event_Honest sid var_uid_0 pk)) (State.events_of state1))
        )
     in
     Classical.forall_intro (Classical.move_requires aux);
     assert (List.memP (CVEvent (Event_Honest sid var_uid_0 pk)) (State.events_of state1));
     assert (is_local sid state1);
     (state, Some (sid, var_pubA_0,var_pubAsign_0))
   end

let lemma_Ogenprinc_event var_uid_0 state : Lemma
   (ensures
     SIGNAL.InvariantLemmas.inv' state ==>
     (let (state', res) = SIGNAL.Gen.Spec.oracle_Ogenprinc var_uid_0 state in
      match res with
      | Some(sid, identity_key, signature_key) ->
        let pk = SIGNAL.Functions.fun_mkidkey identity_key signature_key in
        (exists uid'. is_valid_local_key (Helpers.to_identity_key pk) uid' state') ==> bad_state pk state' /\
        is_local_pk var_uid_0 pk state'
      | None -> True)) =
  let aux state : Lemma
    (requires SIGNAL.InvariantLemmas.inv' state)
    (ensures
      (let (state', res) = SIGNAL.Gen.Spec.oracle_Ogenprinc var_uid_0 state in
      match res with
      | Some(sid, identity_key, signature_key) ->
        let pk = SIGNAL.Functions.fun_mkidkey identity_key signature_key in
        (exists uid'. is_valid_local_key (Helpers.to_identity_key pk) uid' state') ==> bad_state pk state' /\
        is_local_pk var_uid_0 pk state'
      | None -> True)) =
    assert_norm (SIGNAL.Gen.Spec.oracle_Ogenprinc var_uid_0 state == lemma_Ogenprinc_event_aux var_uid_0 state)
  in
  Classical.move_requires aux state

let lemma_Ogenprinc_crypto_aux (var_uid_0: cv_user_id_t) (state: signal_state) : Ghost (signal_state & option (SidMap.sidt & lbytes 32 & lbytes 32))
  (requires True)
  (ensures fun (s', res) -> match res with
    | Some(sid, identity_key, signature_key) ->
      let pk = mk_identity_key identity_key signature_key in
      crypto_keys_match_session_entries sid var_uid_0 pk s'
    | None -> True) =
  (**) lemma_invariant_sessions_crypto();
  (**) let state0 = state in
  let state, sid = state_reserve_session_id state in
   begin
     let state, var_secA0_0 = call_with_entropy state (Random.gen_lbytes 32) in
     let var_pubA_0 = (exp g var_secA0_0) in
     let state, var_signAseed_0 = call_with_entropy state (Random.gen_lbytes 32) in
     let var_secAsign_0 = (skgen var_signAseed_0) in
     let var_pubAsign_0 = (pkgen var_signAseed_0) in
     let pk = fun_mkidkey var_pubA_0 var_pubAsign_0 in
     let ev = CVEvent (Event_Honest sid var_uid_0 pk) in
     let state = state_add_event state ev in
     let sel = [R1_Osend1 var_pubA_0 var_pubAsign_0 var_secA0_0 var_secAsign_0 var_uid_0; 
                R1_Orecv1 var_pubA_0 var_pubAsign_0 var_secA0_0 var_uid_0; 
                R1_Orecv2 var_pubA_0 var_pubAsign_0 var_secA0_0 var_uid_0; 
                R1_OCorrupt var_pubA_0 var_pubAsign_0 var_secA0_0 var_secAsign_0 var_uid_0] in
     (**) let local = mk_identity_key var_pubA_0 var_pubAsign_0 in
     (**) lemma_session_reserved_crypto_invariant state0 var_uid_0 local;
     (**) lemma_add_to_session_update_crypto state sid sel var_uid_0 local;
     let state = state_add_to_session state sid sel in
     (state, Some (sid, var_pubA_0,var_pubAsign_0))
   end

let lemma_Ogenprinc_crypto var_uid_0 state : Lemma
  (ensures 
    (let (state', res) = SIGNAL.Gen.Spec.oracle_Ogenprinc var_uid_0 state in
    match res with
      | Some(sid, identity_key, signature_key) ->
        let pk = mk_identity_key identity_key signature_key in
        crypto_keys_match_session_entries sid var_uid_0 pk state'
      | None -> True)) =  
  assert_norm (SIGNAL.Gen.Spec.oracle_Ogenprinc var_uid_0 state == lemma_Ogenprinc_crypto_aux var_uid_0 state)

let lemma_Ogenprinc var_uid_0 state : Lemma
     (forall (s: session_t). session_invariant s state ==> session_invariant s (fst (SIGNAL.Gen.Spec.oracle_Ogenprinc var_uid_0 state)))
  = lemma_invariant_sessions()
    (* Applies [lemma_session_reserve'] for [state_reserve_session_id] 
    and [lemma_add_to_session_framing'] for [state_add_to_session] by SMTPat *)

let lemma_Ogenprinc_crypto1 var_uid_0 state : Lemma
     (forall (c: cryptographic_state_t). cryptographic_state_invariant c state ==> cryptographic_state_invariant c (fst (SIGNAL.Gen.Spec.oracle_Ogenprinc var_uid_0 state)))
  = lemma_invariant_sessions_crypto()
    (* Applies [lemma_session_reserve_crypto] for [state_reserve_session_id]
    and [lemma_add_to_session_framing_crypto] for [state_add_to_session] by SMTPat *)
    
#push-options "--z3rlimit 40"

let lemma_Orecv1 sid var_x__pubB_1 var_x__pubBsign_1 var_sephPubAB_1 var_signature_1 var_ephPubAB_1 var_msg__start_1 var_remote__uid_3 state : Lemma
  (forall (s: session_t). session_invariant s state ==> session_invariant s (fst (SIGNAL.Gen.Spec.oracle_Orecv1 sid var_x__pubB_1 var_x__pubBsign_1 var_sephPubAB_1 var_signature_1 var_ephPubAB_1 var_msg__start_1 var_remote__uid_3 state)))
  = lemma_invariant_sessions()
    (* Applies [lemma_session_reserve'] for [state_reserve_session_id] 
    and [lemma_add_to_session_framing'] for [state_add_to_session] by SMTPat *)

#restart-solver

let lemma_Orecv1' (sid: SidMap.sidt) (var_x__pubB_1: (lbytes 32)) (var_x__pubBsign_1: (lbytes 32)) (var_sephPubAB_1: (lbytes 32)) (var_signature_1: (lbytes 64)) (var_ephPubAB_1: (lbytes 32)) (var_msg__start_1: t_message) (var_remote__uid_3: cv_user_id_t)
  local_id local (state: signal_state) : Lemma
  (requires (crypto_keys_match_session_entries sid local_id local state))
  (ensures (match SIGNAL.Gen.Spec.oracle_Orecv1 sid var_x__pubB_1 var_x__pubBsign_1 var_sephPubAB_1 var_signature_1 var_ephPubAB_1 var_msg__start_1 var_remote__uid_3 state with
    | _, None -> True
    | state', Some (sidt, _, _, _, _, _) ->
      session_keys_match_session_entries sidt local_id local var_remote__uid_3 (mk_identity_key var_x__pubB_1 var_x__pubBsign_1) state'
    ))
  = 
  let remote = (mk_identity_key var_x__pubB_1 var_x__pubBsign_1) in
  let lemma_reserve_session (st: signal_state): Lemma
    (let (st1, sid) = State.state_reserve_session_id st in
     session_keys_match_session_entries sid local_id local var_remote__uid_3 remote st1)
    [SMTPat (State.state_reserve_session_id st)]
  = 
    lemma_session_reserved_invariant st local_id local var_remote__uid_3 remote
  in
  let lemma_add_to_session_update (st: signal_state) sid (sel: list signal_session_entry): Lemma
    (requires
     session_keys_match_session_entries sid local_id local var_remote__uid_3 remote st /\
     List.for_allP (session_keys_match_session_entry local_id local var_remote__uid_3 remote) sel
  )
  (ensures session_keys_match_session_entries sid local_id local var_remote__uid_3 remote (State.state_add_to_session st sid sel))
    [SMTPat (State.state_add_to_session st sid sel)]
  = lemma_add_to_session_update' st sid sel sid local_id local var_remote__uid_3 remote
  in
  lemma_invariant_sessions ()

let lemma_Orecv1_crypto sid  var_x__pubB_1 var_x__pubBsign_1 var_sephPubAB_1 var_signature_1 var_ephPubAB_1 var_msg__start_1 var_remote__uid_3 state : Lemma
  (forall (c: cryptographic_state_t). cryptographic_state_invariant c state ==> cryptographic_state_invariant c (fst (SIGNAL.Gen.Spec.oracle_Orecv1 sid var_x__pubB_1 var_x__pubBsign_1 var_sephPubAB_1 var_signature_1 var_ephPubAB_1 var_msg__start_1 var_remote__uid_3 state)))
  = lemma_invariant_sessions_crypto()
    (* Applies [lemma_session_reserve_crypto] for [state_reserve_session_id]
    and [lemma_add_to_session_framing_crypto] for [state_add_to_session] by SMTPat *)

#restart-solver

let lemma_Orecv2 sid var_x__pubB_2 var_x__pubBsign_2 var_sephPubAB_2 var_signature_2 var_msg__start_2 var_remote__uid_3 state : Lemma
  (forall (s: session_t). session_invariant s state ==> session_invariant s (fst (SIGNAL.Gen.Spec.oracle_Orecv2 sid var_x__pubB_2 var_x__pubBsign_2 var_sephPubAB_2 var_signature_2 var_msg__start_2 var_remote__uid_3 state)))
  = lemma_invariant_sessions()

let lemma_Orecv2' (sid: SidMap.sidt) (var_x__pubB_2: (lbytes 32)) (var_x__pubBsign_2: (lbytes 32)) (var_sephPubAB_2: (lbytes 32)) (var_signature_2: (lbytes 64)) (var_msg__start_2: t_message) (var_remote__uid_3: cv_user_id_t) 
  local_id local (state: signal_state) : Lemma
  (requires (crypto_keys_match_session_entries sid local_id local state))
  (ensures (match SIGNAL.Gen.Spec.oracle_Orecv2 sid var_x__pubB_2 var_x__pubBsign_2 var_sephPubAB_2 var_signature_2 var_msg__start_2 var_remote__uid_3 state with
    | _, None -> True
    | state', Some (sidt, _, _, _, _, _) ->
      session_keys_match_session_entries sidt local_id local var_remote__uid_3 (mk_identity_key var_x__pubB_2 var_x__pubBsign_2) state'
    ))
  = 
  let remote = (mk_identity_key var_x__pubB_2 var_x__pubBsign_2) in
  let lemma_reserve_session (st: signal_state): Lemma
    (let (st1, sid) = State.state_reserve_session_id st in
     session_keys_match_session_entries sid local_id local var_remote__uid_3 remote st1)
    [SMTPat (State.state_reserve_session_id st)]
  = 
    lemma_session_reserved_invariant st local_id local var_remote__uid_3 remote
  in
  let lemma_add_to_session_update (st: signal_state) sid (sel: list signal_session_entry): Lemma
    (requires
     session_keys_match_session_entries sid local_id local var_remote__uid_3 remote st /\
     List.for_allP (session_keys_match_session_entry local_id local var_remote__uid_3 remote) sel
  )
  (ensures session_keys_match_session_entries sid local_id local var_remote__uid_3 remote (State.state_add_to_session st sid sel))
    [SMTPat (State.state_add_to_session st sid sel)]
  = lemma_add_to_session_update' st sid sel sid local_id local var_remote__uid_3 remote
  in
  lemma_invariant_sessions ()

let lemma_Orecv2_crypto sid var_x__pubB_2 var_x__pubBsign_2 var_sephPubAB_2 var_signature_2 var_msg__start_2 var_remote__uid_3 state : Lemma
  (forall (c: cryptographic_state_t). cryptographic_state_invariant c state ==> cryptographic_state_invariant c (fst (SIGNAL.Gen.Spec.oracle_Orecv2 sid var_x__pubB_2 var_x__pubBsign_2 var_sephPubAB_2 var_signature_2 var_msg__start_2 var_remote__uid_3 state)))
  = lemma_invariant_sessions_crypto()

let lemma_Osend1 sid state : Lemma
  (forall (s: session_t). session_invariant s state ==> session_invariant s (fst (SIGNAL.Gen.Spec.oracle_Osend1 sid state)))
  = lemma_invariant_sessions()

let lemma_Osend1' sid (local_id: cv_user_id_t) (local: identity_key_t) state : Lemma
  (requires (crypto_keys_match_session_entries sid local_id local state))
  (ensures (match SIGNAL.Gen.Spec.oracle_Osend1 sid state with
      | _, None -> True
      | st', Some (id, _, _) -> 
         crypto_keys_match_session_entries sid local_id local st' /\
         crypto_keys_match_session_entries id local_id local st' /\ 
         ~(is_session id state)))
  = 
  let lemma_reserve_session (st: signal_state):
    Lemma (
      let (st1, sid) = State.state_reserve_session_id st in
      crypto_keys_match_session_entries sid local_id local st1
      )
    [SMTPat (State.state_reserve_session_id st)]
  = 
    lemma_session_reserved_crypto_invariant st local_id local
  in
  let lemma_add_to_session_update (st: signal_state) sid (sel: list signal_session_entry): Lemma
    (requires
     crypto_keys_match_session_entries sid local_id local st /\
     List.for_allP (crypto_keys_match_session_entry local_id local) sel
    )
    (ensures crypto_keys_match_session_entries sid local_id local (State.state_add_to_session st sid sel))
    [SMTPat (State.state_add_to_session st sid sel)]
  = 
    lemma_add_to_session_update_crypto st sid sel local_id local
  in
  lemma_invariant_sessions_crypto()  

let lemma_Osend1_crypto sid state : Lemma
  (forall c. cryptographic_state_invariant c state ==> cryptographic_state_invariant c (fst (SIGNAL.Gen.Spec.oracle_Osend1 sid state)))
  = lemma_invariant_sessions_crypto()

let lemma_Osend2 sid state : Lemma
  (forall (s: session_t). session_invariant s state ==> session_invariant s (fst (SIGNAL.Gen.Spec.oracle_Osend2 sid state)))
  = lemma_invariant_sessions()

let lemma_Osend2' sid local_id local state : Lemma
  (crypto_keys_match_session_entries sid local_id local state ==>
    (match SIGNAL.Gen.Spec.oracle_Osend2 sid state with
      | _, None -> True
      | st', Some (sid', _) -> crypto_keys_match_session_entries sid' local_id local st')
  )
  = let lemma_get_session_entry  (st: signal_state) sn sid: 
      Lemma 
        (requires crypto_keys_match_session_entries sid local_id local st)
        (ensures (match get_session_entry st sn sid with
          | None -> True
          | Some e -> crypto_keys_match_session_entry local_id local e)
        )
        [SMTPat (get_session_entry st sn sid)]
    = lemma_get_session_entry_crypto st sn sid local_id local
    in
    let lemma_reserve_session (st: signal_state):
      Lemma (
        let (st1, sid) = State.state_reserve_session_id st in
        crypto_keys_match_session_entries sid local_id local st1
      )
      [SMTPat (State.state_reserve_session_id st)]
    = 
      lemma_session_reserved_crypto_invariant st local_id local
    in
    let lemma_add_to_session_update (st: signal_state) sid (sel: list signal_session_entry): Lemma
      (requires
        crypto_keys_match_session_entries sid local_id local st /\
        List.for_allP (crypto_keys_match_session_entry local_id local) sel
      )
      (ensures crypto_keys_match_session_entries sid local_id local (State.state_add_to_session st sid sel))
      [SMTPat (State.state_add_to_session st sid sel)]
    = 
      lemma_add_to_session_update_crypto st sid sel local_id local
    in
    lemma_invariant_sessions_crypto()  

let lemma_Osend2_crypto sid state : Lemma
  (forall c. cryptographic_state_invariant c state ==> cryptographic_state_invariant c (fst (SIGNAL.Gen.Spec.oracle_Osend2 sid state)))
  = lemma_invariant_sessions_crypto() 

#restart-solver

let lemma_set_disjoint (sid1 sid2: SidMap.sidt) : Lemma
  (requires Set.disjoint (Set.singleton sid1) (Set.singleton sid2))
  (ensures sid1 <> sid2)
  = (* Needed for SMT triggers *)
    assert (Set.mem sid1 (Set.singleton sid1))

let lemma_Osend3 sid var_x__pubA_1 var_x__pubAsign_1 var_ephPubBA_1 var_ephPubBA_27_1 var_msgenc__start_1 var_remote__uid_1 var_n__start__recv_1 state
  : Lemma (forall (s: session_t). session_invariant s state ==>
          session_invariant s (fst (SIGNAL.Gen.Spec.oracle_Osend3 sid var_x__pubA_1 var_x__pubAsign_1 var_ephPubBA_1 var_ephPubBA_27_1 var_msgenc__start_1 var_remote__uid_1 var_n__start__recv_1 state)))
  = lemma_invariant_sessions()

let lemma_Osend3' sid var_x__pubA_1 var_x__pubAsign_1 var_ephPubBA_1 var_ephPubBA_27_1 var_msgenc__start_1 var_remote__uid_1 var_n__start__recv_1 local_id local state
  : Lemma
    (requires crypto_keys_match_session_entries sid local_id local state)
    (ensures (match SIGNAL.Gen.Spec.oracle_Osend3 sid var_x__pubA_1 var_x__pubAsign_1 var_ephPubBA_1 var_ephPubBA_27_1 var_msgenc__start_1 var_remote__uid_1 var_n__start__recv_1 state with
      | st', None -> True
      | st', Some (sid', msg) -> 
        session_keys_match_session_entries sid' local_id local var_remote__uid_1 (mk_identity_key var_x__pubA_1 var_x__pubAsign_1) st' /\
        List.memP (CVEvent (Event_SimplRecv local_id local var_remote__uid_1 (mk_identity_key var_x__pubA_1 var_x__pubAsign_1) msg)) (State.events_of st')))
  = 
    let lemma_get_session_entry  (st: signal_state) sn sid: 
      Lemma 
        (requires crypto_keys_match_session_entries sid local_id local st)
        (ensures (match get_session_entry st sn sid with
          | None -> True
          | Some e -> crypto_keys_match_session_entry local_id local e)
        )
        [SMTPat (get_session_entry st sn sid)]
    = lemma_get_session_entry_crypto st sn sid local_id local
    in
    let lemma_reserve_session (st: signal_state):
      Lemma (
        let (st1, sid) = State.state_reserve_session_id st in
        crypto_keys_match_session_entries sid local_id local st1
      )
      [SMTPat (State.state_reserve_session_id st)]
    = lemma_session_reserved_crypto_invariant st local_id local
    in
    let remote_id = var_remote__uid_1 in
    let remote = mk_identity_key var_x__pubA_1 var_x__pubAsign_1 in
    let lemma_add_to_session_update (st: signal_state) sid (sel: list signal_session_entry): Lemma
      (requires
        crypto_keys_match_session_entries sid local_id local st /\
        List.for_allP (session_keys_match_session_entry local_id local remote_id remote) sel
      )
      (ensures session_keys_match_session_entries sid local_id local remote_id remote (State.state_add_to_session st sid sel))
      [SMTPat (State.state_add_to_session st sid sel)]
    = lemma_add_to_session_update_crypto_to_session st sid sel local_id local remote_id remote
    in
    lemma_invariant_sessions_crypto()  
    
let lemma_Osend3_crypto sid var_x__pubA_1 var_x__pubAsign_1 var_ephPubBA_1 var_ephPubBA_27_1 var_msgenc__start_1 var_remote__uid_1 var_n__start__recv_1 state
  : Lemma (forall (c: cryptographic_state_t). cryptographic_state_invariant c state ==> cryptographic_state_invariant c (fst (SIGNAL.Gen.Spec.oracle_Osend3 sid var_x__pubA_1 var_x__pubAsign_1 var_ephPubBA_1 var_ephPubBA_27_1 var_msgenc__start_1 var_remote__uid_1 var_n__start__recv_1 state)))
  = lemma_invariant_sessions_crypto()

let lemma_Osend4 sid var_x__pubA_2 var_x__pubAsign_2 var_ephPubBA_2 var_ephPubBA2_0 var_msgenc__start_2 var_remote__uid_2 var_n__start__recv_2 state : Lemma
  (forall (s: session_t). session_invariant s state ==> session_invariant s (fst (SIGNAL.Gen.Spec.oracle_Osend4 sid var_x__pubA_2 var_x__pubAsign_2 var_ephPubBA_2 var_ephPubBA2_0 var_msgenc__start_2 var_remote__uid_2 var_n__start__recv_2 state)))
  = lemma_invariant_sessions()

let lemma_Osend4' sid var_x__pubA_2 var_x__pubAsign_2 var_ephPubBA_2 var_ephPubBA2_0 var_msgenc__start_2 var_remote__uid_2 var_n__start__recv_2 local_id local state : Lemma
  (requires crypto_keys_match_session_entries sid local_id local state)
  (ensures (match SIGNAL.Gen.Spec.oracle_Osend4 sid var_x__pubA_2 var_x__pubAsign_2 var_ephPubBA_2 var_ephPubBA2_0 var_msgenc__start_2 var_remote__uid_2 var_n__start__recv_2 state with
    | _, None -> True
    | s', Some (sid', msg) -> 
       session_keys_match_session_entries sid' local_id local var_remote__uid_2 (mk_identity_key var_x__pubA_2 var_x__pubAsign_2) s' /\
       List.memP (CVEvent (Event_SimplRecv local_id local var_remote__uid_2 (mk_identity_key var_x__pubA_2 var_x__pubAsign_2) msg)) (State.events_of s')       
    )
  )
  = 
    let lemma_get_session_entry  (st: signal_state) sn sid: 
      Lemma 
        (requires crypto_keys_match_session_entries sid local_id local st)
        (ensures (match get_session_entry st sn sid with
          | None -> True
          | Some e -> crypto_keys_match_session_entry local_id local e)
        )
        [SMTPat (get_session_entry st sn sid)]
    = lemma_get_session_entry_crypto st sn sid local_id local
    in
    let lemma_reserve_session (st: signal_state):
      Lemma (
        let (st1, sid) = State.state_reserve_session_id st in
        crypto_keys_match_session_entries sid local_id local st1
      )
      [SMTPat (State.state_reserve_session_id st)]
    = lemma_session_reserved_crypto_invariant st local_id local
    in
    let remote_id = var_remote__uid_2 in
    let remote = mk_identity_key var_x__pubA_2 var_x__pubAsign_2 in
    let lemma_add_to_session_update (st: signal_state) sid (sel: list signal_session_entry): Lemma
      (requires
        crypto_keys_match_session_entries sid local_id local st /\
        List.for_allP (session_keys_match_session_entry local_id local remote_id remote) sel
      )
      (ensures session_keys_match_session_entries sid local_id local remote_id remote (State.state_add_to_session st sid sel))
      [SMTPat (State.state_add_to_session st sid sel)]
    = lemma_add_to_session_update_crypto_to_session st sid sel local_id local remote_id remote
    in
    lemma_invariant_sessions_crypto()  

#pop-options

let lemma_Osend4_crypto sid var_x__pubA_2 var_x__pubAsign_2 var_ephPubBA_2 var_ephPubBA2_0 var_msgenc__start_2 var_remote__uid_2 var_n__start__recv_2 state : Lemma
  (forall (c: cryptographic_state_t). cryptographic_state_invariant c state ==> cryptographic_state_invariant c (fst (SIGNAL.Gen.Spec.oracle_Osend4 sid var_x__pubA_2 var_x__pubAsign_2 var_ephPubBA_2 var_ephPubBA2_0 var_msgenc__start_2 var_remote__uid_2 var_n__start__recv_2 state)))
  = lemma_invariant_sessions_crypto()

(** End session_keys_match_session_entries lemmas *)


#push-options "--z3rlimit 300"

let rec make_one_time_prekeys (state: cryptographic_state_t) (n: nat{n <= Constants.num_one_time_prekeys}):
    CVSTInv
        (cryptographic_state_t & (l: list (prekey_id_t & prekey_t) { List.length l <= n }))
        (fun st -> cryptographic_state_invariant state st)
        (fun s1 res s2 ->
           cryptographic_state_invariant res._1 s2
	    /\ get_personal_user_id state == get_personal_user_id res._1
            /\ (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2)
            /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
            /\ (forall sid. State.is_session sid s1 ==> not (Set.mem sid (cstate_session_ids state)) ==> not (Set.mem sid (cstate_session_ids res._1)))
        ) =
    crypto_invariant_stable_under_parallel_rel ();
    cryptographic_state_invariant_stable_under_event ();
    session_invariant_stable_under_event ();
    session_invariant_stable_under_parallel_rel ();
    if n = 0 then (state, []) else
    let (state, l) = make_one_time_prekeys state (n-1) in
    let prekey_id = make_prekey_id (n-1) in
    (**) Classical.forall_intro (lemma_Osend2 state.long_time_prekey_sid);
    (**) Classical.forall_intro (lemma_Osend2' state.long_time_prekey_sid (Helpers.get_cv_uid state.personal_user_id) state.personal_identity_key);
    (**) Classical.forall_intro (lemma_Osend2_crypto state.long_time_prekey_sid);
    match oracle_Osend2 state.long_time_prekey_sid with
    | Some (sid, one_time_prekey) ->
        crypto_keys_stable_under_parallel_rel sid (Helpers.get_cv_uid state.personal_user_id) state.personal_identity_key;
        crypto_invariant_implies_session ();
        FMap.all_finite_map_facts_lemma();
        SidMapSetBase.all_sidmapset_facts_lemma ();
        {
            state with
            one_time_prekey_id_to_sid = FMap.insert prekey_id sid state.one_time_prekey_id_to_sid
         }, (prekey_id, one_time_prekey) :: l
    | None -> state, l

let make_cryptographic_state (principal_sid: SidMap.sidt) (personal_user_id: user_id_t) (personal_identity_key: identity_key_t):
    CVSTInv
        (option (cryptographic_state_t & signed_prekey_bundle_t & (l: list (prekey_id_t & prekey_t) { List.length l <= Constants.num_one_time_prekeys })))
        (fun s -> is_local principal_sid s /\ crypto_keys_match_session_entries principal_sid (Helpers.get_cv_uid personal_user_id) personal_identity_key s /\
          is_valid_local_key personal_identity_key personal_user_id s)
        (fun s1 res s2 ->
            (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2)
            /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
            /\ (match res with
                | Some (st, signed_prekey_bundle, one_time_prekeys) ->
                    (forall sid. State.is_session sid s1 /\ not (sid = principal_sid) ==> not (Set.mem sid (cstate_session_ids st))) /\
                    cryptographic_state_invariant st s2 /\
                    get_personal_user_id st == personal_user_id
                | _ -> True
              )
        ) =
        crypto_invariant_stable_under_parallel_rel ();
        cryptographic_state_invariant_stable_under_event ();
        session_invariant_stable_under_event ();
        session_invariant_stable_under_parallel_rel ();
        crypto_keys_stable_under_parallel_rel principal_sid (Helpers.get_cv_uid personal_user_id) personal_identity_key; 
        SidMapSetBase.all_sidmapset_facts_lemma ();
        (**) Classical.forall_intro (lemma_Osend1 principal_sid);
        (**) Classical.forall_intro (Classical.move_requires (lemma_Osend1' principal_sid (Helpers.get_cv_uid personal_user_id) personal_identity_key));
        (**) Classical.forall_intro (lemma_Osend1_crypto principal_sid);
        match oracle_Osend1 principal_sid with
        | Some (long_time_prekey_sid, prekey, signature) ->
	    let signed_prekey_bundle = {
                    prekey;
                    signature;
                }
            in
            FMap.all_finite_map_facts_lemma();
            SidMapSetBase.all_sidmapset_facts_lemma ();
            let state : cryptographic_state_t = {
                one_time_prekey_id_to_sid = FMap.emptymap;
                signed_prekey_bundle;
                principal_sid;
                long_time_prekey_sid;
                personal_user_id;
                personal_identity_key
            }
	    in
	    let (state', prekeys) = make_one_time_prekeys state Constants.num_one_time_prekeys in
            assert (forall sid. Set.mem sid (cstate_session_ids state') ==> sid == principal_sid \/ sid == long_time_prekey_sid \/ (Set.mem sid (cstate_session_ids state') /\ ~(Set.mem sid (cstate_session_ids state))));
	    Some (state', signed_prekey_bundle, prekeys)
        | None -> None


let regenerate_cryptographic_state (state: cryptographic_state_t) : 
    CVSTInv
        (option (cryptographic_state_t & signed_prekey_bundle_t & (l: list (prekey_id_t & prekey_t) { List.length l <= Constants.num_one_time_prekeys })))
        (fun s -> cryptographic_state_invariant state s)
        (fun s1 res s2 ->
            (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2)
            /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
            /\ (match res with
                | Some (st, signed_prekey_bundle, one_time_prekeys) ->
                    (forall sid. State.is_session sid s1 /\ not (Set.mem sid (cstate_session_ids state)) ==> not (Set.mem sid (cstate_session_ids st))) /\
                    cryptographic_state_invariant st s2 /\
                    get_personal_user_id st == get_personal_user_id state
                | _ -> True
              )
        )
  = make_cryptographic_state state.principal_sid state.personal_user_id state.personal_identity_key

(* We separate genprinc from make_device to help F* do the proof *)
let genprinc (personal_user_id: user_id_t) : CVSTInv (SidMap.sidt & identity_key_t)
       (fun _ -> True)
        (fun s1 (sid, personal_identity_key) s2 -> 
            (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2)
            /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
            /\ crypto_keys_match_session_entries sid (Helpers.get_cv_uid personal_user_id) personal_identity_key s2
            /\ is_local sid s2
            /\ (let pk = Helpers.from_identity_key personal_identity_key in
            // The next line is useful only for proving key injectivity
            ((exists uid'. is_valid_local_key personal_identity_key uid' s2) ==> bad_state pk s2) /\
                 is_local_pk (Helpers.get_cv_uid personal_user_id) pk s2
              )) =
    crypto_invariant_stable_under_parallel_rel ();
    cryptographic_state_invariant_stable_under_event ();
    session_invariant_stable_under_event ();
    session_invariant_stable_under_parallel_rel ();
    let cv_personal_user_id = Helpers.get_cv_uid personal_user_id in
    // The next line is useful only for proving key injectivity
    (**) Classical.forall_intro (lemma_Ogenprinc_event cv_personal_user_id);
    (**) Classical.forall_intro (lemma_Ogenprinc_crypto cv_personal_user_id);
    (**) Classical.forall_intro (lemma_Ogenprinc cv_personal_user_id);
    (**) Classical.forall_intro (lemma_Ogenprinc_crypto1 cv_personal_user_id);
    match oracle_Ogenprinc cv_personal_user_id with
    | Some (sid, identity_key, signature_key) ->
        Helpers.reveal_fun_mkidkey identity_key signature_key;
        let personal_identity_key: identity_key_t = {
            identity_key ;
            signature_key ;
        } in
        sid, personal_identity_key

let make_device (personal_user_id: user_id_t):
    CVSTInv
        (option (cryptographic_state_t & signed_prekey_bundle_t & (l: list (prekey_id_t & prekey_t) { List.length l <= Constants.num_one_time_prekeys })))
        (fun _ -> True)
        (fun s1 res s2 ->
            (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2)
            /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
            /\ (match res with
                | Some (cst, signed_prekey_bundle, prekeys) ->
                    cryptographic_state_invariant cst s2 /\
                    get_personal_user_id cst == personal_user_id
                | _ -> True
              )
        ) =
    let sid, personal_identity_key = genprinc personal_user_id in
    crypto_invariant_stable_under_parallel_rel ();
    cryptographic_state_invariant_stable_under_event ();
    session_invariant_stable_under_event ();
    session_invariant_stable_under_parallel_rel ();
    add_event (Event_Valid_Key_for_User personal_identity_key personal_user_id);
    crypto_keys_stable_under_event sid (Helpers.get_cv_uid personal_user_id) personal_identity_key; 
    make_cryptographic_state sid personal_user_id personal_identity_key

#pop-options

let identity_key (state: cryptographic_state_t): identity_key_t =
    state.personal_identity_key

#push-options "--z3rlimit 60"

/// [cryptographic_state] is our own current state. It contains our personal identity key,
/// as well as the bundles currently known.
/// [remote_identity_key] is the person we are trying to contact.
let create_session_from_prekey_bundle
    (cryptographic_state: cryptographic_state_t)
    (remote_user_id: user_id_t)
    (remote_identity_key: identity_key_t)
    (prekey_bundle: prekey_bundle_t)
    (msg: t_message):
    CVSTInv
        (option (session_t & encrypted_message_t))
        (fun st ->
             cryptographic_state_invariant cryptographic_state st /\
             is_valid_remote_key remote_identity_key remote_user_id st /\
	     msg_send_event msg cryptographic_state.personal_user_id remote_user_id st)
        (fun s1 res s2 ->
            (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2)
            /\ (match res with
                | Some (session, _) ->
                    session_invariant session s2 /\
                    not (State.is_session (session_id session) s1) /\
                    Ghost.reveal session.local_user_id == cryptographic_state.personal_user_id /\
                    Ghost.reveal session.remote_user_id == remote_user_id
                | None -> True)
            /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)) =
    let personal_identity_key = cryptographic_state.personal_identity_key in
    let personal_user_id = cryptographic_state.personal_user_id in
    let cv_personal_user_id = Helpers.get_cv_uid personal_user_id in
    let cv_remote_user_id = Helpers.get_cv_uid remote_user_id in
    crypto_invariant_stable_under_parallel_rel ();
    cryptographic_state_invariant_stable_under_event ();
    session_invariant_stable_under_event ();
    session_invariant_stable_under_parallel_rel ();
    Helpers.reveal_fun_mkidkey personal_identity_key.identity_key personal_identity_key.signature_key;
    Helpers.reveal_fun_mkidkey remote_identity_key.identity_key remote_identity_key.signature_key;
    match prekey_bundle.one_time_prekey with
    | Some (one_time_prekey_id, one_time_prekey) -> (
        (**) Classical.forall_intro (lemma_Orecv1
          cryptographic_state.principal_sid
          remote_identity_key.identity_key
          remote_identity_key.signature_key
          prekey_bundle.signed_prekey_bundle.prekey
          prekey_bundle.signed_prekey_bundle.signature one_time_prekey msg
          cv_remote_user_id);
        (**) Classical.forall_intro (lemma_Orecv1_crypto
          cryptographic_state.principal_sid
          remote_identity_key.identity_key
          remote_identity_key.signature_key
          prekey_bundle.signed_prekey_bundle.prekey
          prekey_bundle.signed_prekey_bundle.signature one_time_prekey msg
          cv_remote_user_id);
        (**) Classical.forall_intro (Classical.move_requires (lemma_Orecv1'
          cryptographic_state.principal_sid
          remote_identity_key.identity_key
          remote_identity_key.signature_key
          prekey_bundle.signed_prekey_bundle.prekey
          prekey_bundle.signed_prekey_bundle.signature
          one_time_prekey msg
          cv_remote_user_id cv_personal_user_id personal_identity_key));
        match oracle_Orecv1
          cryptographic_state.principal_sid
          remote_identity_key.identity_key
          remote_identity_key.signature_key
          prekey_bundle.signed_prekey_bundle.prekey
          prekey_bundle.signed_prekey_bundle.signature one_time_prekey msg
          cv_remote_user_id
        with
        | Some (sidt, _, _, ephemeral_1, ephemeral_2, init_message) ->
            let init_message_bundle: init_message_bundle_t = {
                sender_identity_key = personal_identity_key;
                ephemeral_1;
                ephemeral_2;
                one_time_prekey = Some one_time_prekey_id;
            } in
            Some ({
                    sid = sidt ;
                    last_used_nonce = n_start;
                    encryption_scheme = WithOnetimePrekey ;
                    role = Initiator;
                    remote_user_id;
                    remote_identity_key;
                    local_user_id = personal_user_id;
                    local_identity_key = personal_identity_key;
                    init_message = Some init_message_bundle
                },
		{ init_msg = Some init_message_bundle;
		  counter = n_start;
		  ciphertext = init_message }
            )
        | None -> None
    )
    | None -> (
        (**) Classical.forall_intro (lemma_Orecv2
          cryptographic_state.principal_sid
          remote_identity_key.identity_key
          remote_identity_key.signature_key
          prekey_bundle.signed_prekey_bundle.prekey
          prekey_bundle.signed_prekey_bundle.signature msg
          cv_remote_user_id);
        (**) Classical.forall_intro (lemma_Orecv2_crypto
          cryptographic_state.principal_sid
          remote_identity_key.identity_key
          remote_identity_key.signature_key
          prekey_bundle.signed_prekey_bundle.prekey
          prekey_bundle.signed_prekey_bundle.signature msg
          cv_remote_user_id);
        (**) Classical.forall_intro (Classical.move_requires (lemma_Orecv2'
          cryptographic_state.principal_sid
          remote_identity_key.identity_key
          remote_identity_key.signature_key
          prekey_bundle.signed_prekey_bundle.prekey
          prekey_bundle.signed_prekey_bundle.signature msg
          cv_remote_user_id cv_personal_user_id personal_identity_key));
        match oracle_Orecv2
          cryptographic_state.principal_sid
          remote_identity_key.identity_key
          remote_identity_key.signature_key
          prekey_bundle.signed_prekey_bundle.prekey
          prekey_bundle.signed_prekey_bundle.signature msg
          cv_remote_user_id
        with
        | Some (sidt, _, _, ephemeral_1, ephemeral_2, init_message) ->
            let init_message_bundle: init_message_bundle_t = {
                sender_identity_key = personal_identity_key;
                ephemeral_1;
                ephemeral_2;
                one_time_prekey = None;
            } in
            Some ({
                    sid = sidt ;
                    last_used_nonce = n_start;
                    encryption_scheme = WithoutOnetimePrekey ;
                    role = Initiator;
                    remote_user_id;
                    remote_identity_key;
                    local_user_id = personal_user_id;
                    local_identity_key = personal_identity_key;
                    init_message = Some init_message_bundle
                },
		{ init_msg = Some init_message_bundle;
		  counter = n_start;
		  ciphertext = init_message }
            )
        | None -> None
    )

#pop-options

(*
    To create a session from an initial message, we need to access the `sid`
    that was used to generate the one time prekey, if any.
    For this reason, we need to keep a map from one-time prekey ids to sids
    in field one_time_prekey_id_to_sid of the state.

    We also keep the sid of the session that generated the longtime signed prekey,
    in field long_time_prekey_sid of the state.
*)

let lookup_and_remove_sid
    (state: cryptographic_state_t)
    (one_time_prekey_id: prekey_id_t):
    Pure (option (sid: SidMap.sidt{FMap.values state.one_time_prekey_id_to_sid sid}) & cryptographic_state_t)
     (requires True)
     (ensures (fun (_, state') ->
        forall sid. (FMap.values state'.one_time_prekey_id_to_sid sid) ==>
                    (FMap.values state.one_time_prekey_id_to_sid sid))) =
    FMap.all_finite_map_facts_lemma();
    SidMapSetBase.all_sidmapset_facts_lemma ();
    if FMap.mem one_time_prekey_id state.one_time_prekey_id_to_sid then
      let sid = FMap.lookup one_time_prekey_id state.one_time_prekey_id_to_sid in
      Some sid, {
        state with
        one_time_prekey_id_to_sid = FMap.remove one_time_prekey_id state.one_time_prekey_id_to_sid ;
      }
    else
      None, state


#restart-solver

(* States that the event of receiving the message happened *)
let msg_recv_event' msg uid1 pk1 uid2 pk2 (s2: signal_state) =
    List.memP (CVEvent (Event_SimplRecv uid1 pk1 uid2 pk2 msg)) (State.events_of s2)

let session_invariant_stable_under_remove (sid: SidMap.sidt): Lemma (
    forall s1 s2 d. s2 == State.remove_session s1 sid ==> session_invariant d s1 ==> session_invariant d s2
) = reveal_opaque (`%session_keys_match_session_entries) session_keys_match_session_entries

let cryptographic_state_invariant_stable_under_remove (sid: SidMap.sidt): Lemma (
    forall s1 s2 c. s2 == State.remove_session s1 sid ==>
    cryptographic_state_invariant c s1 ==>
    cryptographic_state_invariant c s2
) = reveal_opaque (`%crypto_keys_match_session_entries) crypto_keys_match_session_entries

let remove_cv_session (sid: SidMap.sidt):
    CVSTInv unit
      (fun s1 -> is_local sid s1)
      (fun s1 res s2 ->
        (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)) =
  crypto_invariant_stable_under_parallel_rel ();
  session_invariant_stable_under_parallel_rel ();
  session_invariant_stable_under_remove sid;
  cryptographic_state_invariant_stable_under_remove sid;
  SIGNAL.Effect.remove_session sid

#push-options "--z3rlimit 300"

let create_session_from_init_message_with_one_time_prekey
    (state: cryptographic_state_t)
    (init_message: t_cipher)
    (counter: nonce_t)
    (remote_user_id: user_id_t)
    (remote_identity_key: identity_key_t)
    (ephemeral_1: prekey_t)
    (ephemeral_2: prekey_t)
    (one_time_prekey: prekey_id_t):
    CVSTInv (option (cryptographic_state_t & session_t & t_message))
      (fun st ->
        is_valid_remote_key remote_identity_key remote_user_id st
        /\ cryptographic_state_invariant state st)
      (fun s1 res s2 ->
        (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2) /\
        (match res with
          | Some (state', session, msg) -> 
              cryptographic_state_invariant state' s2 /\
	      get_personal_user_id state' == get_personal_user_id state /\
              Set.subset (cstate_session_ids state') (cstate_session_ids state) /\
              session_invariant session s2 /\
              not (State.is_session (session_id session) s1) /\
              not (Set.mem (session_id session) (cstate_session_ids state')) /\
              Ghost.reveal session.local_user_id == state.personal_user_id /\
              Ghost.reveal session.remote_user_id == remote_user_id /\
              msg_recv_event msg session.local_user_id session.remote_user_id s2
          | None -> cryptographic_state_invariant state s2)
      ) =
    crypto_invariant_stable_under_parallel_rel (); 
    cryptographic_state_invariant_stable_under_event ();
    session_invariant_stable_under_event ();
    session_invariant_stable_under_parallel_rel ();
    crypto_invariant_framing ();
    match lookup_and_remove_sid state one_time_prekey with
    | Some sid, state' -> (
        SidMapSetBase.all_sidmapset_facts_lemma ();
        FMap.all_finite_map_facts_lemma ();
        (* The one-time prekey is a real one *)
        let cv_personal_user_id = Helpers.get_cv_uid state.personal_user_id in
        let cv_remote_user_id = Helpers.get_cv_uid remote_user_id in
        (**) let st = get_state () in
        (**) assert (cryptographic_state_invariant state' st);
        Classical.forall_intro (Classical.move_requires (SidMapSetBase.set_mem_implies_exists state'.one_time_prekey_id_to_sid Set.singleton));
        (**) assert (Set.subset (cstate_session_ids state') (State.local_of st));
        (**) assert (all_prekeys_sessions_match_keys state.one_time_prekey_id_to_sid cv_personal_user_id state.personal_identity_key st);

        (**) Classical.forall_intro (lemma_Osend3
            sid
            remote_identity_key.identity_key
            remote_identity_key.signature_key
            ephemeral_1
            ephemeral_2
            init_message
            cv_remote_user_id
	    counter);
        (**) Classical.forall_intro (Classical.move_requires (lemma_Osend3'
            sid
            remote_identity_key.identity_key
            remote_identity_key.signature_key
            ephemeral_1
            ephemeral_2
            init_message
            cv_remote_user_id
	    counter
            cv_personal_user_id
            state'.personal_identity_key));
        (**) Classical.forall_intro (lemma_Osend3_crypto
            sid
            remote_identity_key.identity_key
            remote_identity_key.signature_key
            ephemeral_1
            ephemeral_2
            init_message
            cv_remote_user_id
	    counter);
        (**) assert (crypto_keys_match_session_entries sid cv_personal_user_id state'.personal_identity_key st);
        match oracle_Osend3
            sid
            remote_identity_key.identity_key
            remote_identity_key.signature_key
            ephemeral_1
            ephemeral_2
            init_message
            cv_remote_user_id
	    counter
        with
        | None ->
            (**) Classical.forall_intro (fun sid -> crypto_keys_stable_under_parallel_rel sid cv_personal_user_id state.personal_identity_key);
            (**) let st2 = get_state () in
            (* Needed for the proof to go through *)
            (**) assert (all_prekeys_sessions_match_keys state.one_time_prekey_id_to_sid cv_personal_user_id state.personal_identity_key st2);
            None
        | Some (sid', msg) ->
	  (* The next assertions are no longer needed, and in fact make the proof fail.
          (**) assert (not (Set.mem sid' (State.local_of st)));
	  (**) assert (not (Set.mem sid' (cstate_session_ids state')));
          (**) let s1 = get_state () in
          (**) assert (cryptographic_state_invariant state' s1);
          (**) session_keys_stable_under_parallel_rel sid' state'.personal_identity_key remote_identity_key; *)
            (* We will not retry with the same one-time prekey,
               so we can remove the CryptoVerif session *)
            remove_cv_session sid;
            Some (state', {
               sid = sid';
               last_used_nonce = n_start;
               encryption_scheme = WithOnetimePrekey;
               role = Responder;
               local_user_id = state'.personal_user_id;
               local_identity_key = state'.personal_identity_key;
               remote_user_id;
               remote_identity_key;
               init_message = None
             }, msg)
    )
    | None, state' ->
        (* The one-time prekey is forged *)
        None

#pop-options

#push-options "--z3rlimit 20"

let create_session_from_init_message_without_one_time_prekey
    (state: cryptographic_state_t)
    (init_message: t_cipher)
    (counter: nonce_t)
    (remote_user_id: user_id_t)
    (remote_identity_key: identity_key_t)
    (ephemeral_1: prekey_t)
    (ephemeral_2: prekey_t):
    CVSTInv (option (cryptographic_state_t & session_t & t_message))
      (fun s1 ->
        is_valid_remote_key remote_identity_key remote_user_id s1 /\
        cryptographic_state_invariant state s1
      )
      (fun s1 res s2 ->
        (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2) /\
        (match res with
          | Some (state', session, msg) ->
	      cryptographic_state_invariant state' s2 /\
	      get_personal_user_id state' == get_personal_user_id state /\
              cstate_session_ids state == cstate_session_ids state' /\
              session_invariant session s2 /\
              not (State.is_session (session_id session) s1) /\
              not (Set.mem (session_id session) (cstate_session_ids state')) /\
              Ghost.reveal session.local_user_id == state.personal_user_id /\
              Ghost.reveal session.remote_user_id == remote_user_id /\
              msg_recv_event msg session.local_user_id session.remote_user_id s2
          | None -> cryptographic_state_invariant state s2
        )
      ) =
    crypto_invariant_stable_under_parallel_rel ();
    cryptographic_state_invariant_stable_under_event ();
    session_invariant_stable_under_event ();
    session_invariant_stable_under_parallel_rel ();
    crypto_invariant_implies_session ();
    let cv_personal_user_id = Helpers.get_cv_uid state.personal_user_id in
    let cv_remote_user_id = Helpers.get_cv_uid remote_user_id in
    (**) Classical.forall_intro (lemma_Osend4
        state.long_time_prekey_sid
        remote_identity_key.identity_key
        remote_identity_key.signature_key
        ephemeral_1
        ephemeral_2
        init_message
        cv_remote_user_id
	counter);
    (**) Classical.forall_intro (Classical.move_requires (lemma_Osend4'
        state.long_time_prekey_sid
        remote_identity_key.identity_key
        remote_identity_key.signature_key
        ephemeral_1
        ephemeral_2
        init_message
        cv_remote_user_id
	counter
        cv_personal_user_id
        state.personal_identity_key));
    (**) Classical.forall_intro (lemma_Osend4_crypto
        state.long_time_prekey_sid
        remote_identity_key.identity_key
        remote_identity_key.signature_key
        ephemeral_1
        ephemeral_2
        init_message
        cv_remote_user_id
	counter);
    match
        oracle_Osend4
        state.long_time_prekey_sid
        remote_identity_key.identity_key
        remote_identity_key.signature_key
        ephemeral_1
        ephemeral_2
        init_message
        cv_remote_user_id
	counter
    with
      | None -> None
      | Some (sidt, msg) ->
          Some (state, {
             sid = sidt;
             last_used_nonce = n_start;
             encryption_scheme = WithoutOnetimePrekey;
             role = Responder;
             local_user_id = state.personal_user_id;
             local_identity_key = state.personal_identity_key;
             remote_user_id;
             remote_identity_key;
             init_message = None
             }, msg)

#pop-options

let create_session_from_init_message
    (state: cryptographic_state_t)
    (remote_user_id: user_id_t)
    (remote_identity_key: identity_key_t)
    (init_message_bundle: init_message_bundle_t)
    (ciphertext: t_cipher)
    (counter: nonce_t):
    CVSTInv (option (cryptographic_state_t & session_t & t_message))
        (fun s1 ->
           is_valid_remote_key remote_identity_key remote_user_id s1
           /\ cryptographic_state_invariant state s1)
        (fun s1 res s2 ->
              (match res with
                | Some (state', session, msg) ->
                    cryptographic_state_invariant state' s2 /\
	            get_personal_user_id state' == get_personal_user_id state /\
                    Set.subset (cstate_session_ids state') (cstate_session_ids state) /\
                    session_invariant session s2 /\
                    not (State.is_session (session_id session) s1) /\
                    not (Set.mem (session_id session) (cstate_session_ids state')) /\
                    Ghost.reveal session.local_user_id == state.personal_user_id /\
                    Ghost.reveal session.remote_user_id == remote_user_id /\
                    msg_recv_event msg session.local_user_id session.remote_user_id s2
                | None -> cryptographic_state_invariant state s2)
            /\ (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2)
            /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
        ) =
    match init_message_bundle.one_time_prekey with
        | Some one_time_prekey_id ->
            create_session_from_init_message_with_one_time_prekey
                state
                ciphertext counter
                remote_user_id
                remote_identity_key
                init_message_bundle.ephemeral_1
                init_message_bundle.ephemeral_2
                one_time_prekey_id
        | None ->
            create_session_from_init_message_without_one_time_prekey
                state
                ciphertext counter
                remote_user_id
                remote_identity_key
                init_message_bundle.ephemeral_1
                init_message_bundle.ephemeral_2

let update_nonce
    (session: session_t)
    (n: nonce_t):
    session_t = { session with last_used_nonce = n }

#push-options "--z3rlimit 20"

let is_se_Oenc se = match se with
  | Oracle_Oenc1 | Oracle_Oenc2 | Oracle_Oenc3 | Oracle_Oenc4 -> True
  | _ -> False

let get_pre_Oenc (se: signal_oracle_name{is_se_Oenc se}) = match se with
  | Oracle_Oenc1 -> SIGNAL.Invariant.pre_Oenc1
  | Oracle_Oenc2 -> SIGNAL.Invariant.pre_Oenc2
  | Oracle_Oenc3 -> SIGNAL.Invariant.pre_Oenc3
  | Oracle_Oenc4 -> SIGNAL.Invariant.pre_Oenc4

let lemma_pre_Oenc (s: session_t) message new_nonce (on: signal_oracle_name{is_se_Oenc on}) (st: signal_state) : Lemma
  (requires session_invariant s st /\
            SIGNAL.Invariant.inv st /\
            msg_send_event message (local_user_id s) (remote_user_id s) st)
  (ensures
    (get_pre_Oenc on) s.sid message new_nonce st
  )
  = match get_session_entry st on s.sid with
    | None -> ()
    | Some se ->
      match se with
      | R1_Oenc1 _ _ local_key local_signkey remote_id local_id remote_key remote_signkey
      | R1_Oenc2 _ _ local_key local_signkey remote_id local_id remote_key remote_signkey
      | R1_Oenc3 _ _ local_key local_signkey remote_id local_id remote_key remote_signkey
      | R1_Oenc4 _ _ local_key local_signkey remote_id local_id remote_key remote_signkey ->
        begin
        match SidMap.get (State.sessions_of st) s.sid with
        | None -> ()
        | Some entries ->
          lemma_get_session_entry st on s.sid (Helpers.get_cv_uid s.local_user_id) s.local_identity_key (Helpers.get_cv_uid s.remote_user_id) s.remote_identity_key;
          Helpers.reveal_fun_mkidkey local_key local_signkey;
          Helpers.reveal_fun_mkidkey remote_key remote_signkey
        end
      | _ -> ()

let encrypt_message
    (session: session_t)
    (message: t_message):
    CVSTInv (session_t & option encrypted_message_t)
        (fun st -> session_invariant session st
            /\ msg_send_event message (local_user_id session) (remote_user_id session) st)
        (fun s1 res s2 ->
            local_user_id session == local_user_id res._1 /\
            remote_user_id session == remote_user_id res._1 /\
            session_id session == session_id res._1 /\
            session_invariant res._1 s2
            /\ (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2)
            /\ forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2) =
    crypto_invariant_stable_under_parallel_rel ();
    session_invariant_stable_under_parallel_rel ();
    let new_nonce = increase_nonce session.last_used_nonce in
    match session.encryption_scheme, session.role with
    | WithOnetimePrekey, Initiator -> (
        (**) lemma_invariant_sessions();
        (**) lemma_invariant_sessions_crypto();
        (**) Classical.forall_intro (Classical.move_requires (lemma_pre_Oenc session message new_nonce Oracle_Oenc1));
        match oracle_Oenc1
                session.sid
                message
                new_nonce with
            | None -> update_nonce session new_nonce, None
            | Some b -> update_nonce session new_nonce,
	        Some { init_msg = session.init_message; ciphertext = b; counter = new_nonce }
    )
    | WithOnetimePrekey, Responder -> (
        (**) lemma_invariant_sessions();
        (**) lemma_invariant_sessions_crypto();
        (**) Classical.forall_intro (Classical.move_requires (lemma_pre_Oenc session message new_nonce Oracle_Oenc2));
        match oracle_Oenc2
                session.sid
                message
                new_nonce with
            | None -> update_nonce session new_nonce, None
            | Some b -> update_nonce session new_nonce,
	        Some { init_msg = session.init_message; ciphertext = b; counter = new_nonce }
    )
    | WithoutOnetimePrekey, Initiator -> (
        (**) lemma_invariant_sessions();
        (**) lemma_invariant_sessions_crypto();
        (**) Classical.forall_intro (Classical.move_requires (lemma_pre_Oenc session message new_nonce Oracle_Oenc3));
        match oracle_Oenc3
                session.sid
                message
                new_nonce with
            | None -> update_nonce session new_nonce, None
            | Some b -> update_nonce session new_nonce,
	        Some { init_msg = session.init_message; ciphertext = b; counter = new_nonce }
    )
    | WithoutOnetimePrekey, Responder -> (
        (**) lemma_invariant_sessions();
        (**) lemma_invariant_sessions_crypto();
        (**) Classical.forall_intro (Classical.move_requires (lemma_pre_Oenc session message new_nonce Oracle_Oenc4));
        match oracle_Oenc4
                session.sid
                message
                new_nonce with
            | None -> update_nonce session new_nonce, None
            | Some b -> update_nonce session new_nonce,
	        Some { init_msg = session.init_message; ciphertext = b; counter = new_nonce }
    )

#pop-options

#push-options "--z3rlimit 40"

let decrypt_message_1
    (session: session_t)
    (cipher: t_cipher)
    (nonce: nonce_t)
    : CVSTInv (option t_message)
        (fun s1 -> session_invariant session s1)
        (fun s1 res s2 ->
            (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2)
            /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
            /\ (match res with | None -> True | Some msg -> msg_recv_event' msg (Helpers.get_cv_uid session.local_user_id) session.local_identity_key (Helpers.get_cv_uid session.remote_user_id) session.remote_identity_key s2)
        ) =
    crypto_invariant_stable_under_parallel_rel ();
    session_invariant_stable_under_parallel_rel ();
    lemma_invariant_sessions();
    lemma_invariant_sessions_crypto();
      (* Applies [lemma_get_session_entry'] for [get_session_entry]
     [lemma_state_add_event] for [state_add_event]
     and [Helpers.reveal_fun_mkidkey] for [fun_mkidkey]
     by SMTPat to prove [msg_recv_event'] *)
    oracle_Odec1
        session.sid
        cipher
        nonce

let decrypt_message_2
    (session: session_t)
    (cipher: t_cipher)
    (nonce: nonce_t)
    : CVSTInv (option t_message)
        (fun s1 -> session_invariant session s1)
        (fun s1 res s2 ->
            (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2)
            /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
            /\ (match res with | None -> True | Some msg -> msg_recv_event' msg (Helpers.get_cv_uid session.local_user_id) session.local_identity_key (Helpers.get_cv_uid session.remote_user_id) session.remote_identity_key s2)
        ) =
    crypto_invariant_stable_under_parallel_rel ();
    session_invariant_stable_under_parallel_rel ();
    lemma_invariant_sessions();
    lemma_invariant_sessions_crypto();
    oracle_Odec2
        session.sid
        cipher
        nonce

let decrypt_message_3
    (session: session_t)
    (cipher: t_cipher)
    (nonce: nonce_t)
    : CVSTInv (option t_message)
        (fun s1 -> session_invariant session s1)
        (fun s1 res s2 ->
            (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2)
            /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
            /\ (match res with | None -> True | Some msg -> msg_recv_event' msg (Helpers.get_cv_uid session.local_user_id) session.local_identity_key (Helpers.get_cv_uid session.remote_user_id) session.remote_identity_key s2)
        ) =
    crypto_invariant_stable_under_parallel_rel ();
    session_invariant_stable_under_parallel_rel ();
    lemma_invariant_sessions();
    lemma_invariant_sessions_crypto();
    oracle_Odec3
        session.sid
        cipher
        nonce

let decrypt_message_4
    (session: session_t)
    (cipher: t_cipher)
    (nonce: nonce_t)
    : CVSTInv (option t_message)
        (fun s1 -> session_invariant session s1)
        (fun s1 res s2 ->
            (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2)
            /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
            /\ (match res with | None -> True | Some msg -> msg_recv_event' msg (Helpers.get_cv_uid session.local_user_id) session.local_identity_key (Helpers.get_cv_uid session.remote_user_id) session.remote_identity_key s2)
        ) =
    crypto_invariant_stable_under_parallel_rel ();
    session_invariant_stable_under_parallel_rel ();
    lemma_invariant_sessions();
    lemma_invariant_sessions_crypto();
    oracle_Odec4
        session.sid
        cipher
        nonce

let decrypt_message
    (session: session_t)
    (cipher: t_cipher)
    (nonce: nonce_t):
    CVSTInv (option (session_t & t_message))
        (fun s1 -> session_invariant session s1)
        (fun s1 res s2 ->
            (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2)
            /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
            /\ (match res with | None -> True | Some (session', msg) ->
	          session_invariant session' s2 /\
                  msg_recv_event msg (local_user_id session) (remote_user_id session) s2 /\
                  session_id session == session_id session' /\
		  session'.local_user_id == session.local_user_id /\
		  session'.remote_user_id == session.remote_user_id)
        ) =
     match
        (match session.encryption_scheme, session.role with
        | WithOnetimePrekey, Initiator ->
            decrypt_message_2
                session
                cipher
                nonce
        | WithOnetimePrekey, Responder ->
            decrypt_message_1
                session
                cipher
                nonce
        | WithoutOnetimePrekey, Initiator ->
            decrypt_message_4
                session
                cipher
                nonce
        | WithoutOnetimePrekey, Responder ->
            decrypt_message_3
                session
                cipher
                nonce)
     with
     | None -> None
     | Some msg ->
           Some ({ session with init_message = None }, msg)

#pop-options

let finalize_session (session: session_t):
    CVSTInv unit
      (fun s1 -> session_invariant session s1)
      (fun s1 res s2 ->
        (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)) =
    remove_cv_session session.sid
