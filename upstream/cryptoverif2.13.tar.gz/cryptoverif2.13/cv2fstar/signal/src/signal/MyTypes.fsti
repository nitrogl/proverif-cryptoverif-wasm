(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module MyTypes

open CVTypes
open Lib.ByteSequence

(**
    The identity key is the cryptographic key identifying the user/device.

    It is composed of the identity key and the signature key.
    It is generated only once per user/device.
*)
noeq
type identity_key_t = {
    identity_key:   lbytes 32 ;
    signature_key:  lbytes 32 ;
}

let identity_key_eq e1 e2 =
    CVTypes.eq_bytes e1.identity_key e2.identity_key
        && CVTypes.eq_bytes e1.signature_key e2.signature_key

let mk_identity_key (identity_key: lbytes 32) (signature_key: lbytes 32) : identity_key_t = { identity_key; signature_key }

val print_identity_key: identity_key_t -> FStar.All.ML unit
val serializer_identity_key : serializer identity_key_t
val size_identity_key_lemma (x: identity_key_t):
  Lemma (Seq.length (serializer_identity_key.serialize x) == 64)

val user_id_t: eqtype
val equal_user_id_t: user_id_t -> user_id_t -> bool
val make_user_id: (Lib.IntTypes.range_t Lib.IntTypes.U64) -> user_id_t
val print_user_id: user_id_t -> FStar.All.ML unit
val user_id_to_string : user_id_t -> string
val serializer_user_id: serializer user_id_t
val size_user_id_lemma (x: user_id_t):
  Lemma (Seq.length (serializer_user_id.serialize x) == 8)

val device_id_t: eqtype
val make_device_id: (x: nat { x < Constants.max_devices_per_user}) -> device_id_t
val print_device_id: device_id_t -> FStar.All.ML unit
val device_id_to_string : device_id_t -> string
val serializer_device_id: serializer device_id_t

val len_devices (l: list device_id_t) : Lemma
  (requires (List.noRepeats l))
  (ensures (List.length l <= Constants.max_devices_per_user))

val prekey_id_t: eqtype
val make_prekey_id (n: nat{ n < Constants.num_one_time_prekeys }) : prekey_id_t
val print_prekey_id: prekey_id_t -> FStar.All.ML unit
val serializer_prekey_id: serializer prekey_id_t
val size_prekey_id_lemma (x: prekey_id_t):
  Lemma (Seq.length (serializer_prekey_id.serialize x) == 1)

let plaintext_t = bbytes Constants.max_message_size

val message_record_t: Type0

val make_message_record : user_id_t -> user_id_t -> plaintext_t -> message_record_t
val checkuid : user_id_t -> user_id_t -> message_record_t -> bool
val get_plaintext : message_record_t -> plaintext_t

val checkuid_lemma (receiver_uid' sender_uid' receiver_uid sender_uid: user_id_t) (msg: plaintext_t):
  Lemma (checkuid receiver_uid' sender_uid' (make_message_record receiver_uid sender_uid msg) /\ Constants.checkuid ==> receiver_uid' == receiver_uid /\ sender_uid' == sender_uid)
val get_plaintext_lemma (receiver_uid sender_uid: user_id_t) (msg: plaintext_t): 
  Lemma (get_plaintext (make_message_record receiver_uid sender_uid msg) == msg)

val serializer_message_record : serializer message_record_t
val size_message_record_lemma (x: message_record_t):
  Lemma (Seq.length (serializer_message_record.serialize x) <= Constants.max_ciphertext_size)
