(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module Network.Helper

open FStar.Mul

open Crypto.Abstraction
open Lib.Sequence
open Lib.ByteSequence
open Lib.IntTypes
open Constants
open Network

open SIGNAL.Effect
open SIGNAL.Types
open SIGNAL.Events.FStar

friend SIGNAL.Types

open Network.Types

let parse_port (p: string): option port =
   match Utils.int_of_string p with
   | Some p ->
      if p >= 0 && p < num_ports then Some p else None
   | None -> None

let debug_print s =
  if debug_level >= 1 then
    print_string s

let send_packet (ch: net_channel) (p: packet_t) :
    CVSTML (net_res_t unit string) =
  if debug_level >= 2 then
    ml_to_CVST (fun () ->
      FStar.IO.print_string "Sending ";
      print_packet p;
      FStar.IO.print_string "\n");
  Network.send ch true (serializer_packet.serialize p)

let recv_packet (ch: net_channel) :
    CVSTML (net_res_t packet_t recv_err_t) =
  let res = Network.receive ch serializer_packet in
  begin
    match res with
    | NTOk p ->
      if debug_level >= 2 then
        ml_to_CVST (fun () ->
          FStar.IO.print_string "Received ";
          print_packet p;
          FStar.IO.print_string "\n")
    | NTError _ -> ()
  end;
  res

let fetch_prekey_bundle
  (ch: net_channel)
  (user_id: user_id_t)
  (device_id: device_id_t):
  CVSTInv (option prekey_bundle_t)
            (requires fun _ -> True)
            (ensures fun s0 _ s1 ->
              State.local_sessions_are_equal s0 s1
            )
  =
  let request: packet_t =
      PacketPrekeyBundleRequest { user_id ; device_id }
  in
  debug_print ("Requesting prekey bundle for user "^user_id_to_string user_id^" device "^device_id_to_string device_id^"\n");
  let send_status = send_packet ch request in
  match send_status with
  | NTOk () ->
    begin
      let response = recv_packet ch in
      match response with
      | NTOk(PacketPrekeyBundle prekey_bundle) ->
          debug_print "Received prekey bundle\n";
          Some prekey_bundle
      | NTOk (PacketUserDoesntExist) ->
        debug_print "User does not exist\n";
	None
      | NTOk (PacketDeviceDoesntExist) ->
        debug_print "Device does not exist\n";
	None
      | _ ->
          debug_print "Unexpected error; could not receive prekey bundle\n";
          None
    end
  | NTError s ->
    debug_print ("Network error: "^s^"\n");
    None

let upload_message
  (ch: net_channel)
  (sending_device: user_device_id_t)
  (receiving_user: user_id_t)
  (l: lbyte_list pre_packet_t):
  CVSTInv (option packet_t)
            (requires fun _ -> True)
            (ensures fun s0 _ s1 ->
              State.local_sessions_are_equal s0 s1
            )
  =
  let p: packet_t = 
    if receiving_user = sending_device.user_id then
      PacketSyncMessages { sending_device ; messages = l }
    else
      PacketMessages { sending_device ; receiving_user ; messages = l } 
  in
  debug_print ("Sending messages to user "^user_id_to_string receiving_user^"\n");
  match send_packet ch p with
  | NTOk () ->
    begin
      match recv_packet ch with
      | NTOk packet -> Some packet
      | _ ->
         debug_print "Could not receive answer\n";
         None
    end
  | NTError s ->
    debug_print ("Network error: "^s^"\n");
    None

let query_user_id
  (ch: net_channel):
  CVSTInv (option user_id_t)
            (requires fun _ -> True)
            (ensures fun s0 _ s1 ->
              State.local_sessions_are_equal s0 s1
            )
  =
  let p: packet_t = PacketCreateUserRequest in
  debug_print "Creating user\n";
  match send_packet ch p with
  | NTOk() ->
    begin
      let response = recv_packet ch in
      match response with
      | NTOk (PacketCreateUser user_id) ->
        debug_print ("User "^user_id_to_string user_id^" created\n");
        Some user_id
      | _ ->
        debug_print "Could not create user\n";
	None
    end
  | NTError s ->
    debug_print ("Network error: "^s^"\n");
    None

#push-options "--z3rlimit 30"

let query_device_id
  (ch: net_channel)
  (user_id: user_id_t)
  (k: identity_key_t)
  (b: signed_prekey_bundle_t)
  (otp: lbyte_list (prekey_id_t & prekey_t)):
  CVSTInv (option device_id_t)
            (requires fun s -> SIGNAL.Invariant.is_valid_local_key k user_id s)
            (ensures fun s0 _ s1 ->
              State.local_sessions_are_equal s0 s1
            )
  =
  let p: packet_t = PacketCreateDeviceRequest(user_id, k, b, otp) in
  add_event (Event_Sent_Key_for_User k user_id); 
  debug_print ("Creating device for user "^user_id_to_string user_id^"\n");
  match send_packet ch p with
  | NTOk () ->
    begin
      let response = recv_packet ch in
      match response with
      | NTOk (PacketCreateDevice device_id) ->
        debug_print ("Device "^device_id_to_string device_id^" created\n");
        Some device_id
      | NTOk (PacketUserDoesntExist) ->
        debug_print "User does not exist\n";
	None
      | NTOk (PacketError) ->
        debug_print "Too many devices for this user\n";
	None
      | _ ->
        debug_print "Unexpected error; could not create device\n";
        None
    end
  | NTError s ->
    debug_print ("Network error: "^s^"\n");
    None

#pop-options

let refresh_keys
  (ch: net_channel)
  (user_device_id: user_device_id_t)
  (b: signed_prekey_bundle_t)
  (otp: lbyte_list (prekey_id_t & prekey_t)):
  CVSTInv bool
            (requires fun _ -> True)
            (ensures fun s0 _ s1 ->
              State.local_sessions_are_equal s0 s1
            )
  = let p: packet_t = PacketPrekeys(user_device_id, b, otp) in
  debug_print ("Refreshing prekeys for user "^user_id_to_string user_device_id.user_id^", device "^device_id_to_string user_device_id.device_id^"\n");
  match send_packet ch p with
  | NTOk () ->
    begin
      let response = recv_packet ch in
      match response with
      | NTOk (PacketPrekeysAccepted) ->
        debug_print ("Accepted\n");
        true
      | NTOk (PacketUserDoesntExist) ->
        debug_print "User does not exist\n";
	false
      | NTOk (PacketDeviceDoesntExist) ->
        debug_print "Device does not exist\n";
	false
      | _ ->
        debug_print "Unexpected error; could not refresh prekeys\n";
        false
    end
  | NTError s ->
    debug_print ("Network error: "^s^"\n");
    false

let remove_device
  (ch: net_channel)
  (user_device_id: user_device_id_t):
  CVSTInv bool
            (requires fun _ -> True)
            (ensures fun s0 _ s1 ->
              State.local_sessions_are_equal s0 s1
            )
  =
  let p: packet_t = PacketRemoveDeviceRequest(user_device_id) in
  debug_print ("Removing device "^device_id_to_string user_device_id.device_id^" for user "^user_id_to_string user_device_id.user_id^"\n");
  match send_packet ch p with
  | NTOk () ->
    begin
      let response = recv_packet ch in
      match response with
      | NTOk (PacketRemoveDeviceAccepted) ->
        debug_print ("Accepted\n");
        true
      | NTOk (PacketUserDoesntExist) ->
        debug_print "User does not exist\n";
	false
      | NTOk (PacketDeviceDoesntExist) ->
        debug_print "Device does not exist\n";
	false
      | _ ->
        debug_print "Unexpected error; could not remove device\n";
        false
    end
  | NTError s ->
    debug_print ("Network error: "^s^"\n");
    false

