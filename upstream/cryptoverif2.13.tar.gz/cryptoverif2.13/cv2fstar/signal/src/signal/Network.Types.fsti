(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
(**

    ---------------  Module Network.Types ---------------

    Defines several types used for Networking.

*)
module Network.Types

open CVTypes
open Lib.ByteSequence
open Lib.IntTypes
open Spec.Chacha20Poly1305
open SIGNAL.Types
open Constants

include MyTypes

let signature_t = lbytes 64

let nonce_t = lbytes 12
val increase_nonce : nonce_t -> nonce_t

let prekey_t = lbytes 32

noeq
type signed_prekey_bundle_t = {
    prekey:     prekey_t ;
    signature:  signature_t ;
}

noeq
type prekey_bundle_t = {
    (* Note: the Sesame spec says this also contains the device identity key.
       It does not seem useful since the identity key is also provided in
       the PacketListOfDevicesIncorrect message *)
    signed_prekey_bundle:   signed_prekey_bundle_t ;
    one_time_prekey:        option (prekey_id_t & prekey_t) ;
}

val make_prekey_bundle: signed_prekey_bundle_t -> option (prekey_id_t & prekey_t) -> prekey_bundle_t

noeq
type init_message_bundle_t = {
    (* All initiation messages contain the sending device's identity public key in an unencrypted header. *)
    sender_identity_key: identity_key_t ;
    ephemeral_1: prekey_t ;
    ephemeral_2: prekey_t ;
    one_time_prekey: option prekey_id_t ;
}

val make_init_message_bundle
    (sender_identity_key: identity_key_t)
    (ephemeral_1: prekey_t)
    (ephemeral_2: prekey_t)
    (one_time_prekey: option prekey_id_t):
    init_message_bundle_t

noeq
type user_device_id_t = {
  user_id: user_id_t ;
  device_id: device_id_t ;
}

(* List whose length fits on one byte *)
let lbyte_list a = (l: list a { List.length l < 256 })

noeq
type device_update_t = {
  devices_removed: lbyte_list device_id_t;
  devices_added: lbyte_list (device_id_t & identity_key_t)
  }

noeq
type encrypted_message_t = {
  init_msg: option init_message_bundle_t; (* when this is an initiating session *)
  counter: nonce_t;
  ciphertext: t_cipher;
}

val serializer_encrypted_message : serializer encrypted_message_t

val encrypted_message_not_too_big (x: encrypted_message_t) :
    Lemma
    (ensures (Seq.length (serializer_encrypted_message.serialize x) <= max_pre_packet_content_size))

noeq 
type pre_packet_t = {
  receiving_device: device_id_t;
  content: bbytes max_pre_packet_content_size; (* serialization of a encrypted_message_t -- we keep the serialization
  	   	 because the server does not need to look inside the message *)
}

val make_pre_packet (d: device_id_t) (c: bbytes max_pre_packet_content_size): pre_packet_t

noeq
type packet_messages_t = {
  sending_device: user_device_id_t;
  receiving_user: user_id_t;
  messages: lbyte_list pre_packet_t
}

noeq
type packet_sync_messages_t = {
  sending_device: user_device_id_t;
  messages: lbyte_list pre_packet_t
}

noeq
type packet_message_t = {
  psending_device: user_device_id_t;
  content: bbytes max_pre_packet_content_size; (* serialization of a message_t -- we keep the serialization
  	   	 because the server does not need to look inside the message *)
}

noeq
type packet_t =
    (* To create a new user *)
  | PacketCreateUserRequest
  | PacketCreateUser of user_id_t
  
    (* To create a new device *)
  | PacketCreateDeviceRequest of user_id_t & identity_key_t & signed_prekey_bundle_t & lbyte_list (prekey_id_t & prekey_t)
  | PacketCreateDevice of device_id_t

    (* To remove an existing device *)
  | PacketRemoveDeviceRequest of user_device_id_t
  | PacketRemoveDeviceAccepted

    (* To upload to the server a new signed prekey bundle and a list of one-time prekeys
       We assume that we always renew the signed prekey when we send a bunch
       of one-key prekeys. *)
  | PacketPrekeys of user_device_id_t & signed_prekey_bundle_t & lbyte_list (prekey_id_t & prekey_t)
  | PacketPrekeysAccepted

    (* To retrieve from the server a prekey bundle for a given device *)
  | PacketPrekeyBundleRequest of user_device_id_t
  | PacketPrekeyBundle of prekey_bundle_t

    (* To send a batch of messages
       Note: when we contact a new user, we send a PacketMessages with
       an empty list of messages, and the server replies with
       PacketListOfDevicesIncorrect giving the keys for the devices
       of that user.
       As in Signal, we distinguish messages sent to other users
       (PacketMessages) from messages sent to other devices of the same
       user (PacketSyncMessages). See https://github.com/signalapp/Signal-Server/blob/5fedb48b55875cb10633f3b8962cd8f73e7118ed/service/src/main/proto/org/signal/chat/messages.proto#L19
       *)
  | PacketMessages of packet_messages_t
  | PacketSyncMessages of packet_sync_messages_t
  | PacketMessagesAccepted
  | PacketUserDoesntExist
  | PacketListOfDevicesIncorrect of device_update_t

    (* Poll from the mailbox on the server *)
  | PacketPoll of user_device_id_t
  | PacketMessage of packet_message_t
  | PacketNoMessage

  | PacketError
  | PacketDeviceDoesntExist

val serializer_packet : serializer packet_t

val print_packet : packet_t -> FStar.All.ML unit
