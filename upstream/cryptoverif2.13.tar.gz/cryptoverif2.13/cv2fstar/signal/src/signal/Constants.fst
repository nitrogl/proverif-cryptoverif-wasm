(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module Constants

open Lib.IntTypes
open FStar.Mul

let debug_level = 2

(**
  Crypto constants
*)
let identity_key_t_size = 64

(**
  Protocol constants
*)

(* Maximum number of devices per user. *)
let max_devices_per_user = 124

(* Number of one-time prekeys that are sent to the server in one go *)
let num_one_time_prekeys = 10

(**
  Network constants
*)

let server_name = "127.0.0.1"
let server_port : Network.port = 5555


let max_pre_packet_content_size = 256 * 1024 (* 256 kB, as in Signal
https://github.com/signalapp/Signal-Server/blob/5fedb48b55875cb10633f3b8962cd8f73e7118ed/service/src/main/proto/org/signal/chat/messages.proto#L72 *)

(*
  Maximum size of cipher text.
*)
let max_ciphertext_size = max_pre_packet_content_size - 147 - Spec.Chacha20Poly1305.size_tag

(*
  Maximum size of messages.
*)
let max_message_size = max_ciphertext_size - 20

(* Maximum latency (in seconds).
   After that latency, stale devices and users are deleted 
*)
let max_latency = 1800

(* Maximum number of sessions with a given device. 
   If there are more sessions, the sessions at the tail of the list 
   are removed.
*)
let max_sessions = 40

(* One of the next two settings must be true for the proof of the 
correspondence theorem to work *)

(*
  Do we check the uids of the receiver and the sender?
*)
let checkuid = false

(*
  Do we include the sender and receiver of the first message in
  authenticated data?
*)
let uid_in_ad = true
