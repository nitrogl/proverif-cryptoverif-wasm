(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module Client.Main

open SIGNAL.Effect
open Network.Types
open Network.Helper
open Network
open SIGNAL.InvariantLemmas

let pos char (s: string) : (r: option nat { (match r with | None -> True | Some i -> i < String.length s) }) =
  let rec aux (i: nat { i <= String.length s }) : Tot (r: option nat { (match r with | None -> True | Some i -> i < String.length s) }) (decreases (String.length s - i)) =
    if i = String.length s then None else
    if String.index s i = char then Some i else aux (i+1)
  in
  aux 0

let split_word (s: string) =
  match pos ' ' s with
  | None -> s, ""
  | Some i ->
     String.sub s 0 i, String.sub s (i+1) (String.length s - i - 1)

open Lib.IntTypes
open CVTypes

let parse_user_id (remote_user_id_s: string): option user_id_t =
  (* FStar.Parse.int_of_string was not implemented, so we implemented
     an int_of_string function in the cv2fstar library.
     This issue was fixed in F* on Feb 14, 2026. *)
  match Utils.int_of_string remote_user_id_s with
  | None -> None
  | Some n ->
      if minint U64 <= n && n <= maxint U64 then
        Some (MyTypes.make_user_id n)
      else
        None

let rec parse_send (s: string): FStar.All.ML (option (list user_id_t & string)) =
  let first, rest = split_word s in
  if first = ":" then
    Some ([], rest)
  else
    match parse_user_id first with
    | None ->
        FStar.IO.print_string ("Bad user id "^first^"\n");
        None
    | Some user_id ->
       if rest = "" then
         begin
           FStar.IO.print_string "Expecting : and a message after user ids\n";
           None
         end
       else
       match parse_send rest with
       | None -> None
       | Some (l, s) -> Some (user_id::l, s)

#push-options "--z3rlimit 20"

let open_connection (client: Client.t) (server_addr: sockaddr)
  (f: net_channel -> CVSTInv Client.t
         (fun s -> Client.client_invariant client s)
	 (fun _ c s -> Client.client_invariant c s)):
       CVSTInv Client.t (fun s -> Client.client_invariant client s)
       (fun _ c s -> Client.client_invariant c s) =
  Client.client_invariant_stable_under_event();
  let r = Network.open_connection server_addr in
  match r with
  | NTError s ->
      print_string ("Could not connect to the server: "^s^"\n");
      client
  | NTOk ch ->
      let res = f ch in
      let _ = Network.shutdown_connection ch in
      let _ = Network.close_connection ch in
      res

#pop-options

let rec client_loop (client: Client.t) (server_addr: sockaddr):
  CVSTInv unit (fun s -> Client.client_invariant client s) (fun _ _ _ -> True) =
    Client.client_invariant_stable_under_event();
    print_string "Enter a command: ";
    let instruct = ml_to_CVST FStar.IO.input_line in
    let command, args = split_word instruct in
    match command with
    | "poll" ->
         begin
	   let client' = open_connection client server_addr (fun ch -> Client.poll_server ch client) in
	   client_loop client' server_addr
	 end
    | "send" ->
         begin
	   match ml_to_CVST (fun () -> parse_send args) with
	   | None ->
	      client_loop client server_addr
	   | Some (remote_user_id_list, msg_s) ->
              if List.noRepeats remote_user_id_list then
	        let msg = Utils.bytes_of_utf8_string msg_s in
	        let client' = open_connection client server_addr (fun ch -> Client.send_message_users ch client remote_user_id_list msg) in
	        client_loop client' server_addr
              else
                begin
                  print_string "Each target user should be mentioned once.\n";
                  client_loop client server_addr
                end
	 end
    | "refresh_keys" ->
	 let client' = open_connection client server_addr (fun ch -> Client.refresh_keys ch client) in
	 client_loop client' server_addr
    | "quit" ->
	 let client' = open_connection client server_addr (fun ch ->
	   Client.remove_device ch client;
           Client.client_invariant_stable_under_event();
	   client) in
	 ()
    | _ ->
         print_string "Unexpected command. The allowed commands are poll, refresh_keys, quit, and send <user_ids> : <msg>.\n";
	 client_loop client server_addr

#push-options "--z3rlimit 50"

let client (options: option user_id_t & string & port) : CVSTInvMin unit =
  let (user_id_opt, server_name, server_port) = options in
  match Network.getaddrfromname server_name with
  | NTError _ -> print_string "Could not find server\n"
  | NTOk addr ->
  let server_addr = Network.ADDR_INET(addr, server_port) in
  match Network.open_connection server_addr with
  | NTError s ->
     print_string ("Could not connect to the server: "^s^"\n")
  | NTOk ch ->
     let res =
       match user_id_opt with
       | None -> Client.make ch
       | Some user_id -> Client.make_from_user ch user_id
     in
     Client.client_invariant_stable_under_event();
     let _ = Network.shutdown_connection ch in
     let _ = Network.close_connection ch in
     match res with
     | None -> ()
     | Some client ->
        print_string "The allowed commands are poll, refresh_keys, quit, and send <user_ids> : <msg>.\n";
        client_loop client server_addr

#pop-options

let command_syntax() =
  FStar.IO.print_string "Command-line syntax:\n  client.exe <options> [<user id>]\nwhere the options are:\n  -server <server name>\n  -port <server port number>\n"

let rec parse_args (options: option user_id_t & string & port) (l: list string) :
FStar.All.ML (option (option user_id_t & string & port)) =
let (user_id_opt, server_name, server_port) = options in
match l with
| [] -> Some(user_id_opt, server_name, server_port)
| [id] ->
    begin
      match parse_user_id id with
      | None ->
          FStar.IO.print_string "Bad user id\n";
      	  command_syntax();
	  None
      | Some n ->
          Some(Some n, server_name, server_port)
    end
| "-server"::name::l ->
   parse_args (user_id_opt, name, server_port) l
| "-port"::port::l ->
   begin
     match Network.Helper.parse_port port with
     | Some port -> parse_args (user_id_opt, server_name, port) l
     | None ->
         FStar.IO.print_string "Bad port\n";
      	 command_syntax();
	 None
   end
| s::l ->
   FStar.IO.print_string ("Bad option: " ^ s ^ "\n");
   command_syntax();
   None

let main (args: list string) =
  match parse_args (None, Constants.server_name, Constants.server_port) args with
  | None -> ()
  | Some options ->
      init_and_run (fun () -> client options)
