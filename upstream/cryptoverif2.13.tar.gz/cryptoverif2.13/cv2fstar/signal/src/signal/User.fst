(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module User

open FStar.Tactics.V2

open Network.Helper
open Network
open Constants
open SIGNAL.Events
open SIGNAL.Events.FStar
open SIGNAL.Effect
open SIGNAL.Protocol
open SIGNAL.Types
open SIGNAL.Invariant
module List = FStar.List.Tot
module FSet = FStar.FiniteSet.Base
module FMap = FiniteMap
open Lib.ByteSequence
open Crypto.Abstraction

module UInt8 = FStar.UInt8

let default_sending_loop_limit: UInt8.t = 5uy

#set-options "--split_queries always"

noeq
type _t = {
    local_user_device_identifier:   user_device_id_t;
    remote_user_identifier:  user_id_t;
    remote_devices:     FMap.t device_id_t Device.t;
    (* stale = None means the user is not stale.
       stale = Some t means the user is stale since time n *)    
    stale:              option nat;
    sending_loop_limit: UInt8.t;
}

(*
  Devices of the user hold identifiers corresponding to the ones stored in the user.
 *)
let devices_in_map_have_correct_identifiers
  (user: _t) =
  forall (device_id: device_id_t{FMap.mem user.remote_devices device_id}).
    let device = FMap.lookup user.remote_devices device_id in
    Device.remote_identifier device == device_id /\
    Device.local_user_identifier device == user.local_user_device_identifier.user_id /\
    Device.remote_user_identifier device == user.remote_user_identifier


let state_is_consistent (user: _t) =
  SidMapSet.all_disjoint_sets user.remote_devices Device.device_session_ids /\
  devices_in_map_have_correct_identifiers user

type t = (user: _t{state_is_consistent user})

let user_session_ids_pre (devices: FMap.t device_id_t Device.t) : GTot (Set.set SidMap.sidt) =
  SidMapSet.fold_map_set devices Device.device_session_ids

let device_invariant_is_correct'
  (devices: FMap.t device_id_t Device.t)
  (st: signal_state):
  Type0 =
  forall (id: device_id_t). FMap.mem devices id ==> Device.device_invariant (FMap.lookup devices id) st

let device_invariant_is_correct
  (user: t)
  (st: signal_state):
  Type0 =
  device_invariant_is_correct' user.remote_devices st

let user_invariant
  (user: t)
  (st: signal_state):
  Type0 =
  device_invariant_is_correct user st

let user_invariant_stable_under_event (_: unit): Lemma (
    forall s1 s2 u. SIGNAL.InvariantLemmas.rel' s1 s2 ==> State.local_sessions_are_equal s1 s2 ==> user_invariant u s1 ==> user_invariant u s2
) =
  FMap.all_finite_map_facts_lemma () ;
  Device.device_invariant_stable_under_event ()

let user_invariant_stable_under_parallel_rel (_: unit): Lemma (
    forall s1 s2 c. SIGNAL.InvariantLemmas.parallel_rel' s1 s2 ==> user_invariant c s1 ==> user_invariant c s2
) = Device.device_invariant_stable_under_parallel_rel ()

let user_invariant_is_device_invariant_pre
  (st st': signal_state)
  (d: Device.t)
  (_: (forall (u: t). user_invariant u st ==> user_invariant u st')):
  Lemma
    (ensures Device.device_invariant d st ==> Device.device_invariant d st') =
  FSet.all_finite_set_facts_lemma () ;
  FMap.all_finite_map_facts_lemma () ;
  Device.all_device_facts_lemma () ;
  Device.device_invariant_implies_session ();
  SidMapSet.all_sidmapset_facts_lemma();
  let us: t = {
    local_user_device_identifier =
      { user_id = Device.local_user_identifier d;
        device_id = Device.remote_identifier d
	  (* We just need a device id to build the user,
	     its value does not matter *) };
    remote_user_identifier = Device.remote_user_identifier d ;
    remote_devices = FMap.insert FMap.emptymap (Device.remote_identifier d) d;
    stale = None ;
    sending_loop_limit = default_sending_loop_limit ;
  } in
  assert (Device.device_invariant d st ==> user_invariant us st) ;
  assert (FMap.lookup us.remote_devices (Device.remote_identifier d) == d) ;
  ()

let user_invariant_is_device_invariant_pre_pre (st st': signal_state) (d: Device.t): Lemma
  (ensures (forall (u: t). user_invariant u st ==> user_invariant u st') ==> (Device.device_invariant d st ==> Device.device_invariant d st')) =
  FStar.Classical.impl_intro (user_invariant_is_device_invariant_pre st st' d)

let user_invariant_is_device_invariant (_: unit): Lemma
  (ensures forall (st st': signal_state) (d: Device.t).
    (forall (u: t). user_invariant u st ==> user_invariant u st') ==> (Device.device_invariant d st ==> Device.device_invariant d st')
  ) =
    FStar.Classical.forall_intro
      (fun (st: signal_state) -> FStar.Classical.forall_intro
        (fun (st': signal_state) -> FStar.Classical.forall_intro
          (fun d -> FStar.Classical.impl_intro (user_invariant_is_device_invariant_pre st st' d)))
    )

let remote_identifier (user: t): user_id_t = user.remote_user_identifier
let local_identifier (user: t): user_id_t = user.local_user_device_identifier.user_id

let user_session_ids user = user_session_ids_pre user.remote_devices

let user_invariant_implies_session' (user: t) (st: signal_state) sid : Lemma
  (requires user_invariant user st /\ Set.mem sid (user_session_ids user))
  (ensures State.is_session sid st)
  = SidMapSet.set_mem_implies_exists user.remote_devices Device.device_session_ids sid;
    Device.device_invariant_implies_session ()

let user_invariant_implies_session () =
  Classical.forall_intro_3 (fun x y -> Classical.move_requires (user_invariant_implies_session' x y))

let user_invariant_stable_under_session_invariant () =
  Device.device_invariant_stable_under_session_invariant ()

let make
  (local_user_device_identifier: user_device_id_t)
  (remote_user_identifier: user_id_t) =
  SidMapSet.all_sidmapset_facts_lemma ();
  let user = {
    local_user_device_identifier;
    remote_user_identifier;
    remote_devices = FMap.emptymap;
    stale = None;
    sending_loop_limit = default_sending_loop_limit;
  } in
  FMap.all_finite_map_facts_lemma () ;
  user

let make_is_user_invariant_lemma
  (_: unit):
  Lemma (forall (st: signal_state) (local_udid: user_device_id_t) (i: user_id_t).
    user_invariant (make local_udid i) st) =
  FMap.all_finite_map_facts_lemma () ;
  ()

let set_sending_loop_limit
  (user: t)
  (new_sending_loop_limit: UInt8.t):
  t =
  {
    user with sending_loop_limit = new_sending_loop_limit;
  }

let stale (user: t): 
    CVSTInv t
      (fun s1 -> user_invariant user s1)
      (fun s1 new_user s2 ->
        (forall (u: t). user_invariant u s1 ==> user_invariant u s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2) /\
        user_invariant new_user s2 /\
        remote_identifier user == remote_identifier new_user /\
        local_identifier user == local_identifier new_user /\
        user.remote_devices == new_user.remote_devices) = 
  crypto_invariant_stable_under_parallel_rel ();
  user_invariant_stable_under_parallel_rel ();
  match user.stale with
  | None -> { user with stale = Some (Time.time()) }
  | Some _ -> user

let is_stale
  (user: t):
  bool =
  user.stale <> None

let stale_time (user: t) = 
  user.stale

let update_devices
  (user: t)
  (new_devices: FMap.t device_id_t Device.t
      {forall (device_id: device_id_t{FMap.mem new_devices device_id}).
        let device = FMap.lookup new_devices device_id in
        Device.remote_identifier device == device_id /\
        Device.remote_user_identifier device == user.remote_user_identifier /\
        Device.local_user_identifier device == user.local_user_device_identifier.user_id /\
        SidMapSet.all_disjoint_sets new_devices Device.device_session_ids
        }
        ):
  t =
  let new_user =
  {
    user with
    remote_devices = new_devices;
  }
  in
  new_user

let device_exists
  (user: t)
  (device: Device.t):
  bool =
  FMap.mem user.remote_devices (Device.remote_identifier device)

(* Note: This function does not call CryptoVerif; it could
   have effect Pure instead of CVSTInv. In this case, we need a lemma
   to talk about device_invariant and user_invariant for any
   CryptoVerif state.
   Same remark for [add_device], [conditionally_update], [mark_devices_stale].
*)
let update_with_device
  (user: t)
  (device: Device.t{device_exists user device}):
  CVSTInv
    t
    (fun st ->
      Device.device_invariant device st /\
      user_invariant user st /\
      Device.remote_user_identifier device == user.remote_user_identifier /\
      Device.local_user_identifier device == user.local_user_device_identifier.user_id /\
      (forall id. FMap.mem user.remote_devices id ==> id <> Device.remote_identifier device ==>
        Set.disjoint (Device.device_session_ids (FMap.lookup user.remote_devices id)) (Device.device_session_ids device))
    )
    (fun s1 new_user s2 -> device_exists new_user device
      /\ new_user.remote_user_identifier == user.remote_user_identifier
      /\ new_user.local_user_device_identifier == user.local_user_device_identifier
      /\ FMap.lookup new_user.remote_devices (Device.remote_identifier device) == device
      /\ new_user.remote_devices == FMap.insert user.remote_devices (Device.remote_identifier device) device
      /\ user_invariant new_user s2
      /\ s1 == s2)
  =
  SidMapSet.all_sidmapset_facts_lemma ();
  let device_id = Device.remote_identifier device in
  let new_set_of_devices = FMap.insert user.remote_devices device_id device in
  FMap.all_finite_map_facts_lemma () ;
  assert (user_session_ids_pre (FMap.insert (FMap.remove user.remote_devices device_id) device_id device) == user_session_ids_pre (FMap.insert user.remote_devices device_id device));
  assert (forall (device_id: device_id_t{FMap.mem new_set_of_devices device_id /\ device_id <> Device.remote_identifier device}).
      (FMap.lookup new_set_of_devices device_id) == (FMap.lookup user.remote_devices device_id)
    ) ;
  update_devices user (
    new_set_of_devices
  )

(**
    Removes a device from the list of devices.

    Also, we do not use the update_device function as it does not update devices_id with it.
    I will add some preconditions on the function later.
*)
let remove_device
  (user: t)
  (device_id: device_id_t):
  t =
  FMap.all_finite_map_facts_lemma () ;
  let new_user =
    {
        user with remote_devices = FMap.remove user.remote_devices device_id
    } in
  new_user

(**
    Finds a device with id if any.
*)
let find_device
  (user: t)
  (device_id: device_id_t):
  (res: option (Device.t){forall device. res == Some device ==> device_exists user device /\ Device.remote_identifier device == device_id /\ FMap.lookup user.remote_devices device_id == device}) =
  if FMap.mem user.remote_devices device_id then
    Some (FMap.lookup user.remote_devices device_id)
  else
    None

let find_device_None_device_dont_exists () : Lemma (forall
  (user: t)
  (device_id: device_id_t).
    find_device user device_id == None ==>
      not (FMap.mem user.remote_devices device_id))
  = ()

let add_device
  (user: t)
  (device: Device.t):
  CVSTInv
    t
    (fun st ->
      not (device_exists user device)
      /\ not(Device.is_stale device)
      /\ Device.device_invariant device st
      /\ Device.remote_user_identifier device == user.remote_user_identifier
      /\ Device.local_user_identifier device == user.local_user_device_identifier.user_id
      /\ Device.device_session_ids device == Set.empty
      /\ user_invariant user st)
    (fun s1 res s2 ->
      res.remote_user_identifier == user.remote_user_identifier
      /\ res.local_user_device_identifier == user.local_user_device_identifier
      /\ user_invariant res s2
      /\ device_exists res device
      /\ FMap.lookup res.remote_devices (Device.remote_identifier device) == device
      /\ res.remote_devices == FMap.insert user.remote_devices (Device.remote_identifier device) device
      /\ s1 == s2
    ) =
    SidMapSet.all_sidmapset_facts_lemma ();
    let device_id = Device.remote_identifier device in
    let new_devices = FMap.insert user.remote_devices device_id device in
    FMap.all_finite_map_facts_lemma ();
    assert (FMap.lookup new_devices device_id == device) ;
    let new_user = {
      user with
      remote_devices = new_devices;
    } in
    assert (forall (device_id: device_id_t{FMap.mem new_user.remote_devices device_id /\ device_id <> (Device.remote_identifier device)}).
          (FMap.lookup new_user.remote_devices device_id) == (FMap.lookup user.remote_devices device_id)
    ) ;
    new_user

(* When [remove_stale = false], conditionally updates the device.
   When [remove_stale = true], additionally removes the device if it is stale,
   thus performing steps 1 and 2 of "prep for encrypting", for the device record.
   It returns the device and the updated user. *)

let conditionally_update
  (user: t)
  (remove_stale: bool)
  (device_id: device_id_t)
  (identity_key: identity_key_t):
  CVSTInv
    (Device.t & t)
    (fun st -> 
      is_valid_remote_key identity_key user.remote_user_identifier st /\
      user_invariant user st)
    (fun s1 res s2 ->
      remote_identifier user == remote_identifier res._2 /\
      local_identifier user == local_identifier res._2 /\
      user_invariant res._2 s2 /\
      Device.device_invariant res._1 s2 /\
      Device.local_user_identifier res._1 == user.local_user_device_identifier.user_id /\
      Device.remote_user_identifier res._1 == user.remote_user_identifier /\
      Device.remote_identifier res._1 == device_id /\
      Device.remote_identity_key res._1 == identity_key /\
      device_exists res._2 res._1 /\
      FMap.lookup res._2.remote_devices device_id == res._1 /\
      Set.subset (user_session_ids res._2) (user_session_ids user) /\
      s1 == s2) =
  FMap.all_finite_map_facts_lemma () ;
  Device.all_device_facts_lemma () ;
  SidMapSet.all_sidmapset_facts_lemma ();
  match find_device user device_id with
    | None ->
        (* When the device doesn't exist, we simply create it *)
        let new_device = Device.make user.local_user_device_identifier.user_id user.remote_user_identifier device_id identity_key in
        new_device, add_device user new_device
    | Some device ->
      if (not (remove_stale && Device.is_stale device)) &&
        identity_key_eq (Device.remote_identity_key device) identity_key then
        (* A device with the right info exists so we don't do anything *)
        device, user
      else begin
        (* The data on the device we store are outdated *)
        (* Replace it with fresh values *)
        let new_device = Device.make user.local_user_device_identifier.user_id user.remote_user_identifier device_id identity_key in
	(* F* knows that [Device.device_invariant new_device st]
	   because of [Device.all_device_facts_lemma] *)
        let new_user = update_with_device user new_device in
        assert (user_session_ids_pre (FMap.insert (FMap.remove user.remote_devices device_id) device_id new_device) == user_session_ids new_user);
        new_device, new_user
      end

#push-options "--z3rlimit 30"

let rec compile_cipher_list_aux (ch: net_channel) (cryptographic_state: cryptographic_state_t) (remote_id: user_id_t) (l: list device_id_t) (devices: FMap.t device_id_t Device.t) (message: t_message)
  : CVSTInv
      (FMap.t device_id_t Device.t & list pre_packet_t)
      (requires fun st ->
         cryptographic_state_invariant cryptographic_state st /\
         List.subset l (FMap.listdomain devices) /\
         List.noRepeats l /\
         device_invariant_is_correct' devices st /\
         SidMapSet.all_disjoint_sets devices Device.device_session_ids /\
         (forall d. List.memP d l ==> (
           get_personal_user_id cryptographic_state == (Device.local_user_identifier (FMap.lookup devices d)) /\
           remote_id == (Device.remote_user_identifier (FMap.lookup devices d))
           )
         ) /\
         msg_send_event message (get_personal_user_id cryptographic_state) remote_id st
      )
      (ensures fun s1 (new_devices, cipher_list) s2 ->
         (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
         /\ (forall (u: t). user_invariant u s1 ==> user_invariant u s2)
         /\ device_invariant_is_correct' new_devices s2
         /\ (forall sid. State.is_session sid s1 /\ not (Set.mem sid (user_session_ids_pre devices)) ==>  not (Set.mem sid (user_session_ids_pre new_devices)))
         /\ (forall (id: device_id_t). FMap.mem devices id = FMap.mem new_devices id)
         /\ (forall (did: device_id_t). FMap.mem devices did ==> Device.device_invariant (FMap.lookup devices did) s1 ==> Device.device_invariant (FMap.lookup new_devices did) s2)
         /\ SidMapSet.all_disjoint_sets new_devices Device.device_session_ids
         /\ (forall id. (FMap.mem devices id /\ FMap.mem new_devices id) ==> (
              let d1 = FMap.lookup devices id in
              let d2 = FMap.lookup new_devices id in
              Device.remote_identifier d1 == Device.remote_identifier d2 /\
              Device.local_user_identifier d1 == Device.local_user_identifier d2 /\
              Device.remote_user_identifier d1 == Device.remote_user_identifier d2 /\
              (forall sid. State.is_session sid s1 ==> not (Set.mem sid (Device.device_session_ids d1)) ==>
                 not (Set.mem sid (Device.device_session_ids d2)))
           ))
	 /\ List.length cipher_list <= List.length l
      ) =
  match l with
    | [] -> devices, []
    | device_id :: tl ->
        let new_devices, t_im = compile_cipher_list_aux ch cryptographic_state remote_id tl devices message in
        SidMapSet.all_sidmapset_facts_lemma ();
        FMap.all_finite_map_facts_lemma ();
        Device.device_invariant_implies_session();

        let device = FMap.lookup new_devices device_id in
        let new_device, o_cipher = Device.encrypt ch cryptographic_state (FMap.lookup new_devices device_id) message in
	(* The new_device must be stored, otherwise we forget that
 	   a nonce was consumed or a session inserted. *)
        let final_devices = FMap.insert new_devices device_id new_device in
        let devices_rem = FMap.remove new_devices device_id in
        final_devices,
        (match o_cipher with
          | None -> t_im
          | Some cipher ->
              let pre_packet: pre_packet_t = {
                receiving_device = Device.remote_identifier device;
                content = cipher ;
              } in
              pre_packet :: t_im
        )

#pop-options

let compile_cipher_list' (ch: net_channel) (cryptographic_state: cryptographic_state_t) (remote_id: user_id_t) (devices: FMap.t device_id_t Device.t) (message: t_message)
  : CVSTInv
      (FMap.t device_id_t Device.t & lbyte_list pre_packet_t)
      (requires fun st ->
         cryptographic_state_invariant cryptographic_state st /\
         device_invariant_is_correct' devices st /\
         SidMapSet.all_disjoint_sets devices Device.device_session_ids /\
         (forall d. FMap.mem devices d ==> (
           get_personal_user_id cryptographic_state == (Device.local_user_identifier (FMap.lookup devices d)) /\
           remote_id == (Device.remote_user_identifier (FMap.lookup devices d))
           )
         ) /\
         msg_send_event message (get_personal_user_id cryptographic_state) remote_id st
      )
      (ensures fun s1 (new_devices, cipher_list) s2 ->
         (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
         /\ (forall (u: t). user_invariant u s1 ==> user_invariant u s2)
         /\ device_invariant_is_correct' new_devices s2
         /\ (forall sid. State.is_session sid s1 /\ not (Set.mem sid (user_session_ids_pre devices)) ==>  not (Set.mem sid (user_session_ids_pre new_devices)))
         /\ (forall id. FMap.mem devices id <==> FMap.mem new_devices id)
         /\ SidMapSet.all_disjoint_sets new_devices Device.device_session_ids
         /\ (forall id. FMap.mem devices id ==> (
              let d1 = FMap.lookup devices id in
              let d2 = FMap.lookup new_devices id in
              Device.remote_identifier d1 == Device.remote_identifier d2 /\
              Device.local_user_identifier d1 == Device.local_user_identifier d2 /\
              Device.remote_user_identifier d1 == Device.remote_user_identifier d2 /\
              (forall sid. State.is_session sid s1 ==> not (Set.mem sid (Device.device_session_ids d1)) ==>
                 not (Set.mem sid (Device.device_session_ids d2)))
           ))
      ) =
  MyTypes.len_devices (FMap.listdomain devices);
  let new_devices, cipher_list = compile_cipher_list_aux ch cryptographic_state remote_id (FMap.listdomain devices) devices message in
  assert (List.length cipher_list <= List.length (FMap.listdomain devices));
  assert (List.length (FMap.listdomain devices) <= Constants.max_devices_per_user);
  new_devices, cipher_list

let compile_cipher_list
  (ch: net_channel)
  (cryptographic_state: cryptographic_state_t)
  (user: t)
  (message: t_message):
    CVSTInv
    (t & lbyte_list pre_packet_t)
    (fun st -> 
         cryptographic_state_invariant cryptographic_state st /\
         user_invariant user st /\
         get_personal_user_id cryptographic_state == local_identifier user /\
         msg_send_event message (local_identifier user) (remote_identifier user) st)
    (fun s1 (new_user, _) s2 ->
      (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
      /\ (forall (u: t). user_invariant u s1 ==> user_invariant u s2)

      /\ user_invariant new_user s2
      /\ (forall sid. State.is_session sid s1 ==> not (Set.mem sid (user_session_ids user)) ==>
                 not (Set.mem sid (user_session_ids new_user)))
      /\ new_user.remote_user_identifier == user.remote_user_identifier
      /\ new_user.local_user_device_identifier == user.local_user_device_identifier) =
  let new_devices, cipher_list = compile_cipher_list' ch cryptographic_state (remote_identifier user) user.remote_devices message in
  let new_user = {user with remote_devices = new_devices} in
  new_user, cipher_list

(* Changes the list of devices to match the one on the server *)
let rec mark_devices_stale
  (devices_to_remove: lbyte_list device_id_t)
  (user: t):
  CVSTInv t
    (fun st -> user_invariant user st)
    (fun s1 res s2 ->
        remote_identifier user == remote_identifier res
        /\ local_identifier user == local_identifier res
        /\ user_invariant res s2
        /\ (forall (u: t). user_invariant u s1 ==> user_invariant u s2)
        /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
        /\ user_session_ids user == user_session_ids res
    ) =
  SidMapSet.all_sidmapset_facts_lemma ();
  FMap.all_finite_map_facts_lemma ();
  Device.all_device_facts_lemma () ;
  user_invariant_is_device_invariant () ;
  match devices_to_remove with
    | [] -> user
    | device_id::left_overs ->
        match find_device user device_id with
          | Some device ->
              user_invariant_stable_under_session_invariant();
              let new_device = Device.stale device in
              mark_devices_stale left_overs (update_with_device user new_device)
          | None -> mark_devices_stale left_overs user

let rec add_devices
  (devices_to_add: lbyte_list (device_id_t & identity_key_t))
  (user: t):
  CVSTInv t
    (fun st ->
      user_invariant user st /\
      (forall (d: device_id_t & identity_key_t). List.memP d devices_to_add ==> is_valid_remote_key d._2 user.remote_user_identifier st)
    )
    (fun s1 res s2 ->
        remote_identifier user == remote_identifier res
        /\ local_identifier user == local_identifier res
        /\ user_invariant res s2
        /\ (forall (u: t). user_invariant u s1 ==> user_invariant u s2)
        /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
        /\ Set.subset (user_session_ids res) (user_session_ids user)
    ) =
  SidMapSet.all_sidmapset_facts_lemma ();
  FMap.all_finite_map_facts_lemma ();
  Device.all_device_facts_lemma () ;
  user_invariant_is_device_invariant () ;
  user_invariant_stable_under_parallel_rel ();
  crypto_invariant_stable_under_parallel_rel ();
  match devices_to_add with
    | [] -> user
    | (device_id, identity_key)::left_overs ->
        (* Then there is a missing device that we will prep and add. *)
        if user.local_user_device_identifier.user_id = user.remote_user_identifier && user.local_user_device_identifier.device_id = device_id then
          (* Never add our own device
             Note: our server does not propose to add our own device *)
          add_devices left_overs user
        else
        (* Prep for encryption
           1) remove device if stale
	   2) conditionally update the device *)
        let new_device, new_user = conditionally_update user true device_id identity_key in
        (* 3) if the relevant device record does not have an active session, create a new session
        Minor difference with the specification: We delay the creation of
        the new session and do it when we encrypt, in Device.encrypt, instead
        of doing here, when we "prep for encryption".
        Creating the session here would require adding a new state for the
        session, in which the session is created and has the prekey bundle,
        but the init message has been been computed yet. It does not seem
        essential: the only difference in practice seems to be that, in
        case an existing device (not freshly created) ends up having no
        active session, we will create a new session when encrypting, instead
        of not encrypting to that device and getting a device addition
        message from the server. *)
	add_devices left_overs new_user

let upgrade_devices
  (devices_to_change: device_update_t)
  (user: t):
  CVSTInv t
    (fun st ->
      user_invariant user st /\
      (forall (d: device_id_t & identity_key_t). List.memP d devices_to_change.devices_added ==> is_valid_remote_key d._2 user.remote_user_identifier st)
    )
    (fun s1 res s2 ->
        remote_identifier user == remote_identifier res
        /\ local_identifier user == local_identifier res
        /\ user_invariant res s2
        /\ (forall (u: t). user_invariant u s1 ==> user_invariant u s2)
        /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
        /\ Set.subset (user_session_ids res) (user_session_ids user)
    ) =
  Device.all_device_facts_lemma () ;
  user_invariant_is_device_invariant () ;
  let user' = mark_devices_stale devices_to_change.devices_removed user in
  add_devices devices_to_change.devices_added user' 

let rec iter_add_event_received_key (uid: user_id_t) (l: list (device_id_t & identity_key_t)):
  CVSTInv unit 
    (fun st -> True)
    (fun s1 _ s2 -> 
       (forall (u: t). user_invariant u s1 ==> user_invariant u s2) /\
       (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)  /\
       (forall sid. State.is_session sid s1 ==> State.is_session sid s2) /\
       (forall d id_key. List.memP (d,id_key) l ==> is_valid_remote_key id_key uid s2)) =
   match l with
   | [] -> ()
   | (d,id_key)::r ->
        user_invariant_stable_under_event();
        cryptographic_state_invariant_stable_under_event ();
        add_event (Event_Received_Key_for_User id_key uid);
        iter_add_event_received_key uid r

#push-options "--z3rlimit 40"

let rec send_with_fuel
  (ch: net_channel)
  (user: t)
  (cryptographic_state: cryptographic_state_t)
  (message: t_message)
  (fuel: UInt8.t):
  CVSTInv t
    (fun st ->
      user_invariant user st /\
      cryptographic_state_invariant cryptographic_state st /\
      msg_send_event message (local_identifier user) (remote_identifier user) st /\
      Set.disjoint (cstate_session_ids cryptographic_state) (user_session_ids user) /\
      get_personal_user_id cryptographic_state == user.local_user_device_identifier.user_id
    )
    (fun s1 res s2 ->
        remote_identifier user == remote_identifier res
        /\ local_identifier user == local_identifier res
        /\ user_invariant res s2
        /\ (forall (u: t). Set.disjoint (user_session_ids u) (user_session_ids user) ==> user_invariant u s1 ==> user_invariant u s2)
        /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
        /\ Set.disjoint (cstate_session_ids cryptographic_state) (user_session_ids res)
        /\ (forall sid. State.is_session sid s1 /\ not (Set.mem sid (user_session_ids user)) ==>  not (Set.mem sid (user_session_ids res)))
    ) =
  SidMapSet.all_sidmapset_facts_lemma ();
  FSet.all_finite_set_facts_lemma () ;
  FMap.all_finite_map_facts_lemma () ;
  Device.all_device_facts_lemma () ;
  Device.device_invariant_stable_under_event ();
  cryptographic_state_invariant_stable_under_event ();
  crypto_invariant_implies_session ();
  user_invariant_implies_session ();
  (* 1. Compile a list of ciphers to send to each active device of the user. *)
  let user, cipher_list = compile_cipher_list ch cryptographic_state user message in

  (* 2. Upload this list to the server *)
  let res = Network.Helper.upload_message ch user.local_user_device_identifier user.remote_user_identifier cipher_list in

  (* 3. In case the sending message does not correspond to the up-to-date values on the server, we update our internal state *)
  match res with
  | None ->
    user
  | Some packet ->
  match packet with
    | PacketMessagesAccepted ->
      (* The messages has been correctly sent to the server, we stop *)
      debug_print "Messages accepted\n";
      user
    | PacketUserDoesntExist ->
      (* The user we're trying to reach doesn't exist anymore, mark it as stale and abort the sending process *)
      debug_print "User does not exist\n";
      stale user
    | PacketListOfDevicesIncorrect devices_to_change ->

      debug_print "Updating list of devices\n";
      (* The messages could not be delivered correctly because the list of devices was incorrect *)
      // We receive a list of identity keys from the server for the user 
      // we queried
      iter_add_event_received_key user.remote_user_identifier devices_to_change.devices_added;

      (* Finally, we check the fuel left *)
      let new_user = upgrade_devices devices_to_change user in
      if fuel = 0uy then
        new_user
      else
        send_with_fuel ch new_user cryptographic_state message (UInt8.sub fuel 1uy)
    | _ ->
      debug_print "Unexpected reply from server\n";
      user

#pop-options 

/// [user] is the user we are trying to contact.
/// [cryptographic_state] is our own cryptographic material and state
let send
  (ch: net_channel)
  (user: t)
  (cryptographic_state: cryptographic_state_t)
  (packet: t_message):
  CVSTInv t
    (fun st ->
      user_invariant user st /\
      cryptographic_state_invariant cryptographic_state st /\
      msg_send_event packet (local_identifier user) (remote_identifier user) st /\
      Set.disjoint (cstate_session_ids cryptographic_state) (user_session_ids user) /\
      get_personal_user_id cryptographic_state == user.local_user_device_identifier.user_id
    )
    (fun s1 res s2 ->
       remote_identifier user == remote_identifier res
       /\ local_identifier user == local_identifier res
       /\ user_invariant res s2
       /\ (forall (u: t). Set.disjoint (user_session_ids u) (user_session_ids user) ==> user_invariant u s1 ==> user_invariant u s2)
       /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
       /\ Set.disjoint (cstate_session_ids cryptographic_state) (user_session_ids res)
       /\ (forall sid. State.is_session sid s1 /\ not (Set.mem sid (user_session_ids user)) ==>  not (Set.mem sid (user_session_ids res)))
    ) =
  send_with_fuel ch user cryptographic_state packet user.sending_loop_limit

val user_invariant_stable_under_device_invariant (_: unit) : Lemma (
  forall s1 s2 u idset.
    (forall (d: Device.t). Set.disjoint idset (Device.device_session_ids d) ==> Device.device_invariant d s1 ==> Device.device_invariant d s2) /\
    Set.disjoint idset (user_session_ids u) ==>
    user_invariant u s1 ==>
    user_invariant u s2
  )

let user_invariant_stable_under_device_invariant () = SidMapSet.all_sidmapset_facts_lemma ()

#push-options "--z3rlimit 20"

let decrypt
  (cryptographic_state: cryptographic_state_t)
  (user: t)
  (packet_msg: packet_message_t):
  CVSTInv
    (cryptographic_state_t & t & option t_message)
    (fun st ->
        cryptographic_state_invariant cryptographic_state st /\
        user_invariant user st /\
        Set.disjoint (cstate_session_ids cryptographic_state) (user_session_ids user) /\
	get_personal_user_id cryptographic_state == local_identifier user)
    (fun s1 res s2 ->
        remote_identifier user == remote_identifier res._2
        /\ local_identifier user == local_identifier res._2
	/\ get_personal_user_id res._1 == get_personal_user_id cryptographic_state
        /\ user_invariant res._2 s2
	/\ cryptographic_state_invariant res._1 s2
        /\ (forall (u: t). Set.disjoint (cstate_session_ids cryptographic_state) (user_session_ids u) ==> user_invariant u s1 ==> user_invariant u s2)
        /\ (forall (c: cryptographic_state_t). Set.disjoint (cstate_session_ids cryptographic_state) (cstate_session_ids c) ==> cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
        /\ Set.subset (cstate_session_ids res._1) (cstate_session_ids cryptographic_state)
        /\ Set.disjoint (cstate_session_ids res._1) (user_session_ids res._2)
        /\ (forall sid. State.is_session sid s1 /\ not (Set.mem sid (Set.union (cstate_session_ids cryptographic_state) (user_session_ids user))) ==>
    not (Set.mem sid (Set.union (cstate_session_ids res._1) (user_session_ids res._2))))
        /\ (match res._3 with
          | Some msg -> msg_recv_event msg (local_identifier user) (remote_identifier user) s2
          | None -> True)
    ) =
  SidMapSet.all_sidmapset_facts_lemma ();
  FMap.all_finite_map_facts_lemma ();
  user_invariant_implies_session ();
  user_invariant_stable_under_device_invariant ();
  let device_id = packet_msg.psending_device.device_id in
  match CVTypes.deserialize_full serializer_encrypted_message packet_msg.content with
  | None -> (cryptographic_state, user, None)
  | Some cipher ->
     Device.all_device_facts_lemma () ;
     match cipher.init_msg with
     | Some init_msg ->
        (* We receive an initiation message *)
        // We receive an identity key from the server for the user that 
        // sent the message
        add_event (Event_Received_Key_for_User init_msg.sender_identity_key user.remote_user_identifier);
        user_invariant_stable_under_event();
        cryptographic_state_invariant_stable_under_event ();
        (* Conditionally update the device record
	   According to the spec, it should be done only when there is no device record
	   containing a session that can decrypt the message. But anyway, if there is
	   such a device record, it has the right [device_id] and [identity_key], so it will
	   be left unchanged by [conditionally_update]. *)
        let device, new_user = conditionally_update user false device_id init_msg.sender_identity_key in

        let (cryptographic_state', new_device, message) = Device.decrypt cryptographic_state device cipher in

	begin
	match message with
	| None ->
	    (* When decryption fails, all changes are discarded *)
            // The changes were discarded in Device.find_decrypt_session, so we can
            // return cryptographic_state' instead of cryptographic_state
	    (cryptographic_state', user, None)
	| Some _ ->
            let new_user' = update_with_device new_user new_device in
            assert (user_session_ids new_user' == user_session_ids_pre (FMap.insert (FMap.remove new_user.remote_devices device_id) device_id new_device));
            (cryptographic_state', new_user', message)
	end
     | None ->
        match find_device user device_id with
        | None -> (cryptographic_state, user, None)
        | Some device ->
          let (cryptographic_state', new_device, message) = Device.decrypt cryptographic_state device cipher in

          let new_user = update_with_device user new_device in
          assert (user_session_ids new_user == user_session_ids_pre (FMap.insert (FMap.remove user.remote_devices device_id) device_id new_device));

          (cryptographic_state', new_user, message)

#pop-options

let rec finalize_devices (u: t) (l: list device_id_t):
    CVSTInv unit
      (fun s1 -> user_invariant u s1 /\ (forall (d: device_id_t). List.mem d l ==> FMap.mem u.remote_devices d))
      (fun s1 res s2 ->
        (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)) = 
  match l with
  | [] -> ()
  | d::l -> 
      Device.finalize_device (FMap.lookup u.remote_devices d);
      user_invariant_stable_under_session_invariant();
      finalize_devices u l

let finalize_user (u: t):
    CVSTInv unit
      (fun s1 -> user_invariant u s1)
      (fun s1 res s2 ->
        (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)) = 
  finalize_devices u (FMap.listdomain u.remote_devices)


let remove_stale_device (time: nat) (u: t) (d: device_id_t):
    CVSTInv t
      (fun s1 -> user_invariant u s1 /\ FMap.mem u.remote_devices d)
      (fun s1 res s2 ->
        (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2) /\
        local_identifier res == local_identifier u /\
        remote_identifier res == remote_identifier u /\
        Set.subset (user_session_ids res) (user_session_ids u) /\
        user_invariant res s2 /\
        (forall d'. FMap.mem u.remote_devices d' /\ d' <> d ==> FMap.mem res.remote_devices d')) = 
  FMap.all_finite_map_facts_lemma () ;
  SidMapSet.all_sidmapset_facts_lemma ();
  let device = FMap.lookup u.remote_devices d in
  match Device.stale_time device with
  | None -> u
  | Some t_stale -> 
    if t_stale + Constants.max_latency < time then
      begin
        Device.finalize_device device;
        user_invariant_stable_under_session_invariant();
        remove_device u d
      end
    else u
     
let rec remove_stale_devices (time: nat) (u: t) (l: list device_id_t):
    CVSTInv t
      (fun s1 -> user_invariant u s1 /\ List.noRepeats l /\ (forall (d: device_id_t). List.mem d l ==> FMap.mem u.remote_devices d))
      (fun s1 res s2 ->
        (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2) /\
        local_identifier res == local_identifier u /\
        remote_identifier res == remote_identifier u /\
        Set.subset (user_session_ids res) (user_session_ids u) /\
        user_invariant res s2) = 
   match l with
   | [] -> u
   | d::l -> 
     let u' = remove_stale_device time u d in
     remove_stale_devices time u' l
     
let remove_stale (time: nat) (u: t): 
    CVSTInv t
      (fun s1 -> user_invariant u s1)
      (fun s1 res s2 ->
        (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2) /\
        local_identifier res == local_identifier u /\
        remote_identifier res == remote_identifier u /\
        Set.subset (user_session_ids res) (user_session_ids u) /\
        user_invariant res s2) = 
  remove_stale_devices time u (FMap.listdomain u.remote_devices)
  
