(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module Device

open FStar.Option
module List = FStar.List.Tot.Base
open Crypto.Abstraction
open Lib.ByteSequence
open Network.Helper
open Network

open SIGNAL.Effect
open SIGNAL.Types
open SIGNAL.Events
open SIGNAL.Invariant

noeq
type t': Type0 = {
  local_user_identifier     : Ghost.erased user_id_t ;
  sessions          : list session_t ;
  remote_identity_key      : identity_key_t ;
  remote_user_identifier   : user_id_t ;
  remote_device_identifier : device_id_t ;
  (* stale = None means the device is not stale.
     stale = Some t means the device is stale since time n *)
  stale             : option nat ;
}

let session_user_ids_match (device: t') (session: session_t) =
  local_user_id session == Ghost.reveal device.local_user_identifier /\
  remote_user_id session == device.remote_user_identifier

let rec device_session_ids' sessions = match sessions with
  | [] -> Set.empty
  | hd :: tl -> Set.add (session_id hd) (device_session_ids' tl)

let rec disjoint_session_ids (sessions: list session_t) = match sessions with
  | [] -> True
  | hd :: tl ->
    not (Set.mem (session_id hd) (device_session_ids' tl)) /\ disjoint_session_ids tl

let sessions_user_ids_match (device: t') (sessions: list session_t) =
  forall session. List.memP session sessions ==> session_user_ids_match device session

let well_formed_device (device: t') =
  disjoint_session_ids device.sessions /\
  sessions_user_ids_match device device.sessions

let t = device:t'{well_formed_device device}

let sessions_invariant_is_correct
  (device: t)
  (st: signal_state) :
  Type0 =
  forall (s: session_t). List.memP s device.sessions ==> session_invariant s st

let device_invariant
  (device: t)
  (st: signal_state):
  Type0 =
  is_valid_remote_key device.remote_identity_key device.remote_user_identifier st /\
  sessions_invariant_is_correct device st

let device_invariant_stable_under_event (_: unit): Lemma (
    forall s1 s2 d. SIGNAL.InvariantLemmas.rel' s1 s2 ==> State.local_sessions_are_equal s1 s2 ==> device_invariant d s1 ==> device_invariant d s2
) =
  session_invariant_stable_under_event ()

let device_invariant_stable_under_parallel_rel (_: unit): Lemma (
    forall s1 s2 d. SIGNAL.InvariantLemmas.parallel_rel' s1 s2 ==> device_invariant d s1 ==> device_invariant d s2
) = session_invariant_stable_under_parallel_rel ()

let remote_identifier
  (device: t):
  device_id_t =
  device.remote_device_identifier

let remote_identity_key
  (device: t):
  identity_key_t =
  device.remote_identity_key

let remote_user_identifier
  (device: t):
  user_id_t =
  device.remote_user_identifier

let local_user_identifier
  (device: t):
  GTot user_id_t =
  device.local_user_identifier

let device_session_ids device = device_session_ids' device.sessions

let is_stale
  (device: t):
  bool =
  device.stale <> None

let stale_time (device: t) =
  device.stale

let stale (device: t):
    CVSTInv t
      (fun s1 -> device_invariant device s1)
      (fun s1 new_device s2 ->
        (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2) /\
        device_invariant new_device s2 /\
        remote_identifier device == remote_identifier new_device /\
        remote_user_identifier device == remote_user_identifier new_device /\
        local_user_identifier device == local_user_identifier new_device /\
        device_session_ids device == device_session_ids new_device /\
	is_stale new_device) =
  crypto_invariant_stable_under_parallel_rel ();
  session_invariant_stable_under_parallel_rel ();
  match device.stale with
  | None -> {device with stale = Some (Time.time()) }
  | Some _ -> device

let device_invariant_stable_under_session_invariant () = ()

val device_invariant_stable_under_session_invariant2 (_: unit) : Lemma (
  forall s1 s2 d idset.
    rel s1 s2 ==>
    (forall (s: session_t). Set.disjoint (Set.singleton (session_id s)) idset ==> session_invariant s s1 ==> session_invariant s s2) ==>
    Set.disjoint idset (device_session_ids d) ==>
    device_invariant d s1 ==>
    device_invariant d s2
  )

let device_invariant_stable_under_session_invariant2 () =
  let rec aux (s1: signal_state) (s2: signal_state) sessions idset : Lemma
    (requires
      (forall (s: session_t). Set.disjoint (Set.singleton (session_id s)) idset ==> session_invariant s s1 ==> session_invariant s s2) /\
      Set.disjoint idset (device_session_ids' sessions) /\
      (forall (s: session_t). List.memP s sessions ==> session_invariant s s1)
    )
    (ensures (forall (s: session_t). List.memP s sessions ==> session_invariant s s2))
    = match sessions with
      | [] -> ()
      | hd :: tl -> aux s1 s2 tl idset
  in Classical.forall_intro_4 (fun x y z -> Classical.move_requires (aux x y z))

let session_id_match sid sess = session_id sess = sid

let rec device_sids_mem_session_mem' (sessions: list session_t) sid : Lemma
  (requires Set.mem sid (device_session_ids' sessions))
  (ensures List.existsb (session_id_match sid) sessions)
  = match sessions with
    | [] -> ()
    | hd :: tl -> if session_id hd = sid then ()
                else device_sids_mem_session_mem' tl sid

let device_sids_mem_session_mem () : Lemma
  (forall device sid. Set.mem sid (device_session_ids device) ==> List.existsb (session_id_match sid) device.sessions)
  = Classical.forall_intro_2 (fun x -> Classical.move_requires (device_sids_mem_session_mem' x))

let rec mem_device_mem_device_sids' (sessions: list session_t) (s: session_t) : Lemma
  (List.memP s sessions ==> Set.mem (session_id s) (device_session_ids' sessions)) =
  match sessions with
  | [] -> ()
  | hd :: tl -> mem_device_mem_device_sids' tl s

let device_invariant_implies_session () =
  device_sids_mem_session_mem ();
  Classical.forall_intro_2 (fun sid sess -> List.Tot.memP_existsb (session_id_match sid) sess);
  session_invariant_implies_session ()

let make
  (local_user_identifier: Ghost.erased user_id_t)
  (remote_user_identifier: user_id_t)
  (remote_device_identifier: device_id_t)
  (remote_identity_key: identity_key_t):
  t =
  {
    local_user_identifier ;
    sessions = [] ;
    remote_identity_key;
    remote_device_identifier ;
    remote_user_identifier ;
    stale = None ;
  }

let update_sessions
  (device: t)
  (sessions: list session_t{sessions_user_ids_match device sessions /\ disjoint_session_ids sessions}):
  t =
  {device with sessions = sessions}

let update_sessions_lemma (_: unit):
  Lemma (ensures forall device sessions. (update_sessions device sessions).sessions == sessions) =
  ()

let rec all_disjoint_append (s: session_t) (l: list session_t) : Lemma
  (requires disjoint_session_ids l /\ not (Set.mem (session_id s) (device_session_ids' l)))
  (ensures disjoint_session_ids (s :: l)) =
  match l with
  | [] -> ()
  | hd :: tl -> all_disjoint_append s tl

let rec finalize_sessions (l: list session_t):
    CVSTInv unit
      (fun s1 -> forall s. List.memP s l ==> session_invariant s s1)
      (fun s1 res s2 ->
        (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)) =
  match l with
  | [] -> ()
  | a::l ->
       Crypto.Abstraction.finalize_session a;
       finalize_sessions l

let rec finalize_after_n (n: nat) (l: list session_t):
    CVSTInv (list session_t)
      (fun s1 -> disjoint_session_ids l /\
              forall s. List.memP s l ==> session_invariant s s1)
      (fun s1 res s2 ->
        (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2) /\
        (forall s. List.memP s res ==> List.memP s l) /\
        Set.subset (device_session_ids' res) (device_session_ids' l) /\
        disjoint_session_ids res) =
   if n = 0 then
     begin
       finalize_sessions l;
       []
     end
   else
     match l with
     | [] -> []
     | a::l -> a::(finalize_after_n (n-1) l)

let insert_active_session
  (device: t)
  (session: session_t):
  CVSTInv
    t
    (fun st ->
      device_invariant device st /\
      session_invariant session st /\
      not (Set.mem (session_id session) (device_session_ids device)) /\
      local_user_id session == Ghost.reveal device.local_user_identifier /\
      remote_user_id session == device.remote_user_identifier
    )
    (fun s1 res s2 ->
      (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
      (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2) /\
      device_invariant res s2 /\
      remote_identifier device == remote_identifier res /\
      local_user_identifier device == local_user_identifier res /\
      remote_user_identifier device == remote_user_identifier res /\
      Set.subset (device_session_ids res) (Set.add (session_id session) (device_session_ids device))
    ) =
  all_disjoint_append session device.sessions;
  (* If the list of sessions contains more than Constants.max_sessions
  sessions, sessions at the tail of the list are removed *)
  let sessions' = finalize_after_n Constants.max_sessions (session::device.sessions) in
  update_sessions device sessions'

#push-options "--z3rlimit 20"

/// [device] is the device we are trying to contact.
/// [cryptographic_state] here corresponds to our own cryptographic material.
let create_session
  (ch: net_channel)
  (cryptographic_state: cryptographic_state_t)
  (device: t)
  (msg: t_message):
  CVSTInv (t & option (bbytes Constants.max_pre_packet_content_size))
    (fun st ->
      cryptographic_state_invariant cryptographic_state st /\
      device_invariant device st /\
      get_personal_user_id cryptographic_state == local_user_identifier device /\
      msg_send_event msg (local_user_identifier device) (remote_user_identifier device) st
    )
    (fun s1 (new_device, _) s2 ->
            device_invariant new_device s2
            /\ (forall (d: t). device_invariant d s1 ==> device_invariant d s2)
            /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
            /\ (forall sid. State.is_session sid s1 ==> not (Set.mem sid (device_session_ids device)) ==>
                 not (Set.mem sid (device_session_ids new_device)))
            /\ remote_identifier device == remote_identifier new_device
            /\ local_user_identifier device == local_user_identifier new_device
            /\ remote_user_identifier device == remote_user_identifier new_device
            ) =
  device_invariant_stable_under_event ();
  session_invariant_stable_under_event ();
  cryptographic_state_invariant_stable_under_event ();
  match fetch_prekey_bundle ch device.remote_user_identifier device.remote_device_identifier with
    | Some prekey_bundle -> (
      match create_session_from_prekey_bundle cryptographic_state device.remote_user_identifier device.remote_identity_key prekey_bundle msg with
        | Some (session, encrypted_msg) ->
              device_invariant_implies_session ();
              let device' = insert_active_session device session in
              encrypted_message_not_too_big encrypted_msg;
              device', Some (serializer_encrypted_message.serialize encrypted_msg)

        | None -> device, None
    )
    | None -> device, None

let has_active_session
  (device: t):
  bool =
  match device.sessions with
    | [] -> false
    | _ -> true



let encrypt
  (ch: net_channel)
  (cryptographic_state: cryptographic_state_t)
  (device: t)
  (msg: t_message):
  CVSTInv
    (t & option (bbytes Constants.max_pre_packet_content_size))
    (fun st ->
      cryptographic_state_invariant cryptographic_state st /\
      device_invariant device st /\
      get_personal_user_id cryptographic_state == local_user_identifier device /\
      msg_send_event msg (local_user_identifier device) (remote_user_identifier device) st)
    (fun s1 res s2 ->
        (forall (d: t). device_invariant d s1 ==> device_invariant d s2)
        /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
        /\ device_invariant res._1 s2
        /\ (forall sid. State.is_session sid s1 ==> not (Set.mem sid (device_session_ids device)) ==>
                 not (Set.mem sid (device_session_ids res._1)))
	/\ remote_identifier device == remote_identifier res._1
	/\ local_user_identifier device == local_user_identifier res._1
	/\ remote_user_identifier device == remote_user_identifier res._1) =

  device_invariant_stable_under_session_invariant2 ();
  if is_stale device then device, None else
  match device.sessions with
    | [] ->
      (* When there is no active session, we create a new session.
      Minor difference with the specification: we do that here, instead
      of doing it when we "prep for encryption", in User.add_devices.
      See User.add_devices for further comments on this point. *)
      create_session ch cryptographic_state device msg
    | active_session::t ->
      let session, res = encrypt_message active_session msg in
      (* Needed for SMT Trigger *)
      assert (forall d. Set.disjoint (device_session_ids d) (device_session_ids device) ==> Set.disjoint (Set.singleton (session_id session)) (device_session_ids d));
      Classical.forall_intro (mem_device_mem_device_sids' t);
      update_sessions device (session::t),
      (match res with
      | Some msg ->
          encrypted_message_not_too_big msg;
          Some (serializer_encrypted_message.serialize msg)
      | None -> None)

#pop-options

open SIGNAL.Events

(*
     Try to find a session able to decrypt the cipher.

     When a session can decrypt the message, we return the session
     as well as the tail of the session list to build a list of sessions
     without this session (the selected session becomes active)
*)
let rec find_decrypt_session
  (cryptographic_state: cryptographic_state_t)
  (device: t)
  (sessions: list session_t)
  (cipher: encrypted_message_t):
  CVSTInv (cryptographic_state_t & list session_t & option (session_t & t_message))
    (fun st ->
      local_user_identifier device == get_personal_user_id cryptographic_state /\
      cryptographic_state_invariant cryptographic_state st /\
      device_invariant device st /\
      sessions_user_ids_match device sessions /\
      disjoint_session_ids sessions /\
      Set.disjoint (cstate_session_ids cryptographic_state) (device_session_ids' sessions) /\
      forall (s: session_t). List.memP s sessions ==> session_invariant s st)
    (fun s1 res s2 ->
      (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2)
      /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
      /\ (forall (s: session_t). List.memP s res._2 ==> session_invariant s s2)
      /\ sessions_user_ids_match device res._2
      /\ cryptographic_state_invariant res._1 s2
      /\ get_personal_user_id res._1 == get_personal_user_id cryptographic_state
      /\ disjoint_session_ids res._2
      /\ Set.disjoint (cstate_session_ids res._1) (device_session_ids' res._2)
      /\ Set.subset (cstate_session_ids res._1) (cstate_session_ids cryptographic_state)
      /\ (forall sid. State.is_session sid s1 /\ not (Set.mem sid (Set.union (cstate_session_ids cryptographic_state) (device_session_ids' sessions))) ==>
                 not (Set.mem sid (Set.union (cstate_session_ids res._1) (device_session_ids' res._2))))
      /\ (match res._3 with
        | Some (s, msg) ->
            (not (State.is_session (session_id s) s1) \/ Set.mem (session_id s) (device_session_ids' sessions)) /\
            not (Set.mem (session_id s) (cstate_session_ids res._1)) /\
            not (Set.mem (session_id s) (device_session_ids' res._2)) /\
            session_user_ids_match device s /\
            session_invariant s s2 /\
            msg_recv_event msg (local_user_identifier device) (remote_user_identifier device) s2
        | None -> True)
    ) =
  session_invariant_implies_session ();
  crypto_invariant_implies_session ();
  match sessions with
    | [] ->
      begin
        match cipher.init_msg with
	| None ->
            (cryptographic_state, [], None)
	| Some init_msg ->
	    (* We need to conditionally update the device, with the public key received from the init message.
	       This is done in User.decrypt because the conditionally_update function is in module User. *)
            let res = create_session_from_init_message cryptographic_state device.remote_user_identifier device.remote_identity_key init_msg cipher.ciphertext cipher.counter in
	    match res with
	    | None ->
	        (* When decryption fails, all changes to the device are discarded *)
	        (cryptographic_state, [], None)
	    | Some (cryptographic_state', candidat, msg) ->
                (cryptographic_state', [], Some (candidat, msg))
      end
    | candidat::left_overs ->
      (* check if selected session can decrypt the message *)
      let decypher = decrypt_message candidat cipher.ciphertext cipher.counter in
      match decypher with
      | None ->
        let (cryptographic_state', new_sessions, ret) = find_decrypt_session cryptographic_state device left_overs cipher in
        (cryptographic_state', candidat::new_sessions, ret)
      | Some (candidat', msg) ->
        (cryptographic_state, left_overs, Some (candidat', msg))

let decrypt
  (cryptographic_state: cryptographic_state_t)
  (device: t)
  (cipher: encrypted_message_t):
  CVSTInv (cryptographic_state_t & t & option t_message)
    (fun st ->
      	    local_user_identifier device == get_personal_user_id cryptographic_state /\
    	    cryptographic_state_invariant cryptographic_state st /\
            Set.disjoint (cstate_session_ids cryptographic_state) (device_session_ids device) /\
            device_invariant device st)
    (fun s1 res s2 ->
            remote_identifier device == remote_identifier res._2
            /\ local_user_identifier device == local_user_identifier res._2
            /\ remote_user_identifier device == remote_user_identifier res._2
	    /\ get_personal_user_id res._1 == get_personal_user_id cryptographic_state
            /\ (forall (d: t). device_invariant d s1 ==> device_invariant d s2)
            /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
	    /\ cryptographic_state_invariant res._1 s2
            /\ device_invariant res._2 s2
            /\ Set.subset (cstate_session_ids res._1) (cstate_session_ids cryptographic_state)
            /\ Set.disjoint (cstate_session_ids res._1) (device_session_ids res._2)
            /\ (forall sid. State.is_session sid s1 /\ not (Set.mem sid (Set.union (cstate_session_ids cryptographic_state) (device_session_ids device))) ==>
                 not (Set.mem sid (Set.union (cstate_session_ids res._1) (device_session_ids res._2))))
            /\ (match res._3 with
              | Some msg -> msg_recv_event msg (local_user_identifier device) (remote_user_identifier device) s2
              | None -> True)) =
  device_invariant_stable_under_session_invariant2 ();
  crypto_invariant_stable_under_parallel_rel ();
  session_invariant_stable_under_parallel_rel ();
  let (cryptographic_state', new_sessions, decipher) = find_decrypt_session cryptographic_state device device.sessions cipher in
  match decipher with
    | None ->
      (* When decryption fails, all changes to the device are discarded *)
      // The changes were discarded in find_decrypt_session, so we can
      // return cryptographic_state' instead of cryptographic_state
      (cryptographic_state', device, None)
    | Some (new_active_session, message) ->
      update_sessions_lemma () ;
      let new_device = update_sessions device new_sessions in
      let st = get_state () in
      assert (device_invariant new_device st) ;
      assert (session_invariant new_active_session st) ;
      (* The session that receives a message becomes the new active session *)
      (cryptographic_state', insert_active_session new_device new_active_session, Some message)

let finalize_device (device: t):
    CVSTInv unit
      (fun s1 -> device_invariant device s1)
      (fun s1 res s2 ->
        (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)) =
  finalize_sessions device.sessions



let make_device_invariant_lemma () : Lemma (make_device_invariant_fact) =
  ()

let all_device_facts_lemma () : Lemma (all_device_facts) =
  make_device_invariant_lemma ()
