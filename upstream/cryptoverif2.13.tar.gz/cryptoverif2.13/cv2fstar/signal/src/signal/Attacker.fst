(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module Attacker

(* This module allows an attacker to send commands to the server, 
   as if it were a legitimate client. It is used for testing purposes. *)

open SIGNAL.Effect
open Network.Types
open Network.Helper
open Network
open SIGNAL.InvariantLemmas
open FStar.Mul 

open Lib.IntTypes
open CVTypes

let parse_user_id (remote_user_id_s: string): option user_id_t =
  (* FStar.Parse.int_of_string was not implemented, so we implemented
     an int_of_string function in the cv2fstar library.
     This issue was fixed in F* on Feb 14, 2026. *)
  match Utils.int_of_string remote_user_id_s with
  | None -> None
  | Some n ->
      if minint U64 <= n && n <= maxint U64 then
        Some (MyTypes.make_user_id n)
      else
        None

let parse_device_id (device_id_s: string): option device_id_t =
  (* FStar.Parse.int_of_string was not implemented, so we implemented
     an int_of_string function in the cv2fstar library.
     This issue was fixed in F* on Feb 14, 2026. *)
  match Utils.int_of_string device_id_s with
  | None -> None
  | Some n ->
      if 0 <= n && n < Constants.max_devices_per_user then
        Some (MyTypes.make_device_id n)
      else
        None

let parse_char (c: Char.char) : option (x: nat { x < 16 }) =
  let v = Char.int_of_char c in
  let v0 = Char.int_of_char '0' in
  let v9 = Char.int_of_char '9' in
  let va = Char.int_of_char 'a' in
  let vf = Char.int_of_char 'f' in
  if v0 <= v && v <= v9 then Some(v - v0) else
  if va <= v && v <= vf then Some(v - va + 10) else None

let rec parse_char_list (c: list Char.char) : 
    option (list (Lib.IntTypes.uint8)) = 
  match c with
  | [] -> Some []
  | [_] -> None
  | c1::c2::r ->
     match parse_char c1, parse_char c2, parse_char_list r with
     | Some v1, Some v2, Some vr -> 
         let v = Lib.IntTypes.mk_int #U8 #SEC (v1 * 16 + v2) in
         Some (v::vr)
     | _ -> None

let parse_bytes (s: string) : option bytes = 
  match parse_char_list (String.list_of_string s) with
  | Some l -> Some (Seq.seq_of_list l)
  | None -> None

let parse_bytes_len (len: size_nat) (s: string) : option (lbytes len) = 
  match parse_bytes s with
  | Some l -> 
      if Seq.length l = len then Some l else None
  | None -> None

#push-options "--z3rlimit 20"

let send_packet (server_addr: sockaddr) (packet: packet_t):
       CVSTInvMin unit =
  let r = Network.open_connection server_addr in
  match r with
  | NTError s ->
      print_string ("Could not connect to the server: "^s^"\n")
  | NTOk ch ->
      let _ = 
        match Network.Helper.send_packet ch packet with
        | NTError s -> 
           print_string "Could not send packet: ";
           print_string s;
           print_string "\n"
        | NTOk () -> 
          match Network.Helper.recv_packet ch with
          | NTOk _ -> ()
          | NTError Erecv_End_of_file -> print_string "End of file\n"
          | NTError Erecv_Deserialization_failure -> print_string "Deserialization failure\n"
          | NTError (Erecv_Other s) -> print_string s; print_string "\n"
      in
      let _ = Network.shutdown_connection ch in
      let _ = Network.close_connection ch in
      ()

#pop-options

let user_id_read msg : FStar.All.ML (option user_id_t) =
  FStar.IO.print_string (msg ^ " user id: ");
  let user_id = FStar.IO.input_line() in
  match parse_user_id user_id with
  | None -> 
      FStar.IO.print_string "Bad user id\n"; 
      None
  | r -> r

let device_id_read msg : FStar.All.ML (option device_id_t) =
  FStar.IO.print_string (msg ^ " device id: ");
  let device_id = FStar.IO.input_line() in
  match parse_device_id device_id with
  | None -> 
      FStar.IO.print_string "Bad device id\n"; 
      None
  | r -> r

let user_device_id_read msg : FStar.All.ML (option user_device_id_t) = 
  match user_id_read msg with
  | None -> None
  | Some uid -> 
      match device_id_read msg with
      | None -> None
      | Some did -> Some { user_id = uid; device_id = did }
     
let id_key_read() : FStar.All.ML (option identity_key_t) = 
  FStar.IO.print_string "id_key: ";
  match parse_bytes_len 32 (FStar.IO.input_line()) with
  | None -> 
      FStar.IO.print_string "Bad id key\n"; 
      None
  | Some identity_key -> 
      FStar.IO.print_string "sign_key: ";
      match parse_bytes_len 32 (FStar.IO.input_line()) with
      | None -> 
          FStar.IO.print_string "Bad sign key\n"; 
          None
      | Some signature_key -> 
          Some { identity_key; signature_key }

let rec one_time_prekeys_read (n: nat) : FStar.All.ML (option (x: list (prekey_id_t & prekey_t) { List.length x <= n })) = 
  if n = 0 then Some [] else
  begin
    FStar.IO.print_string "prekey id (q to stop): ";
    let r = FStar.IO.input_line() in
    if r = "q" then Some [] else
    match Utils.int_of_string r with
    | None -> 
      FStar.IO.print_string "Bad prekey id\n";
      None
    | Some id -> 
      if id >= 0 && id < Constants.num_one_time_prekeys then
      begin
        FStar.IO.print_string "one-time prekey: ";
        match parse_bytes_len 32 (FStar.IO.input_line()) with
        | None -> 
          FStar.IO.print_string "Bad one-time prekey\n"; 
          None
        | Some ot_pk -> 
          match one_time_prekeys_read (n-1) with
          | None -> None
          | Some l -> 
            Some ((make_prekey_id id, ot_pk)::l)
      end
      else
      begin
        FStar.IO.print_string "Bad prekey id\n";
        None
        end
  end

let prekeys_read() : FStar.All.ML (option (signed_prekey_bundle_t & lbyte_list (prekey_id_t & prekey_t))) =
  FStar.IO.print_string "signed prekey: ";
  match parse_bytes_len 32 (FStar.IO.input_line()) with
  | None ->   
      FStar.IO.print_string "Bad signed prekey\n"; 
      None
  | Some prekey -> 
      FStar.IO.print_string "signature: ";
      match parse_bytes_len 64 (FStar.IO.input_line()) with
      | None -> 
          FStar.IO.print_string "Bad signature\n"; 
          None
      | Some signature -> 
          match one_time_prekeys_read 255 with
          | None -> None
          | Some ot_prekeys -> 
              Some ({ prekey; signature }, ot_prekeys)
      
let rec messages_read (n: nat) : FStar.All.ML (option (x: list pre_packet_t { List.length x <= n })) = 
  if n = 0 then Some [] else
  begin
    FStar.IO.print_string "Receiving device id (q to stop): ";
    let device_id = FStar.IO.input_line() in
    if device_id = "q" then Some [] else
    match parse_device_id device_id with
    | None -> 
        FStar.IO.print_string "Bad device id\n"; 
        None
    | Some receiving_device -> 
      FStar.IO.print_string "message: ";
      match parse_bytes (FStar.IO.input_line()) with
      | None -> 
        FStar.IO.print_string "Bad message\n"; 
        None
      | Some content -> 
        if Seq.length content <= Constants.max_pre_packet_content_size then
          match messages_read (n-1) with
          | None -> None
          | Some l -> 
            Some ({ receiving_device; content }::l)
        else 
          begin
            FStar.IO.print_string "Message too long\n"; 
            None
          end
  end
    
let rec packet_read () : FStar.All.ML (option packet_t) =
  FStar.IO.print_string "Enter a packet identifier: ";
  let instruct = FStar.IO.input_line() in
  match instruct with
  | "CreateUser" -> 
       Some PacketCreateUserRequest
  | "CreateDevice" -> 
       begin
         match user_id_read "Enter a" with
         | None -> packet_read()
         | Some uid -> 
             match id_key_read() with
             | None -> packet_read() 
             | Some idkey -> 
                match prekeys_read() with
                | None -> packet_read()
                | Some (spk,otpk) -> 
                   Some (PacketCreateDeviceRequest(uid, idkey, spk, otpk))
       end
  | "RemoveDevice" -> 
      begin
        match user_device_id_read "Enter a" with
        | None -> packet_read()
        | Some x -> Some (PacketRemoveDeviceRequest x)
      end
  | "PreKeys" -> 
       begin
        match user_device_id_read "Enter a" with
        | None -> packet_read()
        | Some x -> 
            match prekeys_read() with
            | None -> packet_read()
            | Some (spk,otpk) -> 
                Some (PacketPrekeys(x, spk, otpk))
       end
  | "PrekeyBundleRequest" -> 
      begin
        match user_device_id_read "Enter a" with
        | None -> packet_read()
        | Some x -> Some (PacketPrekeyBundleRequest x)
      end
  | "Messages" -> 
      begin
        match user_device_id_read "Sending" with
        | None -> packet_read()
        | Some sending_device -> 
            match user_id_read "Receiving" with
            | None -> packet_read()
            | Some receiving_user -> 
               match messages_read 255 with
               | None -> packet_read()
               | Some messages -> 
                   if sending_device.user_id = receiving_user then
                     Some (PacketSyncMessages { sending_device; messages })
                   else
                     Some (PacketMessages { sending_device; receiving_user; messages }) 
      end 
  | "Poll" -> 
      begin
        match user_device_id_read "Enter a" with
        | None -> packet_read()
        | Some x -> Some (PacketPoll x)
      end
  | "Quit" -> 
      None
  |  _ -> 
     FStar.IO.print_string "Bad packet id. Allowed packet ids are\nCreateUser, CreateDevice, RemoveDevice, PreKeys, PrekeyBundleRequest, Messages, Poll.\nUse Quit to quit the program.\n";
     packet_read()

let rec attacker_loop (server_addr: sockaddr) : CVSTInvMin unit = 
  match ml_to_CVST packet_read with
  | Some packet -> 
      send_packet server_addr packet;
      attacker_loop server_addr
  | None -> ()

let attacker (options: string & port) : CVSTInvMin unit = 
  let (server_name, server_port) = options in
  match Network.getaddrfromname server_name with
  | NTError _ -> print_string "Could not find server\n"
  | NTOk addr ->
  let server_addr = Network.ADDR_INET(addr, server_port) in
  print_string "Allowed packet ids are\nCreateUser, CreateDevice, RemoveDevice, PreKeys, PrekeyBundleRequest, Messages, Poll.\nUse Quit to quit the program.\n";
  attacker_loop server_addr
     
let command_syntax() =
  FStar.IO.print_string "Command-line syntax:\n  attacker.exe <options>\nwhere the options are:\n  -server <server name>\n  -port <server port number>\n"

let rec parse_args (options: string & port) (l: list string) :
FStar.All.ML (option (string & port)) =
let (server_name, server_port) = options in
match l with
| [] -> Some(server_name, server_port)
| "-server"::name::l ->
   parse_args (name, server_port) l
| "-port"::port::l ->
   begin
     match Network.Helper.parse_port port with
     | Some port -> parse_args (server_name, port) l
     | None ->
         FStar.IO.print_string "Bad port\n";
      	 command_syntax();
	 None
   end
| s::l ->
   FStar.IO.print_string ("Bad option: " ^ s ^ "\n");
   command_syntax();
   None

let main (args: list string) =
  match parse_args (Constants.server_name, Constants.server_port) args with
  | None -> ()
  | Some options ->
      init_and_run (fun () -> attacker options)
