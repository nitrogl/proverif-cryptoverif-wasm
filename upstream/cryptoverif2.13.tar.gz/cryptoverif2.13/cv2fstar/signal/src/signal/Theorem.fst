(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module Theorem

open State
open MyTypes
open SIGNAL.Events
open SIGNAL.Events.FStar
open SIGNAL.Effect
open SIGNAL.Protocol
open SIGNAL.Queries
open SIGNAL.Invariant
open SIGNAL.Types

(** An assumption about keys stored on the server:
    If a user is honest, and we receive keys for this user from the server,
    then these keys have been sent to the server for this user, by
    a honest process.
    In particular, we assume that the server behaves honestly for key
    distribution and that the channels between the devices and the
    server are secured when the devices or the server send device keys.
    (Reimplementing the TLS protocol used for securing these communications
    is out of scope of this case study.)
*)

(* The sender is honest: if we receive a key for sender, then this
   key was associated to the sender by a honest process. *)

let honest_user_send uid (trace: list signal_event) =
  forall pk.
     List.memP (FStarEvent (Event_Received_Key_for_User pk uid)) trace ==>
       List.memP (FStarEvent (Event_Sent_Key_for_User pk uid)) trace

(** The correspondence property for sending to a single user:
    If user [ruid] receives a message claimed to be from [suid] and [suid]
    is a honest user, then this message was indeed previously sent by [suid]
    to [ruid], or [suid] has been corrupted
*)
let correspondence_single (trace: list signal_event) : prop = forall ruid suid msg.
  (List.memP (FStarEvent (Event_Recv_Message ruid suid msg)) trace /\
   honest_user_send suid trace)
   ==> (
     List.memP (FStarEvent (Event_Send_Message suid ruid msg)) trace \/
     List.memP (FStarEvent (Event_Corrupt_User suid)) trace
   )

(** When considering a concurrent setting, we need to restrict pre and postconditions of functions to be "self-framing"
    in the separation logic sense, that is to only relate to the local state (including local sessions).
    We do this through these framing_pre and framing_post predicates below, which capture that predicates are preserved,
    even if there is a concurrent execution intertwined
*)
let framing_pre = p:(signal_state -> prop){forall s0 s0'. SIGNAL.InvariantLemmas.parallel_rel' s0 s0' ==> (p s0 <==> p s0')}
let framing_post a = p:(signal_state -> a -> signal_state -> prop){forall s0 s0' s1 s1' res. SIGNAL.InvariantLemmas.parallel_rel' s0 s0' ==> SIGNAL.InvariantLemmas.parallel_rel' s1' s1 ==> (p s0 res s1 <==> p s0' res s1')}

#push-options "--z3rlimit 100"

(** 
    If we have a CVST function [f], then after executing it, 
    we have the correspondence on its trace of events
*)
let correspondence_theorem_single #a (#pre:framing_pre) (#post:framing_post a) (f: unit -> CVSTInv a pre post) :
  CVSTInv a pre (fun s0 res s1 -> post s0 res s1 /\ correspondence_single (State.events_of s1))
  = let res = f () in
    let s1 = get_state () in
    SIGNAL.Queries.lemma_SimplRecv_1 ();
    SIGNAL.Queries.lemma_Honest_1 ();
    let auxbad pk cv_uid1 sid1 cv_uid2 sid2 : Lemma
      (requires List.memP (CVEvent (Event_Honest sid1 cv_uid1 pk)) (State.events_of s1) /\
      List.memP (CVEvent (Event_Honest sid2 cv_uid2 pk)) (State.events_of s1))
      (ensures sid1 == sid2 /\ cv_uid1 == cv_uid2) =
        let trace: list signal_event = State.events_of s1 in
        SIGNAL.Equations.lemma_23 cv_uid1 cv_uid2
    in
    let nobad pk : Lemma (~ (bad_state pk s1)) =
      Classical.forall_intro_4 (fun cv_uid1 sid1 cv_uid2 -> Classical.move_requires (auxbad pk cv_uid1 sid1 cv_uid2 ))
    in
    let aux ruid suid msg_rec : Lemma
      (requires
        List.memP (FStarEvent (Event_Recv_Message ruid suid msg_rec)) (State.events_of s1) /\
        honest_user_send suid (State.events_of s1))
      (ensures List.memP (FStarEvent (Event_Send_Message suid ruid msg_rec)) (State.events_of s1) \/ List.memP (FStarEvent (Event_Corrupt_User suid)) (State.events_of s1))
    = let trace: list signal_event = State.events_of s1 in
      assert (exists cv_ruid rpk cv_suid spk msg.
        Some msg_rec == Helpers.deserialize_message_record msg /\ 
        List.memP (CVEvent (Event_SimplRecv cv_ruid rpk cv_suid spk msg)) trace /\
        match_local_key (Helpers.to_identity_key rpk) cv_ruid ruid s1 /\
        match_remote_key (Helpers.to_identity_key spk) cv_suid suid s1
      );
      eliminate exists cv_ruid rpk cv_suid spk msg.
        Some msg_rec == Helpers.deserialize_message_record msg /\ 
        List.memP (CVEvent (Event_SimplRecv cv_ruid rpk cv_suid spk msg)) trace /\
        match_local_key (Helpers.to_identity_key rpk) cv_ruid ruid s1 /\
        match_remote_key (Helpers.to_identity_key spk) cv_suid suid s1
      returns List.memP (FStarEvent (Event_Send_Message suid ruid msg_rec)) trace \/ List.memP (FStarEvent (Event_Corrupt_User suid)) trace
      with _. (
        assert (exists sid. List.memP (CVEvent (Event_Honest sid cv_suid spk)) trace);
        eliminate exists sid.
          List.memP (CVEvent (Event_Honest sid cv_suid spk)) trace
        returns List.memP (FStarEvent (Event_Send_Message suid ruid msg_rec)) trace \/ List.memP (FStarEvent (Event_Corrupt_User suid)) trace
        with _. (
          (* The next 2 lines are useful when the sender and receiver user id
             are in the authenticated data *)
          if Constants.uid_in_ad then
            Helpers.lemma_get_cv_uid ();
          (* The next 6 lines are useful when we encrypt the receiver used id *)
          if Constants.checkuid then
            begin
              nobad rpk;
              nobad spk;
              Helpers.forall_intro_5 checkuid_lemma
            end;
          Classical.forall_intro Helpers.lemma_serialize_message_record
        )
      )
    in Classical.forall_intro_3 (fun x y -> Classical.move_requires (aux x y));
    res

#pop-options

(* Intuitive explanation of the proof in the case in which uids are 
authenticated (added to authenticated data in the CryptoVerif model)

FStarEvent (Event_Recv_Message ruid suid msg)
implies by inv
CVEvent (Event_SimplRecv ruid rpk suid spk msg)
FStarEvent(Event_Received_Key_for_User spk suid)

FStarEvent(Event_Received_Key_for_User spk suid)
implies by honest_user_send suid
FStarEvent (Event_Sent_Key_for_User spk suid)
which implies in inv
FStarEvent(Event_Valid_Key_for_User spk suid)
and by inv again
CVEvent (Event_Honest sid suid spk)

we have
CVEvent (Event_SimplRecv ruid rpk suid spk msg)
CVEvent (Event_Honest sid suid spk)
so by query
CVEvent (Event_SimplSend suid spk ruid rpk msg) \/
CVEvent (Event_Corrupt suid spk)

in the first case, by inv
FStarEvent(Event_Send_Message suid ruid msg)

in the second case, by inv
FStarEvent(Event_Valid_Key_for_User spk suid)
FStarEvent(Event_Corrupt_User suid)
*)


(* Intuitive explanation of the proof when we encrypt the receiver user id
   (Constants.checkuid = true)

FStarEvent (Event_Recv_Message ruid suid msg_rec)
implies by inv
ruid == msg_rec.receiver_uid
CVEvent (Event_SimplRecv rpk spk msg)
FStarEvent(Event_Valid_Key_for_User rpk ruid)
FStarEvent(Event_Received_Key_for_User spk suid)

FStarEvent(Event_Received_Key_for_User spk suid)
implies by honest_user_send suid
FStarEvent (Event_Sent_Key_for_User spk suid)
which implies in inv
FStarEvent(Event_Valid_Key_for_User spk suid)
and by inv again
CVEvent (Event_Honest sid spk)

we have
CVEvent (Event_SimplRecv rpk spk msg)

CVEvent (Event_Honest sid spk)
so by query
CVEvent (Event_SimplSend spk rpk msg) \/
CVEvent (Event_Corrupt spk)

in the first case, by inv
FStarEvent(Event_Send_Message suid' ruid' msg_rec')
ruid' == msg_rec'.receiver_uid
FStarEvent(Event_Valid_Key_for_User spk suid')

in the second case, by inv
FStarEvent(Event_Valid_Key_for_User spk suid'')
FStarEvent(Event_Corrupt_User suid'')

by Helpers.lemma_serialize_message_record, msg_rec' == msg_rec, so ruid' == ruid

by key injectivity (part of inv, knowing that bad_state rpk and bad_state spk
are false),
suid == suid' == suid''
*)

(** Our main correspondence: 
    If user [ruid] receives a message claimed to be from [suid] and [suid]
    is a honest user, then this message was indeed previously sent by [suid]
    to a list [ruids] containing [ruid], or [suid] has been corrupted
*)
let correspondence (trace: list signal_event) : prop = forall ruid suid msg.
  (List.memP (FStarEvent (Event_Recv_Message ruid suid msg)) trace /\
   honest_user_send suid trace)
   ==> (
     (exists ruids. List.memP ruid ruids /\
       List.memP (FStarEvent (Event_Send_Message_Users suid ruids (get_plaintext msg))) trace)
       \/
     List.memP (FStarEvent (Event_Corrupt_User suid)) trace
   )

(** Our main correspondence theorem: 
    If we have a CVST function [f], then after executing it, 
    we have the correspondence on its trace of events
*)
let correspondence_theorem #a (#pre:framing_pre) (#post:framing_post a) (f: unit -> CVSTInv a pre post) :
  CVSTInv a pre (fun s0 res s1 -> post s0 res s1 /\ correspondence (State.events_of s1)) = 
  Classical.forall_intro_3 get_plaintext_lemma;
  correspondence_theorem_single #a #pre #post f
