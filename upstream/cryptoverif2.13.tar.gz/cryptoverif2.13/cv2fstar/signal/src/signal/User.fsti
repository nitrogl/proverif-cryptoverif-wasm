(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
(**

    ---------------  Module User ---------------

    Handles communication at user level.

    This module allows one to send and recv messages properly to a user.
*)

module User

open FStar.All

open Crypto.Abstraction
open Network.Types
open Network
open SIGNAL.Effect
open SIGNAL.Protocol
open SIGNAL.Types
open Lib.ByteSequence

val t: Type0

val user_invariant: (user: t) -> (st: signal_state) -> Type0

val user_invariant_stable_under_event (_: unit): Lemma (
    forall s1 s2 u. SIGNAL.InvariantLemmas.rel' s1 s2 ==> State.local_sessions_are_equal s1 s2 ==> user_invariant u s1 ==> user_invariant u s2
)

(**
    Returns the identifier of the remote user.
*)
val remote_identifier: (user: t) -> user_id_t

(**
    Returns the identifier of the local user.
*)
val local_identifier: (user: t) -> user_id_t

(**
    Returns the set of session ids in a given user
*)
val user_session_ids: (user: t) -> GTot (Set.set SidMap.sidt)

val user_invariant_implies_session () : Lemma (forall user st sid.
  user_invariant user st ==> Set.mem sid (user_session_ids user) ==>
    State.is_session sid st)

val user_invariant_stable_under_session_invariant (_: unit) : Lemma (
  forall s1 s2 user.
    SIGNAL.InvariantLemmas.rel' s1 s2 ==>
    (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) ==>
    user_invariant user s1 ==>
    user_invariant user s2
  )


(**** Generators *)

(**
    Creates a new user.

    - identifier: unique identifier of the user
    - identity: identity key, used for cryptographic functions, if run with per-user identity key

    In case an identity key is given, the user will run only in per-user identity key mode.
    In case no identity key is given, the user will run only in per-device identity key mode.

    For more details on the different modes of execution, consult : https://signal.org/docs/specifications/sesame/
*)
val make:
  (local_udid: user_device_id_t) ->
  (remote_id: user_id_t) ->
  (user:t{remote_identifier user == remote_id /\ local_identifier user == local_udid.user_id /\ user_session_ids user == Set.empty})

(**
    Fresh users respect invariant
*)
val make_is_user_invariant_lemma:
  (_: unit)
  -> Lemma
    (forall (st: signal_state) (local_udid: user_device_id_t) (i: user_id_t).
      user_invariant (make local_udid i) st)

(**** Miscallenous functions *)

(**
    Set the maximum amount of time the sending process is tried before giving up.

    This limit is used to mittigate the effects in case the server is malicious of buggy.

    The default value is set to 5.
*)

val set_sending_loop_limit: (user: t) -> (new_limit: UInt8.t) -> t

(**
    Returns true if the user is stale.
*)
val is_stale: (user: t) -> bool

(**
    Returns the time at which the user was marked stale
*)
val stale_time: (device: t) -> option nat

(**** Cryptographic functions *)

(**
    Tries to send the packet to all the devices of the user.

    In case it fails, all the modifications made on `user` are dropped.

    NOTE: add error message (standardized as Result<> type, cf. Rust).
*)

val send:
  (ch: net_channel)
  -> (user: t)
  -> (cryptographic_state: cryptographic_state_t)
  -> (packet: t_message)
  -> CVSTInv t
      (fun st ->
        user_invariant user st /\
        cryptographic_state_invariant cryptographic_state st /\
        msg_send_event packet (local_identifier user) (remote_identifier user)  st /\
        Set.disjoint (cstate_session_ids cryptographic_state) (user_session_ids user) /\
        get_personal_user_id cryptographic_state == local_identifier user
      )
      (fun s1 res s2 ->
          remote_identifier user == remote_identifier res
          /\ local_identifier user == local_identifier res
          /\ user_invariant res s2
          /\ (forall (u: t). Set.disjoint (user_session_ids u) (user_session_ids user) ==> user_invariant u s1 ==> user_invariant u s2)
          /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
          /\ Set.disjoint (cstate_session_ids cryptographic_state) (user_session_ids res)
          /\ (forall sid. State.is_session sid s1 /\ not (Set.mem sid (user_session_ids user)) ==> not (Set.mem sid (user_session_ids res)))
      )

(**
    Tries to decrypt the input ciphertext.
*)
val decrypt:
    (cryptographic_state: cryptographic_state_t)
    -> (user: t) -> (packet_msg: packet_message_t) -> CVSTInv
    (cryptographic_state_t & t & option t_message)
    (fun st ->
        cryptographic_state_invariant cryptographic_state st /\
        user_invariant user st /\
        Set.disjoint (cstate_session_ids cryptographic_state) (user_session_ids user) /\
	get_personal_user_id cryptographic_state == local_identifier user)
    (fun s1 res s2 ->
        remote_identifier user == remote_identifier res._2
        /\ local_identifier user == local_identifier res._2
	/\ get_personal_user_id res._1 == get_personal_user_id cryptographic_state
        /\ user_invariant res._2 s2
	/\ cryptographic_state_invariant res._1 s2
        /\ (forall (u: t). Set.disjoint (cstate_session_ids cryptographic_state) (user_session_ids u) ==> user_invariant u s1 ==> user_invariant u s2)
        /\ (forall (c: cryptographic_state_t). Set.disjoint (cstate_session_ids cryptographic_state) (cstate_session_ids c) ==> cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
        /\ Set.subset (cstate_session_ids res._1) (cstate_session_ids cryptographic_state)
        /\ Set.disjoint (cstate_session_ids res._1) (user_session_ids res._2)
        /\ (forall sid. State.is_session sid s1 /\ not (Set.mem sid (Set.union (cstate_session_ids cryptographic_state) (user_session_ids user))) ==>
    not (Set.mem sid (Set.union (cstate_session_ids res._1) (user_session_ids res._2))))
        /\ (match res._3 with
          | Some msg -> msg_recv_event msg (local_identifier user) (remote_identifier user) s2
          | None -> True)
    )

(** Remove all CryptoVerif sessions of the user
*)
val finalize_user (u: t):
    CVSTInv unit
      (fun s1 -> user_invariant u s1)
      (fun s1 res s2 ->
        (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2))

(** Remove all devices of this user that are stale since long enough
*)
val remove_stale (time: nat) (u: t): 
    CVSTInv t
      (fun s1 -> user_invariant u s1)
      (fun s1 res s2 ->
        (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2) /\
        local_identifier res == local_identifier u /\
        remote_identifier res == remote_identifier u /\
        Set.subset (user_session_ids res) (user_session_ids u) /\
        user_invariant res s2)
