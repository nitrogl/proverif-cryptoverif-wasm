(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
(**

    ---------------  Module Crypto.Abstraction ---------------

    Interface with the extracted code of cryptoverif.

    This modules is a simple interface with cryptoverif extracted code to simplify
    maintaining the code when the model/queries in cryptoverif are modified.

    We centralize in this module all the interactions with CV2FStar extracted modules.
*)

module Crypto.Abstraction

open CVTypes
open Lib.ByteSequence

open SIGNAL.Types
open SIGNAL.Effect
open SIGNAL.Protocol
open SIGNAL.Functions
open SIGNAL.Invariant
open Constants
open MyTypes
open Network.Types

(**** Export types *)

(***** Session *)

val session_t: Type0

(**
  Returns the session id corresponding to a session
*)
val session_id: session_t -> SidMap.sidt

(**
  Returns the local_user_id stored in a session
*)
val local_user_id: session_t -> GTot user_id_t

(**
  Returns the remote_user_id stored in a session
*)
val remote_user_id: session_t -> GTot user_id_t

(**
    Checks that the invariants are kept throught the entire module.
*)
val session_invariant: (session: session_t) -> (st: signal_state) -> prop

val session_invariant_stable_under_event (_: unit): Lemma (
    forall s1 s2 d. SIGNAL.InvariantLemmas.rel' s1 s2 ==> State.local_sessions_are_equal s1 s2 ==> session_invariant d s1 ==> session_invariant d s2
)

val session_invariant_stable_under_parallel_rel (_: unit): Lemma (
    forall s1 s2 s. SIGNAL.InvariantLemmas.parallel_rel' s1 s2 ==> session_invariant s s1 ==> session_invariant s s2
)

val session_invariant_implies_session (_: unit) : Lemma (forall session (st: signal_state).
  session_invariant session st ==> State.is_session (session_id session) st)

(*
    Cryptographic state used to bookeep different information on generated keys.
*)
val cryptographic_state_t: Type0

(**
  Returns the personal_user_id associated to a cryptographic_state
*)
val get_personal_user_id: cryptographic_state_t -> GTot user_id_t

(**
    Cryptographic state invariant. It is required to hold for most functions, and all functions preserve it.
*)
val cryptographic_state_invariant: (state: cryptographic_state_t) -> (st: signal_state) -> Type0

val cryptographic_state_invariant_stable_under_event (_: unit): Lemma (
    forall s1 s2 c. SIGNAL.InvariantLemmas.rel' s1 s2 ==> State.local_sessions_are_equal s1 s2 ==> cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2
)

val crypto_invariant_stable_under_parallel_rel (_: unit): Lemma (
    forall s1 s2 c. SIGNAL.InvariantLemmas.parallel_rel' s1 s2 ==> cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2
)

val cstate_session_ids: cryptographic_state_t -> GTot (Set.set SidMap.sidt)

val crypto_invariant_implies_session () : Lemma (forall cstate (st: signal_state) sid.
  cryptographic_state_invariant cstate st ==> Set.mem sid (cstate_session_ids cstate) ==> State.is_session sid st)

(**
    Create a cryptographic state.

    This creates a unique identity that will be used for all communication outgoing from the device.
*)

val regenerate_cryptographic_state (state: cryptographic_state_t) : 
    CVSTInv
        (option (cryptographic_state_t & signed_prekey_bundle_t & (l: list (prekey_id_t & prekey_t) { List.length l <= Constants.num_one_time_prekeys })))
        (fun s -> cryptographic_state_invariant state s)
        (fun s1 res s2 ->
            (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2)
            /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
            /\ (match res with
                | Some (st, signed_prekey_bundle, one_time_prekeys) ->
                    (forall sid. State.is_session sid s1 /\ not (Set.mem sid (cstate_session_ids state)) ==> not (Set.mem sid (cstate_session_ids st))) /\
                    cryptographic_state_invariant st s2 /\
                    get_personal_user_id st == get_personal_user_id state
                | _ -> True
              )
        )

val make_device (personal_user_id: user_id_t):
    CVSTInv
        (option (cryptographic_state_t & signed_prekey_bundle_t & (l: list (prekey_id_t & prekey_t) { List.length l <= Constants.num_one_time_prekeys })))
        (fun _ -> True)
        (fun s1 res s2 ->
            (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2)
            /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
            /\ (match res with
                | Some (cst, signed_prekey_bundle, one_time_prekeys) ->
                    cryptographic_state_invariant cst s2 /\
		    get_personal_user_id cst == personal_user_id
                | _ -> True
              )
         )

(**
    Returns the identity key.
*)
val identity_key (state: cryptographic_state_t): (r: identity_key_t{ (forall (st: signal_state). cryptographic_state_invariant state st ==> is_valid_local_key r (get_personal_user_id state) st) })

(**
    Creates a session from the input prekey bundle.

    This function also returns the initial packet.

    For practical purposes, cryptographic functions almost exclusively works on bytes.
    Therefore, it takes as an input a bytes as a prekey_bundle and returns None if it does not ahve the correct shape.
    This allows us to avoid confusions on serializeation/deserialization.
*)

let msg_send_event msg local_id remote_id (s2: signal_state) = (exists msg_rec.
  List.memP (State.FStarEvent (SIGNAL.Events.FStar.Event_Send_Message local_id remote_id msg_rec)) (State.events_of s2) /\
  msg == Helpers.serialize_message_record msg_rec)

val create_session_from_prekey_bundle
    (cryptographic_state: cryptographic_state_t)
    (remote_user_identifier: user_id_t)
    (remote_identity_key: identity_key_t)
    (prekey_bundle: prekey_bundle_t)
    (msg: t_message):
      CVSTInv
        (option (session_t & encrypted_message_t))
        (fun st ->
           cryptographic_state_invariant cryptographic_state st /\
           is_valid_remote_key remote_identity_key remote_user_identifier st /\
	   msg_send_event msg (get_personal_user_id cryptographic_state) remote_user_identifier st)
        (fun s1 res s2 ->
            (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2)
            /\ (match res with
              | Some (session, _) ->
                  session_invariant session s2 /\
                  not (State.is_session (session_id session) s1) /\
                  local_user_id session == get_personal_user_id cryptographic_state /\
                  remote_user_id session == remote_user_identifier
              | None -> True)
            /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2))

open SIGNAL.Events

(* States that the event of receiving the message happened *)
let msg_recv_event msg local_id remote_id (s2: signal_state) = (exists cv_uid1 pk1 cv_uid2 pk2.
  List.memP (State.CVEvent (Event_SimplRecv cv_uid1 pk1 cv_uid2 pk2 msg)) (State.events_of s2) /\
  match_local_key (Helpers.to_identity_key pk1) cv_uid1 local_id s2 /\
  match_remote_key (Helpers.to_identity_key pk2) cv_uid2 remote_id s2
)

(**
    Creates a session from an initial message.

    I will add lated invariant on the session generated.
*)
val create_session_from_init_message
    (state: cryptographic_state_t)
    (remote_user_identifier: user_id_t)
    (remote_identity_key: identity_key_t)
    (init_message_bundle: init_message_bundle_t)
    (ciphertext: t_cipher)
    (counter: nonce_t):
      CVSTInv (option (cryptographic_state_t & session_t & t_message))
        (fun s1 ->
          is_valid_remote_key remote_identity_key remote_user_identifier s1
          /\ cryptographic_state_invariant state s1)
        (fun s1 res s2 ->
              (match res with
                | Some (state', session, msg) ->
                    cryptographic_state_invariant state' s2 /\
	            get_personal_user_id state' == get_personal_user_id state /\
                    Set.subset (cstate_session_ids state') (cstate_session_ids state) /\
                    session_invariant session s2 /\
                    not (State.is_session (session_id session) s1) /\
                    not (Set.mem (session_id session) (cstate_session_ids state')) /\
                    local_user_id session == get_personal_user_id state /\
                    remote_user_id session == remote_user_identifier /\
                    msg_recv_event msg (local_user_id session) (remote_user_id session) s2
                | None -> cryptographic_state_invariant state s2)
            /\ (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2)
            /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
         )

(**
    Encrypt a message using the session when possible.
*)

val encrypt_message:
    (session: session_t)
    -> (message: t_message)
    -> CVSTInv (session_t & option encrypted_message_t)
        (fun st -> session_invariant session st
            /\ msg_send_event message (local_user_id session) (remote_user_id session) st)
        (fun s1 res s2 ->
            local_user_id session == local_user_id res._1 /\
            remote_user_id session == remote_user_id res._1 /\
            session_id session == session_id res._1 /\
            session_invariant res._1 s2
            /\ (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2)
            /\ forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)

(**
    Decrypt a cipher using the session when possible.
*)
val decrypt_message:
    (session: session_t)
    -> (cipher: t_cipher)
    -> (nonce: nonce_t)
    ->  CVSTInv (option (session_t & t_message))
        (fun s1 -> session_invariant session s1)
        (fun s1 res s2 ->
            (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2)
            /\ (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2)
            /\ (match res with | None -> True | Some (session', msg) ->
                session_invariant session' s2 /\
                msg_recv_event msg (local_user_id session) (remote_user_id session) s2 /\
                session_id session == session_id session' /\
		local_user_id session' == local_user_id session /\
		remote_user_id session' == remote_user_id session
            )
        )

(* Finalize a session, by removing the associated CryptoVerif state *)
val finalize_session (session: session_t):
    CVSTInv unit
      (fun s1 -> session_invariant session s1)
      (fun s1 res s2 ->
        (forall (s: session_t). session_invariant s s1 ==> session_invariant s s2) /\
        (forall (c: cryptographic_state_t). cryptographic_state_invariant c s1 ==> cryptographic_state_invariant c s2))
