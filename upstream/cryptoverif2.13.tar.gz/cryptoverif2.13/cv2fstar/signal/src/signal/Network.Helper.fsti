(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
(**

    ---------------  Module Network.Helper ---------------

    Defines a serie of helper functions to handle all network calls.
*)

module Network.Helper

open Crypto.Abstraction
open Network.Types
open Network
open Lib.Sequence
open Lib.ByteSequence
open SIGNAL.Effect
open Constants
open CVTypes

val parse_port : string -> option port

val debug_print : string -> CVSTML unit

val send_packet (ch: net_channel) (p: packet_t) :
    CVSTML (net_res_t unit string)

val recv_packet (ch: net_channel) :
    CVSTML (net_res_t packet_t recv_err_t)

(**
    Fetch the prekey bundle from the server.
*)
val fetch_prekey_bundle:
  (ch: net_channel)
  -> (user_id: user_id_t)
  -> (device_id: device_id_t)
  -> CVSTInv (option prekey_bundle_t)
            (requires fun _ -> True)
            (ensures fun s0 _ s1 ->
              State.local_sessions_are_equal s0 s1
            )

val upload_message:
  (ch: net_channel)
  -> (sending_device: user_device_id_t)
  -> (receiving_user: user_id_t)
  -> (l: lbyte_list pre_packet_t)
  -> CVSTInv (option packet_t)
            (requires fun _ -> True)
            (ensures fun s0 _ s1 ->
              State.local_sessions_are_equal s0 s1
            )

val query_user_id (ch: net_channel): CVSTInv (option user_id_t)
            (requires fun _ -> True)
            (ensures fun s0 _ s1 ->
              State.local_sessions_are_equal s0 s1
            )

val query_device_id (ch: net_channel) (user_id: user_id_t) (k: identity_key_t)
   (b: signed_prekey_bundle_t) (otp: lbyte_list (prekey_id_t & prekey_t)):
   CVSTInv (option device_id_t)
            (requires fun s -> SIGNAL.Invariant.is_valid_local_key k user_id s)
            (ensures fun s0 _ s1 ->
              State.local_sessions_are_equal s0 s1
            )

val refresh_keys (ch: net_channel) (user_device_id: user_device_id_t)
  (b: signed_prekey_bundle_t) (otp: lbyte_list (prekey_id_t & prekey_t)):
  CVSTInv bool
            (requires fun _ -> True)
            (ensures fun s0 _ s1 ->
              State.local_sessions_are_equal s0 s1
            )

val remove_device
  (ch: net_channel)
  (user_device_id: user_device_id_t):
  CVSTInv bool
            (requires fun _ -> True)
            (ensures fun s0 _ s1 ->
              State.local_sessions_are_equal s0 s1
            )
