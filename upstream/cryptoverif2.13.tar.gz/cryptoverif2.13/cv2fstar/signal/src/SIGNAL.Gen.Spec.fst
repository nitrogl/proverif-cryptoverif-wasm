(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module SIGNAL.Gen.Spec

open CVTypes
open State
open SIGNAL.Types
open SIGNAL.Functions
open SIGNAL.Tables
open SIGNAL.Events
open SIGNAL.Events.FStar
open SIGNAL.Sessions
open SIGNAL.Protocol
open SIGNAL.Invariant

(* PLEASE ADD PROOFS FOR THE LEMMAS *)

let add_cv_corrupt (s: signal_state) cv_uid pk :
  Lemma (requires SIGNAL.InvariantLemmas.inv' s /\
                  (exists uid.
                    match_local_key (Helpers.to_identity_key pk) cv_uid uid s /\
                      List.memP (FStarEvent (SIGNAL.Events.FStar.Event_Corrupt_User uid)) (State.events_of s)
                  )
        )
        (ensures SIGNAL.InvariantLemmas.local_rel' s (state_add_event s (CVEvent (Event_Corrupt cv_uid pk))))
        [SMTPat (state_add_event s (CVEvent (Event_Corrupt cv_uid pk)))]
  = let e = Event_Corrupt cv_uid pk in
    Classical.forall_intro (Classical.move_requires (List.append_memP (State.events_of s) [CVEvent e]))

#push-options "--z3rlimit 70"

let lemmaoracle_OCorrupt (sid: SidMap.sidt)  (state: signal_state) = ()

#pop-options

// Reexpose this lemma with an SMTPat
let add_cv_event (s: signal_state) (e: SIGNAL.Events.cv_event) :
  Lemma (requires SIGNAL.InvariantLemmas.inv' s /\ not (Event_SimplSend? e) /\ not (Event_Corrupt? e) /\ not (Event_Honest? e))
        (ensures SIGNAL.InvariantLemmas.local_rel' s (state_add_event s (CVEvent e)))
        [SMTPat (state_add_event s (CVEvent e))]
  = add_cv_event s e

let add_cv_simpl (s: signal_state) cv_uid1 pk1 cv_uid2 pk2 msg :
  Lemma (requires SIGNAL.InvariantLemmas.inv' s /\
                  (exists uid1 uid2 msg_rec.
                    msg == Helpers.serialize_message_record msg_rec /\
                    List.memP (FStarEvent (Event_Send_Message uid1 uid2 msg_rec)) (State.events_of s) /\
                    match_local_key (Helpers.to_identity_key pk1) cv_uid1 uid1 s /\
                    match_remote_key (Helpers.to_identity_key pk2) cv_uid2 uid2 s
                  )
        )
        (ensures SIGNAL.InvariantLemmas.local_rel' s (state_add_event s (CVEvent (Event_SimplSend cv_uid1 pk1 cv_uid2 pk2 msg))))
        [SMTPat (state_add_event s (CVEvent (Event_SimplSend cv_uid1 pk1 cv_uid2 pk2 msg)))]
  = let e = Event_SimplSend cv_uid1 pk1 cv_uid2 pk2 msg in
    Classical.forall_intro (Classical.move_requires (List.append_memP (State.events_of s) [CVEvent e]))

let lemmaoracle_Odec1 (sid: SidMap.sidt) (input_136: t_cipher) (input_135: (lbytes 12)) (state: signal_state) = ()

let lemmaoracle_Odec2 (sid: SidMap.sidt) (input_138: t_cipher) (input_137: (lbytes 12)) (state: signal_state) = ()

let lemmaoracle_Odec3 (sid: SidMap.sidt) (input_140: t_cipher) (input_139: (lbytes 12)) (state: signal_state) = ()

let lemmaoracle_Odec4 (sid: SidMap.sidt) (input_142: t_cipher) (input_141: (lbytes 12)) (state: signal_state) = ()

#push-options "--z3rlimit 70"

let lemmaoracle_Oenc1 (sid: SidMap.sidt) (input_144: t_message) (input_143: (lbytes 12)) (state: signal_state) = ()

let lemmaoracle_Oenc2 (sid: SidMap.sidt) (input_146: t_message) (input_145: (lbytes 12)) (state: signal_state) = ()

let lemmaoracle_Oenc3 (sid: SidMap.sidt) (input_148: t_message) (input_147: (lbytes 12)) (state: signal_state) = ()

let lemmaoracle_Oenc4 (sid: SidMap.sidt) (input_150: t_message) (input_149: (lbytes 12)) (state: signal_state) = ()

let add_cv_honest_event (s: signal_state) (sid: SidMap.sidt) (cv_uid: cv_user_id_t) (pk: ty_idkey) :
 Lemma (requires (SIGNAL.InvariantLemmas.inv' s /\ is_local sid s))
       (ensures SIGNAL.InvariantLemmas.local_rel' s (state_add_event s (CVEvent (Event_Honest sid cv_uid pk))))
       [SMTPat (state_add_event s (CVEvent (Event_Honest sid cv_uid pk)))]
  = Classical.forall_intro (Classical.move_requires (List.append_memP (State.events_of s) [CVEvent (Event_Honest sid cv_uid pk)]))

let lemmaoracle_Ogenprinc (var_uid_0: cv_user_id_t) (state: signal_state) = ()

#pop-options

#push-options "--z3rlimit 100"

let lemmaoracle_Orecv1 (sid: SidMap.sidt) (var_x__pubB_1: (lbytes 32)) (var_x__pubBsign_1: (lbytes 32)) (var_sephPubAB_1: (lbytes 32)) (var_signature_1: (lbytes 64)) (var_ephPubAB_1: (lbytes 32)) (var_msg__start_1: t_message) (var_remote__uid_3: cv_user_id_t) (state: signal_state)  = ()

let lemmaoracle_Orecv2 (sid: SidMap.sidt) (var_x__pubB_2: (lbytes 32)) (var_x__pubBsign_2: (lbytes 32)) (var_sephPubAB_2: (lbytes 32)) (var_signature_2: (lbytes 64)) (var_msg__start_2: t_message) (var_remote__uid_4: cv_user_id_t) (state: signal_state)  = ()

let lemmaoracle_Osend1 (sid: SidMap.sidt) (state: signal_state)  = ()

let lemmaoracle_Osend2 (sid: SidMap.sidt)  (state: signal_state)  = ()

let lemmaoracle_Osend3 (sid: SidMap.sidt) (var_x__pubA_1: (lbytes 32)) (var_x__pubAsign_1: (lbytes 32)) (var_ephPubBA_1: (lbytes 32)) (var_ephPubBA_27_1: (lbytes 32)) (var_msgenc__start_1: t_cipher) (var_remote__uid_1: cv_user_id_t) (var_n__start__recv_1: (lbytes 12)) (state: signal_state)  = ()

let lemmaoracle_Osend4 (sid: SidMap.sidt) (var_x__pubA_2: (lbytes 32)) (var_x__pubAsign_2: (lbytes 32)) (var_ephPubBA_2: (lbytes 32)) (var_ephPubBA2_0: (lbytes 32)) (var_msgenc__start_2: t_cipher) (var_remote__uid_2: cv_user_id_t) (var_n__start__recv_2: (lbytes 12)) (state: signal_state)  = ()

#pop-options

