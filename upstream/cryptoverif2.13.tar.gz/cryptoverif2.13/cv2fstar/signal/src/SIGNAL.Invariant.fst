(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module SIGNAL.Invariant

open CVTypes
open SIGNAL.Types
open SIGNAL.Sessions
open SIGNAL.Events
open SIGNAL.Events.FStar
open SIGNAL.Protocol
open State
open MyTypes

unfold
let is_valid_local_key pk uid (s: signal_state) =
  List.memP (FStarEvent(Event_Valid_Key_for_User pk uid)) (State.events_of s)

unfold
let match_local_key pk cv_uid uid (s: signal_state) =
  if Constants.uid_in_ad then
    cv_uid == Helpers.get_cv_uid uid
  else
    is_valid_local_key pk uid s

unfold
let is_valid_remote_key pk uid (s: signal_state) =
  List.memP (FStarEvent(Event_Received_Key_for_User pk uid)) (State.events_of s)

unfold
let match_remote_key pk cv_uid uid (s: signal_state) = 
  cv_uid == Helpers.get_cv_uid uid /\
  is_valid_remote_key pk uid s

let bad_state pk (s: signal_state) =
  (exists sid1 sid2 cv_uid1 cv_uid2. 
     List.memP (CVEvent (Event_Honest sid1 cv_uid1 pk)) (State.events_of s) /\
     List.memP (CVEvent (Event_Honest sid2 cv_uid2 pk)) (State.events_of s) /\
     ~(sid1 == sid2 /\ cv_uid1 == cv_uid2))

(*Example code for counting, which could be adapted if we try to prove the injective correspondence
let count_honest pk (s: signal_state) =
  List.length (List.Tot.filter (fun e ->
    match e with
    | CVEvent (Event_Honest sid pk') -> MyTypes.identity_key_eq pk (Helpers.to_identity_key pk')
    | _ -> false) (State.events_of s))

let count_valid_key_for_user pk (s: signal_state) =
  List.length (List.Tot.filter (fun e ->
    match e with
    | FStarEvent(Event_Valid_Key_for_User pk' uid) -> MyTypes.identity_key_eq pk pk'
    | _ -> false) (State.events_of s))*)

val inv : signal_state -> prop
let inv s =
   // Should follow from the client code: If we "cryptographically" send, we are in the middle of a Sesame send function,
   // and logged an FStar Event send.
  (forall msg cv_uid1 pk1 cv_uid2 pk2.
      (List.memP (CVEvent (Event_SimplSend cv_uid1 pk1 cv_uid2 pk2 msg)) (State.events_of s))
     ==> (exists uid1 uid2 msg_rec.
       Helpers.serialize_message_record msg_rec == msg /\
       List.memP (FStarEvent (Event_Send_Message uid1 uid2 msg_rec)) (State.events_of s) /\
       match_local_key (Helpers.to_identity_key pk1) cv_uid1 uid1 s /\
       match_remote_key (Helpers.to_identity_key pk2) cv_uid2 uid2 s
     )
  ) /\
  // Dual property, but for Recv.
  (forall msg_rec uid1 uid2.
    List.memP (FStarEvent (Event_Recv_Message uid1 uid2 msg_rec)) (State.events_of s) ==>
      (exists cv_uid1 pk1 cv_uid2 pk2 msg.
        checkuid uid1 uid2 msg_rec /\
        Some msg_rec == Helpers.deserialize_message_record msg /\
        List.memP (CVEvent (Event_SimplRecv cv_uid1 pk1 cv_uid2 pk2 msg)) (State.events_of s) /\
        match_local_key (Helpers.to_identity_key pk1) cv_uid1 uid1 s /\
        match_remote_key (Helpers.to_identity_key pk2) cv_uid2 uid2 s
      )
  ) /\
  // Lifting the corruption property to users:
  // We overapproximate user corruption, and consider a user as corrupt as soon as one of its keys is corrupted
  (forall cv_uid pk.
      List.memP (CVEvent (Event_Corrupt cv_uid pk)) (State.events_of s) ==>
        (exists uid. match_local_key (Helpers.to_identity_key pk) cv_uid uid s /\
         List.memP (FStarEvent (Event_Corrupt_User uid)) (State.events_of s))
  ) /\
  (forall pk uid.
      (List.memP (FStarEvent (Event_Sent_Key_for_User pk uid)) (State.events_of s) ==>
      is_valid_local_key pk uid s)
  ) /\
  (forall pk uid.
     is_valid_local_key (Helpers.to_identity_key pk) uid s ==>
     (exists sid. List.memP (CVEvent (Event_Honest sid (Helpers.get_cv_uid uid) pk)) (State.events_of s))
  ) /\
  // Key injectivity
  // Key injectivity is not necessary when the user ids are added to the
  // authenticated data
  // If you want to remove key injectivity, please also remove
  // other parts needed for key injectivity only:
  // - in this file, also cut the next property below and part of local_rel 
  //   and pre_add_event
  // - in SIGNAL.InvariantLemmas.fst, simplify pre_add_event_lemma 
  // - in signal/Crypto.Abstraction.fst, cut lemma_Ogenprinc_event_aux,
  //   lemma_Ogenprinc_event, and two lines in genprinc
  // (see comments there)
  (forall pk uid1 uid2.
     (is_valid_local_key (Helpers.to_identity_key pk) uid1 s /\
      is_valid_local_key (Helpers.to_identity_key pk) uid2 s /\
      ~(uid1 == uid2)) ==> bad_state pk s
  ) /\
  // The next property is useful to prove key injectivity
  (forall cv_uid pk sid.
      List.memP (CVEvent (Event_Honest sid cv_uid pk)) (State.events_of s) ==>
      State.is_session sid s
  ) /\
  (forall msg_rec uid1 uid2.
       List.memP (FStarEvent (Event_Send_Message uid1 uid2 msg_rec)) (State.events_of s)
     ==> (exists uids msg.
            msg_rec == make_message_record uid2 uid1 msg /\
            List.memP uid2 uids /\
            List.memP (FStarEvent (Event_Send_Message_Users uid1 uids msg)) (State.events_of s) )
   )


let is_local_pk cv_uid pk (s: signal_state) =
  (exists sid. List.memP (CVEvent (Event_Honest sid cv_uid pk)) (State.events_of s) /\
    is_local sid s)

(*let is_local_uid uid (s: signal_state) =
  (exists pk. is_valid_local_key (Helpers.to_identity_key pk) uid s /\ is_local_pk pk s) *)

val _rel : signal_state -> signal_state -> prop
let _rel s0 s1 =  forall e. List.memP e (State.events_of s0) ==> List.memP e (State.events_of s1)

val local_rel : signal_state -> signal_state -> prop
let local_rel s0 s1 = _rel s0 s1
   /\ State.non_local_sessions_are_equal s0 s1
   (* The next properties are useful to prove key injectivity.
      They are not needed when the user ids are added to the
      authenticated data *)
   /\ (forall sid cv_uid pk.
     List.memP (CVEvent (Event_Honest sid cv_uid pk)) (State.events_of s1) ==>
     ~(List.memP (CVEvent (Event_Honest sid cv_uid pk)) (State.events_of s0)) ==>
     is_local sid s1)
   /\ (forall pk uid.
     is_valid_local_key (Helpers.to_identity_key pk) uid s1 ==>
     ~(is_valid_local_key (Helpers.to_identity_key pk) uid s0) ==>
     is_local_pk (Helpers.get_cv_uid uid) pk s1)

val rel : signal_state -> signal_state -> prop
let rel = _rel

val pre_add_event : SIGNAL.Events.FStar.fstar_event -> signal_state -> prop
let pre_add_event e s =
  match e with
  | Event_Recv_Message uid1 uid2 msg_rec -> exists cv_uid1 pk1 cv_uid2 pk2 msg.
      checkuid uid1 uid2 msg_rec /\
      Some msg_rec == Helpers.deserialize_message_record msg /\
      List.memP (CVEvent (Event_SimplRecv cv_uid1 pk1 cv_uid2 pk2 msg)) (State.events_of s) /\
      match_local_key (Helpers.to_identity_key pk1) cv_uid1 uid1 s /\
      match_remote_key (Helpers.to_identity_key pk2) cv_uid2 uid2 s
  | Event_Send_Message uid1 uid2 msg_rec -> exists uids msg.
      msg_rec == make_message_record uid2 uid1 msg /\
      List.memP uid2 uids /\
      List.memP (FStarEvent (Event_Send_Message_Users uid1 uids msg)) (State.events_of s)
  | Event_Sent_Key_for_User pk uid ->
      is_valid_local_key pk uid s
  | Event_Valid_Key_for_User pk uid ->
      let pk' = Helpers.from_identity_key pk in
      let cv_uid = Helpers.get_cv_uid uid in
      is_local_pk cv_uid pk' s
      // the next line is needed for key injectivity
      /\ ((exists uid'. is_valid_local_key pk uid' s) ==> bad_state pk' s)
  | _ -> True

val pre_Odec1: SidMap.sidt -> t_cipher -> (lbytes 12) -> signal_state -> prop
let pre_Odec1 sid input_2 input_1 s = True

val pre_Odec2: SidMap.sidt -> t_cipher -> (lbytes 12) -> signal_state -> prop
let pre_Odec2 sid input_4 input_3 s = True

val pre_Odec3: SidMap.sidt -> t_cipher -> (lbytes 12) -> signal_state -> prop
let pre_Odec3 sid input_6 input_5 s = True

val pre_Odec4: SidMap.sidt -> t_cipher -> (lbytes 12) -> signal_state -> prop
let pre_Odec4 sid input_8 input_7 s = True

val pre_Oenc1: SidMap.sidt -> t_message -> (lbytes 12) -> signal_state -> prop
let pre_Oenc1 sid input_10 input_9 s =
  match get_session_entry s Oracle_Oenc1 sid with
  | None -> True
  | Some (R1_Oenc1 _ _ local_key local_signkey cv_uid2 cv_uid1 remote_key remote_signkey) ->
    (exists uid1 uid2 msg_rec.
      input_10 == Helpers.serialize_message_record msg_rec /\
      match_local_key (Helpers.to_identity_key (SIGNAL.Functions.fun_mkidkey local_key local_signkey)) cv_uid1 uid1 s /\
      match_remote_key (Helpers.to_identity_key (SIGNAL.Functions.fun_mkidkey remote_key remote_signkey)) cv_uid2 uid2 s /\
      List.memP (FStarEvent (Event_Send_Message uid1 uid2 msg_rec)) (State.events_of s)
    )
  | Some _ -> True

val pre_Oenc2: SidMap.sidt -> t_message -> (lbytes 12) -> signal_state -> prop
let pre_Oenc2 sid input_12 input_11 s =
  match get_session_entry s Oracle_Oenc2 sid with
  | None -> True
  | Some (R1_Oenc2 _ _ local_key local_signkey cv_uid2 cv_uid1 remote_key remote_signkey) ->
    (exists uid1 uid2 msg_rec.
      input_12 == Helpers.serialize_message_record msg_rec /\
      match_local_key (Helpers.to_identity_key (SIGNAL.Functions.fun_mkidkey local_key local_signkey)) cv_uid1 uid1 s /\
      match_remote_key (Helpers.to_identity_key (SIGNAL.Functions.fun_mkidkey remote_key remote_signkey)) cv_uid2 uid2 s /\
      List.memP (FStarEvent (Event_Send_Message uid1 uid2 msg_rec)) (State.events_of s)
    )
  | Some _ -> True

val pre_Oenc3: SidMap.sidt -> t_message -> (lbytes 12) -> signal_state -> prop
let pre_Oenc3 sid input_14 input_13 s =
  match get_session_entry s Oracle_Oenc3 sid with
  | None -> True
  | Some (R1_Oenc3 _ _ local_key local_signkey cv_uid2 cv_uid1 remote_key remote_signkey) ->
    (exists uid1 uid2 msg_rec.
      input_14 == Helpers.serialize_message_record msg_rec /\
      match_local_key (Helpers.to_identity_key (SIGNAL.Functions.fun_mkidkey local_key local_signkey)) cv_uid1 uid1 s /\
      match_remote_key (Helpers.to_identity_key (SIGNAL.Functions.fun_mkidkey remote_key remote_signkey)) cv_uid2 uid2 s /\
      List.memP (FStarEvent (Event_Send_Message uid1 uid2 msg_rec)) (State.events_of s)
    )
  | Some _ -> True

val pre_Oenc4: SidMap.sidt -> t_message -> (lbytes 12) -> signal_state -> prop
let pre_Oenc4 sid input_16 input_15 s =
  match get_session_entry s Oracle_Oenc4 sid with
  | None -> True
  | Some (R1_Oenc4 _ _ local_key local_signkey cv_uid2 cv_uid1 remote_key remote_signkey) ->
    (exists uid1 uid2 msg_rec.
      input_16 == Helpers.serialize_message_record msg_rec /\
      match_local_key (Helpers.to_identity_key (SIGNAL.Functions.fun_mkidkey local_key local_signkey)) cv_uid1 uid1 s /\
      match_remote_key (Helpers.to_identity_key (SIGNAL.Functions.fun_mkidkey remote_key remote_signkey)) cv_uid2 uid2 s /\
      List.memP (FStarEvent (Event_Send_Message uid1 uid2 msg_rec)) (State.events_of s)
    )
  | Some _ -> True

val pre_Orecv1: SidMap.sidt -> (lbytes 32) -> (lbytes 32) -> (lbytes 32) -> (lbytes 64) -> (lbytes 32) -> t_message -> cv_user_id_t -> signal_state -> prop
let pre_Orecv1 sid remote_key remote_signkey var_sephPubAB_1 var_signature_1 var_ephPubAB_1 msg var_remote__uid s =
   match get_session_entry s Oracle_Orecv1 sid with
   | None -> True
   | Some (R1_Orecv1 local_key local_signkey _ var_local__uid) -> 
    (exists uid1 uid2 msg_rec.
      msg == Helpers.serialize_message_record msg_rec /\
      match_local_key (Helpers.to_identity_key (SIGNAL.Functions.fun_mkidkey local_key local_signkey)) var_local__uid uid1 s /\
      match_remote_key (Helpers.to_identity_key (SIGNAL.Functions.fun_mkidkey remote_key remote_signkey)) var_remote__uid uid2 s /\
      List.memP (FStarEvent (Event_Send_Message uid1 uid2 msg_rec)) (State.events_of s)
    )
  | Some _ -> True
  
val pre_Orecv2: SidMap.sidt -> (lbytes 32) -> (lbytes 32) -> (lbytes 32) -> (lbytes 64) -> t_message -> cv_user_id_t -> signal_state -> prop
let pre_Orecv2 sid remote_key remote_signkey var_sephPubAB_2 var_signature_2 msg var_remote__uid s =
   match get_session_entry s Oracle_Orecv2 sid with
   | None -> True
   | Some (R1_Orecv2 local_key local_signkey _ var_local__uid) -> 
    (exists uid1 uid2 msg_rec.
      msg == Helpers.serialize_message_record msg_rec /\
      match_local_key (Helpers.to_identity_key (SIGNAL.Functions.fun_mkidkey local_key local_signkey)) var_local__uid uid1 s /\
      match_remote_key (Helpers.to_identity_key (SIGNAL.Functions.fun_mkidkey remote_key remote_signkey)) var_remote__uid uid2 s /\
      List.memP (FStarEvent (Event_Send_Message uid1 uid2 msg_rec)) (State.events_of s)
    )
  | Some _ -> True

val pre_Osend1: SidMap.sidt -> signal_state -> prop
let pre_Osend1 sid s = True

val pre_Osend2: SidMap.sidt -> signal_state -> prop
let pre_Osend2 sid s = True

val pre_Osend3: SidMap.sidt -> (lbytes 32) -> (lbytes 32) -> (lbytes 32) -> (lbytes 32) -> t_cipher -> cv_user_id_t -> (lbytes 12) -> signal_state -> prop
let pre_Osend3 sid var_x__pubA_1 var_x__pubAsign_1 var_ephPubBA_1 var_ephPubBA_27_1 var_msgenc__start_1 var_remote__uid_1 var_n__start__recv_1 s = True

val pre_Osend4: SidMap.sidt -> (lbytes 32) -> (lbytes 32) -> (lbytes 32) -> (lbytes 32) -> t_cipher -> cv_user_id_t -> (lbytes 12) -> signal_state -> prop
let pre_Osend4 sid var_x__pubA_2 var_x__pubAsign_2 var_ephPubBA_2 var_ephPubBA2_0 var_msgenc__start_2 var_remote__uid_2 var_n__start__recv_2 s = True

val pre_OH: (lbytes 32) -> (lbytes 32) -> (lbytes 32) -> (lbytes 32) -> (lbytes 32) -> signal_state -> prop
let pre_OH var_x1_0 var_x2_0 var_x3_0 var_x4_0 var_x5_0 s = True

val pre_OH__1: (lbytes 32) -> (lbytes 32) -> (lbytes 32) -> (lbytes 32) -> signal_state -> prop
let pre_OH__1 var_x1_1 var_x2_1 var_x3_1 var_x4_1 s = True

val pre_OCorrupt: SidMap.sidt -> signal_state -> prop
let pre_OCorrupt sid s = match get_session_entry s Oracle_OCorrupt sid with
  | None -> True
  | Some (R1_OCorrupt key sign_key _ _ cv_uid) ->
      exists uid. match_local_key (Helpers.to_identity_key (SIGNAL.Functions.fun_mkidkey key sign_key)) cv_uid uid s /\
        List.memP (FStarEvent (Event_Corrupt_User uid)) (State.events_of s)
  | Some _ -> True

val pre_Ogenprinc: cv_user_id_t -> signal_state -> prop
let pre_Ogenprinc var_uid_0 s = True

let add_event_lemma (s: signal_state) (e: signal_event) :
 Lemma (ensures (forall e'.
    (List.memP e' (State.events_of (State.state_add_event s e))) <==>
    (List.memP e' (State.events_of s) \/ e' == e)))
       [SMTPat (State.state_add_event s e)]
  = Classical.forall_intro (Classical.move_requires (List.append_memP (State.events_of s) [e]))

let add_cv_event (s: signal_state) (e: SIGNAL.Events.cv_event) :
  Lemma (requires inv s /\ not (Event_SimplSend? e) /\ not (Event_Corrupt? e) /\ not (Event_Honest? e))
        (ensures inv (state_add_event s (CVEvent e)) /\ local_rel s (state_add_event s (CVEvent e)))
  = Classical.forall_intro (Classical.move_requires (List.append_memP (State.events_of s) [CVEvent e]))
