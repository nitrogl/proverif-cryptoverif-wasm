(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module SIGNAL.Types

open Spec.Chacha20Poly1305
open Spec.Curve25519

open Lib.IntTypes
open Lib.Sequence
open Lib.ByteSequence
open Constants

let delta = 0x14def9dea2f79cd65812631a5cf5d3ed
let primeq = pow2 252 + delta
let primeq' = pow2 253 - 9 - op_Multiply 2 delta
let modulo = op_Multiply 8 (op_Multiply primeq primeq')
let max = pow2 512

let ith_bit (k:lbytes 64) (i:nat{i < 512}) : uint64 =
  let q = i / 8 in let r = size (i % 8) in
  to_u64 ((k.[q] >>. r) &. u8 1)

let gen_ladder_step (k:lbytes 64) (q:proj_point) (i:nat{i < 512}) (nq, nqp1, swap) =
  let bit = ith_bit k (511-i) in
  let sw = swap ^. bit in
  let nq, nqp1 = cswap2 sw nq nqp1 in
  let nq, nqp1 = add_and_double q nq nqp1 in
  (nq, nqp1, bit)

let gen_montgomery_ladder (init:elem) (k:lbytes 64) : Tot proj_point =
  let q = (init, one) in
  let nq = (one, zero) in
  let nqp1 = (init, one) in
  let swap = u64 0 in
  // all bits depend on k
  let nq,nqp1,swap = Lib.LoopCombinators.repeati 512 (gen_ladder_step k q) (nq, nqp1, swap) in
  let nq,nqp1 = cswap2 swap nq nqp1 in
  nq

let gen_scalar_mult (k: int) (u:elem) : Tot elem =
  let k = k % modulo in
  assert_norm (modulo < max);
  let k = nat_to_bytes_le #SEC 64 k in
  let x, z = gen_montgomery_ladder u k in
  x /% z

let ty_Zth = x: int { x % 8 = 0 /\ x % primeq <> 0 /\ x % primeq' <> 0 }

let t_data = aad: bytes{Seq.length aad <= maxint U64}
let t_cipher = (bbytes max_ciphertext_size) * (lbytes size_tag)

let t_message = bbytes Constants.max_ciphertext_size

let ty_idkey = MyTypes.identity_key_t

let cv_user_id_t = 
  if Constants.uid_in_ad then
    MyTypes.user_id_t
  else
    unit

let equal_t_message: t_message -> t_message -> bool = CVTypes.eq_bytes

let equal_cv_user_id_t : cv_user_id_t -> cv_user_id_t -> bool = (=)
