(*************************************************************
 *                                                           *
 *       Sesame case study                                   *
 *                                                           *
 *       Bruno Blanchet, Aymeric Fromherz, Charlie Jacomme,  *
 *       and Emmanuel Mera                                   *
 *                                                           *
 *       Copyright INRIA                                     *
 *	 2025-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Emmanuel Mera, emmanuel.mera@live.fr

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
module SIGNAL.Functions

open CVTypes
friend SIGNAL.Types

open Lib.Sequence
open Lib.IntTypes
open Lib.ByteSequence
open Lib.NatMod
open Spec.Curve25519
open Spec.Chacha20Poly1305

let bottom: (option bytes) = None

let n_start: (lbytes 12) = create 12 (zeros U8 SEC)

#push-options "--z3rlimit 40"

let fun_convert_aux (k: uint8) : Lemma (v (k &. (u8 248)) % 8 == 0) =
  let open FStar.UInt in
  logand_spec k (u8 248);
  assert_norm (nth #8 248 5 == false);
  assert_norm (nth #8 248 6 == false);
  assert_norm (nth #8 248 7 == false)

let logor_bounds (x: FStar.UInt.uint_t 8) : Lemma
   (requires x < 128)
   (ensures FStar.UInt.logor #8 x 64 >= 64 /\ FStar.UInt.logor #8 x 64 < 128) =
   let open FStar.BV in
   let open FStar.UInt in
   let r : bv_t 8 = bvor (int2bv #8 x) (int2bv #8 64) in
   int2bv_logor #8 #x #64 #r ();
   inverse_num_lemma #8 (logor #8 x 64)

let fun_convert_aux2 (k: uint8) : Lemma (pow2 6 <= v ((k &. (u8 127)) |. u8 64) /\ v ((k &. (u8 127)) |. u8 64) < pow2 7) =
  let k' = k &. u8 127 in
  logand_le k (u8 127);
  logor_spec k' (u8 64);
  logor_bounds (v k')

let fun_convert (x: scalar): ty_Zth =
    let open FStar.Mul in
    let x1 = decodeScalar x in
    let x2 = nat_from_bytes_le x1 in
    // Start proof
    let x1_start = slice x1 0 1 in
    let x1_end = slice x1 1 32 in
    nat_from_intseq_le_slice_lemma x1 1;
    nat_from_intseq_le_lemma0 x1_start;
    assert (x2 == v x1_start.[0] + pow2 (1 * 8) * nat_from_intseq_le x1_end);
    assert (x2 == v x1_start.[0] + pow2 8 * nat_from_intseq_le x1_end);
    let x2_start = v x1_start.[0] in
    let x2_end = pow2 8 * nat_from_intseq_le x1_end in
    fun_convert_aux x.[0];
    assert (x2_end % 8 == 0);
    assert (x2_start % 8 == 0);
    assert (x2 % 8 = 0);

    let x3 = x2 / 8 in
    assert (x2 == 8 * x3);

    let aux () : Lemma (pow2 251 <= x3 /\ x3 < pow2 252) =
      nat_from_intseq_le_slice_lemma x1 31;
      nat_from_intseq_le_lemma0 (slice x1 31 32);
      fun_convert_aux2 x.[31]
    in
    aux();
    assert_norm (pow2 252 < primeq);
    assert_norm (pow2 252 < primeq');
    FStar.Math.Lemmas.small_mod x3 primeq;
    FStar.Math.Lemmas.small_mod x3 primeq';
    x2

#pop-options

let checksign (msg: lbytes 32) (key: lbytes 32) (sig: lbytes 64): bool =
    Spec.Ed25519.verify key msg sig

let enc (msg: t_message) (ad: t_data) (key: lbytes 32) (nonce: lbytes 12): t_cipher =
    let res = Spec.Chacha20Poly1305.aead_encrypt key nonce msg ad in
    (Seq.slice res 0 (Seq.length msg),
        Seq.slice res (Seq.length msg) (Seq.length msg + Spec.Chacha20Poly1305.size_tag))

let dec (c: t_cipher) (ad: t_data) (key: lbytes 32) (n: lbytes 12): option bytes =
    match Spec.Chacha20Poly1305.aead_decrypt key n c._1 c._2 ad with
    | None -> None
    | Some v -> Some (to_seq v)

let injbot (b: t_message): (option bytes) = Some b

let inv_injbot (b: option bytes): option t_message =
    match b with
    | None -> None
    | Some v -> if Seq.length v <= Constants.max_ciphertext_size then Some v else None

let concat_ad (a: lbytes 32) (b: lbytes 32) (c: lbytes 32) (d: lbytes 32) (e: lbytes 32) (f: cv_user_id_t) (g: cv_user_id_t): t_data =
    if Constants.uid_in_ad then
    begin
      MyTypes.size_user_id_lemma f;
      MyTypes.size_user_id_lemma g;
      let fx: lbytes 8 = MyTypes.serializer_user_id.serialize f in
      let gx: lbytes 8 = MyTypes.serializer_user_id.serialize g in
      a @| b @| c @| d @| e @| fx @| gx
    end
    else
      a @| b @| c @| d @| e

let pair (h1: lbytes 32) (h2: lbytes 32): (lbytes 64) =
    h1 @| h2

let pair_inv (s: lbytes 64): (lbytes 32) * (lbytes 32) =
    (Seq.slice s 0 32, Seq.slice s 32 64)

let is_canonical x =
  let xnat = nat_from_bytes_le x in
  if xnat < prime then
    gen_scalar_mult primeq xnat = 0
  else
    false

let sign (msg: lbytes 32) (key: lbytes 32): (lbytes 64) =
    Spec.Ed25519.sign key msg

let fun_mkidkey x y = MyTypes.mk_identity_key x y

let pkgen (a: lbytes 32): (lbytes 32) = Spec.Ed25519.secret_to_public a

let skgen (a: lbytes 32): (lbytes 32) = a

let g: (lbytes 32) = map secret basepoint_lseq

let exp (base: lbytes 32) (exp: lbytes 32): (lbytes 32) = scalarmult exp base

let label_st = (s: string { Spec.Agile.HKDF.expand_info_length_pred Spec.Hash.Definitions.SHA2_256 (String.length s) })

let label_t = (l: bytes { Spec.Agile.HKDF.expand_info_length_pred Spec.Hash.Definitions.SHA2_256 (Seq.length l) })

let byte_of_char c = mk_int #U8 #SEC (FStar.UInt8.v (FStar.Int.Cast.uint32_to_uint8 (FStar.Char.u32_of_char c)))

val label_of_string : label_st -> label_t
let label_of_string s =
  let l = List.Tot.map byte_of_char (FStar.String.list_of_string s) in
  Seq.seq_of_list l

let (label_s: label_st) =
  let s = "WhisperText_X25519_SHA-256" in
  assert_norm(Spec.Agile.HKDF.expand_info_length_pred Spec.Hash.Definitions.SHA2_256 (String.length s));
  s

let (label: label_t) = label_of_string label_s

(* For simplicity, I just compute HKDF of h1 || h2 || h3 || h4.
   If we wanted to be closer to Signal, we should compute first
   HKDF of h1 || h2 || h3, then add h4 (first rachet key) in a second
   HKDF *)
let h4 (_: unit) (h1: lbytes 32) (h2: lbytes 32) (h3: lbytes 32) (h4: lbytes 32): (lbytes 64) =
    let prk = Spec.Agile.HKDF.extract Spec.Hash.Definitions.SHA2_256
      (Seq.create 32 ((mk_int 0) <: uint_t U8 SEC)) (h1 @| h2 @| h3 @| h4)
    in
    Spec.Agile.HKDF.expand Spec.Hash.Definitions.SHA2_256 prk label 64

(* For simplicity, I just compute HKDF of h1 || h2 || h3 || h4.
   If we wanted to be closer to Signal, we should compute first
   HKDF of h1 || h2 || h3, then add h4 (first rachet key) in a second
   HKDF *)
let h5 (_: unit) (h1: lbytes 32) (h2: lbytes 32) (h3: lbytes 32) (h4: lbytes 32) (h5: lbytes 32): (lbytes 64) =
    let prk = Spec.Agile.HKDF.extract Spec.Hash.Definitions.SHA2_256
      (Seq.create 32 ((mk_int 0) <: uint_t U8 SEC)) (h1 @| h2 @| h3 @| h4 @| h5)
    in
    Spec.Agile.HKDF.expand Spec.Hash.Definitions.SHA2_256 prk label 64

