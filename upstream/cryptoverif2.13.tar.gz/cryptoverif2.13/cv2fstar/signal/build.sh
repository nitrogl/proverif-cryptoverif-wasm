#!/bin/sh
set -e

../../cryptoverif -impl FStar -o src signal.ocv
make
# We just check that compilation works, because the programs are interactive
echo CORRECT

