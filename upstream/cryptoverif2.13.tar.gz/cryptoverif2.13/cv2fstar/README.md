# cv2fstar

## Directory Overview

* `cv2fstar`: F\* framework for cv2fstar
* `signal`: a case study of a simplified version of Signal with its Sesame session management
  in cv2fstar

## Prerequisites for running the parts involving CryptoVerif

The following environment variable is recommended:

* `CRYPTOVERIFDIR` set to a directory containing a `cryptoverif` binary,
  ideally the `CryptoVerif` directory in this repository.


## Prerequisites for running the parts involving F\*

You need to be under Linux. If you run Windows, please
install WSL (Windows Subsystem for Linux, see
https://learn.microsoft.com/en-us/windows/wsl/install)
and install CryptoVerif there.
You need to have the F\* language (https://fstar-lang.org/) and the
HACL\* cryptographic library (https://github.com/hacl-star/hacl-star)
installed.
You need to use a recent version of OCaml (>= 4.08).
You first need to have opam installed (https://opam.ocaml.org/).
Then you can install F\* and HACL\* by running
```
  git clone https://github.com/project-everest/everest.git
  cd everest
  ./everest check
  # The command above checks that the environment is ok.
  # Accept installing missing opam packages if it asks for it
  # and/or follow the instructions it gives for installing
  # missing packages and rerun until it succeeds.
  ./everest FStar pull
  ./everest karamel pull
  ./everest hacl-star pull
  ./everest FStar karamel hacl-star make -j <number of threads>
  # Some proofs in HACL* are fragile. You may need to rerun
  # the command above until it succeeds. If you get an error
  # message about the .NET framework, install the version of
  # .NET that it requires before rerunning.
```
You need the following environment variables:

* `CV2FSTAR_HOME` set to the absolute path of the directory `cv2fstar`
* And all environment variables needed for an F\* and HACL\* setup.

Suggestions: Use something like [direnv](https://direnv.net/) to make
that easier on a per-project basis. Example `.envrc` file for this
project:

```
export CRYPTOVERIFDIR=~/workspace/cryptoverif
export EVEREST_HOME=~/workspace/everest

export CV2FSTAR_HOME=$CRYPTOVERIFDIR/cv2fstar/cv2fstar

export EVEREST_ENV_DEST_FILE=$EVEREST_HOME/.envrc

export FSTAR_HOME=$EVEREST_HOME/FStar
export FSTAR=${FSTAR_HOME}/bin/fstar.exe
export KRML_HOME=$EVEREST_HOME/karamel
export HACL_HOME=$EVEREST_HOME/hacl-star
export VALE_HOME=$EVEREST_HOME/vale

if [ -d $EVEREST_HOME/z3-versions ]
then
    export Z3_HOME=$EVEREST_HOME/z3-versions
else
    export Z3_HOME=$EVEREST_HOME/z3/bin
fi

if [ -d $EVEREST_HOME/MLCrypto ]
then
    export MLCRYPTO_HOME=$EVEREST_HOME/MLCrypto
    export OPENSSL_HOME=$EVEREST_HOME/MLCrypto/openssl
    export LD_LIBRARY_PATH=$EVEREST_HOME/MLCrypto/openssl
fi

export PATH=$Z3_HOME:$FSTAR_HOME/bin:$KRML_HOME:$PATH

if [ -d $FSTAR_HOME/stage2/out/lib ]
then
    export OCAMLPATH=$FSTAR_HOME/stage2/out/lib:$OCAMLPATH
fi

export EVEREST_SCONS_CACHE_DIR=/tmp/everest
```

Warning: the value of `LD_LIBRARY_PATH` set above may lead to linking
errors in programs other than HACL*/cv2fstar that use the openssl library. 
Unset it to run such programs.

## Use cv2fstar with an example

* in `cv2fstar`, run `make`. This produces a library file.
* go to subdirectory `signal` and follow the instructions in README.md there.
