(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Types

(* 0. Operations on monomials *)

(* [same_monomial m1 m2] returns true when [m1] and [m2]
   are equal monomials. *)
val same_monomial : monomial -> monomial -> bool
    
(* [build_monomial l] returns a monomial representing the
   product of the probabilities in [l]. [l] must contain
   only basic probabilities, considered as variables of
   polynomials. *)
val build_monomial : probaf list -> monomial
  
(* 1. Operations on polynoms *)

val zero : polynom

(* [sum p1 p2] is the polynom [p1 + p2], where [p1] and [p2] are polynoms *)
val sum : polynom -> polynom -> polynom

(* [max p1 p2] is a polynom upper bound of the maximum of two polynoms 
   [p1] and [p2], assuming all variables are positive or zero *)
val max : polynom -> polynom -> polynom

(* [sub p1 p2] is the polynom [p1 - p2], where [p1] and [p2] are polynoms *)
val sub : polynom -> polynom -> polynom

(* [product p1 p2] is the polynom [p1 * p2], where [p1] and [p2] are polynoms *)
val product : polynom -> polynom -> polynom

(* [power_to_polynom_map f x n] is the polynom [f (x^n)] where [x] is
   a probability formula, and [f] maps probability formulas to
   polynoms and maps product, division, and power to product,
   division, and power respectively. *)
val power_to_polynom_map : (probaf -> polynom) -> probaf -> int -> polynom

(* Tests. They answer true only when the result is true.
   In case the result is not know for sure, they answer false. *)
val is_constant : polynom -> bool
val is_zero : polynom -> bool
val is_positive : polynom -> bool
val is_nonnegative : polynom -> bool
    
(* 2. Basic operations on probabilities, with simple simplifications *) 

val p_div : probaf * probaf -> probaf
val p_mul : probaf * probaf -> probaf
val p_prod : probaf list -> probaf
val p_add : probaf * probaf -> probaf
val p_sum : probaf list -> probaf

(* [minmax_accu] represents the maximum or minimum of some probabilities 
   [empty_minmax_accu] is the maximum or minimum of no probability at all

   [add_max accu_ref p] modifies [accu_ref] into [max (!accu_ref) p]
   [p_max accu] converts [accu] into a probability, for computing the maximum

   [add_min] and [p_min] are similar for the minimum. *)
type minmax_accu
val empty_minmax_accu : minmax_accu
val add_max : minmax_accu ref -> probaf -> unit
val p_max : minmax_accu -> probaf
val add_min : minmax_accu ref -> probaf -> unit
val p_min : minmax_accu -> probaf
    
(* 3. Conversion probaf/polynom *)

val probaf_to_polynom : probaf -> polynom
val polynom_to_probaf : polynom -> probaf 

(* [proba_from_set p] converts the probability [p] represented as
a [setf list] into a probability represented as a [probaf].
[p] must not contain [SetEvent]. *)
val proba_from_set : setf list -> probaf

(* [simplify_proba p] simplifies the probability [p],
   using polynoms as intermediate steps *)
val simplify_proba : probaf -> probaf
