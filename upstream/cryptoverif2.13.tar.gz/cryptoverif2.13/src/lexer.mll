(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
{
open Parsing_helper
open Parser
open Types
  
let create_hashtable size init =
  let tbl = Hashtbl.create size in
  List.iter (fun (key,data) -> Hashtbl.add tbl key data) init;
  tbl

let comment_depth = ref 0
let comment_extent_list = ref []

let in_proof = ref false
    
let common_keywords =
[ "new", NEW;
  "in", IN;
  "if", IF;
  "then", THEN;
  "else", ELSE;
  "find", FIND;
  "orfind", ORFIND;
  "suchthat", SUCHTHAT;
  "fun", FUN;
  "alias", ALIAS;
  "param", PARAM;
  "forall", FORALL;
  "exists", EXISTS;
  "equation", EQUATION;
  "builtin", BUILTIN;
  "proba", PROBA;
  "type", TYPE;
  "equiv", EQUIV;
  "diff", DIFF_INDIST;
  "process", PROCESS;
  "let", LET;
  "query", QUERY;
  "restriction", RESTRICTION;
  "secret", SECRET;
  "public_vars", PUBLICVARS;
  "const", CONST;
  "set", SET;
  "defined", DEFINED;
  "collision", COLLISION;
  "event", EVENT;
  "time", TIME;
  "yield", YIELD;
  "event_abort", EVENT_ABORT;
  "maxlength", MAXLENGTH;
  "length", LENGTH;
  "max", MAX;
  "min", MIN;
  "eps_find", EPSFIND;
  "eps_rand", EPSRAND;
  "Pcoll1rand", PCOLL1RAND;
  "Pcoll2rand", PCOLL2RAND;
  "number", NUMBER;
  "foreach", FOREACH;
  "do", DO;
  "return", RETURN;
  "def", DEFINE;
  "expand", EXPAND;
  "proof", PROOF;
  "implementation", IMPLEMENTATION;
  "get", GET;
  "insert", INSERT;
  "table", TABLE;
  "newtable", NEWTABLE;
  "letfun", LETFUN;
  "letproba", LETPROBA;
  "equivalence", EQUIVALENCE;
  "query_equiv", QUERY_EQUIV;
  "special", SPECIAL;
  "inf", FLOAT infinity;
  "newOracle", NEWORACLE
]  
    
let keyword_table_channel =
  create_hashtable 11
    ([ "out", OUT;
       "channel", CHANNEL ]
     @ common_keywords)

let keyword_table_oracle = 
  create_hashtable 11
    (("run", RUN)::common_keywords)

let keyword_table_proof =
  create_hashtable 11
    [ "set", SET;
      "insert", INSERT;
      "at", AT;
      "at_nth", AT_NTH;
      "before", BEFORE;
      "before_nth", BEFORE_NTH;
      "after", AFTER;
      "after_nth", AFTER_NTH;
      "terms", TERMS;
      "variables", VARIABLES;
      "remove_assign", REMOVE_ASSIGN;
      "use_variable", USE_VARIABLE;
      "useless", USELESS;
      "findcond", FINDCOND;
      "all", ALL;
      "binder", BINDER;
      "move", MOVE;
      "up", UP;
      "to", TO;
      "noarrayref", NOARRAYREF;
      "random", RANDOM;
      "random_noarrayref", RANDOM_NOARRAYREF;
      "assign", ASSIGN;
      "array", ARRAY;
      "simplify", SIMPLIFY;
      "coll_elim", COLL_ELIM;
      "insert_event", INSERT_EVENT;
      "replace", REPLACE;
      "merge_arrays", MERGE_ARRAYS;
      "merge_branches", MERGE_BRANCHES;
      "SArename", SARENAME;
      "global_dep_anal", GLOBAL_DEP_ANAL;
      "expand", EXPAND;
      "all_simplify", ALL_SIMPLIFY;
      "crypto", CRYPTO;
      "start_from_other_end", START_FROM_OTHER_END;
      "quit", QUIT;
      "success", SUCCESS;
      "show_game", SHOW_GAME;
      "occ", OCC;
      "show_state", SHOW_STATE;
      "show_facts", SHOW_FACTS;
      "show_equiv", SHOW_EQUIV;
      "show_commands", SHOW_COMMANDS;
      "out_game", OUT_GAME;
      "out_state", OUT_STATE;
      "out_facts", OUT_FACTS;
      "out_equiv", OUT_EQUIV;
      "out_commands", OUT_COMMANDS;
      "auto", AUTO;
      "allowed_collisions", ALLOWED_COLLISIONS;
      "undo", UNDO;
      "restart", RESTART;
      "forget_old_games", FORGET_OLD_GAMES;
      "help", HELP;
      "interactive", INTERACTIVE;
      "types", TYPES;
      "focus", FOCUS;
      "tag", TAG;
      "special", SPECIAL;
      "assume", ASSUME;
      "guess", GUESS;
      "guess_branch", GUESS_BRANCH;
      "no_test", NO_TEST;
      "above", ABOVE;
      "move_if_fun", MOVE_IF;
      "level", LEVEL;
      "to_term", TO_TERM;
      "use", USE;
      "revert", REVERT;
      "reorder_find", REORDER_FIND;
      "branches", BRANCHES;
      "indices", INDICES;
      "branch", BRANCH;
      "into", INTO;
      "else", ELSE;
      "in", IN
    ]
    
}

rule token = parse
  "\010" | "\013" | "\013\010"
     { Lexing.new_line lexbuf; token lexbuf }
| [ ' ' '\009' '\012' ] +
     { token lexbuf }
| [ 'a'-'z' 'A'-'Z' ] (( [ 'a'-'z' 'A'-'Z' '_' '\192'-'\214' '\216'-'\246' '\248'-'\255' '\'' '0'-'9' ] )*)
    { let s = Lexing.lexeme lexbuf in
         try
	   let keyword = Hashtbl.find
	       (if !in_proof then
		 keyword_table_proof
	       else
		 match !Settings.front_end with
	       Settings.Channels -> keyword_table_channel
	     | Settings.Oracles -> keyword_table_oracle) s
	   in
	   if keyword == PROOF then
	     in_proof := true;
	   keyword
         with Not_found ->
           IDENT (s, extent lexbuf)
     }
| '\"'    
    { 
      clear_buffer ();
      set_start_pos lexbuf;
      string lexbuf;
      STRING (get_string ()) } 

| ([ '0'-'9' ]) +
    { 
      try 
        INT (int_of_string(Lexing.lexeme lexbuf))
      with Failure _ ->
	raise (Error("Incorrect integer", extent lexbuf))
    }
| [ '0'-'9' ]+ ((('.' [ '0'-'9' ]*)? ['e' 'E'] ['+' '-']? [ '0'-'9' ]+) |  '.' [ '0'-'9' ]+)
    { FLOAT (float_of_string(Lexing.lexeme lexbuf)) }
| ([ '0'-'9' ])+ "-proj-" [ 'a'-'z' 'A'-'Z' ] (( [ 'a'-'z' 'A'-'Z' '_' '\192'-'\214' '\216'-'\246' '\248'-'\255' '\'' '0'-'9' ] )*)
    {
      PROJECTION(Lexing.lexeme lexbuf, extent lexbuf)
    }
| "(*" {
      comment_depth := 1;
      comment_extent_list := (extent lexbuf) :: !comment_extent_list;
         comment lexbuf;
         token lexbuf
}
| '_' { UNDERSCORE }
| ',' { COMMA }
| '(' { LPAREN }
| ')' { RPAREN }
| '[' { LBRACKET }
| ']' { RBRACKET }
| '{' { LBRACE }
| '}' { in_proof := false; RBRACE }
| '|' { BAR }
| ';' { SEMI }
| ':' { COLON }
| '!' { REPL }
| "<=" { LEQ }
| ">=" { GEQ }
| '=' { EQUAL }
| "<>" { DIFF }
| "&&" { AND }
| "||" { OR }
| '.' { DOT }
| "<=(" { EQUIVLEFT }
| ")=>" { EQUIVRIGHT } 
| "==>" { IMPLIES }
| '+' { ADD }
| '-' { SUB }
| '*' { MUL }
| '/' { DIV }
| '^' { POWER }
| '<' { LESS }
| '>' { GREATER }
| "->" { MAPSTO }
| ":=" { DEF }
| "<-" { LEFTARROW }
| "<-R" { RANDOM }
| '#' { COUNT }
| '?' { HELP }
| "inj-event" { INJEVENT }
| "independent-of" { INDEPOF }
| "optim-if" { OPTIMIF }
| "is-cst" { ISCST }
| eof { EOF }	
| _ { raise (Error("Illegal character", extent lexbuf)) }

and comment = parse
| "(*" {
    incr comment_depth;
    comment_extent_list := (extent lexbuf) :: !comment_extent_list;
    comment lexbuf }
| "*)"
    {
      decr comment_depth;
      comment_extent_list := List.tl !comment_extent_list;
      if !comment_depth = 0 then () else comment lexbuf
    }
| "\010" | "\013" | "\013\010"
     { Lexing.new_line lexbuf; comment lexbuf }
| eof { raise (Error("Unterminated comment", List.hd !comment_extent_list)) }
| _ { comment lexbuf }

and string = parse 
| '\"' { set_end_pos lexbuf }
| '\\' ['\\' '\'' '"' 'n' 't' 'b' 'r']
      { 
        add_char (char_backslash (Lexing.lexeme_char lexbuf 1));
        string lexbuf
      }
| '\\' _
      { raise (Error("Illegal escape", extent lexbuf)) }
| "\010" | "\013" 
     { Lexing.new_line lexbuf; 
       add_char (Lexing.lexeme_char lexbuf 0);
       string lexbuf }
| "\013\010"
     { Lexing.new_line lexbuf;
       add_char (Lexing.lexeme_char lexbuf 0);
       add_char (Lexing.lexeme_char lexbuf 1);
       string lexbuf  }
| eof 
      { raise (Error("Unterminated string", extent lexbuf)) }
| _ 
      { 
        add_char (Lexing.lexeme_char lexbuf 0);
        string lexbuf 
      }

and collision_matrix = parse
  "\010" | "\013" | "\013\010"
     { Lexing.new_line lexbuf; collision_matrix lexbuf }
| [ ' ' '\009' '\012' ] +
     { collision_matrix lexbuf }
| (( [ 'a'-'z' 'A'-'Z' '_' '\192'-'\214' '\216'-'\246' '\248'-'\255' '\'' '0'-'9' ] )*)
     { IDENT(Lexing.lexeme lexbuf, extent lexbuf) }
| ',' { COMMA }
| ';' { SEMI }
| "(*" {
         comment lexbuf;
         collision_matrix lexbuf
       }
| eof { EOF }	
| _ { raise (Error("Illegal character", extent lexbuf)) }
