(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Types

(* [map_max f l], where [f] is a function from list elements to integers,
   returns the maximum of [f a] for elements [a] in [l] *)
val map_max : ('a -> int) -> 'a list -> int
  
val empty_comp_process : inputprocess -> unit
(* [build_def_process] must be called before [build_compatible_defs] *)
val build_compatible_defs : inputprocess -> unit

(* [get_facts pp] returns the fact_info at program point [pp] *)
val get_facts : program_point -> fact_info
(* [get_start_block_node n] returns the program point corresponding
   to the input that starts the input...output block of code that
   contains node [n]. *)
val get_start_block_pp : program_point -> program_point
val get_start_block_node : def_node -> program_point

(* [is_compatible_pp pp pp'] is true when [pp] and [pp'] can both be executed
   even with the same indices *)
val is_compatible_pp : program_point -> program_point -> bool 
    
(* [incompatible_suffix_length_var_var b b'] returns a length [l] such that if
   [b[args]] and [b'[args']] are both defined, then the suffixes of
   length [l] of [args] and [args'] must be different.
   Raises [Not_found] when [b[args]] and [b'[args']] can be defined 
   for any [args,args']. *)
val incompatible_suffix_length_var_var : binder -> binder -> int
(* [is_compatible (b,args) (b',args')] returns true when
   [b[args]] and [b'[args']] may both be defined *)
val is_compatible : binderref -> binderref -> bool
(* [is_compatible_history (n,args) history] returns true when 
   the information in [history] is compatible with the execution
   of node [n] with indices [args] before that history. *)
val is_compatible_history : program_point_args -> known_history -> bool
(* [facts_compatible_history fact_accu (nl,args) history] returns
   [fact_accu] with additional facts inferred from the execution of a
   node in [nl] with indices [args] before the history [history]. *)
val facts_compatible_history : term list -> program_points_args -> known_history -> term list 
(* [both_def_add_fact fact_accu (b,args) (b',args')] returns [fact_accu] 
   after adding a fact that always holds when
   [b[args]] and [b'[args']] are both defined. *)
val both_def_add_fact : term list -> binderref -> binderref -> term list
(* [both_ppl_facts old_ppl ppl] returns facts
   inferred from the knowledge that the program points in [ppl] and
   [old_ppl] are both executed. It considers pairs 
   of variables in [ppl] and of one variable in [ppl]
   and one in [old_ppl], but does not consider pairs of variables
   in [old_ppl] as those should have been taken into account before.
   Uses the field "incompatible" set by Terms.build_compatible_defs
 *)
val both_ppl_facts : term list -> program_points_args list -> program_points_args list -> term list
(* [ppl_before_pp_facts fact_accu pp args def_list] returns [fact_accu] 
   after adding facts inferred from the knowledge that the variables in [def_list]
   are defined before the execution of program point [pp] with indices [args].
   (Typically, that some indices in [args] are different
   from some indices of variables in [def_list].) *)
val ppl_before_pp_facts : term list -> program_point_args -> program_points_args list -> term list
(* [both_pp (pp, args) (pp', args')] returns true when
   program point [pp] with indices [args] and 
   program point [pp'] with indices [args'] can both be executed. *)
val both_pp :  program_point_args -> program_point_args -> bool
(* [both_pp_add_fact fact_accu (ppa, lidxa) (ppb, lidxb)] returns [fact_accu] 
   after adding a fact inferred from the execution of both
   program point [ppa] with indices [lidxa] and 
   program point [ppb] with indices [lidxb], if any. *)
val both_pp_add_fact : term list ->
  program_point_args -> program_point_args -> term list
(* [both_pp_ppl (pp, args) (ppl', args')] returns true when
   program point [pp] with indices [args] and 
   a program point in [ppl'] with indices [args'] can both be executed. *)
val both_pp_ppl : program_point_args -> program_points_args -> bool
(* [both_pp_ppl_add_fact fact_accu (ppa, lidxa) (pplb, lidxb)] returns [fact_accu] 
   after adding a fact inferred from the execution of both
   program point [ppa] with indices [lidxa] and 
   a program point in [pplb] with indices [lidxb], if any. *)
val both_pp_ppl_add_fact : term list ->
  program_point_args -> program_points_args -> term list
(* [both_ppl_ppl_add_fact fact_accu (ppla, lidxa) (pplb, lidxb)] returns [fact_accu] 
   after adding a fact inferred from the execution of both
   a program point in [ppla] with indices [lidxa] and 
   a program point in [pplb] with indices [lidxb], if any. *)
val both_ppl_ppl_add_fact : term list ->
  program_points_args -> program_points_args -> term list
val both_ppl_ppl_add_facts : term list ->
  program_points_args list -> program_points_args list -> term list
(* [may_def_before (b,args) (b',args')] returns true when
   [b[args]] may be defined before or at the same time as [b'[args']] *)
val may_def_before : binderref -> binderref -> bool
(* [may_def_before_ppl (b,args) (ppl,args')] returns true when
   [b[args]] may be defined before [ppl[args']]
   ("before" includes the case in which [b[args]] is defined
   immediately before [ppl[args']], that is, the program point
   at which the definition is done [n.definition_success] is in [ppl].) *)
val may_def_before_ppl : binderref -> program_points_args -> bool
    
(* [may_be_before_same_block n n'] is true when the variable defined 
   at [n] may be defined before the one defined at [n'] and within the 
   same input...output block. *)
val may_be_before_same_block : def_node -> def_node -> bool
(* [may_be_before_same_block_pp pp pp'] is true when the program point [pp]
   may be before [pp'] and in the same input...output block.
   Note that the time at which a program point is executed corresponds
   to the *beginning* of the execution of that program point. *)
val may_be_before_same_block_pp : program_point -> program_point -> bool
    
(* [is_under pp pp'] returns true when the program point [pp]
   is syntactically under [pp']. *)   
val is_under : program_point -> program_point -> bool
(* [implies (ppl, args) (ppl', args')] returns true when the
   execution of a program point in [ppl] with indices [args]
   implies the execution of a program point in [ppl'] with
   indices [args'] (without taking into account defined conditions). *)
val implies_ppl : program_points_args -> program_points_args -> bool
