(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Ptree
open Types

let underscore_var_name = "ignored"
  
type frontend =
    Channels
  | Oracles

type impl_language = OCaml | FStar | Prove
(* Prove the protocol, do not generate an implementation *)

let easy_crypt_convert = ref None
let easy_crypt_remove_tables = ref false
    
let get_implementation = ref Prove
let out_dir = ref Filename.current_dir_name

let proof_output = ref ""

let equiv_output = ref ""
let command_output = ref ""
    
let front_end = ref Channels

let lib_name = ref []

(* When handling "query_equiv", [events_to_ignore_lhs] contains events 
   that occur in the RHS of the equivalence to prove. Their probability 
   is implicitly added to the probability of distinguishing the LHS
   from the RHS, without trying to prove that it is negligible. *)
let events_to_ignore_lhs = ref []

(* memory saving *)
let forget_old_games = ref false

(* debug settings *)
let debug_ghost = ref false
let debug_instruct = ref false
let debug_cryptotransf = ref 0
let debug_find_unique = ref false
let debug_simplify = ref false
let debug_elsefind_facts = ref false
let debug_simplif_add_facts = ref false
let debug_corresp = ref false
let debug_restriction = ref false
let debug_event_adv_loses = ref false

(* translation to F* *)
let fstar_debug = ref false
let fstar_concurrent = ref true
let fstar_minimal_functions = ref false
    
(* To parse games output by CryptoVerif, 
set this variable to true: such games may contain
"defined" conditions on variables that are never defined. *)
let allow_undefined_var = ref false
    
let proba_zero = ref false
    (* When true, prevents all eleiminations of collisions, so that
       computed equalities *always* hold (not up to negligible probability). *)

let use_oracle_count_in_result = ref true

let max_efl = ref 50
let max_depth_add_fact = ref 1000
let max_depth_is_indep_collect_args = ref 1
    
let max_depth_try_no_var_rec = ref 20
let max_replace_depth = ref 20

let max_fut_pps_length = ref 3
    
let elsefind_facts_in_replace = ref true
let elsefind_facts_in_success = ref true
let elsefind_facts_in_simplify = ref true
let elsefind_facts_in_success_simplify = ref true
let improved_fact_collection = ref false
let corresp_cases = ref true
let simplify_use_equalities_in_simplifying_facts = ref false
let re_reduce_root_sides = ref true
    
let diff_constants = ref true
let constants_not_tuple = ref true

let use_known_equalities_crypto = ref true
let priority_event_unchanged_rand = ref 5

let normalize_in_match_funapp = ref false

let expand_letxy = ref true

type diff_encoding =
  | FunWhenPossible
  | FunWhenSimple
  | AlwaysIf

let diff_encoding = ref FunWhenSimple

type success_simplify_pref_t =
  | SSPRemoveBranch
  | SSPEventAbort

let success_simplify_pref = ref SSPEventAbort
    
(* Bound the number of advice possibilities in cryptotransf.ml
   Having too many of them does not help because we will need to try
   all of them and it will take a lot of time. *)
let max_advice_possibilities_beginning = ref 50
let max_advice_possibilities_end = ref 10

let minimal_simplifications = ref true
let merge_branches = ref true
let merge_arrays = ref false
let unique_branch = ref true
let unique_branch_reorg = ref true
let infer_unique = ref false

let guess_remove_unique = ref false
    
let auto_sa_rename = ref true
let auto_remove_assign_find_cond = ref true
let auto_remove_if_find_cond = ref true
let auto_move = ref true
let auto_expand = ref true

let ignore_small_times = ref 3

let interactive_mode = ref false

let auto_advice = ref true
let no_advice_crypto = ref false
let no_advice_globaldepanal = ref false

let backtrack_on_crypto = ref false

let simplify_after_sarename = ref true

let max_iter_simplif = ref 2
let max_iter_removeuselessassign = ref 10

let detect_incompatible_defined_cond = ref true

let psize_NONINTERACTIVE = 80 (* Eg. an attacker can make at most 2^80 hash computations *)
let psize_PASSIVE = 30

let psize_DEFAULT = psize_PASSIVE

let psize_SMALL = 2
(* For active sessions, when the number of failed
    attempts is limited, e.g. max 4 attemtps then the
    card is blocked. *)

let tysize_LARGE = 160
let tysize_PASSWORD_min = 20
let tysize_PASSWORD_max = 40
let tysize_SMALL = 2

let trust_size_estimates = ref false

let tysize_MIN_Coll_Elim = ref tysize_PASSWORD_min
let tysize_MIN_Auto_Coll_Elim = ref 80
let tysize_MAX_Guess = ref 40
    
let max_exp = 1000000000
(* min_exp = -max_exp is needed for the code in proba.ml
   to evaluate orders of magnitude to be correct *)
let min_exp = -max_exp

(* Determines the probabilities that are considered small enough to 
   eliminate collisions. It consists of a list of probability descriptions
   of the form ([(psize1, n1); ...; (psizek,nk)], tsize) 
   which represent probabilities of the form
   constant * (parameter of size <= psize1)^n1 * ... * 
   (parameter of size <= psizek)^nk / (type of size >= tsize) 

   Also applies to collision statements; the probability
   of one collision must have size <= -tsize, and the number of 
   repetitions be less than constant * (parameter of size <= psize1)^n1 * ... * 
   (parameter of size <= psizek)^nk.

   The default value allows: anything/(a bit less than "large") and 
   small/password *) 
let allowed_collisions = ref [ ([max_int, max_int], tysize_LARGE-5); 
                               ([psize_SMALL, 1], tysize_PASSWORD_min) ]


let check_exp v ext =
  if v < 0 then
    raise (Parsing_helper.Error ("Bounds should be greater or equal to 0", ext));
  if v > max_exp then
    raise
      (Parsing_helper.Error
         ("Bounds should be at most " ^ string_of_int max_exp, ext))

let parse_type_size_pcoll (s, ext) =
  match s with
  | "large" -> Some (tysize_LARGE, max_exp), Some (tysize_LARGE, max_exp)
  | "password" -> Some (tysize_PASSWORD_min, tysize_PASSWORD_max), Some (tysize_PASSWORD_min, tysize_PASSWORD_max)
  | "small" -> Some (0, tysize_SMALL), None
  | s -> (* option size<n>, size<min>_<max>, or pcoll<n> *)
      try
	if (String.sub s 0 4) = "size" then
	  let s1 = String.sub s 4 (String.length s - 4) in
	  try
	    let pos_underscore = String.index s1 '_' in
	    let smin = String.sub s1 0 pos_underscore in
	    let smax = String.sub s1 (pos_underscore+1) (String.length s1-pos_underscore-1) in
	    let min = int_of_string smin in
	    let max = int_of_string smax in
	    if min > max then
	      raise (Parsing_helper.Error ("In option size<min>_<max>, <min> should be at most <max>", ext));
	    check_exp min ext;
	    check_exp max ext;
	    Some (min, max), None
	  with Not_found ->
	    let v = int_of_string s1 in
	    check_exp v ext;
	    Some (v, v), None
	else if (String.sub s 0 5) = "pcoll" then
	  let min = int_of_string (String.sub s 5 (String.length s - 5)) in
	  check_exp min ext;
	  None, Some (min, max_exp)
	else
	  raise Not_found
      with
      | (Parsing_helper.Error _) as x -> raise x
      | _ -> raise (Parsing_helper.Error ("Unknown type option " ^ s, ext))

let parse_pest (s, ext) =
  match s with
  | "large" -> tysize_LARGE
  | "password" -> tysize_PASSWORD_min
  | _ -> (* option pest<n> *)
      try
	if (String.sub s 0 4) <> "pest" then raise Not_found;
	let v = int_of_string (String.sub s 4 (String.length s - 4)) in
	check_exp v ext;
	v
      with
      | (Parsing_helper.Error _) as x -> raise x
      | _ -> raise (Parsing_helper.Error("Unknown probability estimate option "^s^" (allowed options are large, password, and pest<n>)", ext))
	  
let parse_psize (s, ext) =
  match s with
  | "noninteractive" -> psize_NONINTERACTIVE
  | "passive" -> psize_PASSIVE
  | "default" -> psize_DEFAULT
  | "small" -> psize_SMALL
  | _ -> (* option "size<n>" where <n> is an integer *)
      try
	if (String.sub s 0 4) <> "size" then raise Not_found;
	let v = int_of_string (String.sub s 4 (String.length s - 4)) in
	check_exp v ext;
	v	  
      with
      | (Parsing_helper.Error _) as x -> raise x
      | _ -> raise (Parsing_helper.Error("Unknown size option " ^ s^" (allowed options are noninteractive, passive, default, small, and size<n>)", ext))
	  
	  
let parse_bool v var =
  match v with
    S ("true",_) -> var := true
  | S ("false",_) -> var := false
  | _ -> raise Not_found
	  
let do_set p v =
  match (p,v) with
  | "diffEncoding", S ("alwaysIf",_) -> diff_encoding := AlwaysIf
  | "diffEncoding", S ("funWhenPossible",_) -> diff_encoding := FunWhenPossible
  | "diffEncoding", S ("funWhenSimple",_) -> diff_encoding := FunWhenSimple
  | "successSimplifyPrefers", S ("removeBranch", _) -> success_simplify_pref := SSPRemoveBranch
  | "successSimplifyPrefers", S ("eventAbort", _) -> success_simplify_pref := SSPEventAbort
  | "allowUndefinedVar", _ -> parse_bool v allow_undefined_var
  | "diffConstants", _ -> parse_bool v diff_constants 
  | "constantsNotTuple", _ -> parse_bool v constants_not_tuple 
  | "expandAssignXY", _ -> parse_bool v expand_letxy
  | "minimalSimplifications", _ -> parse_bool v minimal_simplifications 
  | "uniqueBranch", _ -> parse_bool v unique_branch
  | "uniqueBranchReorganize", _ -> parse_bool v unique_branch_reorg
  | "inferUnique", _ -> parse_bool v infer_unique
  | "guessRemoveUnique", _ -> parse_bool v guess_remove_unique
  | "autoMergeBranches", _ -> parse_bool v merge_branches
  | "autoMergeArrays", _ -> parse_bool v merge_arrays
  | "autoSARename", _ -> parse_bool v auto_sa_rename
  | "autoRemoveAssignFindCond", _ -> parse_bool v auto_remove_assign_find_cond
  | "autoRemoveIfFindCond", _ -> parse_bool v auto_remove_if_find_cond
  | "autoMove", _ -> parse_bool v auto_move
  | "autoExpand", _ -> parse_bool v auto_expand
  | "autoAdvice", _ -> parse_bool v auto_advice
  | "interactiveMode", _ -> parse_bool v interactive_mode
  | "noAdviceCrypto", _ -> parse_bool v no_advice_crypto
  | "noAdviceGlobalDepAnal", _ -> parse_bool v no_advice_globaldepanal
  | "backtrackOnCrypto", _ -> parse_bool v backtrack_on_crypto
  | "simplifyAfterSARename", _ -> parse_bool v simplify_after_sarename
  | "detectIncompatibleDefined", _ -> parse_bool v detect_incompatible_defined_cond
  | "ignoreSmallTimes", I n -> ignore_small_times := n
  | "maxElsefind", I n -> max_efl := n
  | "maxIterSimplif", I n -> max_iter_simplif := n
  | "maxIterRemoveUselessAssign", I n -> max_iter_removeuselessassign := n
  | "maxAdvicePossibilitiesBeginning", I n -> max_advice_possibilities_beginning := n
  | "maxAdvicePossibilitiesEnd", I n -> max_advice_possibilities_end := n
  | "useKnownEqualitiesInCryptoTransform", _ -> parse_bool v use_known_equalities_crypto
  | "priorityEventUnchangedRand", I n -> priority_event_unchanged_rand := n
  | "useKnownEqualitiesWithFunctionsInMatching", _ -> parse_bool v normalize_in_match_funapp
  | "minAutoCollElim", S s_ext -> 
      let r = parse_pest s_ext in
      if r <= 0 then raise Not_found;
      tysize_MIN_Auto_Coll_Elim := r
  | "maxGuess", S s_ext ->
      let r = parse_psize s_ext in
      tysize_MAX_Guess := r
  | "trustSizeEstimates", _ -> parse_bool v trust_size_estimates
  | "elsefindFactsInReplace", _ -> parse_bool v elsefind_facts_in_replace
  | "elsefindFactsInSuccess", _ -> parse_bool v elsefind_facts_in_success
  | "elsefindFactsInSimplify", _ -> parse_bool v elsefind_facts_in_simplify
  | "elsefindFactsInSuccessSimplify", _ -> parse_bool v elsefind_facts_in_success_simplify
  | "improvedFactCollection", _ -> parse_bool v improved_fact_collection
  | "useEqualitiesInSimplifyingFacts", _ -> parse_bool v simplify_use_equalities_in_simplifying_facts
  | "reReduceRootSides", _ -> parse_bool v re_reduce_root_sides
  | "maxReplaceDepth", I n -> max_replace_depth := n
  | "maxAddFactDepth", I n -> max_depth_add_fact := n
  | "maxIsIndepDepth", I n ->
      (* For uniformity with maxAddFactDepth, 0 means no limit *)
      max_depth_is_indep_collect_args := (if n = 0 then -1 else n)
  | "maxTryNoVarDepth", I n ->
      (* For uniformity with maxAddFactDepth, 0 means no limit *)
      max_depth_try_no_var_rec := (if n = 0 then -1 else n)
  | "maxFutureProgramPoints", I n ->
      (* 0 means no limit *)
      max_fut_pps_length := n
  | "casesInCorresp", _ -> parse_bool v corresp_cases

  | "debugInstruct", _ -> parse_bool v debug_instruct
  | "debugFindUnique", _ -> parse_bool v debug_find_unique
  | "debugCryptotransf", I n -> debug_cryptotransf := n
  | "debugElsefindFacts", _ -> parse_bool v debug_elsefind_facts
  | "debugSimplify", _ -> parse_bool v debug_simplify
  | "debugSimplifAddFacts", _ -> parse_bool v debug_simplif_add_facts
  | "debugCorresp", _ -> parse_bool v debug_corresp
  | "debugRestriction", _ -> parse_bool v debug_restriction
  | "debugAdvLoses", _ -> parse_bool v debug_event_adv_loses
  | "fstarDebug", _ -> parse_bool v fstar_debug
  | "fstarConcurrent", _ -> parse_bool v fstar_concurrent
  | "fstarMinimalFunctions", _ -> parse_bool v fstar_minimal_functions
  | "forgetOldGames", _ -> parse_bool v forget_old_games
  | _ -> raise Not_found

(* Type options *)

(* Types consisting of all bitstrings of the same length *)
let tyopt_FIXED = 2

(* Finite types *)
let tyopt_BOUNDED = 4

(* Types for which the standard distribution for generating
   random numbers is non-uniform *)
let tyopt_NONUNIFORM = 8

(* Types for which we can generate random numbers.
   Corresponds to one of the three options above *)
let tyopt_CHOOSABLE = tyopt_FIXED + tyopt_BOUNDED + tyopt_NONUNIFORM

(* Types that get erased when generating an implementation *)
let tyopt_GHOST = 16
    
(* Function options *)

let fopt_COMPOS = 1
let fopt_DECOMPOS = 2
let fopt_UNIFORM = 8
let fopt_AUTO_SWAP_IF = 16
let fopt_BIJECTIVE = 32
    
let tex_output = ref ""

(* Types and constants should be added to the initial environment,
as well as f_not *)
(* Types *)

let t_bitstring =
  {
    tname = "bitstring";
    tcat = BitString;
    toptions = 0;
    tsize = Some (max_exp, max_exp);
    tpcoll = None;
    timplsize = None;
    tpredicate = Some "always_true";
    timplname = Some "string";
    tserial = Some ("id", "id");
    tfstar_serial = Some "serializer_bytes";
    trandom = None;
    tequal = None;
  }

let t_bitstringbot =
  {
    tname = "bitstringbot";
    tcat = BitString;
    toptions = 0;
    tsize = Some (max_exp, max_exp);
    tpcoll = None;
    timplsize = None;
    tpredicate = Some "always_true";
    timplname = Some "string option";
    tserial = Some ("stringbot_to", "stringbot_from");
    tfstar_serial = Some "serializer_obytes";
    trandom = None;
    tequal = None;
  }

let t_bool =
  {
    tname = "bool";
    tcat = BitString;
    toptions = tyopt_FIXED + tyopt_BOUNDED;
    tsize = Some (1, 1);
    tpcoll = Some (1, 1);
    timplsize = Some 1;
    tpredicate = Some "always_true";
    timplname = Some "bool";
    tserial = Some ("bool_to", "bool_from");
    tfstar_serial = Some "serializer_bool";
    trandom = Some "rand_bool";
    tequal = Some "(=)";
  }

(* For precise computation of the runtime only*)
let t_unit =
  {
    tname = "unit";
    tcat = BitString;
    toptions = tyopt_BOUNDED;
    tsize = Some (0, 0);
    tpcoll = Some (0, 0);
    timplsize = None;
    tpredicate = None;
    timplname = None;
    tserial = None;
    tfstar_serial = None;
    trandom = None;
    tequal = None;
  }

(* For events in terms; they have a type compatible with any type*)
let t_any =
  {
    tname = "any";
    tcat = BitString;
    toptions = 0;
    tsize = None;
    tpcoll = None;
    timplsize = None;
    tpredicate = None;
    timplname = None;
    tserial = None;
    tfstar_serial = None;
    trandom = None;
    tequal = None;
  }

let p_empty_idx = { pname = "0"; psize = 0 }

let t_empty_idx =
  {
    tname = "empty-idx";
    tcat = Interv p_empty_idx;
    toptions = tyopt_BOUNDED;
    tsize = Some (0, 0);
    tpcoll = Some (0, 0);
    timplsize = None;
    tpredicate = None;
    timplname = None;
    tserial = None;
    tfstar_serial = None;
    trandom = None;
    tequal = None;
  }

let create_fun s ty ?(options=0) ?(eqth=NoEq) ?(impl=No_impl) ?(impl_inv=None) cat =
  { f_name = s;
    f_type = ty;
    f_cat = cat;
    f_options = options;
    f_aliases = [];
    f_statements = [];
    f_collisions = [];
    f_eq_theories = eqth;
    f_impl = impl;
    f_impl_inv = impl_inv;
    f_impl_ent = false;
    f_impl_needs_full_state = false;
    f_impl_diff_side = false }
    
(* Constants *)

let c_true = create_fun "true" ([],t_bool) ~impl:(Const "true") Std

let c_false = create_fun "false" ([],t_bool) ~impl:(Const "false") Std

(* Functions *)

let f_and = create_fun "&&" ([t_bool; t_bool], t_bool) ~impl:(Func "(&&)") And

let f_or = create_fun "||" ([t_bool; t_bool], t_bool) ~impl:(Func "(||)") Or

let _ =
  f_and.f_eq_theories <- AssocCommutN(f_and, c_true);
  f_or.f_eq_theories <- AssocCommutN(f_or, c_false)

module HashedCatType =
  struct
    type t = Types.funcats * Types.typet
    let equal (cat1, t1) (cat2, t2) = (cat1 == cat2) && (t1 == t2)
    (* The hash function must use only parts that are not modified,
       otherwise, we may have the same element with several different hashes *)
    let hash (cat, t) = Hashtbl.hash (cat, t.tname)
  end

module CatTypeHashtbl = Hashtbl.Make(HashedCatType)

let comp_funs = CatTypeHashtbl.create 7

let f_comp cat t t2 =
  let t =
    if t2 == t_any then t
    else if t == t_any then t2
    else if t != t2 then
      Parsing_helper.internal_error "Comparisons for compatible types only"
    else t
  in
  if t.toptions land tyopt_GHOST != 0 then
    Parsing_helper.user_error ("Error: cannot compare elements of ghost type "^t.tname^"\n");
  try CatTypeHashtbl.find comp_funs (cat, t)
  with Not_found ->
    let r = create_fun
	(match cat with
	  Equal -> "="
	| Diff -> "<>"
	| LetEqual -> ">>="
	| ForAllDiff -> "<A>"
	| _ -> Parsing_helper.internal_error "no comparison for this category")
	([t; t], t_bool) 
	~eqth:(if cat == Equal || cat == Diff then Commut else NoEq)
        ~impl:(match cat with
          Equal -> FuncEqual
        | Diff -> FuncDiff
        | _ -> No_impl)
	cat
    in
    CatTypeHashtbl.add comp_funs (cat, t) r;
    r

let sym_not = "not"

let f_not = create_fun sym_not ([t_bool], t_bool) ~impl:(Func "not") Std

(* Create tuple function of given type *)

module HashedTypeList = struct
  type t = Types.typet list

  let equal x1 x2 =
    List.length x1 == List.length x2 && List.for_all2 ( == ) x1 x2

  (* The hash function must use only parts that are not modified,
     otherwise, we may have the same element with several different hashes *)
  let hash x = Hashtbl.hash (List.map (fun t -> t.tname) x)
end

module TypeListHashtbl = Hashtbl.Make (HashedTypeList)

let tuple_fun_table = TypeListHashtbl.create 7

let get_tuple_fun tl =
  try TypeListHashtbl.find tuple_fun_table tl
  with Not_found ->
    let f = create_fun "" (tl, t_bitstring) ~impl:(Func "tuple")
	~impl_inv:(Some "detuple") ~options:fopt_COMPOS	Tuple 
    in
    TypeListHashtbl.add tuple_fun_table tl f;
    f

let empty_tuple = get_tuple_fun []

(* if functions *)

module HashedType =
  struct
    type t = Types.typet
    let equal = (==)
    (* The hash function must use only parts that are not modified,
       otherwise, we may have the same element with several different hashes *)
    let hash x = Hashtbl.hash x.tname
  end

module TypeHashtbl = Hashtbl.Make(HashedType)

let if_fun_table = TypeHashtbl.create 7

let get_if_fun t =
  try 
    TypeHashtbl.find if_fun_table t
  with Not_found ->
    let f = create_fun "if_fun" ([t_bool; t; t], t) ~impl:(Func "if_fun") If in
    TypeHashtbl.add if_fun_table t f;
    f
      
(*For precise computation of the runtime only*)

let t_interv =
  {
    tname = "[1,*]";
    tcat = Interv { pname = "N*"; psize = 0 };
    toptions = tyopt_BOUNDED;
    tsize = None;
    tpcoll = None;
    timplsize = None;
    tpredicate = None;
    timplname = None;
    tserial = None;
    tfstar_serial = None;
    trandom = None;
    tequal = None;
  }

let f_plus = create_fun "+" ([t_interv; t_interv],t_interv) ~eqth:Commut Std

let f_mul = create_fun "*" ([t_interv; t_interv],t_interv;) ~eqth:Commut Std

module HashedFun =
  struct
    type t = funsymb
    let equal = (==)
    (* The hash function must use only parts that are not modified,
       otherwise, we may have the same element with several different hashes *)
    let hash x = Hashtbl.hash (x.f_name, List.map (fun t -> t.tname) (fst x.f_type), (snd x.f_type).tname, x.f_cat, x.f_options)
  end

module FunHashtbl = Hashtbl.Make(HashedFun)

let proj_table = FunHashtbl.create 7

let get_proj f =
  if f.f_options land fopt_BIJECTIVE == 0 then
    Parsing_helper.internal_error "Can get inverse only for [bijective] functions";
  try FunHashtbl.find proj_table f
  with Not_found ->
    let finv =
      List.mapi (fun i ty ->
	create_fun ((string_of_int (i+1)) ^ "-proj-" ^ f.f_name)
	  ([snd f.f_type], ty)
	  ~options:(fopt_DECOMPOS + if ty.toptions land tyopt_FIXED != 0 && (snd f.f_type).toptions land tyopt_FIXED != 0 then fopt_UNIFORM else 0) (Proj(f,i+1))
		) (fst f.f_type)
    in
    FunHashtbl.add proj_table f finv;
    finv

(***************************************************************************)

let get_query_status (_, _, poptref) =
  !poptref

let add_pub_vars_q reach_1s public_vars q =
  let add_pub_vars pub_vars =
    List.iter
      (fun b ->
        if not (List.memq b !public_vars) then public_vars := b :: !public_vars)
      pub_vars
  in
  match q with
  | QSecret (b', pub_vars, Reachability true) when not reach_1s ->
      (* When [reach_1s = false] (the default), 
	 for one-session reachability secrecy, the variable for which we
	 prove secrecy is not considered public. *)
      add_pub_vars pub_vars
  | QSecret (b',pub_vars,_) ->
      add_pub_vars (b'::pub_vars)
  | QEventQ (_,_,pub_vars)      
  | QEquivalence(_,pub_vars,_)
  | QEquivalenceFinal(_,pub_vars)
  | QDiffEquivalence(pub_vars) ->
      add_pub_vars pub_vars
  | AbsentQuery -> ()
	
let get_public_vars0 ?(reach_1s=false) queries =
  let public_vars = ref [] in
  List.iter (add_pub_vars_q reach_1s public_vars) queries;  
  !public_vars

let get_public_vars queries =
  let public_vars = ref [] in
  List.iter (function 
    | q when get_query_status q != ToProve -> () (* I ignore already proved and inactive queries *)
    | (q,_),_,_ -> add_pub_vars_q false public_vars q) queries;
  !public_vars

let occurs_in_queries b q = List.memq b (get_public_vars q)

let event_occurs_in_term f t =
  match t.t_desc with FunApp (f', _) -> f == f' | _ -> false

let rec event_occurs_in_qterm f = function
  | QEvent (_, t) -> event_occurs_in_term f t
  | QTerm _ -> false
  | QNot t -> event_occurs_in_qterm f t
  | QAnd (t1, t2) | QOr (t1, t2) ->
      event_occurs_in_qterm f t1 || event_occurs_in_qterm f t2
  | QExists(_, t) | QForall(_, t) ->
      event_occurs_in_qterm f t

let event_occurs_in_query f = function
  | QSecret _ | QDiffEquivalence _ -> false
  | AbsentQuery | QEquivalence _ | QEquivalenceFinal _ ->
      (* When I want to prove indistinguishability, keep all events *)
      true
  | QEventQ (l, r, _) ->
      List.exists (fun (_, t) -> event_occurs_in_term f t) l
      || event_occurs_in_qterm f r

let event_occurs_in_restriction f = function
  | QRestrictionQ (phi,_) -> event_occurs_in_qterm f phi

let event_occurs_in_queries_or_restrictions f ql rl =
  (List.exists
    (function
      | q when get_query_status q != ToProve ->
          false (* I ignore already proved and inactive queries *)
      | (q, _),_,_ -> event_occurs_in_query f q)
    ql)
  ||
  (List.exists
     (event_occurs_in_restriction f)
     rl)

(***************************************************************************)

let equivs = ref ([] : equiv_gen list)
let initial_statements = ref ([] : collision list) (* statements before generalization with aliases *)
let statements = ref ([] : collision list)
let collisions = ref ([] : collision list)
    
(****************************************************************************)

(* Set when a game is modified *)

let changed = ref false

(* Instructions are added in advise when an instruction I cannot be fully
   performed. The added instructions correspond to suggestions of instructions
   to apply before I so that instruction I can be better performed. *)

let advise = ref ([] : instruct list)
