(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Types
module StringMap = Map.Make (String)

(* Identifiers
   Given by user:
   get_impl -> f.f_impl, finv.f_impl_inv or "fun"/"invfun"^alphabetize_string f.f_name
   get_table_file -> alphabetize_string tbl.tblname or tbl.tblfile
   used only in identifiers get_table_field/name/entry_name/print_entry below
   get_type_name -> ty.timplname or "ty_"^alphabetize_string ty.tname
   get_random -> t.trandom or "random_"^get_type_name ty
   equal -> t.tequal or "equal_"^get_type_name ty

Generated:
   let get_oracle_function_name name = "oracle_" ^ alphabetize_string name
   let get_repr_oracle_function_name name = "repr"^get_oracle_function_name name
   let get_lemma_oracle_function_name name = "lemma" ^ get_oracle_function_name on
   let get_binder_name b = "var_" ^ alphabetize_string b.sname ^ "_" ^ string_of_int b.vname
   "st"^get_binder_name b
   "stqueried"^get_binder_name b
   "vnst"^get_binder_name b
   "vnstqueried"^get_binder_name b
   fun_name_return = "indist"^get_binder_name b
                     "reachreveal"^get_binder_name b
   "reprindist"^get_binder_name b (via fun_name_return)
   "reprreachreveal"^get_binder_name b (via fun_name_return)
   "lemmaindist"^get_binder_name b (via fun_name_return)
   "lemmareachreveal"^get_binder_name b (via fun_name_return)
   fun_name_eq = "reach"^get_binder_name b
   "public"^get_binder_name b
   "reprpublic"^get_binder_name b
let get_letfun_name f = "letfun_" ^ alphabetize_string f.f_name
let get_proj_name f i = "proj_" ^ (string_of_int i) ^ "_" ^ alphabetize_string f.f_name
let get_oracle_name o = "Oracle_" ^ alphabetize_string o
let get_tuple_dec_fun_name tl = "decompose_" ^ get_types_name tl
let get_tuple_tag_name tl = "tag_" ^ get_types_name tl
let get_table_field t = "table_" ^ get_table_file t
let get_table_name t = "tn_" ^ get_table_file t
let get_table_entry_name t = "te_" ^ get_table_file t
let get_table_print_entry t = "printentry_" ^ get_table_file t
let get_event_name e = "Event_"^(alphabetize_string e.f_name)
let get_return_name nr fon = "R" ^ string_of_int nr ^ "_" ^ alphabetize_string fon

   "bvar_<n>"
   "tvar_<n>"
   "cvar_<n>"
   "v<n>"
   "var<n>"
   "input_<n>"
   "x<n>", "y<n>"
   "x_<n>"
   "pos_<n>"
   "lemma_<n>"  -> project to have better names for lemmas
   "tau<n>", "xtau<n>", "ytau<n>"

   "inj_"^corresp_name
   "ft_"^corresp_name
   "corresp_"^corresp_name
   "x"^get_binder_name b, "y"^get_binder_name b

   !protocol_name ^ "_state"
   !protocol_name ^ "_state_type"
   !protocol_name ^ "_print_event"
   !protocol_name ^ "_event"
   !protocol_name ^ "_session_type"
   !protocol_name ^ "_session_entry"
   (!protocol_name) ^ "_session_entry_to_name"
   (!protocol_name) ^ "_oracle_name"
   (!protocol_name) ^ "_following_oracles"
   !protocol_name ^ "_print_session_entry"
   !protocol_name ^ "_print_session"
   !protocol_name ^ "_print_tables"
   !protocol_name ^ "_print_events"
   => protocol_name should not collide with a prefix used above, to avoid possible clashes
   In fact, the !protocol_name ^ "_" prefix may not be needed, since these values are
   generated in modules !protocol_name_allcaps
   All encoded by get_protocol_id

   Check that there is no clash between identifiers, by registering all identifiers
   *)

(*informations to the user*)
let info mess = print_string ("Information: " ^ mess ^ " (implementation)\n")

let error mess =
  Parsing_helper.user_error ("Error: " ^ mess ^ " (implementation)\n")

let activate_debug_comments = false

let debug_comment str =
  if activate_debug_comments then " (* " ^ str ^ " *) " else ""

(* Protocol name *)

let protocol_name = ref "nsl"
let protocol_name_allcaps = ref "NSL"

let alphabetize_string = StringPlus.alphabetize_string

let set_protocol_name filename =
  let suffix =
    try
      List.find (fun suffix -> StringPlus.case_insensitive_ends_with filename suffix) [".pcv"; ".cv"; ".ocv" ]
    with Not_found ->
      ""
  in
  let basename = String.sub filename 0 (String.length filename - String.length suffix) in
  let alph_basename = alphabetize_string basename in
  protocol_name := String.lowercase_ascii alph_basename;
  protocol_name_allcaps := String.uppercase_ascii alph_basename

(* Some standard identifiers *)

let letfun_module = "Letfun"

let letfun_prefix = ref ""

let side1 = "Real"
let side2 = "Ideal"

let current_side = ref ""
(* This variable can contain:
   - "" when we generate a single implementation
   - side1^"." or side2^"." when we generate 2 implementations *)

let string_list_sep = String.concat

let list_args l =
  if l = [] then
    "()"
  else
    String.concat " " l

let state_variable = "state"

let table_entry_exists = "entry_exists"
let table_entry_exists_full = "entry_exists_full"

let table_get = "get"

let table_get_unique = "get_unique"
let table_get_unique_full = "get_unique_full"

let table_insert = "insert"
let table_local_insert = "local_insert"

let entropy_type = "Random.entropy"
let entropy_variable = "ent"
let entropy_declaration =  entropy_variable ^ ": " ^ entropy_type
let call_with_entropy = "call_with_entropy"

let session_id_variable = "sid"

(*
    Name of the type of cv events.

    It defines the type of types for CVST and does not include FStar-defined events.
*)
let cv_event_type_name = "cv_event"

let cv_event = "CVEvent"
let fstar_event = "FStarEvent"

(* Avoid clashes between identifiers *)

let identifiers_CVTypes =
  [ "bytes"; "lbytes"; "tagt"; "tag_from_nat"; "eq_bytes"; "eq_obytes";
    "eq_lbytes"; "lemma_eq_bytes_equal"; "lemma_eq_obytes_equal";
    "deserialize_res"; "DSOk"; "DSTooShort"; "DSFailure";
    "deser_is_ok"; "serialize_type"; "deserialize_type";
    "deser_ok_type"; "deser_too_short_type"; "deser_rev_type";
    "lemma_append_ok"; "lemma_append_too_short1"; "lemma_append_too_short2";
    "lemma_append_rev";
    "serialize"; "deserialize"; "deser_ok"; "deser_too_short"; "deser_rev";
    "serializer";
    "serializer_bytes"; "serializer_lbytes"; "serializer_option"; "serializer_obytes";
    "serializer_bool"; "bbytes"; "serializer_bbytes"; "serializer_ghost";
    "bool_to_str"; "print_bytes"; "print_bool";
    "print_label_bytes"; "print_label_bool" ]

let identifiers_State =
  [ "session_type"; "SessionType"; "oracle_name"; "session_entry";
    "is_valid_entry"; "is_valid_next_entry"; "session_entry_to_name";
    "sessions"; "init_sessions"; "state_type"; "StateType";
    "tt_of"; "local_tt_of"; "vt_of"; "st_of"; "et_of"; "db_of";
    "opt_erased"; "opt_hide"; "opt_reveal"; "event_type"; "CVEvent";
    "FStarEvent"; "_state"; "state";
    "entropy_of"; "tables_of"; "local_tables_of"; "variables_of"; "sessions_of";
    "events_of"; "local_of"; "is_init_state";
    "_get_remove_session_entry"; "get_session_entry";
    "get_and_remove_session_entry"; "state_reserve_session_id";
    "state_add_to_session"; "print_session"; "call_with_entropy";
    "accessor"; "table"; "table_empty"; "table_name"; "local_table_name";
    "return_table"; "return_local_table";
    "table_filter_simple"; "table_filter_full"; "table_filter";
    "TableFilterSimple"; "TableFilterFull"; "insert"; "local_insert";
    "get_inner_simple";
    "get_inner_full"; "get"; "get_unique_full"; "get_unique";
    "entry_exists_full"; "entry_exists"; "print_table";
    "var"; "var_empty"; "var_name"; "var_bool_set"; "var_def";
    "var_bool_get"; "var_get"; "indist_real"; "indist_ideal";
    "indist_one_session_real"; "indist_one_session_ideal";
    "reach_reveal"; "reach_test"; "state_add_event"; "print_events";
    "is_local"; "is_session"; "non_local"; "remove_local"; "inverse_local";
    "lemma_inverse_local_involution"; "local_inverse_aux"; "local_inverse";
    "local_inverse'"; "sessions_included";
    "lemma_sessions_included_inverse_local";
    "non_local_sessions_are_equal"; "local_sessions_are_equal";
    "lemma_non_local_inverse_local"; "init_state"; "finalize_state";
    "remove_session" ]

let identifiers_FStar_primitives =
  [ "unit"; "False"; "True"; "bool"; "not"; "nat"; "option"; "Some"; "None";
    "eqtype"; "eqtype_as_type"; "Lemma"; "SMTPat"; "prop" ]

let fstar_keywords =
  [ "attributes"; "noeq"; "unopteq"; "and"; "assert";
    "assume"; "begin"; "by"; "calc"; "class"; "default"; "decreases";
    "effect"; "eliminate"; "else"; "end"; "ensures"; "exception"; "exists";
    "false"; "friend"; "forall"; "fun"; "function"; "if"; "in"; "include";
    "inline"; "inline_for_extraction"; "instance"; "introduce"; "irreducible";
    "let"; "logic"; "match"; "returns"; "as"; "module"; "new"; "new_effect";
    "layered_effect"; "polymonadic_bind"; "polymonadic_subcomp"; "noextract";
    "of"; "open"; "opaque"; "private"; "quote"; "range_of"; "rec"; "reifiable";
    "reify"; "reflectable"; "requires"; "set_range_of"; "sub_effect"; "synth";
    "then"; "total"; "true"; "try"; "type"; "unfold"; "unfoldable"; "val";
    "when"; "with" ]

let identifiers_cv2fstar_reserved =
  [ session_id_variable; entropy_variable;
    "sel"; "a"; "b"; "c"; "t"; "ev"; "se"; "init";
    "print"; "R0_dummy"; "buf"; "pos"; "x"; "y"; "vars"; "te";
    (* "s1"; "s2"; "res" not needed because interfere only with get_oracle_function_name; "on"
       "s1"; "s2"; "res" also interfere (harmlessly) with vn<...>, vnst<...>,
       vnstqueried<...> *)
    (* CVSTBasic module *)
    "repr"; "return"; "bind"; "CVSTBasic"; 
    (* Effect module *)
    "stt"; "pre_t"; "post_t";
    (*"repr"; "return"; "bind" already in CVSTBasic *)
    "subcomp"; "if_then_else";
    "CVSTPre"; "pre_inv"; "post_inv"; "post_local_inv"; "CVSTInv";
    "post_interm"; "CVST1Call"; "true_pre"; "CVSTInvMin"; "CVSTAxiom";
    "pure_p"; "pure_q"; "lift_pure"; "PURE"; "CVSTML";
    "ml_to_CVST"; "print_string"; "print_sid"; "print_label_sid";
    (* "print_bytes"; "print_bool"; "print_label_bytes"; "print_label_bool"
       already in identifiers_CVTypes *)
    "basic_post"; "lift_basic"; "get_state"; "get_state_no_par"; 
    "CVSTInit"; "init_and_run"; "establish_server";
    "establish_server_no_fork"; "add_event";
    (* "remove_session" already in State *)
    (* Queries module *)
    "evlist"; "interv"; "occursat"; "e"; "f"; "n"; "v"
  ]

let used_identifiers = Hashtbl.create 51

let check_no_identifier_collision usage s =
  try
    let usage' = Hashtbl.find used_identifiers s in
    if usage <> usage' then
      error ("Identifier "^s^" is used for both "^(String.concat " " usage')^
	     " and "^(String.concat " " usage));
    s
  with Not_found ->
    Hashtbl.add used_identifiers s usage;
    s

let add_id_list list_name l =
  List.iter (fun s ->
    ignore (check_no_identifier_collision [list_name; s] s)
      ) l

let _ =
  add_id_list "module CVTypes identifier" identifiers_CVTypes;
  add_id_list "module State identifier" identifiers_State;
  add_id_list "F* primitive" identifiers_FStar_primitives;
  add_id_list "F* keyword" fstar_keywords;
  add_id_list "cv2fstar reserved identifier" identifiers_cv2fstar_reserved

let get_protocol_id id =
  let s = !protocol_name ^ "_" ^ id in
  check_no_identifier_collision [ "protocol"; !protocol_name; id ] s

let state_type () = get_protocol_id "state"

let get_oracle_function_name name =
  let s = "oracle_" ^ alphabetize_string name in
  check_no_identifier_collision [ "oracle"; name ] s

let get_repr_oracle_function_name name =
  let s = "repr" ^ get_oracle_function_name name in
  check_no_identifier_collision [ "representation of oracle"; name ] s

let get_lemma_oracle_function_name name =
  let s = "lemma" ^ get_oracle_function_name name in
  check_no_identifier_collision [ "lemma for oracle"; name ] s

let get_oracle_precondition_name name =
  let s = "pre_" ^ alphabetize_string name in
  check_no_identifier_collision [ "precondition"; name ] s

let get_lemma_oracle_precondition_name name =
  let s = "lemma" ^ get_oracle_precondition_name name in
  check_no_identifier_collision [ "lemma for precondition"; name ] s

let get_binder_name b =
  let s = "var_" ^ alphabetize_string b.sname ^ "_" ^ string_of_int b.vname in
  check_no_identifier_collision [ "variable"; Display.binder_to_string b ] s

let get_prefix_binder_name prefix b bname =
  check_no_identifier_collision [ prefix; Display.binder_to_string b ] (prefix^bname)

let get_letfun_name f =
  let s = "letfun_" ^ alphabetize_string f.f_name in
  check_no_identifier_collision [ "letfun"; f.f_name ] s

let get_proj_name f i =
  let s = "proj_" ^ (string_of_int i) ^ "_" ^ alphabetize_string f.f_name in
  check_no_identifier_collision [ "projection"; string_of_int i; "of"; f.f_name ] s

let get_oracle_name o =
  let s = "Oracle_" ^ alphabetize_string o in
  check_no_identifier_collision [ "oracle"; o ] s

let get_types_name tl =
  String.concat "_" (List.map (fun t -> alphabetize_string (
    match t.tcat with
    | BitString -> t.tname
    | Interv p -> p.pname)) tl)

let get_tuple_dec_fun_name tl =
  let s = "decompose_" ^ get_types_name tl in
  check_no_identifier_collision ("tuple decomposition of types" :: List.map (fun t -> t.tname) tl) s

let get_tuple_tag_name tl =
  let s = "tag_" ^ get_types_name tl in
  check_no_identifier_collision ("tuple tag of types" :: List.map (fun t -> t.tname) tl) s

module Binder =
  struct
    type t = binder
    let compare b1 b2 = compare (get_binder_name b1) (get_binder_name b2)
  end

module BinderSet = Set.Make (Binder)

let is_alphabetic c =
  (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')

type case =
  | Lower
  | Upper
  | Any

let check_fstar_id case s =
  if s = "" then error "The empty string is not a good F* identifier";
  String.iter (fun c -> if not (is_alphabetic c || c = '\'' || c = '_') then
    error (s ^ " is not a good F* identifier")
      ) s;
  begin
    let c = s.[0] in
    match case with
    | Upper ->
	if not (c >= 'A' && c <= 'Z') then
	  error ("The F* identifier "^s^" should start with an uppercase letter")
    | Lower ->
	if not (c >= 'a' && c <= 'z') then
	  error ("The F* identifier "^s^" should start with a lowercase letter")
    | Any ->
	if not ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) then
	  error ("The F* identifier "^s^" should start with a letter")
  end;
  s

let built_in_constants = [Settings.c_true; Settings.c_false]
let built_in_functions = [Settings.f_and; Settings.f_or; Settings.f_not;
  Settings.f_plus; Settings.f_mul; Settings.f_comp Equal Settings.t_bool Settings.t_bool;
  Settings.f_comp Diff Settings.t_bool Settings.t_bool;
  Settings.f_comp Equal Settings.t_bitstring Settings.t_bitstring;
  Settings.f_comp Diff Settings.t_bitstring Settings.t_bitstring;
  Settings.f_comp Equal Settings.t_bitstringbot Settings.t_bitstringbot;
  Settings.f_comp Diff Settings.t_bitstringbot Settings.t_bitstringbot]

let get_impl f =
  match f.f_cat with
  | Proj(finv,n) ->
      Func(get_proj_name finv n)
  | _ ->
      match f.f_impl with
      | No_impl | Func "" ->
	  let s = "fun_" ^alphabetize_string f.f_name in
	  let s = check_no_identifier_collision [ "function"; f.f_name ] s in
	  Func s
      | Const "" ->
	  let s = "fun_" ^alphabetize_string f.f_name in
	  let s = check_no_identifier_collision [ "function"; f.f_name ] s in
	  Const s
      | Func(s) ->
	  if List.memq f built_in_functions then
	    Func s
	  else
	    let s = check_fstar_id Lower s in
	    let s = check_no_identifier_collision [ "function"; f.f_name ] s in
	    Func s
      | Const(s) ->
	  if List.memq f built_in_constants ||
	     (snd f.f_type).toptions land Settings.tyopt_GHOST != 0 then
	    Const s
	  else
	    let s = check_fstar_id Lower s in
	    let s = check_no_identifier_collision [ "function"; f.f_name ] s in
	    Const s
      | (SepFun | FuncEqual | FuncDiff) as x -> x

let get_inv_impl f =
  let s =
    match f.f_impl_inv with
    | Some s -> check_fstar_id Lower s
    | None -> "invfun_"^alphabetize_string f.f_name
  in
  check_no_identifier_collision [ "inverse function of"; f.f_name ] s

let in_parens str = "(" ^ str ^ ")"

let in_parens_if_needed code_str =
  let trimmed = String.trim code_str in
  (* We do not produce \r, nor form feed characters, nor other whitespace, so these should suffice: *)
  if String.contains trimmed '\n' || String.contains trimmed ' ' || String.contains trimmed '\t' then
    in_parens code_str
  else code_str

let is_complicated code_str =
  let trimmed = String.trim code_str in
  String.contains trimmed '\n' || String.length trimmed > 15

(* Add ind in front of every line *)
let code_block_add_line_prefix code_str ind =
  ind ^ String.concat ("\n" ^ ind) (String.split_on_char '\n' code_str)

let code_block code ind print_right_separator =
  (* We reuse code_str to make sure to evaluate `code` only once. *)
  let code_str = code "" in
  if is_complicated code_str then
    "\n" ^
    ind ^ "  begin\n" ^
    (code_block_add_line_prefix code_str (ind ^ "    ")) ^ "\n" ^
    ind ^ "  end" ^
    if print_right_separator then "\n" ^ ind else ""
  else
    " " ^ String.trim code_str ^
    if print_right_separator then " " else ""

(* returns set of free and set of bound variables
  get_iprocess_bv returns the set of variables bound not under a replication
  The set of variables bound under a replication is stored in
  bound_vars_under_repl.
  The set of variables bound inside a term is stored in bound_vars_terms.
  The set of free variables is stored in free_vars.
*)

let empty_bv = BinderSet.empty

let bound_bv = BinderSet.singleton

let add_bv = BinderSet.union

let add_list_bv f l = List.fold_left (fun x y -> add_bv x (f y)) empty_bv l

let get_binderref_binder ext (b, l) =
  if Terms.is_args_at_creation b l then b
  else
    Parsing_helper.input_error
      "There should not be any find variable (implementation)" ext

let free_vars = ref BinderSet.empty

(* Contains all free variables; may contain some variables that are also bound *)

let bound_vars_under_repl = ref BinderSet.empty

let bound_vars_terms = ref BinderSet.empty


type prepared_queries = {
  public_vars: binder list;
    (* We will create a reveal query for these variables:
       x:T is always under replication, field st_x: Map.t T in state variables,
         initially empty, reveal query q_x(n: SidMap.sidt) = return st_x[n]
       store x in state variable st_x when it is assigned *)
  secret_vars: (binder * q_secret_opt) list;
    (* We will create queries depending on the secrecy option for these variables
       - RealOrRandom false (several sessions):
         Add field stqueried_x: Map.t T initially empty
         Real side: reveal query
         Ideal side:
           q_x(n): if st_x[n] contains no value, return None;
           otherwise, if stqueried_x[n] contains a value, return it;
           otherwise, choose a random value, store it in stqueried_x[n],
           return it.
       - RealOrRandom true (one-session):
         Add field stqueried_x: bool initially false
         Real side: reveal query that can be called once (answer None when
           stqueried_x is already set, and set stqueried_x)
         Ideal side: q_x(n:SidMap.sidt) = if stqueried_x, then return None,
           else st_x_queried <- true;
                if st_x[n] contains no value, return None
                else return Some(random value).
       - Reachability false (several sessions):
         Add field stqueried_x: Map.t () initially empty
         Reveal query q_x(n: SidMap.sidt) = if st_x[n] contains no value, return None;
            otherwise, add n -> () to stqueried_x; return st_x[n]
         Test query: qtest_x(n: SidMap.sidt, y:T) =
            if stqueried_x[n] contains a value, then return;
            if st_x[n] contains a value and y = st_x[n], then assert false
            else return.
       - Reachability true (one-session):
         Test query qtest_x(n: SidMap.sidt, y:T) =
            if st_x[n] contains a value and y = st_x[n], then assert false
            else return.
 *)
  has_diff_equiv: bool;
  has_equiv: bool;
  corresp: ((bool(*true when injective*) * term) list * qterm) list
}

type fstar_vars =
  | FSBool of string * string
  | FSVar of string * string * string

type oracle_def =
  | Top of int option * inputprocess
    (*current session id needed for local tables, with number of replications
      above it, to choose its name; input process *)
  | NonTop of (int * binder list * int list * int option * int option * inputprocess) list
    (* nb_of_return; free variables; session ids needed for local tables,
       passed like variables; received session id needed for local tables;
       current session id needed for local tables; input process *)

type oracle_data = {
  oracle_name: string;
  under_repl: bool;
  number_repl_above: int;
  mutable has_queried_var: bool;
  previous_oracle: oracle_data option;
  input_type: typet list;
  mutable output_type: typet list option;
  mutable following_oracles: string list option;
  mutable list_of_returns: (int * (string * binder list * int list) list * process) list;
  mutable list_of_defs: oracle_def;
  mutable seen_returns: int
}

let oracle_only_yields od =
  match od.output_type with
  (* this is if all branches yield *)
  | None -> true
  (* this is if at least one other branch returns/has an output *)
  | Some _ -> false

let oracles = ref (StringMap.empty:oracle_data StringMap.t)

let empty_prepared_queries =
  { public_vars = [];
    secret_vars = [];
    has_diff_equiv = false;
    has_equiv = false;
    corresp = []
 }

let prepared_queries_ref = ref empty_prepared_queries

let tables = ref []

let events = ref []

let built_in_types = [Settings.t_bitstring; Settings.t_bitstringbot;
                      Settings.t_bool; Settings.t_unit; Settings.t_interv]

let types = ref []
let eq_types = ref []
let ser_types = ref []
let serde_types = ref []
let random_types = ref []

let functions = ref []
let inv_functions = ref []

let add_bv_term bs = bound_vars_terms := BinderSet.union bs !bound_vars_terms

let free_var b =
  free_vars := BinderSet.add b !free_vars;
  BinderSet.empty

let rec get_pattern_bv = function
  | PatVar b -> bound_bv b
  | PatTuple (fs, pl) -> add_list_bv get_pattern_bv pl
  | PatEqual t ->
      add_bv_term (get_term_bv t);
      empty_bv

and get_iprocess_bv p =
  match p.i_desc with
  | Nil -> empty_bv
  | OracleDecl (o, patl, p) -> add_bv (add_list_bv get_pattern_bv patl) (get_oprocess_bv p)
  | Par (p1, p2) -> add_bv (get_iprocess_bv p1) (get_iprocess_bv p2)
  | Repl (b, p1) ->
      let bv = get_iprocess_bv p1 in
      bound_vars_under_repl := BinderSet.union !bound_vars_under_repl bv;
      empty_bv

and get_term_bv t =
  match t.t_desc with
  | Var (b, tl) -> free_var (get_binderref_binder t.t_loc (b, tl))
  | FunApp (fs, tl) -> add_list_bv get_term_bv tl
  | TestE (t1, t2, t3) ->
      add_bv (add_bv (get_term_bv t1) (get_term_bv t2)) (get_term_bv t3)
  | LetE (pat, t1, t2, t3) ->
      add_bv (get_pattern_bv pat)
        (add_bv (get_term_bv t1)
           (add_bv (get_term_bv t2)
              (match t3 with None -> empty_bv | Some t -> get_term_bv t)))
  | ResE (b, t) -> add_bv (bound_bv b) (get_term_bv t)
  | ReplIndex _ -> empty_bv
      (* Replication indices may occur in events and variables *)
  | EventAbortE _ -> empty_bv
  | EventE (t, p) -> add_bv (get_term_bv t) (get_term_bv p)
  | FindE _ ->
      Parsing_helper.input_error "Find not supported (implementation)" t.t_loc
  | GetE (tbl, patl, topt, p1, p2, _) ->
      List.fold_right add_bv
        (List.map get_pattern_bv patl)
        (add_bv
           (match topt with Some t -> get_term_bv t | None -> empty_bv)
           (add_bv (get_term_bv p1) (get_term_bv p2)))
  | InsertE (tbl, tl, p) ->
      List.fold_right add_bv (List.map get_term_bv tl) (get_term_bv p)

and get_oprocess_bv p =
  match p.p_desc with
  | Yield | EventAbort _ -> empty_bv
  | Restr (b, p) -> add_bv (bound_bv b) (get_oprocess_bv p)
  | Test (t, p1, p2) ->
      add_bv_term (get_term_bv t);
      add_bv (get_oprocess_bv p1) (get_oprocess_bv p2)
  | Return (tl, p) ->
      List.iter (fun t -> add_bv_term (get_term_bv t)) tl;
      get_iprocess_bv p
  | Let (pat, t, p1, p2) ->
      add_bv_term (get_term_bv t);
      add_bv (get_pattern_bv pat)
        (add_bv (get_oprocess_bv p1) (get_oprocess_bv p2))
  | EventP (t, p) ->
      add_bv_term (get_term_bv t);
      get_oprocess_bv p
  | Find (fl, ep, _) -> error "Find not supported"
  | Get (tbl, patl, topt, p1, p2, _) ->
      (match topt with Some t -> add_bv_term (get_term_bv t) | None -> ());
      List.fold_right add_bv
        (List.map get_pattern_bv patl)
        (add_bv (get_oprocess_bv p1) (get_oprocess_bv p2))
  | Insert (tbl, tl, p) ->
      List.iter (fun t -> add_bv_term (get_term_bv t)) tl;
      get_oprocess_bv p
  | NewTable(tbl, p) ->
      get_oprocess_bv p

let display_vars (a, b) =
  print_string "Free vars : ";
  BinderSet.iter (fun x -> print_string ((get_binder_name x) ^ " ")) a;
  print_newline ();
  print_string "Bound vars : ";
  BinderSet.iter (fun x -> print_string ((get_binder_name x) ^ " ")) b;
  print_newline ()

let impl_get_vars p =
  free_vars := BinderSet.empty;
  bound_vars_under_repl := BinderSet.empty;
  bound_vars_terms := BinderSet.empty;
  let bv_no_repl = get_iprocess_bv p in
  let bv_repl = !bound_vars_under_repl in
  let bv_terms = !bound_vars_terms in
  (* This way of computing free variables is ok because the variables
     are renamed to distinct names *)
  let fv =
    BinderSet.diff !free_vars
      (BinderSet.union bv_no_repl (BinderSet.union bv_repl bv_terms))
  in
  free_vars := BinderSet.empty;
  bound_vars_under_repl := BinderSet.empty;
  bound_vars_terms := BinderSet.empty;
  (fv, bv_no_repl, bv_repl, bv_terms)

let rt = ref 0

let create_fresh_number () =
  rt := !rt + 1;
  !rt

let create_fresh_name prefix =
  let s = prefix ^ string_of_int (create_fresh_number ()) in
  check_no_identifier_collision [ "fresh variable"; s ] s

let rec create_fresh_names prefix = function
  | 0 -> []
  | i ->
      let n = create_fresh_name prefix in
      let nl = create_fresh_names prefix (i - 1) in
      n :: nl

let create_local_name prefix i =
  let s = prefix ^ string_of_int i in
  check_no_identifier_collision [ "local variable"; s ] s

let create_local_names prefix l =
  List.mapi (fun i _ -> create_local_name prefix i) l

let create_oracle_args od =
  match od.list_of_defs with
  | Top (_, process) | NonTop [_,_,_,_,_,process] ->
      (* The oracle has a single definition, try to reuse CryptoVerif variable names
	 as arguments *)
      begin
	match process.i_desc with
	| OracleDecl(_, patl,_) ->
	    List.mapi (fun i pat ->
	      match pat with
	      | PatVar b -> get_binder_name b
	      | _ -> create_local_name "input_" i
		) patl
	| _ -> assert false
      end
  | _ ->
      create_local_names "input_" od.input_type

let user_defined_type t =
  match t.timplsize with
  | Some _ -> false
  | None ->
      (not (List.memq t built_in_types)) &&
      (match t.tcat with | Interv _ -> false | _ -> true) &&
      (t.toptions land Settings.tyopt_GHOST == 0)

let user_defined_function f =
  (not (List.memq f built_in_functions)) &&
  (not (List.memq f built_in_constants))

let get_type_name t =
  if not (user_defined_type t) then
    match t.timplname with
    | Some s -> s
    | None ->
	match t.tcat with
	| Interv _ ->
          (* translate replication indices *)
            "SidMap.sidt"
	| _ -> assert false
  else
    let s =
      match t.timplname with
      | Some s -> check_fstar_id Lower s
      | None -> "ty_"^alphabetize_string t.tname
    in
    check_no_identifier_collision [ "type"; t.tname ] s

let preamble module_name =
  "module " ^ !protocol_name_allcaps ^ "." ^ (!current_side) ^ module_name ^ "\n\n" ^
  "open CVTypes\n" ^
  "open State\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Types\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Functions\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Tables\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Events\n" ^
  "open " ^ !protocol_name_allcaps ^ "." ^ (!current_side) ^ "Sessions\n" ^
  "open " ^ !protocol_name_allcaps ^ "." ^ (!current_side) ^ "Protocol\n" ^
  "open " ^ !protocol_name_allcaps ^ "." ^ (!current_side) ^ "Invariant\n\n"

let get_table_file tbl =
  match tbl.tblfile with
  | None -> alphabetize_string tbl.tblname
  | Some f -> check_fstar_id Any f

let get_table_field t =
  let s = "table_" ^ get_table_file t in
  check_no_identifier_collision [ "table"; t.tblname ] s

let get_table_data t =
  let s = "Table_" ^ get_table_file t in
  check_no_identifier_collision [ "Table"; t.tblname ] s

let get_table_name t =
  let s = "tn_" ^ get_table_file t in
  check_no_identifier_collision [ "name of table"; t.tblname ] s

let get_table_entry_name t =
  let s = "te_" ^ get_table_file t in
  check_no_identifier_collision [ "entry of table"; t.tblname ] s

let get_table_print_entry t =
  let s = "printentry_" ^ get_table_file t in
  check_no_identifier_collision [ "print entry of table"; t.tblname ] s

let get_sid i =
  let istr = string_of_int i in
  check_no_identifier_collision ["session identifier"; "sid"; istr]
    ("sid" ^ istr)

let get_event_name e =
  let s = "Event_"^(alphabetize_string e.f_name) in
  check_no_identifier_collision [ "event"; e.f_name] s

(* In F*, the field tpredicate is not used:
   the full specification can be included in the type (field timplname),
   using a dependent type to include a predicate if needed *)

let get_serializer ty =
  if not (user_defined_type ty) then
    match ty.tfstar_serial with
    | Some s -> s
    | None ->
	match ty.tcat with
	| Interv _ -> "SidMap.serializer_sidt"
	| _ -> assert false
  else
    let s =
      match ty.tfstar_serial with
      | Some s -> check_fstar_id Lower s
      | None -> "ser_"^get_type_name ty
    in
    check_no_identifier_collision ["serializer of type"; ty.tname] s

let get_read_serial ty =
  (get_serializer ty) ^ ".deserialize"

let get_write_serial ty =
  (get_serializer ty) ^ ".serialize"

let get_deser_ok_lemma ty =
  (get_serializer ty) ^ ".deser_ok"

let get_deser_rev_lemma ty =
  (get_serializer ty) ^ ".deser_rev"

let get_random t =
  if not (user_defined_type t) then
    match t.trandom with
    | Some r -> r
    | None -> assert false
  else
    let s =
      match t.trandom with
      | Some r -> check_fstar_id Lower r
      | None -> "random_"^get_type_name t
    in
    check_no_identifier_collision ["random generation for type"; t.tname] s

(* When we generate the F* code for a term, the term may either need
   the full state or just entropy *)

type needs_state_kind =
  | NState
  | NEntropy

let get_state_var = function
  | NState -> state_variable
  | NEntropy -> entropy_variable

let get_state_type = function
  | NState -> state_type()
  | NEntropy -> entropy_type

let get_state_decl state_kind =
  get_state_var state_kind ^ ": " ^ get_state_type state_kind

let call_entropy state_kind f =
  (* Call a function [f] that needs entropy, using a state specified by
     [state_kind]. *)
  match state_kind with
  | NState -> call_with_entropy ^ " " ^ state_variable ^ " " ^ f
  | NEntropy -> f ^ " " ^ entropy_variable

let random state_kind b ind =
  let rand = get_random b.btype in
  "\n" ^
  (* rand already is in parentheses if needed *)
  ind ^ "let " ^ get_state_var state_kind ^ ", " ^ get_binder_name b ^ " = " ^
  call_entropy state_kind rand ^ " in\n"

let equal t =
  if not (user_defined_type t) then
    match t.tequal with
    | Some eq -> eq
    | None ->
	match t.tcat with
	| Interv _ -> "(=)"
	| _ -> assert false
  else
    let s =
      match t.tequal with
      | Some eq -> check_fstar_id Lower eq
      | None -> "equal_" ^get_type_name t
    in
    check_no_identifier_collision ["equality for type"; t.tname] s


let yield_transl od ind =
  if oracle_only_yields od then "\n" ^ ind ^ state_variable ^ ", ()"
  else "\n" ^ ind ^ state_variable ^ ", None"

let store_var b =
  List.memq b (!prepared_queries_ref).public_vars ||
  List.exists (fun (b',_) -> b' == b) (!prepared_queries_ref).secret_vars

let def_var b ind =
  if store_var b then
    let bname = get_binder_name b in
    let vnstb = get_prefix_binder_name "vnst" b bname in
    ind ^ "let " ^ state_variable ^ " = State.var_def " ^ state_variable ^ " " ^
    !protocol_name_allcaps^".Variables."^ vnstb ^ " " ^ session_id_variable ^ " " ^ bname ^ " in\n"
  else
    ""

(* [needs_state t] is true when [t] needs state or entropy *)

let rec needs_state t =
  match t.t_desc with
  | Var _ -> false (* indices are always the current indices, and not encoded *)
  | FunApp(f, tl) -> f.f_impl_ent || f.f_impl_needs_full_state || List.exists needs_state tl
  | TestE(t1,t2,t3) -> needs_state t1 || needs_state t2 || needs_state t3
  | ReplIndex _ -> false
  | EventAbortE _ -> Parsing_helper.input_error "event_abort not supported in F* implementation" t.t_loc
  | EventE _ | GetE _ | InsertE _ | ResE _ -> true
  | FindE _ -> Parsing_helper.input_error "Find not supported (implementation)" t.t_loc
  | LetE (pat, t1, t2, topt) ->
      needs_state_pat pat ||
      needs_state t1 || needs_state t2 ||
      (match topt with
         None -> false
       | Some t3 -> needs_state t3)

and needs_state_pat = function
  | PatVar b -> store_var b
  | PatEqual(t) -> needs_state t
  | PatTuple(f, pl) -> List.exists needs_state_pat pl

(* [needs_full_state t] is true when [t] needs the full state,
   not only entropy *)

let rec needs_full_state t =
  match t.t_desc with
  | Var _ -> false (* indices are always the current indices, and not encoded *)
  | FunApp(f, tl) -> f.f_impl_needs_full_state || List.exists needs_full_state tl
  | TestE(t1,t2,t3) -> needs_full_state t1 || needs_full_state t2 || needs_full_state t3
  | ReplIndex _ -> false
  | EventAbortE _ -> Parsing_helper.input_error "event_abort not supported in F* implementation" t.t_loc
  | EventE _ | GetE _ | InsertE _ -> true
  | ResE(b,t1) -> needs_full_state t1
  | FindE _ -> Parsing_helper.input_error "Find not supported (implementation)" t.t_loc
  | LetE (pat, t1, t2, topt) ->
      needs_full_state_pat pat ||
      needs_full_state t1 || needs_full_state t2 ||
      (match topt with
         None -> false
       | Some t3 -> needs_full_state t3)

and needs_full_state_pat = function
  | PatVar b -> store_var b
  | PatEqual(t) -> needs_full_state t
  | PatTuple(f, pl) -> List.exists needs_full_state_pat pl

(* [needs_entropy t] is true when [t] needs entropy. This function
   is called only when [needs_full_state t] is false. *)

let rec needs_entropy t =
  match t.t_desc with
  | Var _ -> false (* indices are always the current indices, and not encoded *)
  | FunApp(f, tl) ->
      assert (f.f_impl_needs_full_state = false);
      f.f_impl_ent || List.exists needs_entropy tl
  | TestE(t1,t2,t3) -> needs_entropy t1 || needs_entropy t2 || needs_entropy t3
  | ReplIndex _ -> false
  | EventAbortE _ -> Parsing_helper.input_error "event_abort not supported in F* implementation" t.t_loc
  | EventE _ | GetE _ | InsertE _ -> assert false (* [needs_entropy] is called only when [needs_full_state] is false, so these cases cannot occur *)
  | ResE _ -> true
  | FindE _ -> Parsing_helper.input_error "Find not supported (implementation)" t.t_loc
  | LetE (pat, t1, t2, topt) ->
      needs_entropy_pat pat ||
      needs_entropy t1 || needs_entropy t2 ||
      (match topt with
         None -> false
       | Some t3 -> needs_entropy t3)

and needs_entropy_pat = function
  | PatVar b -> false
  | PatEqual(t) -> needs_entropy t
  | PatTuple(f, pl) -> List.exists needs_entropy_pat pl

(* [diff_side t] is true when [t] calls a letfun function that has 2 different
   implementations, via the diff[.,.] construct. This function
   is called only when [needs_full_state t] is false. *)

let rec diff_side t =
  match t.t_desc with
  | Var _ -> false (* indices are always the current indices, and not encoded *)
  | FunApp(f, tl) ->
      assert (f.f_impl_needs_full_state = false);
      f.f_impl_diff_side || List.exists diff_side tl
  | TestE(t1,t2,t3) -> diff_side t1 || diff_side t2 || diff_side t3
  | ReplIndex _ -> false
  | EventAbortE _ -> Parsing_helper.input_error "event_abort not supported in F* implementation" t.t_loc
  | EventE _ | GetE _ | InsertE _ -> assert false (* [diff_side] is called only when [needs_full_state] is false, so these cases cannot occur *)
  | ResE(_,t1) -> diff_side t1
  | FindE _ -> Parsing_helper.input_error "Find not supported (implementation)" t.t_loc
  | LetE (pat, t1, t2, topt) ->
      diff_side_pat pat ||
      diff_side t1 || diff_side t2 ||
      (match topt with
         None -> false
       | Some t3 -> diff_side t3)

and diff_side_pat = function
  | PatVar b -> false
  | PatEqual(t) -> diff_side t
  | PatTuple(f, pl) -> List.exists diff_side_pat pl

let decompos_pattuple ind f pl =
  if f.f_name = "" then
    (fun arg -> (get_tuple_dec_fun_name (List.map Terms.get_type_for_pattern pl)) ^ " " ^ arg), false
  else
    (let finv = get_inv_impl f in
     (fun arg -> finv ^ " " ^ arg), f.f_options land Settings.fopt_BIJECTIVE != 0
    )


let rec translate_termlist_ns sep tl ind = match tl with
  | [] -> "()"
  | [a] -> translate_term_ns a ind
  | a::b -> (translate_term_ns a ind) ^ sep ^ (translate_termlist_ns sep b ind)

(* ns = no state *)
and translate_term_ns t ind =
  (* This wraps everything except Var into parentheses, so everything that might contain spaces.
     This is important because translate_termlist_ns is used for event and function parameters. *)
  match t.t_desc with
  | Var(b, tl) -> debug_comment "translate_term_ns Var" ^ get_binder_name (get_binderref_binder t.t_loc (b, tl))
  | FunApp(f, tl) ->
      if f.f_name = "" then
        "(Tuples.compos "^(get_tuple_tag_name (List.map (fun t -> t.t_type) tl)) ^ " [" ^
        (string_list_sep
          ";"
          (List.map
            (fun t -> (get_write_serial t.t_type) ^ " " ^(translate_term_ns t ind))
            tl)) ^
        "])"
      else
        (match get_impl f with
         | Func x ->
             assert (not f.f_impl_ent);
             debug_comment "translate_term_ns FunApp/Func" ^
	     if tl = [] then
	       x
	     else
               "(" ^ x ^ " " ^ (translate_termlist_ns " " tl ind) ^ ")"
         | Const x ->
             debug_comment "translate_term_ns FunApp/Const" ^
             x
         | SepFun ->
             assert (not f.f_impl_needs_full_state && not f.f_impl_ent);
             "(" ^ (!letfun_prefix) ^ (get_letfun_name f) ^ " " ^ (translate_termlist_ns " " tl ind) ^ ")"
         | FuncEqual ->
             let eq = equal (List.hd tl).t_type in
             "(" ^ debug_comment "translate_term_ns FunApp/FuncEqual" ^
             eq ^ " " ^ (translate_termlist_ns " " tl ind) ^ ")"
         | FuncDiff ->
             let eq = equal (List.hd tl).t_type in
             "(" ^ debug_comment "translate_term_ns FunApp/FuncDiff" ^
             "not (" ^ eq ^ " " ^ (translate_termlist_ns " " tl ind) ^ "))"
         | No_impl -> assert false
        )
  | TestE(t1,t2,t3) ->
      "(if " ^ (translate_term_ns t1 ind) ^
      debug_comment "translate_term_ns TestE" ^
      " then " ^
      (translate_term_ns t2 ind) ^
      " else " ^
      (translate_term_ns t3 ind) ^ " )"
  | ReplIndex _ ->
      (* if we end up here, this means that the CV model contains
         not all replication indices, or not in the right order. *)
      Parsing_helper.input_error "Replication indices should occur only inside variables and events, and only as tuple of all replication indices leading to this program point (implementation)" t.t_loc
  | EventAbortE _ ->
      Parsing_helper.input_error "event_abort not supported in F* implementation" t.t_loc
  | EventE _ -> assert false  (* These need state and if we end up here *)
  | GetE _ -> assert false    (* it is an error in the code and so *)
  | InsertE _ -> assert false (* we assert it does not happen. *)
  | ResE _ -> assert false
  | FindE _ ->
      Parsing_helper.input_error "Find not supported (implementation)" t.t_loc
  | LetE (pat, t1, t2, topt) ->
      "(" ^ debug_comment "translate_term_ns LetE" ^
      (match_pattern_ns [] pat (translate_term_ns t1 ind) (translate_term_ns t2)
         (match topt with
            Some t3 ->
              translate_term_ns t3
          | None ->
              (fun ind ->
                Parsing_helper.internal_error "else branch of let called but not defined"))
         true ind) ^
      ")"

and match_pattern_complex_ns opt pat s p1 p2 in_term ind =
  (* decomposition of every function *)
  let rec decompos = function
    (* On the first layer, we will not find PatVar or PatEqual -- it will have been captured
       by match_pattern_ns, already. *)
    | PatVar(b) ->
        let bname = get_binder_name b in
	assert (store_var b = false);
        ([], bname, [], [bname])
    | PatEqual(t) ->
        let n = create_fresh_name "bvar_" in
        let eq = equal t.t_type in
        ([], n, [(eq, n, translate_term_ns t ind)], [])
    | PatTuple(f, pl) ->
        let n = create_fresh_name "bvar_" in
        let (func, bij) = decompos_pattuple ind f pl in
        let decompos_list = List.map decompos pl in
        (
          (* func: (parameter n, func, bij, variable list) *) (n, func, bij, List.map (fun (_, y, _, _) -> y) decompos_list)::
            (List.concat (List.map (fun (x, _, _, _) -> x) decompos_list)),
          (* name *) n,
          (* tests *) List.concat (List.map (fun (_, _, z, _) -> z) decompos_list),
          (* all_binders *) List.concat (List.map (fun (_, _, _, t) -> t) decompos_list)
        )
  in
  let rec andlist = function
    | [] -> "true"
    | [x] -> x
    | x::y -> x ^ " && " ^ (andlist y)
  in
  let (func, name, tests, all_binders) = decompos pat in
  let aux ovar p1 p2_str =
    let p2_block = code_block (fun _ -> p2_str) (ind ^ "  ") false in
    ind ^ "  let " ^ name ^ " = " ^ s ^ " in\n" ^
    (* decompos functions *)
    (match ovar with Some m -> ind ^ "let " ^ m ^ " =\n" | _ -> "") ^
    (List.fold_left (^) ""
       (List.map
          (fun (n, f, bij, vl) ->
	    if bij then
	      ind ^ "  let (" ^ (string_list_sep "," vl) ^ ") = " ^ f n ^ " in\n"
	    else
              ind ^ "  match " ^ (f n) ^ " with\n" ^
              ind ^ "  | None ->" ^ code_block_add_line_prefix p2_block "  " ^ "\n" ^
              ind ^ "  | Some (" ^ (string_list_sep "," vl) ^ ") ->\n") func)
    ) ^
    (* tests *)
    (if tests == [] then code_block p1 (ind ^ "  ") true
    else
      ind ^ "  if " ^ (andlist (List.map (fun (eq, n, s) -> eq ^ " " ^ n ^ " " ^ s) tests)) ^ " then" ^
      code_block p1 (ind ^ "  ") true ^
      "else" ^
      p2_block ^ "\n") ^ (match ovar with Some m -> ind ^ "in\n" | _ -> "")
  in
  (* We reuse p2_str to make sure p2 is only evaluated once. p1 is evaluated only once anyway. *)
  let p2_str = p2 "" in
  if is_complicated p2_str then
    (*the result of the match needs to be assigned to a new variable.*)
    let m = create_fresh_name "bvar_" in
    debug_comment "match_pattern_complex_ns" ^
    (aux (Some m) (fun s -> "Some (" ^ (string_list_sep "," all_binders) ^ ")") "None") ^ "\n" ^
    ind ^ "match " ^ m ^ " with\n" ^
    ind ^ "| None ->\n" ^
    ind ^ "  " ^ (code_block_add_line_prefix p2_str (ind ^ "      ")) ^ "\n" ^
    ind ^ "| Some (" ^ (string_list_sep "," all_binders) ^ ") ->\n" ^
    ind ^ "  " ^ (p1 (ind ^ "      "))
  else
    debug_comment "match_pattern_complex_ns" ^
    aux None p1 p2_str

(*
  The meaning of the parameters is the following:
  let pat = var in ( p1 ) else ( p2 )
*)
and match_pattern_ns opt (pat:Types.pattern) (var:string) (p1:string -> string) (p2: string -> string) (in_term:bool) ind =
  match pat with
  | PatVar(b) ->
      assert (store_var b = false);
      ind ^
      "let " ^ (get_binder_name b) ^ " = " ^ var ^
      debug_comment "match_pattern_ns PatVar" ^
      " in\n" ^
      (p1 ind)
  | PatEqual(t) ->
      let eq = equal t.t_type in
      ind ^
      "if " ^ eq ^ " " ^ (translate_term_ns t ind) ^ " " ^ var ^ " then" ^
      debug_comment "match_pattern_ns PatEqual" ^
      (code_block p1 ind true) ^
      "else" ^
      (code_block p2 ind true)
  | _ -> match_pattern_complex_ns opt pat var p1 p2 in_term ind

let get_return_name n oname =
  let sn = string_of_int n in
  let s = "R" ^ sn ^ "_" ^ alphabetize_string oname in
  check_no_identifier_collision [ "return"; sn; "of oracle"; oname ] s

let translate_insert tbl valtl =
  "let " ^ state_variable ^ " = " ^
  (match tbl.tbllocalopt with
  | None -> table_insert ^ " " ^ state_variable
  | Some i ->
      let sidid = get_sid i in
      table_local_insert^ " " ^ state_variable ^ " " ^ sidid) ^
  " " ^ get_table_name tbl ^ " (" ^
  (string_list_sep ", "
     (List.map in_parens_if_needed valtl)
      ) ^ ") in\n"

let rec translate_oprocess od p ind =
  match p.p_desc with
  | Yield -> yield_transl od ind
  | EventAbort _ ->
      Parsing_helper.input_error "event_abort not supported in F* implementation" p.p_loc
  | Restr(b, p) ->
      (random NState b ind) ^
      (def_var b ind) ^
      (translate_oprocess od p ind)
  | Test(t, p1, p2) ->
      let (prefix, valt) = translate_term_get_val NState t ind in
      "\n" ^
      prefix ^ "\n" ^
      ind ^ "if " ^ valt ^ " then\n" ^
      ind ^ "begin" ^
      (translate_oprocess od p1 (ind ^ "  ")) ^ "\n" ^
      ind ^ "end\n" ^
      ind ^ "else\n" ^
      ind ^ "begin" ^
      (translate_oprocess od p2 (ind ^ "  ")) ^ "\n" ^
      ind ^ "end"
  | Return(tl,p1) ->
      (try
        let (nr, fol, _) = List.find (fun (_, _, pr) -> pr == p) od.list_of_returns in
        (if fol == [] then ""
        else
          "let sel = [" ^
          String.concat "; "
            (List.map
              (fun (fon, bl, sidl) ->
                get_return_name nr fon ^
                String.concat ""
		  (List.map (fun b -> " " ^ get_binder_name b) bl) ^
                String.concat ""
                  (List.map (fun i -> " " ^ get_sid i) sidl)
              )
              fol) ^ "] in\n" ^
        "let " ^ state_variable ^ " = state_add_to_session " ^ state_variable ^ " " ^ session_id_variable ^ " sel in\n") ^
        let (prefix, valt) = translate_term_to_output tl ind in
        "\n" ^ prefix ^ "(" ^
        state_variable ^ ", Some (" ^
        (if (fol != [] || od.has_queried_var) && od.under_repl then session_id_variable ^ ", " else "") ^
        valt ^ "))\n"
      with Not_found ->
        Parsing_helper.internal_error ("Expected exactly one list entry corresponding to the process, when treating an output of oracle " ^ od.oracle_name)
      )
  | Let(pat,t,p1,p2) ->
      let (prefix, valt) = translate_term_get_val NState t ind in
      let (prefixpat, valpat) = match_pattern NState [] pat valt (translate_oprocess od p1) (translate_oprocess od p2) false ind in
      "\n" ^ prefix ^ prefixpat ^
      "\n" ^ ind ^ valpat
  | EventP(t,p)->
      "\n"^ind^(translate_event t ind)^
      (translate_oprocess od p ind)
  | Find(_,_,_) ->
      Parsing_helper.input_error "Find not supported (implementation)" p.p_loc
  | Get(tbl,patl,topt,p1,p2,find_info) ->
      translate_get (fun b -> Terms.refers_to_oprocess b p1) [] tbl patl topt (translate_oprocess od p1) (translate_oprocess od p2) find_info ind
  | Insert(tbl,tl,p) ->
      let (prefixtl, valtl) = translate_termlist NState tl ind in
      prefixtl ^ translate_insert tbl valtl ^
      (translate_oprocess od p ind)
  | NewTable(tbl, p) ->
      (* We do not translate newtable. The table will be created at the
	 first insert *)
      translate_oprocess od p ind

(* p1 and p2 are functions that take the indentation level
   and return the string corresponding to the program.
   Meaning of parameters: get tbl(patl) suchthat topt (p1) else (p2)
*)
and translate_get used opt tbl patl topt p1 p2 find_info ind =
  let get_table_str =
    match tbl.tbllocalopt with
    | None ->
	"(return_table " ^ state_variable ^ " " ^ (get_table_name tbl) ^ ")"
    | Some i ->
	let sidid = get_sid i in
	"(return_local_table " ^ state_variable ^ " " ^ sidid ^ " " ^ (get_table_name tbl) ^ ")"
  in
  let pat_vars = Terms.vars_from_pat_list [] patl in
  let used_vars = List.filter used pat_vars in
  let match_res = "("^(string_list_sep "," (List.map get_binder_name used_vars))^")" in
  let tvars = create_fresh_names "tvar_" (List.length tbl.tbltype) in
  let filter_needs_state =
    match topt with
    | Some t -> needs_state t
    | None -> false
  in
  let (prefix, matchfilt) =
    match_pattern_list
      opt patl tvars
      (fun ind -> (* p1 *)
        match topt with
           | Some t ->
               if filter_needs_state then
                 let prefixf, valf = translate_term_get_val NState t ind in
                 ind ^ prefixf ^ "if (" ^ valf ^ ") then " ^ state_variable ^ ", Some " ^ match_res ^ " else " ^ state_variable ^ ", None"
               else
                 ind ^ "if (" ^ (translate_term_ns t ind) ^ ") then Some " ^ match_res ^ " else None"
           | None -> ind ^ "Some " ^ match_res)
      (fun ind -> "None") (* p2 *)
      false
      (ind ^ "      ")
  in
  let filterfun =
    ind ^ "  (fun " ^ (if filter_needs_state then "(" ^ state_variable ^ ":"  ^ (state_type ()) ^ ") " else "") ^ "(te:" ^ get_table_entry_name tbl ^ ") -> " ^
    ind ^ "let (" ^ (string_list_sep ", " tvars) ^ ") = te in\n" ^
    ind ^ "    begin\n" ^
    (*  *)
    matchfilt ^ "\n" ^
    ind ^ "    end\n" ^
    ind ^ "  )"
  in
  if used_vars = [] then
    "\n" ^
    ind^"begin\n"^
    prefix ^
    (if filter_needs_state then
      ind ^ "let " ^ state_variable ^ ", b = " ^ table_entry_exists_full ^ " " ^ state_variable ^ " " ^ get_table_str ^ "\n" ^ filterfun ^ " in\n" ^
      ind ^ "if b then"
    else
      ind ^ "if " ^ table_entry_exists ^ " " ^ get_table_str ^ "\n" ^ filterfun ^
      ind ^ "then") ^
    (code_block p1 ind true) ^
    "else" ^
    (code_block p2 ind true) ^
    "end"
  else if find_info = Unique then
    "\n" ^
    ind ^ "begin\n"^
    prefix ^
    ind ^ "match " ^ (if filter_needs_state then table_get_unique_full ^ " " ^ state_variable else table_get_unique) ^ " " ^ get_table_str ^ "\n" ^
    filterfun ^ "\n" ^
    ind ^ "with\n"^
    ind ^ "| " ^ (if filter_needs_state then state_variable ^ ", " else "") ^ "None ->" ^
    (code_block p2 ind false) ^ "\n" ^
    ind ^ "| " ^ (if filter_needs_state then state_variable ^ ", " else "") ^ "Some " ^ match_res ^ " ->" ^
    (code_block p1 ind true) ^
    "end"
  else
    "\n" ^
    ind ^ "begin\n"^
    prefix ^
    ind ^ "match " ^ table_get ^ " " ^
    state_variable ^ " " ^ get_table_str ^
    " (TableFilter" ^ (if filter_needs_state then "Full" else "Simple") ^ " \n" ^
    filterfun ^ ")\n" ^
    ind ^ "with\n"^
    ind ^ "| " ^ state_variable ^ ", None ->" ^
    (code_block p2 ind false) ^ "\n" ^
    ind ^ "| " ^ state_variable ^ ", Some " ^ match_res ^ " ->" ^
    (code_block p1 ind true) ^
    "end"

and translate_event t ind =
  match t.t_desc with
  | FunApp (event_function, repl_indices :: paraml) ->
      let is_session_id = match repl_indices.t_desc with
        (* first boolean: if it matches, second boolean: if we need serialization.
           We need serialization if the event was declared bitstring as type for
           a tuple of replication indices. *)
        | FunApp (_, []) -> (fun t -> false, false)
        | FunApp (_, [repl_index]) -> (fun t -> Terms.equal_terms t repl_index, false)
        | FunApp (_, _) -> (fun t -> Terms.equal_terms t repl_indices, true)
        | _ -> Parsing_helper.internal_error "Expected FunApp for event replication index list (translate_event)"
      in
      let translate_term_get_val_event t ind =
        match is_session_id t with
        | true, true -> ("", "(SidMap.serializer_sidt.serialize " ^ session_id_variable ^ ")")
        | true, false -> ("", session_id_variable)
        (* if the model uses only _some_ replication indices, or in the wrong order,
           or not as top-level parameter of the event but nested inside a parameter,
           we will end up in this last case, and then translate_term_get_val will
           complain about any replication indices. *)
        | _ -> translate_term_get_val NState t ind
      in
      let rec translate_termlist_event l ind =
        match l with
          [] -> ("", [])
        | [a] -> let (prefix, vala) = translate_term_get_val_event a ind in (prefix, [vala])
        | a::l ->
            let (prefixa, vala) = translate_term_get_val_event a ind in
            let (prefixl, vall) = translate_termlist_event l ind in
            prefixa ^ prefixl, vala :: vall
      in
      let prefix, vall = translate_termlist_event paraml "  " in
      prefix ^
      "let ev = " ^ cv_event ^ " (" ^ (get_event_name event_function) ^ " " ^ (String.concat " " vall) ^ ") in\n" ^
      "let " ^ state_variable ^ " = state_add_event " ^ state_variable ^ " ev in\n"
  | _ -> Parsing_helper.internal_error "Expected FunApp for event (translate_event)"

and translate_termlist state_kind l ind =
  match l with
    [] -> ("", [])
  | [a] -> let (prefix, vala) = translate_term_get_val state_kind a ind in (prefix, [vala])
  | a::l ->
      let (prefixa, vala) = translate_term_get_val state_kind a ind in
      let (prefixl, vall) = translate_termlist state_kind l ind in
      prefixa ^ prefixl, vala :: vall

and translate_term_get_val state_kind t ind =
  if not (needs_state t) then
    ("", translate_term_ns t ind)
  else
    begin
      match t.t_desc with
      | Var _ | ReplIndex _ -> assert false (* should be translated by the version without state *)
      | FunApp(f, tl) when (not f.f_impl_needs_full_state) && (not f.f_impl_ent) ->
          let prefix, valtl = translate_termlist state_kind tl ind in
          if f.f_name = "" then
            prefix,
            "(Tuples.compos " ^
	    (get_tuple_tag_name (List.map (fun t -> t.t_type) tl)) ^ " [" ^
            (string_list_sep
              ";"
              (List.map2
                (fun t valt -> (get_write_serial t.t_type) ^ " " ^ valt)
                tl
                valtl)) ^
            "])"
          else
            (match get_impl f with
             | Func x ->
                 prefix,
                 "(" ^ debug_comment "translate_term_get_val FunApp/Func" ^
                 x ^ " " ^ (list_args valtl) ^ ")"
             | Const x -> assert false (* should be translated by the version without state *)
             | SepFun ->
		 prefix,
                 "(" ^ (!letfun_prefix) ^ (get_letfun_name f) ^ " " ^
                 (list_args valtl) ^ ")"
             | FuncEqual ->
                 let eq = equal (List.hd tl).t_type in
                 prefix,
                 "(" ^ debug_comment "translate_term_get_val FunApp/FuncEqual" ^
                 eq ^ " " ^ (list_args valtl) ^ ")"
             | FuncDiff ->
                 let eq = equal (List.hd tl).t_type in
                 prefix,
                 "(" ^ debug_comment "translate_term_get_val FunApp/FuncDiff" ^
                 "not (" ^ eq ^ " " ^ (list_args valtl) ^ "))"
             | No_impl -> assert false
            )
      | EventAbortE _ ->
          Parsing_helper.input_error "event_abort not supported in F* implementation" t.t_loc
      | FindE _ ->
          Parsing_helper.input_error "Find not supported (implementation)" t.t_loc
      | EventE(t,p)->
	  assert (state_kind == NState);
          let (prefix, valp) = translate_term_get_val state_kind p ind in
          (translate_event t ind) ^ prefix, valp
      | InsertE(tbl, tl, p) ->
	  assert (state_kind == NState);
          let (prefixtl, valtl) = translate_termlist state_kind tl ind in
          let (prefix, valp) = translate_term_get_val state_kind p ind in
          prefixtl ^ translate_insert tbl valtl ^ prefix, valp
      | ResE (b, p) ->
          let (prefix, valp) = translate_term_get_val state_kind p ind in
          (* random is producing prefix-like code. *)
          debug_comment "translate_term_get_val ResE" ^
          (random state_kind b ind) ^ (def_var b ind) ^ prefix, valp
      | TestE(t1,t2,t3) when not(needs_state t2 || needs_state t3) ->
          let (prefix1, v1) = translate_term_get_val state_kind t1 ind in
          prefix1,
          "(if " ^ v1 ^
          debug_comment "translate_term_get_val state_kind TestE" ^
          " then " ^ (translate_term_ns t2 ind) ^
          " else " ^ (translate_term_ns t3 ind) ^ ")"
      | _ ->
          let v = create_fresh_name "v" in
          "let " ^ get_state_var state_kind ^ ", " ^ v ^ " = " ^ (translate_term_get_pair state_kind t ind) ^ " in\n", v
    end

and  translate_term_get_pair state_kind t ind =
  if not (needs_state t) then
    "("^ get_state_var state_kind ^ ", " ^ (translate_term_ns t ind) ^ ")"
  else
    begin
      match t.t_desc with
      | Var _ | ReplIndex _ -> assert false (* should be translated by the version without state *)
      | FunApp(f, tl) when f.f_impl_ent || f.f_impl_needs_full_state ->
          let prefix, valtl = translate_termlist state_kind tl ind in
          assert (f.f_name <> ""); (* tuples should not need entropy *)
          (match get_impl f with
          | Func x ->
	      (* Using the full state is allowed only for letfun *)
	      assert(f.f_impl_ent && not f.f_impl_needs_full_state);
              let f_code =
                "(" ^
                debug_comment "translate_term_get_pair FunApp/Func" ^
                x ^
                (if valtl = [] then "" else " " ^ (list_args valtl)) ^
                ")" in
              "(" ^ prefix ^
	      call_entropy state_kind f_code ^ ")"
          | Const x -> assert false (* should be translated by the version without state *)
          | SepFun ->
	      if f.f_impl_needs_full_state then
		begin
		  assert (state_kind == NState);
		  "(" ^ prefix ^
		  (!letfun_prefix) ^ (get_letfun_name f) ^ " " ^
		  (if valtl = [] then "" else (list_args valtl)) ^ " " ^
                  state_variable ^ ")"
		end
	      else
		begin
		  assert (f.f_impl_ent);
		  let f_code =
		    "(" ^ (!letfun_prefix) ^ (get_letfun_name f) ^
		    (if valtl = [] then "" else " " ^ (list_args valtl)) ^ ")"
		  in
		  "(" ^ prefix ^
		  call_entropy state_kind f_code ^ ")"
		end
	  | FuncEqual | FuncDiff -> assert false (* should not need entropy *)
          | No_impl -> assert false
		)
      | TestE(t1,t2,t3) when needs_state t2 || needs_state t3 ->
          let (prefix1, v1) = translate_term_get_val state_kind t1 ind in
          "(" ^ prefix1 ^
          " if " ^ v1 ^
          debug_comment "translate_term_get_pair TestE" ^
          " then " ^ (translate_term_get_pair state_kind t2 ind) ^
          " else " ^ (translate_term_get_pair state_kind t3 ind) ^ " )"
      | EventAbortE _ ->
          Parsing_helper.input_error "event_abort not supported in F* implementation" t.t_loc
      | EventE(t,p)->
	  assert (state_kind == NState);
          "(" ^ (translate_event t ind) ^
          (translate_term_get_pair state_kind p ind) ^ ")"
      | GetE(tbl,patl,topt,p1,p2, find_info) ->
	  assert (state_kind == NState);
          translate_get (fun b -> Terms.refers_to b p1) [] tbl patl topt
	    (translate_term_get_pair state_kind p1)
	    (translate_term_get_pair state_kind p2) find_info ind
      | InsertE(tbl, tl, p) ->
	  assert (state_kind == NState);
          let (prefixtl, valtl) = translate_termlist state_kind tl ind in
          prefixtl ^ "(" ^ translate_insert tbl valtl ^
          (translate_term_get_pair state_kind p ind) ^ ")"
      | FindE _ -> Parsing_helper.input_error "Find not supported (implementation)" t.t_loc
      | ResE (b, t) ->
          "(" ^ debug_comment "translate_term_get_pair ResE" ^
          (random state_kind b ind) ^ (def_var b ind) ^
	  (translate_term_get_pair state_kind t ind) ^ ")"
      | LetE (pat, t1, t2, topt) ->
          let (prefix1, val1) = translate_term_get_val state_kind t1 ind in
          let (prefixpat, valpat) =
          match_pattern state_kind [] pat val1 (translate_term_get_pair state_kind t2)
                       (match topt with
                          Some t3 -> translate_term_get_pair state_kind t3
                        | None -> (fun ind -> Parsing_helper.internal_error "else branch of let called but not defined"))
              true ind
          in
          "(" ^ debug_comment "translate_term_get_pair LetE" ^
          prefix1 ^ prefixpat ^ valpat ^
          ")"
      | _ ->
          let (prefix, valt) = translate_term_get_val state_kind t ind in
          prefix ^ "(" ^ get_state_var state_kind ^ ", " ^ valt ^ ")"
    end

and translate_term_to_output tl ind =
     if tl = [] then "", "()" else
     let prefix, valtl = translate_termlist NState tl ind in
     prefix, (string_list_sep "," valtl)

and match_pattern_complex state_kind opt patl sl p1 p2 in_term ind =
  (* decomposition of every function *)
  let rec decompos = function
    | PatVar(b) ->
        let bname = get_binder_name b in
        ([], bname, [], [b])
    | PatEqual(t) ->
        let n = create_fresh_name "bvar_" in
        let eq = equal t.t_type in
        ([], n, [(eq, n, translate_term_get_val state_kind t ind)], [])
    | PatTuple(f, pl) ->
        let n = create_fresh_name "bvar_" in
        let (func, bij) = decompos_pattuple ind f pl in
        let decompos_list = List.map decompos pl in
        (
          (n,func, bij, List.map (fun (x,y,z,_)->y) decompos_list)::
            (List.concat (List.map (fun (x,y,z,_)->x) decompos_list)),
          n,
          List.concat (List.map (fun (x,y,z,_)->z) decompos_list),
          List.concat (List.map (fun (_,_,_,t)->t) decompos_list)
        )
  in
  let rec andlist = function
    | [] -> "true"
    | [x] -> x
    | x::y -> x^" && "^(andlist y)
  in
  let decompos_list = List.map decompos patl in
  let func = List.concat (List.map (fun (x,y,z,t)->x) decompos_list) in
  let assign = List.map2 (fun (x,y,z,t) s -> (y,s)) decompos_list sl in
  let tests = List.concat (List.map (fun (x,y,z,t)-> z) decompos_list) in
  let all_binders = List.concat (List.map (fun (_,_,_,t)->t) decompos_list) in
  let prefix = String.concat "" (List.map (fun (eq, n, (prefix, s)) -> prefix) tests) in
  let success =
    String.concat "" (List.map (fun b -> def_var b ind) all_binders) ^
    code_block p1 (ind ^ "  ") true
  in
  let aux ovar p1 p2_str =
    let p2_block = code_block (fun _ -> p2_str) (ind ^ "  ") false in
    "\n" ^
    (String.concat
      ""
      (List.map
        (fun (name, s) ->
          ind ^ "let " ^ name ^ " = " ^ s ^ " in\n") assign)) ^
    (* decompos functions *)
    (match ovar with Some m -> "let " ^ m ^ " =\n" | _ -> "") ^
    (List.fold_left (^) ""
       (List.map
          (fun (n, f, bij, vl) ->
	    if bij then
	      ind ^ "  let (" ^ (string_list_sep "," vl) ^ ") = " ^ f n ^ " in\n"
	    else
              ind ^ "  match " ^ (f n) ^ " with\n" ^
              ind ^ "  | None ->" ^ code_block_add_line_prefix p2_block "  " ^ "\n" ^
              ind ^ "  | Some (" ^ (string_list_sep "," vl) ^ ") ->\n") func)
    ) ^
    (* tests *)
    (if tests == [] then success
     else
      ind ^ "  if " ^ (andlist (List.map (fun (eq, n, (prefix, s)) -> eq ^ " " ^ n ^ " " ^ s) tests)) ^ " then" ^
      success ^
      "else" ^
      p2_block ^ "\n") ^ (match ovar with Some m -> ind ^ "in\n" | _ -> "") ^
    ind ^ ""
  in
  (* We reuse p2_str to make sure p2 is only evaluated once. p1 is evaluated only once anyway. *)
  let p2_str = p2 "" in
  if is_complicated p2_str then
    let all_binders = List.map get_binder_name all_binders in
    (* the result of the match needs to be assigned to a new variable. *)
    let m = create_fresh_name "bvar_" in
    prefix,
    debug_comment "match_pattern_complex" ^
    (aux (Some m) (fun s -> "Some (" ^ (string_list_sep "," all_binders) ^ ")") "None") ^ "\n" ^
    (* the new variable needs to be used here. *)
    ind ^ "match " ^ m ^ " with\n" ^
    ind ^ "| None ->\n" ^
    ind ^ "  " ^ (code_block_add_line_prefix p2_str (ind ^ "      ")) ^ "\n" ^
    ind ^ "| Some (" ^ (string_list_sep "," all_binders) ^ ") ->\n" ^
    ind ^ "  " ^ (p1 (ind ^ "      "))
  else
    prefix,
    debug_comment "match_pattern_complex" ^
    aux None p1 p2_str

and match_pattern state_kind opt (pat:Types.pattern) (var:string) (p1:string -> string) (p2: string -> string) (in_term:bool) ind =
  match pat with
  | PatVar(b) ->
      "",
      debug_comment "match_pattern PatVar" ^ "\n" ^
      ind ^ "let " ^ (get_binder_name b) ^ " = " ^ var ^ " in\n" ^
      def_var b ind ^
      (p1 ind)
  | PatEqual(t) ->
      let (prefixt, valt) = translate_term_get_val state_kind t ind in
      let eq = equal t.t_type in
      prefixt,
      ind ^ "if " ^ eq ^ " " ^ valt ^ " " ^ var ^ " then" ^
      debug_comment "match_pattern PatEqual" ^
      (code_block p1 ind true) ^
      "else" ^
      (code_block p2 ind true)
  | _ -> match_pattern_complex state_kind opt [pat] [var] p1 p2 in_term ind

and match_pattern_list opt patl vars (p1:string -> string) (p2:string -> string) in_term ind =
  match patl, vars with
  | [pat], [var] ->
      match_pattern NState opt pat var p1 p2 in_term ind
  | _ ->
      match_pattern_complex NState opt patl vars p1 p2 in_term ind

and match_pattern_from_input opt pl (vars:string list) (next:string -> string) od ind =
  match od.list_of_defs with
  | Top (_, process) | NonTop [_,_,_,_,_,process] ->
      (* The oracle has a single definition, try to reuse CryptoVerif variable names
         as arguments *)
      let pat_args = List.combine pl vars in
      let need_match_pat_args = List.filter (function
	| (PatVar b, var) ->
	    (* Verify for safety that [var] was correctly chosen *)
	    assert (var = get_binder_name b);
	    false
	| _ -> true) pat_args
      in
      let (pl, vars) = List.split need_match_pat_args in
      let (prefix, matchfilt) = match_pattern_list opt pl vars next (yield_transl od) false ind in
      prefix ^ matchfilt
  | _ ->
      let (prefix, matchfilt) = match_pattern_list opt pl vars next (yield_transl od) false ind in
      prefix ^ matchfilt

let needs_sid od =
  (od.following_oracles <> None && od.following_oracles <> (Some [])) ||
  od.has_queried_var ||
  (match od.list_of_defs with
  | Top (needs_current_sid, _) -> needs_current_sid != None
  | NonTop dl ->
      List.exists (fun (_,_,_,_,needs_current_sid,_) ->
	needs_current_sid != None) dl)

let needs_current_sid od =
  match od.list_of_defs with
  | Top (needs_current_sid, _) -> needs_current_sid
  | NonTop dl ->
      match List.find_opt (fun (_,_,_,_,needs_current_sid,_) ->
	needs_current_sid != None) dl with
      | Some (_,_,_,_,needs_current_sid,_) -> needs_current_sid
      | None -> None

let needs_received_sid od =
  match od.list_of_defs with
  | Top _ -> None
  | NonTop dl ->
      match List.find_opt (fun (_,_,_,needs_received_sid,_,_) ->
	needs_received_sid != None) dl with
      | Some (_,_,_,needs_received_sid,_,_) -> needs_received_sid
      | None -> None

let takes_id od =
  match od.list_of_defs with
  | Top _ -> false
  | NonTop _ -> true

let oracle_precondition od args state_variable =
  get_oracle_precondition_name od.oracle_name ^ " " ^
  (if takes_id od then session_id_variable ^ " " else "") ^
  (string_list_sep "" (List.map (fun arg -> arg^" ") args)) ^
  state_variable

let oracle_precondition_wl od args state_variable =
  (if takes_id od then "is_local " ^ session_id_variable ^ " " ^ state_variable ^ " /\\ " else "") ^
  oracle_precondition od args state_variable

let get_interface_spec module_name opt oracles =
  preamble (module_name ^ ".Spec") ^
  StringMap.fold
    (fun on od s -> s ^
      let args = create_oracle_args od in
      let takes_id = takes_id od in
      (* name of the function *)
      let fun_on = get_oracle_function_name on in
      let lemma_on = get_lemma_oracle_function_name on in
      "let " ^ fun_on ^ " " ^
      (* we take a session id as input in some cases *)
      (if takes_id then "(" ^ session_id_variable ^ ": SidMap.sidt) " else "") ^
      (* names for the explicit oracle parameters *)
      (string_list_sep " " (List.map2 (fun arg t -> "("^arg^": "^ get_type_name t^")") args od.input_type)) ^
      (* we always take the current state as input *)
      " (" ^ get_state_decl NState ^ ") =\n" ^
      (* first line ends here *)
      (* if this continues a session, retrieve the entry *)
      (match od.list_of_defs with
      | Top (needs_current_sid, p) ->
          (match p.i_desc with
          | OracleDecl (_, patl, p1) ->
              (if needs_sid od then
                "let " ^ state_variable ^ ", " ^ session_id_variable ^ " = state_reserve_session_id " ^ state_variable ^ " in\n"
              else "") ^
	      (match needs_current_sid with
	      | None -> ""
	      | Some i -> "let " ^ get_sid i ^ " = " ^ session_id_variable ^ " in\n") ^
              match_pattern_from_input opt patl args (translate_oprocess od p1) od ("      ")
          | _ -> Parsing_helper.internal_error "expected input process"
          )
      | NonTop dl ->
          "match " ^
          (if od.under_repl then "get_session_entry "
          else "get_and_remove_session_entry ") ^
          state_variable ^ " " ^
          get_oracle_name od.oracle_name ^ " " ^ session_id_variable ^ " with\n" ^
          "| " ^ (if od.under_repl then "None -> " else state_variable ^ ", None -> ") ^ state_variable ^ ", None\n" ^
          "| " ^ (if od.under_repl then "Some (se:" else state_variable ^ ", Some (se:") ^ get_protocol_id "session_entry" ^ ") ->\n" ^
	  (match needs_received_sid od with
	  | None -> ""
	  | Some i ->
	      "  let " ^ get_sid i ^ " = " ^ session_id_variable ^ " in\n") ^
          (if od.under_repl && needs_sid od then
            "  let " ^ state_variable ^ ", " ^ session_id_variable ^ " = state_reserve_session_id " ^ state_variable ^ " in\n"
          else "") ^
	  (match needs_current_sid od with
	  | None -> ""
	  | Some i ->
	      "  let " ^ get_sid i ^ " = " ^ session_id_variable ^ " in\n") ^
            "  match se with\n" ^
          (* And now we treat all definitions of the oracle/returns of the previous oracle.
             We know that we are in a NonTop case because we are in takes_id. *)
          (List.fold_left
             (fun s (nr, bl, sidl, _, _, p) -> s ^
               "    | " ^ get_return_name nr od.oracle_name ^
               (String.concat ""
                  (List.map (fun b -> " " ^ get_binder_name b) bl)) ^
               (String.concat ""
                  (List.map (fun i -> " " ^ get_sid i) sidl)) ^
	       " ->\n" ^
               (match p.i_desc with
               | OracleDecl (_, patl, p1) ->
                   match_pattern_from_input opt patl args (translate_oprocess od p1) od ("      ")
               | _ -> Parsing_helper.internal_error "expected input process"
               )
             )
             ""
             dl
          )

      ) ^ "\n\n" ^

      (* name of the function *)
      "val " ^ lemma_on ^ " " ^
      (* we take a session id as input in some cases *)
      (if takes_id then "(" ^ session_id_variable ^ ": SidMap.sidt) " else "") ^
      (* names for the explicit oracle parameters *)
      (string_list_sep " " (List.map2 (fun arg t -> "("^arg^": "^ get_type_name t^")") args od.input_type)) ^
      (* we always take the current state as input *)
      " (" ^ get_state_decl NState ^ ") :\n" ^
      "  Lemma (requires (" ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "InvariantLemmas.inv' " ^ state_variable ^ " /\\ " ^
      (oracle_precondition_wl od args state_variable) ^ "))\n"^
      "    (ensures (" ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "InvariantLemmas.local_rel' " ^ state_variable ^
      " (" ^ fun_on ^ " " ^
      (if takes_id then session_id_variable ^ " " else "") ^
      (string_list_sep " " args) ^ " " ^ state_variable ^ ")._1))\n\n"
    )
    oracles
    ""

let get_implementation_spec module_name opt oracles =
  preamble (module_name ^ ".Spec") ^
  "(* PLEASE ADD PROOFS FOR THE LEMMAS *)\n\n" ^
  StringMap.fold
    (fun on od s -> s ^
      let args = create_oracle_args od in
      let takes_id =
	match od.list_of_defs with
	| Top _ -> false
        | NonTop _ -> true
      in
      (* name of the function *)
      "let " ^ get_lemma_oracle_function_name on ^ " " ^
      (* we take a session id as input in some cases *)
      (if takes_id then "(" ^ session_id_variable ^ ": SidMap.sidt) " else "") ^
      (* names for the explicit oracle parameters *)
      (string_list_sep " " (List.map2 (fun arg t -> "("^arg^": "^ get_type_name t^")") args od.input_type)) ^
      (* we always take the current state as input *)
      " (" ^ get_state_decl NState ^ ")  = ()\n\n"
    )
    oracles
    ""

let cvst_args module_name od =
  let takes_id =
    match od.list_of_defs with
    | Top _ -> false
    | NonTop _ -> true
  in
  let args = create_oracle_args od in
  "(" ^
  (match od.output_type with
  | None -> "unit" (* We come here if all branches yield *)
  | Some tl -> "option (" ^
      (* return session id if needed *)
      (if needs_sid od && od.under_repl then "SidMap.sidt * " else "") ^
      (* output types *)
      (match tl with
      | [] -> "unit"
      | _ -> String.concat " * " (List.map get_type_name tl)) ^
      ")"
  ) ^
  ") (fun s1 -> " ^ oracle_precondition_wl od args "s1" ^ ") (fun s1 res s2 -> (s2, res) == " ^ !protocol_name_allcaps ^ "." ^ (!current_side) ^ module_name ^ ".Spec." ^ get_oracle_function_name od.oracle_name ^
       (if takes_id then " " ^ session_id_variable ^ " " else " ") ^
       (String.concat " " args) ^
       " s1" ^ (if needs_sid od && od.under_repl then " /\\ (match res with | Some(sid" ^
       (match od.output_type with
       | None | Some [] -> ",_"
       | Some tl -> String.concat "" (List.map (fun _ -> ",_") tl)) ^
       ") -> is_local sid s2 | None -> True)" else "") ^ ")"


let get_interface module_name opt oracles =
  preamble module_name ^
  "open " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Effect\n\n"^
  StringMap.fold
    (fun on od s -> s ^
      "val " ^ get_oracle_function_name on ^ ": " ^
       (match od.list_of_defs with
        | Top _ ->
	    (* Add unit argument if the function would have no argument at all *)
	    if od.input_type = [] then "unit -> " else ""
        | NonTop _ -> "(" ^ session_id_variable ^ ":SidMap.sidt) -> ") ^
      (String.concat ""
	 (List.map2
	    (fun s t -> "(" ^ s  ^ ": " ^ get_type_name t ^ ") -> ")
	    (create_oracle_args od) od.input_type)) ^
       "CVST1Call "^ cvst_args module_name od ^ "\n\n"
    )
    oracles
    ""

let get_implementation module_name opt oracles =
  preamble module_name ^
  "friend " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Effect\n\n"^
  StringMap.fold
    (fun on od s -> s ^
      let args_vars = create_oracle_args od in
      let args_typed =
	" " ^
	(match od.list_of_defs with
        | Top _ ->
	    (* Add unit argument if the function would have no argument at all *)
	    if od.input_type = [] then "() " else ""
        | NonTop _ -> "(" ^ session_id_variable ^ ":SidMap.sidt) ") ^
	(String.concat ""
	   (List.map2
	      (fun s t -> "(" ^ s  ^ ": " ^ get_type_name t ^ ") ")
	      args_vars od.input_type))
      in
      let args =
	(match od.list_of_defs with
        | Top _ -> " "
        | NonTop _ -> " " ^ session_id_variable ^ " ") ^
	(String.concat " " args_vars)
      in
      let args_with_unit =
	match od.list_of_defs with
        | Top _ ->
	    (* Add unit argument if the function would have no argument at all *)
	    if od.input_type = [] then " ()" else args
        | NonTop _ -> args
      in
      let repr_on = get_repr_oracle_function_name on in
      let lemma_on = get_lemma_oracle_function_name on in
      let fun_on = get_oracle_function_name on in
      "val " ^ repr_on ^ args_typed ^ ": repr_inv " ^ cvst_args module_name od ^ "\n" ^
      "let " ^ repr_on ^ args_with_unit ^ " = fun s1 ->
  " ^ !protocol_name_allcaps ^ "." ^ (!current_side) ^ module_name ^ ".Spec." ^ lemma_on ^ args ^ " s1;
  " ^ !protocol_name_allcaps ^ "." ^ (!current_side) ^ module_name ^ ".Spec." ^ fun_on ^ args ^ " s1\n\n" ^
      "let " ^ fun_on ^ args_typed ^
       "= cvst_reflect ("^ repr_on ^ args_with_unit ^ ")\n\n"
    )
    oracles
    ""


let prepare_letfun_1impl (impl_letfuns, _) =
  List.iter (fun (f,bl,res) ->
    f.f_impl_needs_full_state <- needs_full_state res;
    if not f.f_impl_needs_full_state then
      f.f_impl_ent <- needs_entropy res;
    if f.f_impl_needs_full_state && (f.f_impl != SepFun && f.f_impl != No_impl) then
      error ("Function " ^ f.f_name ^ " needs the state; it cannot be implemented as a basic F* function.")
	) impl_letfuns

let prepare_letfun_2impl (impl_letfuns1, _) (impl_letfuns2, _) =
  List.iter2 (fun (f1,bl1,res1) (f2,bl2,res2) ->
    assert (f1 == f2);
    f1.f_impl_needs_full_state <- needs_full_state res1 || needs_full_state res2;
    if not f1.f_impl_needs_full_state then
      begin
	f1.f_impl_ent <- needs_entropy res1 || needs_entropy res2;
	f1.f_impl_diff_side <- diff_side res1 || not (Terms.equal_terms res1 res2)
      end;

    if f1.f_impl_needs_full_state && (f1.f_impl != SepFun && f1.f_impl != No_impl) then
      error ("Function " ^ f1.f_name ^ " needs the state; it cannot be implemented as a basic F* function.");

    if f1.f_impl_diff_side && (f1.f_impl != SepFun && f1.f_impl != No_impl) then
      error ("Function " ^ f1.f_name ^ " has two different implementations via the diff[.,.] construct; it cannot be implemented as a single F* function.")
	) impl_letfuns1 impl_letfuns2

let get_letfun_implementation module_name letfuns =
  preamble module_name ^
  (string_list_sep "\n"
     (List.map
        (fun (f,bl,res,translate) ->
	  if not translate then "" else

	  let state_kind =
	    if f.f_impl_needs_full_state then
	      Some NState
	    else if f.f_impl_ent then
	      Some NEntropy
	    else
	      None
	  in

	  (* val *)
	  let fname = get_letfun_name f in
           "val " ^ fname ^ " : " ^
           (if bl = [] then
              if state_kind == None then "unit -> " else ""
            else
              (string_list_sep " -> " (List.map (fun b -> get_type_name b.btype) bl)) ^ " -> "
           ) ^
          (match state_kind with
	  | Some s -> get_state_type s ^ " -> " ^ get_state_type s ^ " * "
	  | None -> "") ^
	  (get_type_name res.t_type) ^ "\n" ^

	  (* let *)
          "let " ^ fname ^ " " ^
          (if bl = [] then
            if state_kind == None then "()" else ""
          else
            (string_list_sep " "
               (List.map
                  (fun b -> ("(" ^ (get_binder_name b) ^ " : " ^ (get_type_name b.btype) ^ ")")) bl)
               )
              ) ^
          (match state_kind with
	  | Some s -> " " ^ in_parens (get_state_decl s)
	  | None -> "") ^
          " =\n" ^
          (match state_kind with
	  | Some s -> translate_term_get_pair s res "  "
          | None -> translate_term_ns res "  ") ^
          "\n"
        )
        letfuns
     )
  )

let check_no_module_name_clash (impl_letfuns, impl_processes) =
  let basic_modules = [
    (* cv2fstar library *)
    "CVTypes"; "CVSTBasic"; "Network"; "Time"; "Tuples"; "SidMap"; "Random";
    "Crypto"; "State"; "StateLemmas"; "Utils";
    (* Generated modules for protocols *)
    "Types"; "Functions"; "Tables"; "Variables";"Events";
    "Sessions"; "Protocol"; "Invariant"; "InvariantLemmas"; "Effect";
    "Queries"; "QueryLemmas"; "Equations" ] in
  let reserved_modules =
    if impl_letfuns <> [] then letfun_module :: basic_modules else basic_modules
  in
  let rec check_clash = function
    | [] -> ()
    | (x, _, _) :: rest ->
        List.iter
          (fun m ->
             if x = m then error ("Module " ^ x ^ " clashes with reserved module");
             if String.uppercase_ascii x = String.uppercase_ascii m then
               error
                 ( "Module " ^ x ^ " clashes with reserved module " ^ m
                   ^ " (filenames are case-insensitive on Windows)" ))
          reserved_modules;
        List.iter
          (fun (x', _, _) ->
             if String.uppercase_ascii x = String.uppercase_ascii x' then
               error
                 ( "Module " ^ x ^ " clashes with module " ^ x'
                   ^ " (filenames are case-insensitive on Windows)" ))
          rest;
        check_clash rest
  in
  check_clash impl_processes

let implemented_function f =
  (!Settings.fstar_minimal_functions = false) ||
  (match f.f_cat with
  | Proj _ -> true
  | _ ->
      match f.f_impl with
      | No_impl -> false
      | _ -> true) ||
  (List.memq f (!functions))

let add_type t =
  if user_defined_type t && not (List.memq t !types) then types := t::!types
let add_eq_type t =
  if user_defined_type t && not (List.memq t !eq_types) then eq_types := t::!eq_types
let add_ser_type t =
  if user_defined_type t && not (List.memq t !ser_types) then ser_types := t::!ser_types
let add_debug_display_type t =
  if !Settings.fstar_debug then add_ser_type t
let add_serde_type t =
  add_ser_type t;
  if user_defined_type t && not (List.memq t !serde_types) then serde_types := t::!serde_types
let add_random_type t =
  if user_defined_type t && not (List.memq t !random_types) then random_types := t::!random_types

let start_tag = 1
let tuple_types = ref []
let add_tuple_type tl =
  if not (List.exists (Terms.equal_lists (==) tl) (!tuple_types)) then tuple_types := tl :: !tuple_types

let add_table tab =
  if not (List.memq tab !tables) then tables := tab::!tables

let add_event e =
  if not (List.memq e !events) then events := e::!events

let add_inv_function f =
  if user_defined_function f && not (List.memq f !inv_functions) then inv_functions := f::!inv_functions

let rec add_function f =
  if user_defined_function f && not (List.memq f !functions) then
    begin
      functions := f::!functions;
      match f.f_cat with
      | Proj(finv,_) -> add_function finv; add_inv_function finv
      | _ -> ()
    end

let unionq_pair (l1,l2) (l1',l2') =
  Terms.unionq l1 l1', Terms.unionq l2 l2'

let eq_prev_oracle p1 p2 =
  match p1, p2 with
  | None, None -> true
  | Some o1, Some o2 -> o1 == o2
  | _ -> false
    
let rec get_iprocess_oracles p under_repl previous_oracle nb_of_return =
  match p.i_desc with
  | Nil -> [], []
  | OracleDecl (o, patl, p1)  ->
     List.iter get_pattern_types patl;
     let input_type = List.map Terms.get_type_for_pattern patl in
     let (fv, bv_no_repl, _, _) = impl_get_vars p in
     let fv = BinderSet.elements fv in
     let has_queried_var =
       List.exists (fun b -> BinderSet.mem b bv_no_repl) (!prepared_queries_ref).public_vars ||
       List.exists (fun (b,_) -> BinderSet.mem b bv_no_repl) (!prepared_queries_ref).secret_vars
     in
     let oracle =
       try
	 let oracle = StringMap.find o.ooracle.oname !oracles in
	 oracle.has_queried_var <- has_queried_var || oracle.has_queried_var;
	 if oracle.oracle_name <> o.ooracle.oname then
           error ("Oracle name " ^ oracle.oracle_name ^
		  " expected to be " ^ o.ooracle.oname ^
		  " at occ " ^ string_of_int p.i_occ ^ ".")
	 else if oracle.under_repl <> under_repl then
           error ("Oracle " ^ oracle.oracle_name ^
		  " expected to be "^ (if under_repl then "" else "not ") ^
		  " under replication at occ " ^ string_of_int p.i_occ ^ ".")
	 else if not (eq_prev_oracle oracle.previous_oracle previous_oracle) then
           error ("Oracle " ^ oracle.oracle_name ^
		  " does not have the expected same previous oracle as " ^
		  "other occurrences of this oracle, at occ " ^
		  string_of_int p.i_occ ^ ".")
	 else
           if not (Terms.equal_lists (==) oracle.input_type input_type) then
             error ("Oracle " ^ oracle.oracle_name ^
		    " has different input type than other occurrences of this oracle" ^
		    ", at occ " ^ string_of_int p.i_occ ^ ".")
	   else
	     oracle
       with Not_found ->
	 let oracle = {
           oracle_name = o.ooracle.oname;
           under_repl = under_repl;
	   number_repl_above = List.length o.ooracle.oindices_type;
           has_queried_var = has_queried_var;
           previous_oracle = previous_oracle;
           input_type = input_type;
           output_type = None;
           following_oracles = None;
           list_of_returns = [];
           list_of_defs = NonTop []; (* dummy initialization value *)
           seen_returns = 0
	 } in
	 oracles := StringMap.add o.ooracle.oname oracle !oracles;
	 oracle
     in
     let loc_tables, new_tables = get_oprocess_oracles p1 oracle in
     let needs_cur_sid_of o =
       if List.exists (fun tbl -> tbl.tbllocalopt = Some o.number_repl_above) loc_tables then
	 Some o.number_repl_above
       else
	 None
     in
     let needs_current_sid = needs_cur_sid_of oracle in
     let rec needs_previous_sids o =
       match o.previous_oracle with
       | None -> []
       | Some prev_oracle ->
	   let prev_needs = needs_previous_sids prev_oracle in
	   if o.under_repl then
	     match needs_cur_sid_of prev_oracle with
	     | None -> prev_needs
	     | Some i -> i::prev_needs
	   else
	     prev_needs
     in
     let needs_received_sid, needs_previous_sids =
       match previous_oracle with
       | None -> None, []
       | Some prev_oracle ->
	   (if under_repl then
	     needs_cur_sid_of prev_oracle
	   else
	     None),
	   needs_previous_sids prev_oracle
     in
     oracle.list_of_defs <-
	begin
        match oracle.list_of_defs with
        | Top (_, p2) ->
	    error ("Oracle " ^ oracle.oracle_name ^
		   " is a top-level oracle and should not occur multiple times, " ^
		   "but does so at occ " ^ string_of_int p2.i_occ ^ ".")
        | NonTop l ->
	    match previous_oracle with
	    | None ->
		if l = [] then
		  Top (needs_current_sid, p)
		else
                  error ("Oracle " ^ oracle.oracle_name ^
			 " is not a top-level oracle but does not have a previous oracle," ^
			 " at occ " ^ string_of_int p.i_occ ^ ".")
	    | Some _ ->
                NonTop ((nb_of_return, fv, needs_previous_sids, needs_received_sid, needs_current_sid, p)::l)
	end;
     [o.ooracle.oname, fv, needs_previous_sids],
     List.filter (fun tbl -> not (List.memq tbl new_tables)) loc_tables
  | Par (p1, p2) ->
      let fo1, loc_tables1 = get_iprocess_oracles p1 under_repl previous_oracle nb_of_return in
      let fo2, loc_tables2 = get_iprocess_oracles p2 under_repl previous_oracle nb_of_return in
      fo1 @ fo2, Terms.unionq loc_tables1 loc_tables2
  | Repl (_, p1) ->
      get_iprocess_oracles p1 true previous_oracle nb_of_return

and get_oprocess_oracles p0 oracle =
  match p0.p_desc with
  | Yield | EventAbort _ -> [],[]
  | EventP (e, p) -> get_event_types e; get_oprocess_oracles p oracle
  | Restr (b, p) ->
      add_type b.btype;
      add_random_type b.btype;
      get_oprocess_oracles p oracle
  | Let (pat, t, p1, p2) ->
      get_pattern_types pat;
      get_term_types t;
      unionq_pair (get_oprocess_oracles p1 oracle)
	(get_oprocess_oracles p2 oracle)
  | Test (t, p1, p2) ->
      get_term_types t;
      unionq_pair (get_oprocess_oracles p1 oracle)
	(get_oprocess_oracles p2 oracle)
  | Get (tab, patl, topt, p1, p2, _) ->
      add_table tab;
      (* For <PROTOCOL>.Tables.print
	 If we decide to write tables to a file, add_serde_type
	 may be needed. *)
      List.iter add_debug_display_type tab.tbltype;
      List.iter get_pattern_types patl;
      (match topt with
      | Some t -> get_term_types t
      | None -> ());
      let loc_tables, new_tables =
	unionq_pair (get_oprocess_oracles p1 oracle)
	  (get_oprocess_oracles p2 oracle)
      in
      (if tab.tbllocalopt = None || List.memq tab loc_tables then loc_tables else tab::loc_tables), new_tables
  | Insert (tab, tl, p) ->
      add_table tab;
      (* For <PROTOCOL>.Tables.print
	 If we decide to write tables to a file, add_serde_type
	 may be needed. *)
      List.iter add_debug_display_type tab.tbltype;
      List.iter get_term_types tl;
      let loc_tables, new_tables = get_oprocess_oracles p oracle in
      (if tab.tbllocalopt = None || List.memq tab loc_tables then loc_tables else tab::loc_tables), new_tables
  | Find (fl, ep, _) -> error "Find not supported"
  | Return (tl, p) ->
      List.iter get_term_types tl;
      let ot = List.map (fun t -> t.t_type) tl in
      oracle.seen_returns <- oracle.seen_returns + 1;
      (match oracle.output_type with
      | None -> oracle.output_type <- Some ot
      | Some l ->
         if not (Terms.equal_lists (==) l ot) then
           error ("Oracle " ^ oracle.oracle_name ^
           " has different output type than other occurrences of this oracle" ^
           ", at occ " ^ string_of_int p.i_occ ^ ".") );

      let (fo, loc_tables) = get_iprocess_oracles p false (Some oracle) oracle.seen_returns in
      let following_oracles = List.map (fun (o,_,_) -> o) fo in
      (match oracle.following_oracles with
      | None -> oracle.following_oracles <- Some following_oracles
      | Some l ->
      	  if l <> following_oracles then
            error ("Oracle " ^ oracle.oracle_name ^
              " has different following oracles than other occurrences of this oracle" ^
              ", at occ " ^ string_of_int p.i_occ ^ ".") );
      oracle.list_of_returns <- (oracle.seen_returns, fo, p0) :: oracle.list_of_returns;
      loc_tables, []
  | NewTable(tbl, p) ->
      (* It is enough to collect tables at insert and get since
         the table is created at the first insert. *)
      let loc_tables, new_tables = get_oprocess_oracles p oracle in
      loc_tables, tbl :: new_tables

and get_term_types t =
  match t.t_desc with
  | Var (b, tl) -> add_type b.btype; List.iter get_term_types tl
  | ReplIndex _ -> ()
  | FunApp (f, tl) ->
      (if f.f_name = "" then (
        List.iter (fun t -> add_serde_type t.t_type) tl;
        add_tuple_type (List.map (fun t -> t.t_type) tl)
      ) else (
        add_function f;
        (* return type *)
        add_type (snd f.f_type);
        (* input types *)
        List.iter add_type (fst f.f_type);
        (match f.f_impl with | FuncEqual | FuncDiff -> add_eq_type (List.hd tl).t_type | _ -> ())
      ));
      List.iter get_term_types tl;
  | TestE (t1, t2, t3) ->
      get_term_types t1;
      get_term_types t2;
      get_term_types t3;
  | FindE _ -> Parsing_helper.input_error "Find not supported (implementation)" t.t_loc
  | LetE (pat, t1, t2, topt) ->
      get_pattern_types pat;
      get_term_types t1;
      get_term_types t2;
      (match topt with
      | Some t3 -> get_term_types t3;
      | None -> ())
  | ResE (b, t) ->
      add_type b.btype;
      add_random_type b.btype;
      get_term_types t
  | EventAbortE _ -> Parsing_helper.input_error "event_abort not supported in F* implementation" t.t_loc
  | EventE (t, p) ->
      get_event_types t;
      get_term_types p
  | InsertE (tbl, tl, t) ->
      add_table tbl;
      (* For <PROTOCOL>.Tables.print
	 If we decide to write tables to a file, add_serde_type
	 may be needed. *)
      List.iter add_debug_display_type tbl.tbltype;
      List.iter get_term_types tl;
      get_term_types t
  | GetE (tbl, patl, topt, t1, t2, _) ->
      add_table tbl;
      (* For <PROTOCOL>.Tables.print
	 If we decide to write tables to a file, add_serde_type
	 may be needed. *)
      List.iter add_debug_display_type tbl.tbltype;
      List.iter get_pattern_types patl;
      (match topt with
      | Some t -> get_term_types t
      | None -> ());
      get_term_types t1;
      get_term_types t2

and get_event_types e =
  match e.t_desc with
  | FunApp (ef, repl_indices :: param_list) ->
      add_event ef;
      (* For <PROTOCOL>.Events.<protocol>_print_event *)
      List.iter add_debug_display_type (List.tl (fst ef.f_type));
      List.iter get_term_types param_list
  | _ -> Parsing_helper.internal_error "Expected FunApp for event (do_implementation)"

and get_pattern_types pat =
  match pat with
  | PatVar b -> add_type b.btype
  | PatTuple (f, pl) ->
      (* As we are in a pattern, it is actually the inverse function that we need. *)
      if f.f_name = "" then
        begin
          List.iter (fun p ->
            let ty = Terms.get_type_for_pattern p in
            add_serde_type ty) pl;
          add_tuple_type (List.map Terms.get_type_for_pattern pl)
        end
      else
        begin
          add_function f;
          add_inv_function f;
          add_type (snd f.f_type);
          List.iter add_type (fst f.f_type);
          (* We are generating lemmas for inverse functions, so we need equality test. *)
          add_eq_type (snd f.f_type);
          List.iter add_eq_type (fst f.f_type)
        end;
      List.iter get_pattern_types pl
  | PatEqual t -> add_eq_type t.t_type; get_term_types t

let rec get_qterm_types = function
  | QEvent(_,t) -> get_event_types t
  | QTerm t -> get_term_types t
  | QNot(QEvent(false,t)) -> get_event_types t
  | QNot _ | QExists _ | QForall _ -> assert false
  | QAnd(t1,t2) | QOr(t1,t2) ->
      get_qterm_types t1; get_qterm_types t2

let get_corresp_types (l1,t2) =
  List.iter (fun (_, t) -> get_event_types t) l1;
  get_qterm_types t2

let rec term_is_translatable t =
  match t.t_desc with
  | Var (b, tl) -> List.for_all term_is_translatable tl
  | ReplIndex _ -> true
  | FunApp (f, tl) ->
      if f.f_name = "" || implemented_function f then
        List.for_all term_is_translatable tl
      else
	begin
          info ("1 equation will not be translated because there is no implementation for " ^ f.f_name);
	  false
	end
  | TestE (t1, t2, t3) ->
      term_is_translatable t1 &&
      term_is_translatable t2 &&
      term_is_translatable t3
  | FindE _ -> Parsing_helper.input_error "Find not supported (implementation)" t.t_loc
  | LetE (pat, t1, t2, topt) ->
      pattern_is_translatable pat &&
      term_is_translatable t1 &&
      term_is_translatable t2 &&
      (match topt with
      | Some t3 -> term_is_translatable t3
      | None -> true)
  | ResE (b, t) ->
      term_is_translatable t
  | EventAbortE _ -> Parsing_helper.input_error "event_abort not supported in F* implementation" t.t_loc
  | EventE (t, p) ->
      event_is_translatable t &&
      term_is_translatable p
  | InsertE (tbl, tl, t) ->
      List.for_all term_is_translatable tl &&
      term_is_translatable t
  | GetE (tbl, patl, topt, t1, t2, _) ->
      List.for_all pattern_is_translatable patl &&
      (match topt with
      | Some t -> term_is_translatable t
      | None -> true) &&
      term_is_translatable t1 &&
      term_is_translatable t2

and event_is_translatable e =
  match e.t_desc with
  | FunApp (ef, repl_indices :: param_list) ->
      List.for_all term_is_translatable param_list
  | _ -> Parsing_helper.internal_error "Expected FunApp for event (do_implementation)"

and pattern_is_translatable p =
  match p with
  | PatVar b -> true
  | PatTuple (f, pl) ->
      if f.f_name = "" || implemented_function f then
	List.for_all pattern_is_translatable pl
      else
	begin
          info ("1 equation will not be translated because there is no implementation for " ^ f.f_name);
	  false
	end
  | PatEqual t -> term_is_translatable t

(* translate built-in equational theories *)
let lemma_id i =
  let si = string_of_int i in
  let s = "lemma_" ^ si in
  check_no_identifier_collision [ "lemma"; si ] s

let get_fun_equations impl first_nr =

  let header i = (if impl then "let " else "val ") ^ lemma_id i ^ " " in

  let opt_lemma s = (if impl then " = ()" else ": Lemma ("^s^")") in

  let info s = if impl then () else info s in

  (* f is always a binary function with both inputs of the same type
     in the currently supported builtin equational theories. *)
  let typename f =
    (get_type_name (List.hd (fst f.f_type))) in

  let eq_result f =
    equal (snd f.f_type) in

  let commut f x =
    "(a b:" ^ typename f ^ ")" ^ opt_lemma (
    eq_result f ^ " (" ^ x ^ " a b) (" ^ x ^ " b a)") ^ "\n\n" in

  let assoc f x =
    "(a b c :" ^ typename f ^ ")" ^ opt_lemma (
    eq_result f ^ " (" ^ x ^ " a (" ^ x ^ " b c)) (" ^ x ^ " (" ^ x ^ " a b) c)") ^ "\n\n" in

  let neutral f x n =
    "(a:" ^ typename f ^ ")" ^ opt_lemma ("(" ^
    eq_result f ^ " (" ^ x ^ " a " ^ n ^ ") a) /\\ (" ^
    eq_result f ^ "(" ^ x ^ " " ^ n ^ " a) a)") ^ "\n\n" in

  let cancel f x n =
    "(a:" ^ typename f ^ ")" ^ opt_lemma (
    eq_result f ^ " (" ^ x ^ " a a) " ^ n ^ "") ^ "\n\n" in

  let inverse f x n inv =
    "(a:" ^ typename f ^ ")" ^ opt_lemma (
    eq_result f ^ " (" ^ x ^ " a (" ^ inv ^ " a)) " ^ n ^ " /\\ " ^
    eq_result f ^ " (" ^ x ^ " (" ^ inv ^ " a) a) " ^ n ^ "") ^ "\n\n" in

  let is_fstar_eq ty =
    "(a b:" ^ get_type_name ty ^ ")" ^ opt_lemma ("(" ^ equal ty ^ " a b) <==> (a == b)") ^ "\n\n" in
(*
  let refl t x =
    "(a:" ^ t ^ ")" ^ opt_lemma ( x ^ " a a") ^ "\n\n" in

  let sym t x =
    "(a b:" ^ t ^ ")" ^ opt_lemma ("requires (" ^ x ^ " a b)) (ensures (" ^ x ^ " b a)") ^ "\n\n" in

  let trans t x =
    "(a b c:" ^ t ^ ")" ^ opt_lemma ("requires ((" ^ x ^ " a b) /\\ (" ^ x ^ " b c)))\n" ^
    "  (ensures (" ^ x ^ " a c)") ^ "\n\n" in
*)
  let translate_eq_th f x (s,i) =
    (match f.f_eq_theories with
    | NoEq -> s, i
    | Commut ->
        s ^ debug_comment "Commut" ^
        header i ^
        commut f x
        , i + 1
    | Assoc ->
        s ^ debug_comment "Assoc" ^
        header i ^
        assoc f x
        , i + 1
    | AssocCommut ->
        s ^ debug_comment "AssocCommut" ^
        header i ^
        commut f x ^
        header (i+1) ^
        assoc f x
        , i + 2
    | AssocN (_, n) ->
        (if implemented_function n then
	  match get_impl n with
          | Const const ->
              s ^ debug_comment "AssocN" ^
              header i ^
              assoc f x ^
              header (i+1) ^
              neutral f x const
              , i + 2
          | SepFun | Func _ | FuncEqual | FuncDiff ->
              Parsing_helper.internal_error "Expected a constant as second parameter to assocU."
          | No_impl -> assert false
	else
          begin
	    info ("  1 builtin equation will not be translated because there is no implementation for " ^ n.f_name);
            s, i
	  end)
    | AssocCommutN (_, n) ->
        (if implemented_function n then
	  match get_impl n with
          | Const const ->
              s ^ debug_comment "AssocCommutN" ^
              header i ^
              commut f x ^
              header (i+1) ^
              assoc f x ^
              header (i+2) ^
              neutral f x const
              , i + 3
          | SepFun | Func _ | FuncEqual | FuncDiff ->
              Parsing_helper.internal_error "Expected a constant as second parameter to ACU."
          | No_impl -> assert false
	else
	  begin
            info ("  1 builtin equation will not be translated because there is no implementation for " ^ n.f_name);
            s, i
	  end)
    | Group (_, inv, n) ->
        (if implemented_function inv && implemented_function n then
	  match get_impl n with
          | Const const ->
              (match get_impl inv with
                | Func invx ->
                    s ^ debug_comment "Group" ^
                    header i ^
                    assoc f x ^
                    header (i+1) ^
                    neutral f x const ^
                    header (i+2) ^
                    inverse f x const invx
                    , i + 3
                | Const _ | SepFun | FuncEqual | FuncDiff -> Parsing_helper.internal_error "Expected a non-constant function as second parameter to group."
                | No_impl -> assert false)
          | SepFun | Func _ | FuncEqual | FuncDiff ->
              Parsing_helper.internal_error "Expected a constant as third parameter to group."
          | No_impl -> assert false
	else
	  begin
	    info ("  1 builtin equation will not be translated because there is no implementation for " ^ n.f_name ^" or "^inv.f_name);
	    s, i
	  end)
    | CommutGroup (_, inv, n) ->
        (if implemented_function inv && implemented_function n then
	  match get_impl n with
          | Const const ->
              (match get_impl inv with
                | Func invx ->
                    s ^ debug_comment "CommutGroup" ^
                    header i ^
                    assoc f x ^
                    header (i+1) ^
                    commut f x ^
                    header (i+2) ^
                    neutral f x const ^
                    header (i+3) ^
                    inverse f x const invx
                    , i + 4
                | Const _ | SepFun | FuncEqual | FuncDiff -> Parsing_helper.internal_error "Expected a non-constant function as second parameter to commut_group."
                | No_impl -> assert false)
          | SepFun | Func _ | FuncEqual | FuncDiff ->
              Parsing_helper.internal_error "Expected a constant as third parameter to commut_group."
          | No_impl -> assert false
	else
	  begin
	    info ("  1 builtin equation will not be translated because there is no implementation for " ^ n.f_name ^" or "^inv.f_name);
	    s, i
	  end)
    | ACUN (_, n) ->
        (if implemented_function n then
	  match get_impl n with
          | Const const ->
              s ^ debug_comment "ACUN" ^
              header i ^
              commut f x ^
              header (i+1) ^
              assoc f x ^
              header (i+2) ^
              neutral f x const ^
              header (i+3) ^
              cancel f x const
              , i + 4
          | SepFun | Func _ | FuncEqual | FuncDiff ->
              Parsing_helper.internal_error "Expected a constant as second parameter to ACUN."
          | No_impl -> assert false
	else
	  begin
            info ("  1 builtin equation will not be translated because there is no implementation for " ^ n.f_name);
            s, i
	  end)
    ) in

  let lemma_equal (s,i) ty =
    s ^ debug_comment "Equallemma" ^
    header i ^
    is_fstar_eq ty, i + 1
      (* In the future, it might be good to allow some equality functions
	 to differ from the F* equality ==, while still being a congruence.
	 That's more complex to deal with for the user.
	 Which option we choose for each equality function might depend
	 on its name.
	 The following code generates lemmas for the equivalence relation;
	 the preservation by function application is still to be written.
      "val " ^ lemma_id i ^ " " ^
      refl ty eq ^
      "val " ^ lemma_id (i+1) ^ " " ^
      sym ty eq ^
      "val " ^ lemma_id (i+2) ^ " " ^
      trans ty eq, i+3 *)
  in

  let s_i = 
    List.fold_left
      (fun s_i f ->
      (* We ignore f_plus and f_mul explicitly because they cannot have an implementation
         and we do not want a useless warning about that. *)
	if f.f_eq_theories <> NoEq && f <> Settings.f_plus && f <> Settings.f_mul then (
	  if implemented_function f then
            match get_impl f with
            | Func x -> translate_eq_th f x s_i
            | Const _ | SepFun -> Parsing_helper.internal_error "Expected a non-constant non-letfun function as subject of a builtin equation."
            | FuncEqual | FuncDiff -> s_i
            | No_impl -> assert false
	  else
	    begin
              info ("  1 builtin equation will not be translated because there is no implementation for " ^ f.f_name);
              s_i
	  end)
	else s_i)
      ("", first_nr)
      (List.append built_in_functions !functions)
  in
  List.fold_left lemma_equal s_i (!eq_types) 

(* Tables module *)

let gen_str_tables_impl () =
  let (global_tables, local_tables) = List.partition (fun tbl -> tbl.tbllocalopt = None) (!tables) in

  let str_table_entries =
    String.concat ""
      (List.map (fun t ->
	"type " ^ get_table_entry_name t ^ " = " ^
	(String.concat " * " (List.map (fun ty -> get_type_name ty) t.tbltype)) ^
	"\n"
	  ) (!tables))
  in

  if global_tables != [] then
    error "global tables not supported in cv2F*; please use local tables";
  
  let global_tables_str =
    if global_tables = [] then
      "type t = unit\n\n" ^
      "val init: t\n" ^
      "let init = ()\n\n" ^
      (if !Settings.fstar_debug then
	"val print: #stt:state_type{tt_of stt == t} -> state stt -> FStar.All.ML unit\n" ^
	"let print st = ()\n"
      else
	"")
    else
      let str_table_record = "noeq type t = {\n" ^
	(String.concat ""
	   (List.map (fun t ->
	     "  " ^ get_table_field t ^ ": table " ^ get_table_entry_name t ^ ";\n"
		  ) global_tables)) ^
	"}\n"
      in

      let str_table_init = "let init = {\n" ^
	(String.concat ""
	   (List.map (fun t ->
	     "  " ^ get_table_field t ^ " = table_empty " ^ get_table_entry_name t ^ ";\n"
		   ) global_tables)) ^
	"}\n"
      in

      let str_table_names =
	String.concat ""
	  (List.map (fun t ->
	    "val " ^ get_table_name t ^ ": table_name t " ^ get_table_entry_name t ^ "\n\n" ^
	    "let " ^ get_table_name t ^ " =\n" ^
	    "  { get = (fun tabs -> tabs." ^ get_table_field t ^ ");\n" ^
	    "    set = (fun tabs -> fun tab -> { tabs with " ^ get_table_field t ^ " = tab }) }\n\n"
		  ) global_tables)
      in

      str_table_record ^ "\n" ^
      "val init: t\n\n" ^
      str_table_init ^ "\n" ^
      str_table_names ^ "\n" ^
      (if !Settings.fstar_debug then
	let str_table_print_entry =
	  String.concat ""
	    (List.map (fun t ->
	      let vars = create_local_names "var" t.tbltype in
	      "val " ^ get_table_print_entry t ^ ": " ^ get_table_entry_name t ^ " -> FStar.All.ML unit\n\n" ^
	    "let " ^ get_table_print_entry t ^ " (" ^
	      (String.concat ", " vars) ^ ") =\n" ^
	      "  IO.print_string \"{\"; IO.print_newline ();\n" ^
	      (String.concat "" (List.map2 (fun t v ->
		"  print_label_bytes \"" ^ get_type_name t ^
		"\" (" ^ get_write_serial t ^ " " ^ v ^ ") true;\n") t.tbltype vars)) ^
	      "  IO.print_string \"}\"; IO.print_newline ()\n\n"
		) global_tables)
	in

	let str_table_print = "let print st =\n" ^
	  (String.concat ";\n"
	   (List.map (fun t ->
	     "  print_table st " ^ get_table_name t ^ " \"" ^
	     t.tblname ^ "\" " ^ get_table_print_entry t
				   ) global_tables))
	in

	str_table_print_entry ^ "\n" ^
	"\nval print: #stt:state_type{tt_of stt == t} -> state stt -> FStar.All.ML unit\n" ^
	str_table_print ^ "\n"
      else
	"")
  in
  let local_tables_str =
    if local_tables = [] then
      "type localt = unit\n"
    else
      let str_table_data = "noeq type localt = \n" ^
	(String.concat ""
	   (List.map (fun t ->
	     "  | " ^ get_table_data t ^ ": table " ^ get_table_entry_name t ^ " -> localt\n"
		  ) local_tables))
      in

      let str_table_names =
	String.concat ""
	  (List.map (fun t ->
	    "val " ^ get_table_name t ^ ": local_table_name localt " ^ get_table_entry_name t ^ "\n\n" ^
	    "let " ^ get_table_name t ^ " =\n" ^
	    "  { local_get = (fun tabs -> match tabs with\n" ^
	    "       | " ^ get_table_data t ^ " tab -> Some tab\n"^
            "       | _ -> None);\n" ^
	    "    local_set = (fun tab -> " ^ get_table_data t ^ " tab) }\n\n"
		  ) local_tables)
      in

      str_table_data ^ "\n" ^
      str_table_names
  in
  "module " ^ !protocol_name_allcaps ^ ".Tables\n\n" ^
  "open CVTypes\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Types\n" ^
  "open State\n\n" ^
  str_table_entries ^ "\n" ^
  global_tables_str ^ "\n" ^
  local_tables_str

(* Events module *)

let gen_str_events_impl () =
  let str_events =
    if !events = [] then
      "type " ^ cv_event_type_name ^ " = unit\n"
    else
      "noeq type " ^ cv_event_type_name ^ " =\n" ^
      List.fold_left
      (fun s ef ->
	s ^ "  | " ^ get_event_name ef ^ ": " ^
        (List.fold_left
           (fun s t -> s ^ get_type_name t ^ " -> ")
           ""
             (* ignore the first element from e and s: it is the bitstring corresponding to the replication indices. *)
           (List.tl (fst ef.f_type))) ^
        cv_event_type_name ^ "\n"
      )
      ""
      !events in

  let prot_print_event = get_protocol_id "print_event" in

  "module " ^ !protocol_name_allcaps ^ ".Events\n\n" ^
  "open CVTypes\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Types\n" ^
  str_events ^ "\n\n" ^
  (if !Settings.fstar_debug then
    let str_events_print = "val " ^ prot_print_event ^ ": " ^ cv_event_type_name ^ " -> FStar.All.ML unit" in

    let str_events_print_let = "let " ^ prot_print_event ^
      " e = " ^ 
      if !events = [] then
	"  ()\n"
      else
	"  match e with\n" ^
	List.fold_left
	  (fun s ef ->
	    let tyl = List.tl (fst ef.f_type) in
	    if tyl = [] then
	      s ^ "  | " ^ get_event_name ef ^ " ->\n" ^
	      "    IO.print_string \"" ^ ef.f_name ^ "\"; IO.print_newline ()\n"
	    else
	      let vars = create_local_names "var" tyl in
	      s ^ "  | " ^ get_event_name ef ^ " " ^
              String.concat " " vars ^ " ->\n" ^
              "    IO.print_string \"" ^ ef.f_name ^ ": { \";\n" ^
              String.concat "" (List.map2 (fun e v -> "    print_label_bytes " ^ " \"" ^ get_type_name e ^ "\" (" ^ get_write_serial e ^ " "^ v ^ ") true;\n") tyl vars) ^
              "    IO.print_string \"}\"; IO.print_newline ()\n"
		)
	  ""
	  !events in

    str_events_print ^ "\n" ^
    str_events_print_let
  else
    "")

let gen_str_fstar_events_impl() =
  "module " ^ !protocol_name_allcaps ^ ".Events.FStar

open CVTypes
open " ^ !protocol_name_allcaps ^ ".Types

noeq type fstar_event =
    (* PLEASE DEFINE THE TYPE OF FSTAR EVENTS *)
    | DummyEvent\n" ^
  (if !Settings.fstar_debug then
    "\n(* PLEASE DEFINE A FUNCTION FOR PRINTING FSTAR EVENTS *)
let print_fstar_event (e: fstar_event) = ()\n"
  else
    "")

(* Sessions module *)

let foreach_oracle oracles_for_modules f init =
  List.fold_left
    (fun s (_, _, oracles) -> StringMap.fold f oracles s)
    init
    oracles_for_modules

let foreach_following_oracle oracles_for_modules f init =
  foreach_oracle oracles_for_modules
    (fun _ od s ->
      List.fold_left
        (fun s (nr, ol, _) ->
          List.fold_left
            (fun s oinfo -> f s nr oinfo)
            s
            ol)
        s
        od.list_of_returns)
  init

let has_following_oracles oracles_for_modules =
  List.exists (fun (_, _, oracles) ->
    StringMap.exists (fun _ od ->
      List.exists (fun (nr, ol, _) -> ol <> []) od.list_of_returns
		     ) oracles
	      ) oracles_for_modules


let gen_str_sessions_interface oracles_for_modules =
  let prot_oracle_name = get_protocol_id "oracle_name" in
  let prot_session_entry = get_protocol_id "session_entry" in
  let prot_session_entry_to_name = get_protocol_id "session_entry_to_name" in
  let prot_print_session_entry = get_protocol_id "print_session_entry" in
  let prot_following_oracles = get_protocol_id "following_oracles" in
  let prot_session_type = get_protocol_id "session_type" in
  (* Generate types for session states *)
  let str_oracle_name =
    foreach_oracle oracles_for_modules (fun name od s -> s ^ "  | " ^ get_oracle_name name ^ "\n")
      ("type " ^ prot_oracle_name ^ ": eqtype =\n") in

  let following_oracles = has_following_oracles oracles_for_modules in

  let str_session_entry =
    if following_oracles then
      foreach_following_oracle oracles_for_modules
	(fun s nr (name, bl, sidl) ->
          s ^ "  | " ^ get_return_name nr name ^ ": " ^
          (String.concat ""
             (List.map (fun b ->
               get_binder_name b ^ ":" ^
	       ((* For <PROTOCOL>.Sessions.<protocol>_print_session_entry *)
		add_debug_display_type b.btype;
		get_type_name b.btype) ^ " -> ") bl)) ^
          (String.concat ""
             (List.map (fun i -> get_sid i ^ ": SidMap.sidt -> ") sidl)) ^
          prot_session_entry ^ "\n")
	("noeq type " ^ prot_session_entry ^ " =\n")
    else
      "noeq type " ^ prot_session_entry ^ " =\n" ^
      "  | R0_dummy: " ^ prot_session_entry ^ "\n"
  in

  let str_session_entry_to_name =
    if following_oracles then
      foreach_following_oracle oracles_for_modules
	(fun s nr (name, bl, sidl) ->
          s ^ "  | " ^ get_return_name nr name ^ " " ^
          (String.concat ""
             (List.map (fun b -> "_ ") bl)) ^
          (String.concat ""
             (List.map (fun i -> "_ ") sidl)) ^
          "-> " ^ get_oracle_name name ^ "\n")
	("let " ^ prot_session_entry_to_name ^ " se =\n" ^
	 "  match se with\n")
    else
      (* Always return the name of the first oracle, as a dummy
	 function *)
      let (_,_,oracles) = List.hd oracles_for_modules in
      let (oname,_) = StringMap.find_first (fun _ -> true) oracles in
      "let " ^ prot_session_entry_to_name ^ " se =\n" ^
      "  " ^ (get_oracle_name oname) ^"\n"
  in

  let str_following_oracles =
    foreach_oracle oracles_for_modules
      (fun name od s ->
        s ^ "  | " ^ get_oracle_name name ^ " -> [" ^
        (match od.following_oracles with
        | None | Some [] -> ""
        | Some fol ->
            (List.fold_left
              (fun s name -> (match s with | "" -> "" | _ -> s ^ "; ") ^ get_oracle_name name)
              ""
              fol)) ^
        "]\n")
      ("let " ^ prot_following_oracles ^ " on =\n" ^
       "  match on with\n") in

  let str_session_rest =
    (if !Settings.fstar_debug then
      "val " ^ prot_print_session_entry ^ ": " ^ prot_session_entry ^ " -> FStar.All.ML unit\n\n"
    else "") ^
    "let " ^ prot_session_type ^ " = SessionType " ^
    prot_oracle_name ^ " " ^ prot_session_entry ^ " " ^
    prot_following_oracles ^ " " ^ prot_session_entry_to_name ^ "\n\n"
  in

  "module " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Sessions\n\n" ^
  "open CVTypes\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Types\n" ^
  "open State\n\n" ^
  str_oracle_name ^ "\n\n" ^
  str_session_entry ^ "\n\n" ^
  str_session_entry_to_name ^ "\n\n" ^
  str_following_oracles ^ "\n\n" ^
  str_session_rest


let gen_str_sessions_impl oracles_for_modules =
  let prot_print_session_entry = get_protocol_id "print_session_entry" in
  let following_oracles = has_following_oracles oracles_for_modules in
  let str_session_print_entry =
    if !Settings.fstar_debug then
      if following_oracles then
	foreach_following_oracle oracles_for_modules
	  (fun s nr (name, bl, sidl) ->
            s ^ "  | " ^ get_return_name nr name ^ " " ^
            (String.concat ""
               (List.map (fun b -> get_binder_name b ^ " ") bl)) ^
            (String.concat ""
               (List.map (fun i -> get_sid i ^ " ") sidl)) ^
            "->\n" ^
            "    IO.print_string \"" ^ get_return_name nr name ^ ": {\\n\";\n" ^
            (List.fold_left
               (fun s b ->
		 s ^ "    print_label_bytes \"" ^ get_binder_name b ^ "\" (" ^ get_write_serial b.btype ^ " " ^ get_binder_name b ^ ") true;\n")
               ""
               bl) ^
	    (*TODO print session ids in sidl*)
            "    IO.print_string \"}\\n\"\n"
	      )
	  ("let " ^ prot_print_session_entry ^ " se =\n" ^
	   "  match se with\n")
      else
	"let " ^ prot_print_session_entry ^ " se = ()\n"
    else
      ""
  in

  "module " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Sessions\n\n" ^
  "open CVTypes\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Types\n" ^
  "open State\n\n" ^
  str_session_print_entry

(* Protocol module *)

let gen_str_protocol () =
  let prot_state_type = get_protocol_id "state_type" in
  let prot_session_type = get_protocol_id "session_type" in
  "module " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Protocol\n\n" ^
  "open CVTypes\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Types\n" ^
  "open " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Sessions\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Events\n" ^
  "open State\n\n" ^
  (* state_type *)
  "let " ^ prot_state_type ^ " = { 
    tt = " ^ !protocol_name_allcaps ^ ".Tables.t;
    tt_init = " ^ !protocol_name_allcaps ^ ".Tables.init;
    local_tt = " ^ !protocol_name_allcaps ^ ".Tables.localt;
    vt = " ^ !protocol_name_allcaps ^ ".Variables.t;
    vt_init = " ^ !protocol_name_allcaps ^ ".Variables.init;
    st = " ^ prot_session_type ^ ";
    cv_event_type = " ^ !protocol_name_allcaps ^ ".Events.cv_event;
    fs_event_type = " ^ !protocol_name_allcaps ^ ".Events.FStar.fstar_event;
    debug = " ^ (if !Settings.fstar_debug then "true" else "false") ^ " }\n\n" ^
  (* events *)
  "type " ^ get_protocol_id "event" ^ " = event_type " ^ prot_state_type ^ "\n\n" ^ 
  (* state *)
  "type " ^ state_type () ^ " = state " ^ prot_state_type ^ "\n"

(* Invariant module *)

let gen_str_invariant oracles_for_modules =
  "module " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Invariant\n\n" ^
  "open CVTypes\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Types\n" ^
  "open " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Sessions\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Events\n" ^
  "open " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Protocol\n" ^
  "open State\n\n" ^

  "val inv : " ^ state_type () ^ " -> prop\n" ^
  "(* PLEASE DEFINE THE INVARIANT OF YOUR CHOICE *)\n" ^
  "let inv s = True\n\n" ^
  "(* Relation satisfied by any sequence of local functions *)\n" ^ 
  "val local_rel : " ^ state_type () ^ " -> " ^ state_type () ^ " -> prop\n" ^
  "(* PLEASE DEFINE THE RELATION OF YOUR CHOICE *)\n" ^
  "let local_rel s0 s1 = True\n\n" ^
  "(* Relation satisfied by any sequence of local or parallel functions *)\n" ^ 
  "val rel : " ^ state_type () ^ " -> " ^ state_type () ^ " -> prop\n" ^
  "(* PLEASE DEFINE THE RELATION OF YOUR CHOICE *)\n" ^
  "let rel s0 s1 = True\n\n" ^
  "val pre_add_event : " ^ !protocol_name_allcaps ^ ".Events.FStar.fstar_event -> " ^ state_type () ^ " -> prop\n" ^
  "(* PLEASE DEFINE THE PRECONDITION OF YOUR CHOICE *)\n" ^
  "let pre_add_event e s = True\n\n" ^
  String.concat "" (List.map (fun (_,_,oracle_map) ->
    StringMap.fold (fun on od s -> s ^
      "val " ^ get_oracle_precondition_name on ^ ": " ^
      (if takes_id od then "SidMap.sidt -> " else "") ^
      (string_list_sep "" (List.map (fun t -> get_type_name t^" -> ") od.input_type)) ^
      state_type () ^ " -> prop\n" ^
      "(* PLEASE DEFINE THE PRECONDITION OF YOUR CHOICE *)\n" ^
      let args = create_oracle_args od in
      "let " ^ oracle_precondition od args "s" ^ " = True\n\n"
		   ) oracle_map ""
			     ) oracles_for_modules)

(* InvariantLemmas module *)

let gen_str_invariant_lemmas_intf oracles_for_modules =
  let state_t = state_type() in
  "module " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "InvariantLemmas\n\n" ^
  "open CVTypes\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Types\n" ^
  "open " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Sessions\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Events\n" ^
  "open " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Protocol\n" ^
  "open " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Invariant\n" ^
  "open State\n\n" ^

"let inv' (s: " ^ state_t ^ ") =
  (" ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Invariant.inv (remove_local s))

let local_rel' (s0 s1: " ^ state_t ^ ") =
  " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Invariant.local_rel s0 s1 /\\
  sessions_included s0 s1 /\\
  inv' s1

let rel' (s0 s1: " ^ state_t ^ ") =
  " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Invariant.rel s0 s1 /\\
  sessions_included s0 s1 /\\
  inv' s1

val initial (s: " ^ state_t ^ "):
  Lemma (requires (is_init_state s)) (ensures (" ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Invariant.inv s))

let initial' (s: " ^ state_t ^ "):
  Lemma (requires (is_init_state s)) (ensures (inv' s))
  [SMTPat (is_init_state s)] =
  initial s

val local_reflexivity (s: " ^ state_t ^ "):
  Lemma (requires (inv' s)) (ensures (" ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Invariant.local_rel s s))

let local_reflexivity' (s: " ^ state_t ^ "):
  Lemma (requires (inv' s)) (ensures (local_rel' s s)) =
  local_reflexivity s

val local_transitivity (s0 s1 s2: " ^ state_t ^ "):
  Lemma (requires (inv' s0 /\\ local_rel' s0 s1 /\\ local_rel' s1 s2))
    (ensures (" ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Invariant.local_rel s0 s2))

let local_transitivity' (s0 s1 s2: " ^ state_t ^ "):
  Lemma (requires (inv' s0 /\\ local_rel' s0 s1 /\\ local_rel' s1 s2))
    (ensures (local_rel' s0 s2)) [SMTPat (local_rel' s0 s1); SMTPat(local_rel' s1 s2)] =
  local_transitivity s0 s1 s2

val reflexivity (s: " ^ state_t ^ "):
  Lemma (requires (inv' s)) (ensures (" ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Invariant.rel s s))

let reflexivity' (s: " ^ state_t ^ "):
  Lemma (requires (inv' s)) (ensures (rel' s s)) =
  reflexivity s

val transitivity (s0 s1 s2: " ^ state_t ^ "):
  Lemma (requires (inv' s0 /\\ rel' s0 s1 /\\ rel' s1 s2))
    (ensures (" ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Invariant.rel s0 s2))

let transitivity' (s0 s1 s2: " ^ state_t ^ "):
  Lemma (requires (inv' s0 /\\ rel' s0 s1 /\\ rel' s1 s2))
    (ensures (rel' s0 s2)) [SMTPat (rel' s0 s1); SMTPat(rel' s1 s2)] =
  transitivity s0 s1 s2

val local_rel_implies_rel (s0 s1: " ^ state_t ^ ") :
  Lemma (requires (inv' s0 /\\ local_rel' s0 s1))
  (ensures (" ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Invariant.rel s0 s1))

let local_rel_implies_rel' (s0 s1: " ^ state_t ^ ") :
  Lemma (requires (inv' s0 /\\ local_rel' s0 s1))
  (ensures (rel' s0 s1)) [SMTPat (local_rel' s0 s1)] =
  local_rel_implies_rel s0 s1

let inverse (s: " ^ state_t ^ "):
  Lemma (requires (inv' s)) (ensures (inv' (inverse_local s))) = ()\n\n"
  ^ (if !Settings.fstar_concurrent then
"let parallel_rel' (s0 s1: " ^ state_t ^ ") =
  local_rel' (inverse_local s0) (inverse_local s1)

let parallel_reflexivity (s: " ^ state_t ^ "):
 Lemma (requires (inv' s)) (ensures (parallel_rel' s s)) 
  [SMTPat (inv' s)] =
  local_reflexivity' (inverse_local s)  

let parallel_transitivity (s0 s1 s2: " ^ state_t ^ "):
  Lemma (requires (inv' s0 /\\ parallel_rel' s0 s1 /\\ parallel_rel' s1 s2))
    (ensures (parallel_rel' s0 s2)) [SMTPat (parallel_rel' s0 s1); SMTPat(parallel_rel' s1 s2)] =
  local_transitivity' (inverse_local s0) (inverse_local s1) (inverse_local s2)

val parallel_rel_implies_rel (s0 s1: " ^ state_t ^ ") :
  Lemma (requires (inv' s0 /\\ parallel_rel' s0 s1))
  (ensures (" ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Invariant.rel s0 s1))

let parallel_rel_implies_rel' (s0 s1: " ^ state_t ^ ") :
  Lemma (requires (inv' s0 /\\ parallel_rel' s0 s1))
  (ensures (rel' s0 s1)) [SMTPat (parallel_rel' s0 s1)] =
  parallel_rel_implies_rel s0 s1;
  lemma_sessions_included_inverse_local s0 s1;
  inverse (inverse_local s1);
  lemma_inverse_local_involution s1\n\n"
    else "") ^
"val add_event (s: " ^ state_t ^ ") (e: " ^ !protocol_name_allcaps ^ ".Events.FStar.fstar_event):
    Lemma (requires (inv' s /\\ " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Invariant.pre_add_event e s))
    (ensures (local_rel' s (state_add_event s (FStarEvent e))))

val remove_session (s: " ^ state_t ^ ") (n: SidMap.sidt):
    Lemma (requires (inv' s /\\ is_local n s))
    (ensures (local_rel' s (remove_session s n)))\n\n" ^
(if !Settings.fstar_concurrent then
"val pre_add_event_lemma (e: " ^ !protocol_name_allcaps ^ ".Events.FStar.fstar_event) (s s': " ^ state_t ^ ") :
    Lemma (requires (inv' s /\\ " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Invariant.pre_add_event e s /\\ parallel_rel' s s'))
      (ensures (" ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Invariant.pre_add_event e s'))\n\n" ^
  String.concat "" (List.map (fun (_,_,oracle_map) ->
    StringMap.fold (fun on od s -> s ^
      let args = create_oracle_args od in
      "val " ^ get_lemma_oracle_precondition_name on ^ " " ^
      (if takes_id od then "(" ^ session_id_variable ^ ": SidMap.sidt) " else "") ^
      (string_list_sep "" (List.map2 (fun arg t -> "(" ^ arg ^ ": " ^ get_type_name t^") ") args od.input_type)) ^
      "(s s':" ^ state_t ^ ") :\n" ^
      "  Lemma (requires (inv' s /\\ " ^ oracle_precondition_wl od args "s" ^ " /\\ parallel_rel' s s'))\n" ^
      "    (ensures (" ^ oracle_precondition od args "s'" ^ "))\n\n"
		   ) oracle_map ""
			     ) oracles_for_modules)
else "")

let gen_str_invariant_lemmas_impl oracles_for_modules =
  "module " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "InvariantLemmas\n\n" ^
  "open CVTypes\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Types\n" ^
  "open " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Sessions\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Events\n" ^
  "open " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Protocol\n" ^
  "open " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Invariant\n" ^
  "open State\n\n" ^

"(* PLEASE ADD PROOFS FOR THE LEMMAS *)
let initial s = ()

let local_reflexivity s = ()

let local_transitivity s0 s1 s2 = ()

let reflexivity s = ()

let transitivity s0 s1 s2 = ()

let local_rel_implies_rel s0 s1 = ()\n\n" ^
(if !Settings.fstar_concurrent then
"let parallel_rel_implies_rel s0 s1 = ()\n\n"
else "") ^
"let add_event s e = ()

let remove_session s n = ()\n\n" ^
(if !Settings.fstar_concurrent then
  "let pre_add_event_lemma e s s' = ()\n\n"^
  String.concat "" (List.map (fun (_,_,oracle_map) ->
    StringMap.fold (fun on od s -> s ^
      let args = create_oracle_args od in
      "let " ^ get_lemma_oracle_precondition_name on ^ " " ^
      (if takes_id od then "(" ^ session_id_variable ^ ": SidMap.sidt) " else "") ^
      (string_list_sep "" (List.map2 (fun arg t -> "(" ^ arg ^ ": " ^ get_type_name t^") ") args od.input_type)) ^
      "(s s':" ^ state_type() ^ ") = ()\n\n"
		   ) oracle_map ""
			     ) oracles_for_modules)
else "")

(* Types interface *)

let gen_str_types () =
  let str_types = List.fold_left
    (fun s t ->
      s ^ "val " ^ get_type_name t ^ ": Type0\n")
    ""
    !types
  in

  let str_eq_types = List.fold_left
    (fun s t ->
      s ^ "val " ^ equal t ^ ": " ^ get_type_name t ^ " -> " ^ get_type_name t ^ " -> bool\n\n")
    ""
    !eq_types
  in

  let str_serde_types = List.fold_left
    (fun s t ->
      s ^
      "val " ^ get_serializer t ^ ": serializer " ^ get_type_name t ^ "\n"
    )
    ""
    !ser_types
  in

  let str_tuple_types = String.concat "" (List.mapi
      (fun n tl ->
        "let " ^ (get_tuple_tag_name tl)^" : tagt = tag_from_nat "^(string_of_int (n+start_tag))^"\n\n"^
	"let " ^ get_tuple_dec_fun_name tl ^ " (buf: bytes) =\n" ^
	"  match Tuples.check_tag "^(get_tuple_tag_name tl)^" buf with\n" ^
        "  | None -> None\n" ^
	"  | Some pos ->\n" ^
	let return_vars = create_fresh_names "cvar_" (List.length tl) in
	(String.concat "" (List.map2 (fun rv t ->
	  "  match " ^(get_read_serial t)^ " buf pos with\n" ^
	  "  | DSTooShort _ | DSFailure -> None\n" ^
	  "  | DSOk(" ^rv^ ", pos) ->\n"
			     ) return_vars tl)) ^
	"     if pos = Seq.length buf then\n" ^
	"       Some(" ^ (String.concat "," return_vars) ^ ")\n" ^
	"     else\n"  ^
	"       None\n\n"
	)
      !tuple_types)
  in

  let str_random_types = List.fold_left
    (fun s t ->
      s ^ "val " ^ get_random t ^ ": Random.entropy -> Random.entropy * " ^ get_type_name t ^ "\n\n"
    )
    ""
    !random_types
  in

  "module " ^ !protocol_name_allcaps ^ ".Types\n\n" ^
  "open CVTypes\n" ^
  str_types ^ "\n\n" ^
  str_eq_types ^ "\n\n" ^
  str_serde_types ^ "\n\n" ^
  str_tuple_types ^ "\n\n" ^
  str_random_types

let gen_str_types_impl () =
  let str_types = List.fold_left
    (fun s t ->
      s ^ "let " ^ get_type_name t ^ " = unit\n")
    ""
    !types
  in

  let str_eq_types = List.fold_left
    (fun s t ->
      s ^ "let " ^ equal t ^ " x y = true\n\n")
    ""
    !eq_types
  in

  let str_serde_types = List.fold_left
    (fun s t ->
      s ^
      "let " ^ get_serializer t ^ " = serializer_ghost\n"
    )
    ""
    !ser_types
  in

  let str_random_types = List.fold_left
    (fun s t ->
      s ^ "let " ^ get_random t ^ " entropy = (entropy, ())\n\n"
    )
    ""
    !random_types
  in

  "module " ^ !protocol_name_allcaps ^ ".Types\n\n" ^
  "open CVTypes\n" ^
  "(* PLEASE DEFINE ALL TYPES AND ASSOCIATED FUNCTIONS *)\n\n" ^
  str_types ^ "\n\n" ^
  str_eq_types ^ "\n\n" ^
  str_serde_types ^ "\n\n" ^
  str_random_types

(* Functions interface *)

let gen_str_functions () =
  let str_functions =
    List.fold_left
      (fun s f ->
        s ^
	match f.f_cat with
	| Proj _ -> "" (* Projections are defined just after their bijective inverse *)
	| _ ->
        match get_impl f with
        | Func x ->
            "val " ^ x ^ ": " ^
            (* parameter types *)
            (List.fold_left
              (fun s t -> s ^ get_type_name t ^ " -> ")
              ""
              (fst f.f_type)) ^
            (* additional types when needing entropy *)
            (if f.f_impl_ent then "Random.entropy -> Random.entropy * " else "") ^
            (* return type *)
            get_type_name (snd f.f_type) ^ "\n\n" ^

            (* inverse *)
            (if List.memq f !inv_functions then
              (let inv = get_inv_impl f in
	      let input_type =
		String.concat " * " (List.map
				       (fun t -> get_type_name t)
				       (fst f.f_type))
	      in
              "val " ^ inv ^ ": " ^
                  (* parameter is the return type *)
              get_type_name (snd f.f_type) ^ " -> " ^
                  (* return type is the input input when f is bijective,
		     option of the input type when f is only injective *)
	      (if f.f_options land Settings.fopt_BIJECTIVE != 0 then
		input_type
	      else
                "option (" ^ input_type ^ ")")^ "\n\n" ^
	      if f.f_options land Settings.fopt_BIJECTIVE != 0 then
		    (* Define all the projection functions *)
		String.concat "" (List.mapi (fun i t ->
		  "let " ^ get_proj_name f (i+1)^" (x: " ^
		  get_type_name (snd f.f_type) ^ ") =\n  let ("^
		  (String.concat ", " (List.mapi (fun j _ ->
		    if j = i then "y" else "_") (fst f.f_type)))^
		  ") = "^inv^" x in y\n\n"
				) (fst f.f_type))

	      else "")
            else "")

        | Const x when (snd f.f_type).toptions land Settings.tyopt_GHOST == 0 ->
	    (* The ghost constant (): unit is already known by F*,
	       should not be declared *)
            "val " ^ x ^ ": " ^
            get_type_name (snd f.f_type) ^ "\n\n"
        | Const _ | SepFun | FuncEqual | FuncDiff -> ""
        | No_impl -> assert false)
      ""
      !functions
  in

  "module " ^ !protocol_name_allcaps ^ ".Functions\n\n" ^
  "open CVTypes\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Types\n\n" ^
  str_functions

let gen_str_functions_impl () =
  let str_functions =
    List.fold_left
      (fun s f ->
        s ^
	match f.f_cat with
	| Proj _ -> "" (* Projections are defined just after their bijective inverse *)
	| _ ->
        match get_impl f with
        | Func x ->
            "let " ^ x ^ " " ^
            (* parameter types *)
	    let args = create_local_names "x" (fst f.f_type) in
	    (String.concat " " args) ^
            (* additional types when needing entropy *)
            (if f.f_impl_ent then " entropy = entropy," else " =") ^
            (* return type *)
            " ()\n\n" ^

            (* inverse *)
            (if List.memq f !inv_functions then
              (let inv = get_inv_impl f in
              "let " ^ inv ^ " x = " ^
                  (* return type is the input input when f is bijective,
		     option of the input type when f is only injective *)
	      (if f.f_options land Settings.fopt_BIJECTIVE != 0 then
		"()"
	      else
                "None")^ "\n\n")
            else "")

        | Const x when (snd f.f_type).toptions land Settings.tyopt_GHOST == 0 ->
	    (* The ghost constant (): unit is already known by F*,
	       should not be declared *)
            "let " ^ x ^ " = ()\n\n"
        | Const _ | SepFun | FuncEqual | FuncDiff -> ""
        | No_impl -> assert false)
      ""
      !functions
  in

  "module " ^ !protocol_name_allcaps ^ ".Functions\n\n" ^
  "open CVTypes\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Types\n\n" ^
  "(* PLEASE DEFINE ALL FUNCTIONS AND CONSTANTS *)\n\n" ^
  str_functions



(* Effect module *)

let gen_str_effect_interface() =
"module " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Effect

open State
open CVSTBasic
module InvariantLemmas = " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "InvariantLemmas

let stt = " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Protocol." ^ get_protocol_id "state_type" ^ "

type pre_t = state stt -> Type0
type post_t (a:Type) = state stt -> a -> state stt -> Type0

val repr (a:Type) (pre:pre_t) (post:post_t a) : Type0

val return (a:Type) (x:a) : repr a (fun _ -> True) (fun s0 r s1 -> r == x /\\ s0 == s1)

/// bind bakes in the weakening of f's post to compose it with g's pre

val bind (a:Type) (b:Type)
  (pre_f:pre_t) (post_f:post_t a) (pre_g:a -> pre_t) (post_g:a -> post_t b)
  (f:repr a pre_f post_f) (g:(x:a -> repr b (pre_g x) (post_g x)))
: repr b
  (fun s0 -> pre_f s0 /\\ (forall (x:a) (s1:state stt). post_f s0 x s1 ==> pre_g x s1))
  (fun s0 y s2 -> exists (x:a) (s1:state stt). pre_f s0 /\\ post_f s0 x s1 /\\ post_g x s1 y s2)

/// sub comp rule

val subcomp (a:Type)
  (pre_f:pre_t) (post_f:post_t a)
  (pre_g:pre_t) (post_g:post_t a)
  (f:repr a pre_f post_f)
: Pure (repr a pre_g post_g)
  (requires
    (forall (s:state stt). pre_g s ==> pre_f s) /\\
    (forall (s0 s1:state stt) (x:a). (pre_g s0 /\\ post_f s0 x s1) ==> post_g s0 x s1))
  (ensures fun _ -> True)

let if_then_else (a:Type)
  (pre_f:pre_t) (post_f:post_t a)
  (pre_g:pre_t) (post_g:post_t a)
  (f:repr a pre_f post_f)
  (g:repr a pre_g post_g)
  (p:bool)
  : Type
= repr a
  (fun s -> (p ==> pre_f s) /\\ ((~ p) ==> pre_g s))
  (fun s0 r s1 -> (p ==> post_f s0 r s1) /\\ ((~ p) ==> post_g s0 r s1))

reifiable
reflectable
effect {
  CVSTPre (a:Type) (pre:pre_t) (post:post_t a)
  with {repr; return; bind; subcomp; if_then_else}
      }

let pre_inv (pre: pre_t) (s0: state stt) =
  InvariantLemmas.inv' s0 /\\ pre s0

let post_inv (#a: Type) (post: post_t a) (s0: state stt) (r: a) (s1: state stt) =
  post s0 r s1 /\\ InvariantLemmas.rel' s0 s1

let post_local_inv (#a: Type) (post: post_t a) (s0: state stt) (r: a) (s1: state stt) =
  post s0 r s1 /\\ InvariantLemmas.local_rel' s0 s1

effect CVSTInv a (pre: pre_t) (post: post_t a) =
  CVSTPre a (pre_inv pre) (post_inv post)\n\n" ^
(if !Settings.fstar_concurrent then
"let post_interm (#a: Type) (post: post_t a) (s0: state stt) (r: a) (s1: state stt) = exists si.
  InvariantLemmas.parallel_rel' s0 si /\\
  post_local_inv post si r s1\n\n"
else
"let post_interm = post_local_inv\n\n") ^
"effect CVST1Call (a:Type) (pre: pre_t) (post: post_t a) =
  CVSTPre a (pre_inv pre) (post_interm post)

let true_pre (s: state stt) = True

effect CVSTInvMin (a:Type) =
  CVSTInv a true_pre (fun _ _ _ -> True)

effect CVSTAxiom (a:Type) (ax: state stt -> Type0) =
  CVSTPre a true_pre (fun s1 _ s2 -> s1 == s2 /\\ ax s2)

/// We now define a lift from PURE. This is needed to use total computations/function calls
/// inside of CVST computations

unfold
let pure_p (#a:Type) (wp: pure_wp a) : pre_t = fun _ -> as_requires wp

unfold
let pure_q (#a:Type) (wp: pure_wp a) : post_t a =
  fun s0 x s1 -> s0 == s1 /\\ as_ensures wp x

val lift_pure (a:Type) (wp:pure_wp a) (f:eqtype_as_type unit -> PURE a wp) : 
  repr a (pure_p wp) (pure_q wp)

sub_effect PURE ~> CVSTPre = lift_pure

/// We now define a lift from CVSTBasic. This is needed to use ML, network, 
/// time, ... function calls inside of CVST computations

val lift_basic (a:Type) (f: CVSTBasic.repr a) : repr a true_pre (fun s0 _ s1 -> s0 == s1)

sub_effect CVSTBasic ~> CVSTPre = lift_basic

/// We do not want to lift the entire ALL effect, as we do not have an ML heap in CVST. We instead
/// provide an explicit coercion from ML to CVST, which will allow the use of printing functions

effect CVSTML (a: Type) =
  CVSTPre a true_pre (fun s0 _ s1 -> s0 == s1)
val ml_to_CVST (#a: Type) (f: eqtype_as_type unit -> FStar.All.ML a) : CVSTML a

/// Lifting print functions to CVST
val print_string: string -> CVSTML unit
val print_bytes: CVTypes.bytes -> CVSTML unit
val print_sid: SidMap.sidt -> CVSTML unit
val print_bool: bool -> CVSTML unit

val print_label_bytes: string -> CVTypes.bytes -> bool -> CVSTML unit
val print_label_sid: string -> SidMap.sidt -> bool -> CVSTML unit
val print_label_bool: string -> bool -> bool -> CVSTML unit

/// A helper function, returning the current state. The returned state is erased,
/// thus only usable inside proofs.
val get_state () : CVST1Call (Ghost.erased (state stt)) true_pre 
  (fun s0 r s1 -> s0 == s1 /\\ Ghost.reveal r == s1)

val get_state_no_par () : CVSTPre (Ghost.erased (state stt)) true_pre
  (fun s0 r s1 -> s0 == s1 /\\ Ghost.reveal r == s1)\n\n" ^ 
(if !Settings.fstar_debug then
"// DEBUG ONLY: These functions may print secrets!
// TODO comment out in final version
effect CVSTId (a: Type) = CVSTPre a true_pre (fun s0 _ s1 -> s0 == s1)

val " ^ get_protocol_id "print_session" ^ ": SidMap.sidt -> CVSTId unit
val " ^ get_protocol_id "print_tables" ^ ": unit -> CVSTId unit
val " ^ get_protocol_id "print_events" ^ ": unit -> CVSTId unit\n\n"
else "") ^
"effect CVSTInit (a:Type) =
  CVSTPre a (fun s0 -> State.is_init_state s0) (fun _ _ _ -> True)

val init_and_run (#a:Type) (f: unit -> CVSTInit a) : FStar.All.ML a

(* [establish_server a f] establishes a server on address [a]. The function [f]
   is called for each connection with an input/output channel connected to the
   client. A new process is created for each connection. The function
   [establish_server] normally does not return. It returns an error message in
   case of error. *)
val establish_server (a: Network.sockaddr) (f:(ch: Network.net_channel) -> CVSTInit unit) : FStar.All.ML string

(* [establish_server_no_fork #a #s addr max_pending timeout
   serializer f state] runs a server in a single
   thread (in contrast to [establish_server], which forks a new process
   for each connection). This is useful when the various instances of
   the server share a common state in memory. The implementation is based
   on non-blocking sockets. It is not designed to resist denial of service
   attacks.
   [a] is the type of input packets received by the server.
   [s] is the type of the internal state of the function [f], which processes
   packets. This state is passed from one call to [f] to the next one.
   [addr] is the address on which the server listens, typically
   [ADDR_INET(Network.inet_addr_any, <port number>)].
   [max_pending] is the maximum number of pending connections. When this number is
   exceeded, client connections are rejected.
   [timeout]: when a connection is inactive for longer than [timeout] seconds,
   it may be closed. A timeout of 0 means no timeout. This is not recommended,
   as it makes it easy for clients to create idle connections that remain forever.
   [serializer] is a serializer for type [a]. It is used to deserialize input
   packets.
   [f] is the function that processes packets. It receives an input packet
   of type [a] and its internal state of type [s] and returns a triple formed
   of the new internal state, the reply to send to the network, and a flag
   that tells whether the channel should be closed after sending this reply.
   The execution of [f] should be fast, since the server is blocked while
   [f] runs. In particular, [f] must not wait for network communications.
   [state] is the initial value of the internal state of [f].
   This function normally does not return. In case of error, it returns
   the current internal state of [f] and an error message.
  *)
val establish_server_no_fork (#a: Type0) (#s: Type0) (addr: Network.sockaddr)
  (max_pending: nat) (timeout: nat) (serializer: CVTypes.serializer a)
  (f: a -> s -> CVSTInvMin (s & CVTypes.bytes & bool))
  (state: s): CVSTInvMin (s & string)

val add_event (e: " ^ !protocol_name_allcaps ^ ".Events.FStar.fstar_event) :
  CVST1Call unit (" ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Invariant.pre_add_event e) (fun s1 _ s2 -> s2 == state_add_event s1 (FStarEvent e))

val remove_session (n: SidMap.sidt) :
  CVST1Call unit (fun s -> is_local n s) (fun s1 _ s2 -> s2 == remove_session s1 n)
"

let gen_str_effect_impl() =
"module " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Effect

open State

module InvariantLemmas = " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "InvariantLemmas

let repr (a:Type) (pre:pre_t) (post:post_t a) : Type0 =
  s: state stt { pre s } -> FStar.All.ML (r: (state stt * a) { post s r._2 r._1 })

let return (a:Type) (x:a)
: repr a (fun _ -> True) (fun s0 r s1 -> r == x /\\ s0 == s1)
= fun s -> (s,x)

/// bind bakes in the weakening of f's post to compose it with g's pre

let bind (a:Type) (b:Type)
  (pre_f:pre_t) (post_f:post_t a) (pre_g:a -> pre_t) (post_g:a -> post_t b)
  (f:repr a pre_f post_f) (g:(x:a -> repr b (pre_g x) (post_g x)))
: repr b
  (fun s0 -> pre_f s0 /\\ (forall (x:a) (s1:state stt). post_f s0 x s1 ==> pre_g x s1))
  (fun s0 y s2 -> exists (x:a) (s1:state stt). pre_f s0 /\\ post_f s0 x s1 /\\ post_g x s1 y s2)
= fun s0 ->
  let (s1,x) = f s0 in
  g x s1

/// sub comp rule

let subcomp (a:Type)
  (pre_f:pre_t) (post_f:post_t a)
  (pre_g:pre_t) (post_g:post_t a)
  (f:repr a pre_f post_f)
: Pure (repr a pre_g post_g)
  (requires
    (forall (s:state stt). pre_g s ==> pre_f s) /\\
    (forall (s0 s1:state stt) (x:a). (pre_g s0 /\\ post_f s0 x s1) ==> post_g s0 x s1))
  (ensures fun _ -> True)
= fun (x:state stt {pre_g x}) -> f x

/// We now define a lift from PURE. This is needed to use total computations/function calls
/// inside of CVST computations

let lift_pure a wp f = fun s ->
  FStar.Monotonic.Pure.elim_pure_wp_monotonicity wp;
  let x = f () in
  s, x

/// We now define a lift from CVSTBasic. This is needed to use network function calls
/// inside of CVST computations

friend CVSTBasic

let lift_basic a f = fun s ->
  let r = f () in
  s, r

let repr_inv (a:Type) (pre:pre_t) (post:post_t a) : Type0 =
  repr a (fun s0 -> InvariantLemmas.inv' s0 /\\ pre s0) (fun s0 r s1 ->
	post s0 r s1 /\\
	InvariantLemmas.local_rel' s0 s1)

val cvst_reflect (#a: Type) (#pre: pre_t) (#post:post_t a) (f: repr_inv a pre post): CVST1Call a pre post

let cvst_reflect #a #pre #post f = CVSTPre?.reflect f

val ml_to_CVST_repr (#a: Type) (f: eqtype_as_type unit -> FStar.All.ML a) :
  repr a true_pre (fun s0 _ s1 -> s0 == s1)

let ml_to_CVST_repr #a f = fun s -> s, f ()

let ml_to_CVST #a f = CVSTPre?.reflect (ml_to_CVST_repr f)

let print_string s = ml_to_CVST (fun _ -> FStar.IO.print_string s)
let print_bytes b = ml_to_CVST (fun _ -> CVTypes.print_bytes b)
let print_sid n = ml_to_CVST (fun _ -> SidMap.print_sid n)
let print_bool b = ml_to_CVST (fun _ -> CVTypes.print_bool b)

let print_label_bytes l b separator = ml_to_CVST (fun _ -> CVTypes.print_label_bytes l b separator)
let print_label_sid l n separator = ml_to_CVST (fun _ -> SidMap.print_label_sid l n separator)
let print_label_bool l b separator = ml_to_CVST (fun _ -> CVTypes.print_label_bool l b separator)

let get_repr : repr_inv (Ghost.erased (state stt)) true_pre
  (fun s0 r s1 -> s0 == s1 /\\ Ghost.reveal r == s1) =
  fun s ->
    InvariantLemmas.local_reflexivity' s;
    s, Ghost.hide s

let get_state () = cvst_reflect get_repr

let get_repr_no_par : repr (Ghost.erased (state stt)) true_pre
  (fun s0 r s1 -> s0 == s1 /\\ Ghost.reveal r == s1) =
  fun s -> s, Ghost.hide s

let get_state_no_par () = CVSTPre?.reflect get_repr_no_par\n\n" ^ 
(if !Settings.fstar_debug then
"// Functions that print the internal state

val print_to_CVST_repr (f: state stt -> FStar.All.ML unit) : repr unit true_pre (fun s0 _ s1 -> s0 == s1)

let print_to_CVST_repr (f: state stt -> FStar.All.ML unit) = fun s1 ->
  f s1;
  (s1, ())

val print_to_CVST (f: state stt -> FStar.All.ML unit) : CVSTId unit

let print_to_CVST (f: state stt -> FStar.All.ML unit) = CVSTPre?.reflect (print_to_CVST_repr f)

// print_session
let print_session_internal (sid: SidMap.sidt) (st: state stt) : FStar.All.ML unit =
  print_session #stt st " ^ !protocol_name_allcaps ^ "." ^ (!current_side) ^ "Sessions." ^ get_protocol_id "print_session_entry" ^ " sid

let " ^ get_protocol_id "print_session" ^ " (sid:SidMap.sidt) = print_to_CVST (print_session_internal sid)

// print_tables
let " ^ get_protocol_id "print_tables" ^ "() = print_to_CVST " ^ !protocol_name_allcaps ^ ".Tables.print

// print_events
let print_events_internal (st: state stt) : FStar.All.ML unit =
  print_events #stt st " ^ !protocol_name_allcaps ^ ".Events." ^ get_protocol_id "print_event" ^ " " ^ !protocol_name_allcaps ^ ".Events.FStar.print_fstar_event

let " ^ get_protocol_id "print_events" ^ " () = print_to_CVST print_events_internal\n\n"
else "") ^
"// init_and_run
val init_and_run_repr (#a:Type) (f: repr a (fun s -> State.is_init_state s) (fun _ _ _ -> True)) : FStar.All.ML a

let init_and_run_repr f =
  let ent = Lib.RandomSequence.entropy0 in
  let s = init_state stt ent in
  let s', r = f s in
  let _ = finalize_state s' in
  r

let init_and_run f = init_and_run_repr (reify (f ()))

let establish_server a f =
  Network.establish_server a (fun ch -> init_and_run_repr (fun s ->
    (reify (f ch)) s))

let internal_s (#s: Type0) (state0: state stt) : Type0 =
  (s0: (s & state stt) { InvariantLemmas.rel' state0 s0._2 })

let establish_server_no_fork_repr (#a: Type0) (#s: Type0) (addr: Network.sockaddr)
  (max_pending: nat) (timeout: nat)
  (serializer: CVTypes.serializer a)
  (f: a -> s -> repr (s & CVTypes.bytes & bool) (pre_inv true_pre) (post_inv (fun _ _ _ -> True)))
  (f_state: s) : repr (s & string) (pre_inv true_pre) (post_inv (fun _ _ _ -> True)) =
  fun (state0: state stt { InvariantLemmas.inv' state0 }) ->
  let internal_f (request: a) (state: internal_s #s state0) :
    FStar.All.ML (internal_s #s state0 & CVTypes.bytes & bool) =
    let (state', (f_state', reply, close_channel)) = f request state._1 state._2 in
    ((f_state', state'), reply, close_channel)
  in
  let ((f_state',state'), err_mess) =
    Network.establish_server_no_fork #a #(internal_s #s state0)
    addr max_pending timeout
    serializer internal_f (f_state, state0)
  in
  (state', (f_state',err_mess))

let establish_server_no_fork (#a: Type0) (#s: Type0) (addr: Network.sockaddr)
  (max_pending: nat) (timeout: nat)
  (serializer: CVTypes.serializer a) (f: a -> s -> CVSTInvMin (s & CVTypes.bytes & bool))
  (f_state: s) =
  let internal_f (request: a) (f_state: s) (state0: state stt { pre_inv true_pre state0 }):
    FStar.All.ML (r: (state stt & (s & CVTypes.bytes & bool)) { post_inv (fun _ _ _ -> Prims.l_True) state0 r._2 r._1 }) =
     (reify (f request f_state)) state0
  in
  CVSTPre?.reflect (establish_server_no_fork_repr #a #s addr max_pending timeout
    serializer internal_f f_state)

let add_event_repr (e: " ^ !protocol_name_allcaps ^ ".Events.FStar.fstar_event):
  repr_inv unit (" ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Invariant.pre_add_event e) (fun s1 x s2 -> x == () /\\ s2 == state_add_event s1 (FStarEvent e)) =
  fun s ->
    InvariantLemmas.add_event s e ;
    state_add_event s (FStarEvent e), ()

let add_event (e: " ^ !protocol_name_allcaps ^ ".Events.FStar.fstar_event) = cvst_reflect (add_event_repr e)

let remove_session_repr (n: SidMap.sidt):
  repr_inv unit (fun s -> is_local n s) (fun s1 x s2 -> x == () /\\ s2 == remove_session s1 n) =
  fun s ->
    InvariantLemmas.remove_session s n ;
    remove_session s n, ()

let remove_session (n: SidMap.sidt) = cvst_reflect (remove_session_repr n)
"

(* Equations module *)

let gen_str_equations translatable_equations impl_list =

  let is_trivial_equation t =
    match t.t_desc with
    | FunApp (f, _) -> f = Settings.c_true
    | _ -> false
  in

  let (str_equations, last_nr) = List.fold_left
    (fun (s, i) (_, bl, t, t_if, _, _) ->
      (let binders = (List.fold_left
          (fun s b ->
            s ^ "(" ^ get_binder_name b ^ ":" ^ get_type_name b.btype ^ ") ")
          ""
          bl) in
      let equation = (* side condition *)
        (if is_trivial_equation t_if then "" else
          ("  (" ^ (translate_term_ns t_if "  ") ^ "\n" ^
          "  ) =>\n")) ^
        (* main equation *)
        ("  " ^ translate_term_ns t "  ") in

      s ^

      (* Not using this style at the moment because it is hard
         to control the SMTPat for general equations:
         We want to avoid using `not` in an SMTPat, for example.
      "val " ^ lemma_id i ^ " " ^
      (if bl = [] then "(_:unit) " else binders) ^
      " : Lemma (\n" ^
      equation ^ ")\n" ^
      " [SMTPat (" ^ equation ^ ")]\n\n" *)

      "val " ^ lemma_id i ^ " " ^
      (* Binder List *)
      (if bl = [] then "(_:unit) " else binders) ^ " : " ^
      "Lemma (\n" ^
      equation ^ ")\n\n"
      , i + 1)
    )
    ("", 0)
    translatable_equations
  in

  let (str_inv_equations, last_nr) = List.fold_left
    (fun (s, i) f ->
      (match get_impl f with
      | Func x when f.f_name <> "" ->
          (let inv = get_inv_impl f in
              (* inv (f a) = Some (a) *)
              let inv_f =
                let binders = create_local_names "x" (fst f.f_type) in
                let binders_pat = create_local_names "y" (fst f.f_type) in
                let str_parameters = (List.fold_left2
                  (fun s b t ->
                    s ^ "(" ^ b ^ ":" ^ get_type_name t ^ ") ")
                  ""
                  binders
                  (fst f.f_type)) in
                let function_call = inv ^ " (" ^ x ^ " " ^
                  (if binders = [] then "()" else
                  (String.concat " " binders)) ^ ")" in
		let equality =
		  String.concat " /\\\n      " (List.mapi
                    (fun i t ->
                      (equal t) ^ " " ^ (List.nth binders i) ^ " " ^ (List.nth binders_pat i))
                    (fst f.f_type)
					       )
		in
                let equation =
                  (* main equation *)
		  if f.f_options land Settings.fopt_BIJECTIVE != 0 then
		    if binders = [] then "" else
		    "  let (" ^ (String.concat ", " binders_pat) ^ ") = " ^
		    function_call ^ " in\n  " ^ equality
		  else
                    "  match " ^ function_call ^ " with\n" ^
                    "  | Some (" ^
                    (String.concat ", " binders_pat) ^ ") ->\n" ^
                    "      " ^
                    (if binders = [] then "True" else equality) ^ "\n" ^
                    "  | None -> False"
                in
                "val " ^ lemma_id i ^ " " ^
                (if binders = [] then "(_:unit) " else str_parameters) ^
                ": Lemma (" ^
                equation ^ ")\n" ^
                "[SMTPat (" ^
                function_call ^
                ")]\n\n"
              in
              (* f (inv a) = a *)
              let f_inv =
                let returns_unit = ((snd f.f_type) = Settings.t_unit) in
                let binders_pat = create_local_names "y" (fst f.f_type) in
                let str_parameters = "(x:" ^ get_type_name (snd f.f_type) ^ ")" in
                let function_call = inv ^ (if returns_unit then " () " else " x ") in
		let equality =
		  (if returns_unit then "True" else
                  (equal (snd f.f_type)) ^ " (" ^ x ^ " " ^ (if binders_pat = [] then "()" else String.concat " " binders_pat) ^ ") x") ^ "\n"
		in
                let equation =
		  if f.f_options land Settings.fopt_BIJECTIVE != 0 then
		    "let (" ^ (String.concat ", " binders_pat) ^ ") = " ^ function_call ^ " in\n" ^
		    equality
		  else
                    "  match " ^ function_call ^ "  with\n" ^
                    "  | Some (" ^ (String.concat ", " binders_pat) ^ ") ->\n" ^
                    "      " ^ equality ^
                    "  | None -> " ^
                    (if binders_pat = [] then "True" else
                    "~ (exists " ^
                    (List.fold_left2
                       (fun s b t -> s ^ "(" ^ b ^ ":" ^ get_type_name t ^ ") ")
                       ""
                       binders_pat
                       (fst f.f_type)
                    ) ^
                    ". " ^
                    (equal (snd f.f_type)) ^ " (" ^ x ^ " " ^ (if binders_pat = [] then "()" else String.concat " " binders_pat) ^ ") x)") in

                "val " ^ lemma_id (i+1) ^ " " ^
                (if returns_unit then "(_:unit) " else str_parameters) ^
                ": Lemma (" ^
                equation ^
                ")\n" ^
                "[SMTPat (" ^
                function_call ^
                ")]\n\n"
              in
              s ^ inv_f ^ f_inv
              , i + 2
          )
      | Func x (*when f.f_name = ""*) -> s, i (* We currently do not translate the tuple/detuple functions *)
      | Const _ | SepFun | FuncEqual | FuncDiff -> Parsing_helper.internal_error "Only non-constant non-letfun functions expected as functions that have an inverse."
      | No_impl -> assert false
    ))
    ("", last_nr)
    !inv_functions in

  let (str_fun_equations, last_nr) = get_fun_equations false last_nr in

  let (str_tuple_lemmas, last_nr) = List.fold_left (fun (s, i) tl ->
    let x_vars = create_fresh_names "x_" (List.length tl) in
    let return_vars = create_fresh_names "cvar_" (List.length tl) in
    let ser_list x_vars tl =
      "[" ^ (String.concat "; " (List.map2 (fun x t ->
	(get_write_serial t) ^ " " ^ x) x_vars tl))^"]"
    in
    (s ^
    "let " ^ (lemma_id i) ^
    (String.concat "" (List.map2 (fun x t ->
      " ("^x^": "^get_type_name t^")"
				     ) x_vars tl))^":\n"^
    "  Lemma ("^ get_tuple_dec_fun_name tl ^ " (Tuples.compos "^
    get_tuple_tag_name tl ^ " "^ser_list x_vars tl^") == Some("^
    (String.concat ", " x_vars)^"))\n"^
    "  =\n"^
    "  let l = "^ser_list x_vars tl^" in\n"^
    "  let buf = Tuples.compos "^get_tuple_tag_name tl^" l in\n"^
    "  Tuples.lemma_check_tag "^get_tuple_tag_name tl^" l buf;\n"^
    "  match Tuples.check_tag "^get_tuple_tag_name tl^" buf with\n"^
    "  | None -> ()\n"^
    "  | Some pos ->\n"^
    let rec aux x_vars return_vars tl =
      match x_vars, return_vars, tl with
      | [], [], [] ->
	  "  ()\n\n"
      | x::x_vars_rest, cvar::return_vars_rest, t::tl_rest ->
	  "  lemma_append_ok (Tuples.compos_rec "^
	  ser_list x_vars tl^") ("^get_write_serial t^" "^x^") (Tuples.compos_rec "^
	  ser_list x_vars_rest tl_rest^") buf pos;\n"^
	  "  "^get_deser_ok_lemma t^" "^x^" buf pos;\n"^
	  "  match "^get_read_serial t^" buf pos with\n"^
	  "  | DSTooShort _ | DSFailure -> ()\n"^
	  "  | DSOk("^cvar^", pos) ->\n"^
	  aux x_vars_rest return_vars_rest tl_rest
      | _ -> assert false
    in
    aux x_vars return_vars tl^

    let pos_vars = create_fresh_names "pos_" (List.length tl) in
    "let " ^ (lemma_id (i+1)) ^ " (buf: bytes) :\n"^
    "  Lemma (match "^get_tuple_dec_fun_name tl^" buf with\n"^
    "  | None -> True\n" ^
    "  | Some("^(String.concat ", " x_vars)^") -> buf == Tuples.compos "^
    get_tuple_tag_name tl^" "^ser_list x_vars tl^")\n"^
    "  =\n"^
    "  Tuples.lemma_check_tag_rev "^get_tuple_tag_name tl^" buf;\n"^
    "  match Tuples.check_tag "^get_tuple_tag_name tl^" buf with\n"^
    "  | None -> ()\n"^
    "  | Some pos_0 ->\n"^
    let rec aux1 in_pos pos_vars return_vars tl =
      match pos_vars, return_vars, tl with
      | [], [], [] ->
	  "  if "^in_pos^" = Seq.length buf then\n"
      | out_pos::pos_vars_rest, cvar::return_vars_rest, t::tl_rest ->
	  "  "^get_deser_rev_lemma t^" buf "^in_pos^";\n"^
	  "  match "^get_read_serial t^" buf "^in_pos^" with\n"^
	  "  | DSTooShort _ | DSFailure -> ()\n"^
	  "  | DSOk("^cvar^", "^out_pos^") ->\n"^
	  aux1 out_pos pos_vars_rest return_vars_rest tl_rest
      | _ -> assert false
    in
    aux1 "pos_0" pos_vars return_vars tl^
    "  begin\n"^
    let rec aux2 in_pos pos_vars return_vars tl =
      match pos_vars, return_vars, tl with
      | [], [], [] ->
          ""
      | out_pos::pos_vars_rest, cvar::return_vars_rest, t::tl_rest ->
	  aux2 out_pos pos_vars_rest return_vars_rest tl_rest^
	  "    lemma_append_rev ("^get_write_serial t^" "^cvar^") (Tuples.compos_rec "^
	  ser_list return_vars_rest tl_rest^") buf "^in_pos^";\n"
      | _ -> assert false
    in
    aux2 "pos_0" pos_vars return_vars tl^
    "    lemma_append_rev (Tuples.char4_of_int "^get_tuple_tag_name tl^") (Tuples.compos_rec "^ser_list return_vars tl^") buf 0\n"^
    "  end\n"^
    "  else ()\n\n"), i+2
      ) ("",last_nr) (!tuple_types)
  in

  let str_tuple_letfun_lemmas,_ = List.fold_left (fun
    (s,nr) (side_prefix, impl_letfuns, _, _) ->
      letfun_prefix := !protocol_name_allcaps ^ "." ^ side_prefix ^ letfun_module ^ ".";
      List.fold_left (fun (s,nr) (f,bl,res,translate) ->
	if not (translate && f.f_impl != SepFun) then s,nr else
	(* The letfun is translatable and has a direct F* implementation.
           Check that the two match *)

	let f_name =
	  match get_impl f with
	  | Func x -> x
	  | Const x -> assert (bl = []); x
	  | _ -> assert false
	in

	s ^
	(* The proof of equality for randomized functions in F* works
	   for trivial cases, but may not work when randomness manipulations
	   are not the same on both sides, even though they yield the same
	   distribution *)
	(if f.f_impl_ent then "(* Proofs of equality between randomized functions work only\n   when the random choices are organized in the same way.\n   You might admit the result otherwise. *)\n" else "") ^
	"val " ^ lemma_id nr ^ " " ^
	(String.concat "" (List.map (fun b ->
	  "(" ^ get_binder_name b ^ ": " ^ get_type_name b.btype ^ ") ") bl)) ^
	(if f.f_impl_ent then "(" ^ (get_state_decl NEntropy) ^ ") " else
	if bl = [] then "() " else "") ^ ": Lemma (" ^
	equal (snd f.f_type) ^
	(* The direct F* implementation *)
	" (" ^ f_name ^
	String.concat "" (List.map (fun b -> " " ^ get_binder_name b) bl) ^
	(if f.f_impl_ent then " " ^ (get_state_var NEntropy) else "") ^ ")" ^
	(if f.f_impl_ent then "._2" else "") ^ " " ^
	(* The letfun implementation *)
	"(" ^ !letfun_prefix ^ get_letfun_name f ^
	String.concat "" (List.map (fun b -> " " ^ get_binder_name b) bl) ^
	(if f.f_impl_ent then " " ^ (get_state_var NEntropy) else
	if bl = [] then " ()" else "") ^ ")" ^
	(if f.f_impl_ent then "._2" else "") ^ ")\n\n"

	,nr+1

	) (s,nr) impl_letfuns
      ) ("",last_nr) impl_list
  in

  "module " ^ !protocol_name_allcaps ^ ".Equations\n\n" ^
  "open CVTypes\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Types\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Functions\n\n" ^
  str_equations ^
  str_inv_equations ^
  str_fun_equations ^
  str_tuple_lemmas ^
  str_tuple_letfun_lemmas

let gen_str_equations_impl translatable_equations impl_list =

  let (str_equations, last_nr) = List.fold_left
    (fun (s, i) (_, bl, t, t_if, _, _) ->
      (let binders = (List.fold_left
          (fun s b ->
            s ^ "(" ^ get_binder_name b ^ ":" ^ get_type_name b.btype ^ ") ")
          ""
          bl) in
      s ^
      "let " ^ lemma_id i ^ " " ^
      (* Binder List *)
      (if bl = [] then "(_:unit) " else binders) ^ " = ()\n\n"
      , i + 1)
    )
    ("", 0)
    translatable_equations
  in

  let (str_inv_equations, last_nr) = List.fold_left
    (fun (s, i) f ->
      (match get_impl f with
      | Func x when f.f_name <> "" ->
          (
              (* inv (f a) = Some (a) *)
              let inv_f =
                let binders = create_local_names "x" (fst f.f_type) in
                let str_parameters = (List.fold_left2
                  (fun s b t ->
                    s ^ "(" ^ b ^ ":" ^ get_type_name t ^ ") ")
                  ""
                  binders
                  (fst f.f_type)) in
                "let " ^ lemma_id i ^ " " ^
                (if binders = [] then "(_:unit) " else str_parameters) ^
                " = ()\n\n"
              in
              (* f (inv a) = a *)
              let f_inv =
                let returns_unit = ((snd f.f_type) = Settings.t_unit) in
                let str_parameters = "(x:" ^ get_type_name (snd f.f_type) ^ ")" in
                "let " ^ lemma_id (i+1) ^ " " ^
                (if returns_unit then "(_:unit) " else str_parameters) ^
                " = ()\n\n"
              in
              s ^ inv_f ^ f_inv
              , i + 2
          )
      | Func x (*when f.f_name = ""*) -> s, i (* We currently do not translate the tuple/detuple functions *)
      | Const _ | SepFun | FuncEqual | FuncDiff -> Parsing_helper.internal_error "Only non-constant non-letfun functions expected as functions that have an inverse."
      | No_impl -> assert false
    ))
    ("", last_nr)
    !inv_functions in

  let (str_fun_equations, last_nr) = get_fun_equations true last_nr in

  let last_nr = last_nr + 2 * List.length (!tuple_types) in

  let str_tuple_letfun_lemmas,_ = List.fold_left (fun
    (s,nr) (side_prefix, impl_letfuns, _, _) ->
      letfun_prefix := !protocol_name_allcaps ^ "." ^ side_prefix ^ letfun_module ^ ".";
      List.fold_left (fun (s,nr) (f,bl,res,translate) ->
	if not (translate && f.f_impl != SepFun) then s,nr else
	(* The letfun is translatable and has a direct F* implementation.
           Check that the two match *)

	s ^
	(* The proof of equality for randomized functions in F* works
	   for trivial cases, but may not work when randomness manipulations
	   are not the same on both sides, even though they yield the same
	   distribution *)
	(if f.f_impl_ent then "(* Proofs of equality between randomized functions work only\n   when the random choices are organized in the same way.\n   You might admit the result otherwise. *)\n" else "") ^
	"let " ^ lemma_id nr ^ " " ^
	(String.concat "" (List.map (fun b ->
	  "(" ^ get_binder_name b ^ ": " ^ get_type_name b.btype ^ ") ") bl)) ^
	(if f.f_impl_ent then "(" ^ (get_state_decl NEntropy) ^ ") " else
	if bl = [] then "() " else "") ^ " = ()\n\n"

	,nr+1

	) (s,nr) impl_letfuns
      ) ("",last_nr) impl_list
  in

  "module " ^ !protocol_name_allcaps ^ ".Equations\n\n" ^
  "open CVTypes\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Types\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Functions\n\n" ^
  "(* PLEASE PROVE ALL EQUATIONS *)\n\n" ^
  str_equations ^
  str_inv_equations ^
  str_fun_equations ^
  str_tuple_letfun_lemmas

(* Variables module *)

let fstar_vars (b, secr_opt) =
  let bname = get_binder_name b in
  let stb = get_prefix_binder_name "st" b bname in
  let stqueriedb = get_prefix_binder_name "stqueried" b bname in
  let vnstb = get_prefix_binder_name "vnst" b bname in
  let vnstqueriedb = get_prefix_binder_name "vnstqueried" b bname in
  let ty = get_type_name b.btype in
  match secr_opt with
  | RealOrRandom false ->
      [ FSVar (stb, vnstb, ty);
        FSVar (stqueriedb, vnstqueriedb, ty) ]
  | RealOrRandom true ->
      [ FSVar (stb, vnstb, ty);
        FSBool (stqueriedb, vnstqueriedb) ]
  | Reachability false ->
      [ FSVar (stb, vnstb, ty);
        FSVar (stqueriedb, vnstqueriedb, "unit") ]
  | Reachability true ->
      [ FSVar (stb, vnstb, ty) ]
  | Bit ->
      (* All variables are under replication by the constraints on modules,
	 and bit-secrecy can be proved only for variables not under replication *)
      assert false

let fstar_all_vars prepared_queries =
  (List.map (fun b ->
    FSVar (get_prefix_binder_name "st" b (get_binder_name b),
	   get_prefix_binder_name "vnst" b (get_binder_name b),
	   get_type_name b.btype)
	    ) prepared_queries.public_vars) @
  List.concat (List.map fstar_vars prepared_queries.secret_vars)

let gen_str_variables_impl fstar_variables =
  if fstar_variables = [] then
    "module " ^ !protocol_name_allcaps ^ ".Variables\n\n" ^
    "type t = unit\n\n" ^
    "val init: t\n\n" ^
    "let init = ()\n\n"
  else

  let str_variables_record = "noeq type t = {\n" ^
    (String.concat ""
       (List.map (function
	 | FSBool(v,_) -> "  "^v^": bool;\n"
	 | FSVar(v,_,t) -> "  "^v^": var "^t^";\n"
		 ) fstar_variables)) ^
    "}\n"
  in

  let str_variables_init = "let init = {\n" ^
    (String.concat ""
       (List.map (function
	 | FSBool(v,_) -> "  "^v^" = false;\n"
	 | FSVar(v,_,t) -> "  "^v^" = var_empty "^t^";\n"
		 ) fstar_variables)) ^
    "}\n"
  in

  let str_variables_names =
    String.concat ""
      (List.map (fun fsv ->
	let s, v, vn =
	  match fsv with
	  | FSBool(v,vn) -> "accessor t bool", v, vn
	  | FSVar(v,vn,t) -> "var_name t "^t, v, vn
	in
	"val " ^ vn ^ ": " ^ s ^ "\n" ^
	"let " ^ vn ^ " =\n" ^
	"  { get = (fun vars -> vars." ^ v ^ ");\n" ^
	"    set = (fun vars -> fun var -> { vars with " ^ v ^ " = var }) }\n\n"
		) fstar_variables)
  in

  "module " ^ !protocol_name_allcaps ^ ".Variables\n\n" ^
  "open CVTypes\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Types\n" ^
  "open State\n\n" ^
  str_variables_record ^ "\n" ^
  "val init: t\n\n" ^
  str_variables_init ^ "\n" ^
  str_variables_names ^ "\n"

(* Queries *)

(* There are two kinds of oracles for queries:

   - Those that return a value (test queries for indistinguishability
     secrecy, reveal queries for reachability secrecy). The returned
     result is computed by [get_call_return], the arguments of the
     CVST effect are computed by [cvst_args_return] (they express that
     the result is computed using [get_call_return]), and the name of
     the function is computed by [fun_name_return].

   - Those that compare with a received value (test queries for
     (one-session) reachability secrecy). The compared result is
     computed by [get_call_eq], the arguments of the CVST effect are
     computed by [cvst_args_eq] (they express that the result of 
     [get_call_eq] is guaranteed to be different from the received value), 
     and the name of the function is computed by [fun_name_eq].
*)

let get_call_return (b, opt) =
  let bname = get_binder_name b in
  let vnstb = get_prefix_binder_name "vnst" b bname in
  let vnstqueriedb = get_prefix_binder_name "vnstqueried" b bname in
  match opt with
  | RealOrRandom onesession ->
      if onesession then
	if !current_side = side1^"." (* Real *) then
	  "State.indist_one_session_real s1 "^vnstb^" "^vnstqueriedb^" n"
	else (* Ideal *)
	  begin
	    assert(!current_side = side2^".");
	    "State.indist_one_session_ideal s1 "^vnstb^" "^vnstqueriedb^" "^get_random b.btype^" n"
	  end
      else
	if !current_side = side1^"." (* Real *) then
	  "State.indist_real s1 "^vnstb^" n"
	else (* Ideal *)
	  begin
	    assert(!current_side = side2^".");
	    "State.indist_ideal s1 "^vnstb^" "^vnstqueriedb^" "^get_random b.btype^" n"
	  end
  | Reachability false ->
      "State.reach_reveal s1 "^vnstb^" "^vnstqueriedb^" n"
  | Reachability true -> raise Not_found
  | Bit -> assert false

let cvst_args_return (b,opt) =
  "(option " ^ get_type_name b.btype ^ ") true_pre (fun s1 res s2 ->
  (s2, res) == " ^ get_call_return (b,opt) ^ ")"

let fun_name_return (b,opt) =
  let bname = get_binder_name b in
  match opt with
  | RealOrRandom _ ->
      (get_prefix_binder_name "indist" b bname,
       get_prefix_binder_name "reprindist" b bname,
       get_prefix_binder_name "lemmaindist" b bname)
  | Reachability false ->
      (get_prefix_binder_name "reachreveal" b bname,
       get_prefix_binder_name "reprreachreveal" b bname,
       get_prefix_binder_name "lemmareachreveal" b bname)
  | Reachability true -> raise Not_found
  | Bit -> assert false

let get_call_eq (b,opt) =
  let bname = get_binder_name b in
  match opt with
  | RealOrRandom _ -> raise Not_found
  | Reachability false ->
      "State.reach_test s1 "^get_prefix_binder_name "vnst" b bname^" "^
      get_prefix_binder_name "vnstqueried" b bname^" n"
  | Reachability true ->
      "State.var_get s1 "^get_prefix_binder_name "vnst" b bname^" n"
  | Bit -> assert false

let cvst_args_eq (b,opt) =
  "unit (fun s1 -> ~(" ^ get_call_eq (b,opt) ^ " == Some v))"

let fun_name_eq (b,opt) =
  let bname = get_binder_name b in
  get_prefix_binder_name "reach" b bname

type fqterm =
  | FQEvent of string option
  | FQTerm
  | FQAnd of fqterm * fqterm
  | FQOr of fqterm * fqterm
  | FQNot of fqterm

let rec build_fqterm = function
  | QEvent(inj,_) ->
      let f = Terms.fresh_id "tauf" in
      let f = check_no_identifier_collision ["correspondence mapping function"; f] f in
      FQEvent(if inj then Some f else None)
  | QTerm _ -> FQTerm
  | QNot(QEvent(false,_) as t) -> FQNot(build_fqterm t)
  | QNot _ | QExists _ | QForall _ -> assert false
  | QAnd(t1,t2) -> FQAnd(build_fqterm t1, build_fqterm t2)
  | QOr(t1,t2) -> FQOr(build_fqterm t1, build_fqterm t2)

let rec collect_functions accu = function
  | FQEvent(Some f) -> f :: accu
  | FQEvent None | FQTerm -> accu
  | FQAnd(t1,t2) | FQOr(t1,t2) ->
      collect_functions (collect_functions accu t1) t2
  | FQNot t -> collect_functions accu t

let translate_eterm t =
  match t.t_desc with
  | FunApp(f, _::l) ->
      "(" ^ cv_event ^ " (" ^ get_event_name f ^ " " ^ (String.concat " " (List.map (fun t -> translate_term_ns t "") l)) ^ "))"
  | _ -> assert false

let args s vars =
  List.map (fun b ->
    let bname = get_binder_name b in
    if s = "" then bname else get_prefix_binder_name s b bname) vars

let targs s vars =
  String.concat "" (List.map2 (fun bname b ->
    "("^bname^": "^(get_type_name b.btype) ^ ") ") (args s vars) vars)

let quantify q l s =
  if l = [] then s else "      ("^q^" "^(targs "" l) ^ ".\n" ^ s ^ ")"

let rec translate_qterm forall t ft args =
  match t, ft with
  | QEvent(inj, t), FQEvent(fopt) ->
      if inj then
	"(occursat e ("^(Option.get fopt)^" "^args^") "^(translate_eterm t)^")"
      else
	"(List.memP "^(translate_eterm t)^" e)"
  | QTerm t, FQTerm ->
      translate_term_ns t ""
  | QAnd(t1,t2), FQAnd(ft1,ft2) ->
      "(" ^ translate_qterm forall t1 ft1 args ^ " /\\ " ^ translate_qterm forall t2 ft2 args ^ ")"
  | QOr(t1,t2), FQOr(ft1,ft2) ->
      "(" ^ translate_qterm forall t1 ft1 args ^ " \\/ " ^ translate_qterm forall t2 ft2 args ^ ")"
  | QNot(QEvent(false,t)), FQNot _ ->
      let forallev =
	List.filter (fun b -> Terms.refers_to b t) forall
      in
      quantify "forall" forallev
	("        (~(List.memP "^(translate_eterm t)^" e))")
  | _ -> assert false

let translate_corresp (t1,t2) =
  let (forall, exists, forall2) = Terms.collect_vars_corresp t1 t2 in
  let corresp_base_name =
    match t1 with
    | (_,{t_desc = FunApp(f,_)}) :: _ -> alphabetize_string f.f_name
    | _ -> "corresp"
  in
  let corresp_name = Terms.fresh_id corresp_base_name in
  let corresp = check_no_identifier_collision [ "correspondence"; corresp_name ] ("corresp_"^corresp_name) in
  let lemma = check_no_identifier_collision [ "lemma for correspondence"; corresp_name ] ("lemma_"^corresp_name) in
  let ft2 = build_fqterm t2 in
  let step_functions = collect_functions [] ft2 in
  let steparg s n =
    let id = s^"tau"^(string_of_int (n+1)) in
    check_no_identifier_collision [ "step id"; id ] id
  in
  let targf s =
    (String.concat "" (List.mapi (fun n _ -> "("^steparg s n^": interv e) ") t1)) ^
    (targs s forall)
  in
  let argf s =
    (String.concat "" (List.mapi (fun n _ -> steparg s n^" ") t1)) ^
    (String.concat "" (List.map (fun id -> id^" ") (args s forall)))
  in
  let interface =
    (if List.exists (fun (inj,_) -> inj) t1 then
      (* Injective correspondence *)
      let ft = check_no_identifier_collision [ "step function type for correspondence"; corresp_name ] ("ft_"^corresp_name) in
      let injprop = check_no_identifier_collision [ "injectivity property for correspondence"; corresp_name ] ("inj_"^corresp_name) in
      "type "^ft^" (e:evlist) = "^
      (String.concat "" (List.map (fun _ -> "interv e -> ") t1)) ^
      (String.concat "" (List.map (fun b -> (get_type_name b.btype) ^ " -> ") forall)) ^
      "intervopt e\n\n" ^
      "type "^injprop^" (e:evlist) (f: "^ft^" e) = \n"^
      "  forall "^ (targf "x") ^ (targf "y") ^ ".\n" ^
      "    ((f "^ (argf "x") ^ "== f " ^(argf "y")^ ") /\\ ~(f " ^ (argf "x") ^ "== None)) ==> (" ^
      let first = ref true in
      (String.concat "" (List.mapi (fun n (inj, _) ->
	if inj then
	  let prefix = if !first then "" else " /\\ " in
	  first := false;
	  prefix ^ steparg "x" n ^ " == " ^ steparg "y" n
	else
	  "") t1)) ^ ")\n\n" ^
      "type "^corresp^" (e: evlist) = \n"^
      "  exists " ^ (String.concat "" (List.map (fun f -> "(" ^ f ^ ": " ^ ft ^ " e)") step_functions)) ^ ".\n" ^
      "    "^(String.concat " /\\ " (List.map (fun f -> injprop^" e "^f) step_functions))^" /\\\n"^
      "    (forall " ^ (targf "") ^ ".\n" ^
      "      ("^(String.concat " /\\ " (List.mapi (fun n (inj,t) ->
	"(List.Tot.index e " ^ steparg "" n ^ " == "^translate_eterm t^")") t1))^
      ") ==>\n"^
      (quantify "exists" exists
	    ("        "^translate_qterm forall2 t2 ft2 (argf "")))^
      ")\n\n"
    else
      begin
	(* Non-injective correspondence: step functions not needed *)
	assert (step_functions = []);
	"type "^corresp^" (e: evlist) = \n"^
	(if forall = [] then "" else "  forall " ^ (targs "" forall) ^ ".\n")^
	"    ("^(String.concat " /\\ " (List.map (fun (inj,t) ->
	  assert(inj = false);
	  "(List.memP "^translate_eterm t^" e)") t1))^
	") ==>\n"^
	(quantify "exists" exists
	   ("        "^translate_qterm forall2 t2 ft2 ""))^"\n\n"
      end)^
    "val "^lemma^": unit -> CVSTAxiom unit (fun s -> "^corresp^" (State.events_of s))\n\n"
  in
  let implem =
    "let "^lemma^"() = admit()\n\n"
  in
  (interface, implem)


let cvst_args_public b =
  let bname = get_binder_name b in
  "(option " ^ get_type_name b.btype ^ ") true_pre (fun s1 res s2 ->
  (s2 == s1) /\\ res == State.var_get s1 "^get_prefix_binder_name "vnst" b bname ^ " n)"

let gen_str_queries_interface corresp =
  "module " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Queries\n\n"^
  "open CVTypes\n" ^
  "open State\n" ^ 
  "open " ^ !protocol_name_allcaps ^ ".Types\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Variables\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Functions\n" ^
  "open " ^ !protocol_name_allcaps ^ "." ^ (!current_side) ^ "Protocol\n" ^
  "open " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Effect\n\n" ^

  (String.concat "" (List.map (fun b ->
    let bname = get_binder_name b in
    let pubb = get_prefix_binder_name "public" b bname in
    "val "^ pubb ^ ": (n:SidMap.sidt) -> CVST1Call " ^ cvst_args_public b ^ "\n\n"
			   ) ((!prepared_queries_ref).public_vars))) ^
  (String.concat "" (List.map (fun (b,opt) ->
    (try
      let (f,_, _) = fun_name_return (b,opt) in
      "val " ^ f ^ ": (n: SidMap.sidt) -> CVST1Call " ^ cvst_args_return (b, opt) ^ "\n\n"
    with Not_found ->
      "") ^
    (try
      let f = fun_name_eq (b, opt) in
      "val " ^ f ^ ": (n:SidMap.sidt) -> (v:"^get_type_name b.btype ^") -> CVSTAxiom " ^ cvst_args_eq (b, opt) ^ "\n\n"
    with Not_found ->
      "")
  ) ((!prepared_queries_ref).secret_vars))) ^
  (if (!prepared_queries_ref).corresp = [] then "" else
  let prot_event = get_protocol_id "event" in
  "open " ^ !protocol_name_allcaps ^ ".Events\n\n" ^
  "type evlist = list " ^ prot_event ^ "\n\n" ^
  "type interv (e: evlist) = x: nat { x < List.length e }\n\n" ^
  "type intervopt (e: evlist) = option (interv e)\n\n" ^
  "let occursat (e: evlist) (tauopt:intervopt e) (evt: "^prot_event^") =
  match tauopt with
  | None -> False
  | Some tau -> List.Tot.index e tau == evt\n\n"^
  String.concat "" (List.map fst corresp))

let gen_str_queries_impl corresp =
  "module " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Queries\n\n" ^
  "open CVTypes\n" ^
  "open State\n" ^ 
  "open " ^ !protocol_name_allcaps ^ ".Types\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Variables\n" ^
  "open " ^ !protocol_name_allcaps ^ "." ^ (!current_side) ^ "Protocol\n" ^
  "friend " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Effect\n\n" ^
  (String.concat "" (List.map (fun b ->
    let bname = get_binder_name b in
    let pubb = get_prefix_binder_name "public" b bname in
    let reprpubb = get_prefix_binder_name "reprpublic" b bname in
    "val " ^ reprpubb ^ " (n:SidMap.sidt): repr_inv " ^ cvst_args_public b ^ "\n" ^
    "let " ^ reprpubb ^ " n = fun s1 ->
  " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "InvariantLemmas.local_reflexivity' s1;
  s1, State.var_get s1 "^get_prefix_binder_name "vnst" b bname ^ " n\n\n" ^
    "let " ^ pubb ^ " (n:SidMap.sidt) = cvst_reflect (" ^ reprpubb ^ " n)\n\n"
			   ) ((!prepared_queries_ref).public_vars))) ^

  (String.concat "" (List.map (fun (b,opt) ->
    (try
      let (fun_name, repr_fun_name, lemma_fun_name) = fun_name_return (b,opt) in
      "val "^repr_fun_name ^ " (n:SidMap.sidt): repr_inv " ^ cvst_args_return (b,opt) ^ "\n" ^
      "let "^repr_fun_name ^ " n = fun s1 ->\n  " ^
      "  " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "QueryLemmas."^lemma_fun_name^ " n s1;\n   " ^
      get_call_return (b, opt) ^ "\n\n" ^
      "let "^fun_name ^" (n:SidMap.sidt) = cvst_reflect ("^repr_fun_name ^ " n)\n\n"
    with Not_found ->
      "") ^
    (try
      let fun_name = fun_name_eq (b,opt) in
      "let "^fun_name^" (n:SidMap.sidt) (v:"^get_type_name b.btype^") = admit()\n\n"
    with Not_found ->
      "")
      ) ((!prepared_queries_ref).secret_vars))) ^
  (String.concat "" (List.map snd corresp))


let gen_str_querylemmas_interface () =
  "module " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "QueryLemmas\n\n"^
  "open CVTypes\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Types\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Variables\n" ^
  "open " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Protocol\n\n" ^

  (String.concat "" (List.map (fun b_opt ->
    try
      let (_,_,lemma_fun_name) = fun_name_return b_opt in
      "val "^ lemma_fun_name ^ " (n: SidMap.sidt) (s1: "^state_type()^"):\n" ^
      "  Lemma (requires (" ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "InvariantLemmas.inv' s1))\n" ^
      "    (ensures (" ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "InvariantLemmas.local_rel' s1 (" ^ get_call_return b_opt ^ ")._1))\n\n"
    with Not_found ->
      ""
  ) ((!prepared_queries_ref).secret_vars)))

let gen_str_querylemmas_impl () =
  "module " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "QueryLemmas\n\n" ^
  "open CVTypes\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Types\n" ^
  "open " ^ !protocol_name_allcaps ^ ".Variables\n" ^
  "open " ^ !protocol_name_allcaps ^ "." ^ !current_side ^ "Protocol\n\n" ^
  (String.concat "" (List.map (fun b_opt ->
    try
      let (_,_,lemma_fun_name) = fun_name_return b_opt in
      "(* PLEASE ADD PROOF FOR THE FOLLOWING LEMMA *)\n"^
      "let "^lemma_fun_name ^ " (n: SidMap.sidt) (s1: "^state_type()^") = ()\n\n"
    with Not_found ->
      ""
	) ((!prepared_queries_ref).secret_vars)))

(* Print a string to a file *)

let print_to_file filename content =
  let f = open_out (Filename.concat !Settings.out_dir filename) in
  output_string f content;
  close_out f

let print_template filename content =
  print_to_file (filename ^ ".template") content;
  if not (Sys.file_exists (Filename.concat !Settings.out_dir filename)) then
    print_to_file filename content

(* Remove redundant queries *)

let includes l l' =
  List.for_all (fun b -> List.memq b l') l

let implies_query q q' =
  match q, q' with
  | QDiffEquivalence pub_vars, QDiffEquivalence pub_vars' ->
      includes pub_vars' pub_vars
  | QEquivalence(_,pub_vars,_), QEquivalence(_,pub_vars',_) ->
      includes pub_vars' pub_vars
  | QSecret(x, pub_vars, opt), QSecret(x', pub_vars', opt') ->
      (x == x') && (includes pub_vars' pub_vars) &&
      (match opt, opt' with
      | _ when opt = opt' -> true
      | Bit, _ -> true
      | RealOrRandom false, _ -> true
      | RealOrRandom true, Bit -> true
          (* Bit secrecy is equivalent to real-or-random secrecy and
	     to one-session real-or-random secrecy, because the bit must
	     be chosen once. There may be a constant probability loss. *)
      | _, Bit -> false
      | _, RealOrRandom false -> false
      | _, Reachability true -> true
      | Reachability true, _ -> false
      | _ -> false
	    )
  | QEventQ(t1,t2,pub_vars),  QEventQ(t1',t2',pub_vars') ->
      false
      (* We could be more precise here:
	 (includes pub_vars' pub_vars) && (matches (t1,t2) (t1',t2'))
	 but the computation of [matches] is complicated,
	 and it is not essential, so we just give up for simplicity. *)
  | _ -> false

let remove_redundant_queries queries =
  let rec aux seen = function
    | [] -> seen
    | a::l ->
	let test_fun q = implies_query q a in
	if List.exists test_fun seen
        || List.exists test_fun l then
	  aux seen l
	else
	  let filter_fun q = not (implies_query a q) in
	  let seen' = List.filter filter_fun seen in
	  let l' = List.filter filter_fun l in
	  aux (a::seen') l'
  in
  aux [] queries

(* Check that the public variables are coherent *)

let check_coherent_public_vars queries =
  let public_vars = Settings.get_public_vars0 queries in
  List.iter (fun q ->
    let public_vars_q =
      match q with
      | QSecret (b', pub_vars, Reachability true) ->
      (* For one-session reachability secrecy, the variable for which we
	 prove secrecy is not considered public. *)
	  pub_vars
      | QSecret (b',pub_vars,_) ->
	  b'::pub_vars
      | QEventQ (_,_,pub_vars)
      | QEquivalence(_,pub_vars,_)
      | QEquivalenceFinal(_,pub_vars)
      | QDiffEquivalence(pub_vars) ->
	  pub_vars
      | AbsentQuery -> []
    in
    if not (Terms.equal_lists_sets_q public_vars public_vars_q) then
      let display_pubvars pubvars =
	if pubvars = [] then
	  Display.print_string "no public variable"
	else
	  begin
	    Display.print_string "public variable(s) ";
	    Display.display_list Display.display_binder pubvars
	  end
      in
      let s = Display.string_out (fun () ->
	Display.print_string "The query ";
	Display.display_query3 q;
	Display.print_string " has ";
	display_pubvars public_vars_q;
	Display.print_string ". This is not coherent with the other queries, which have ";
	display_pubvars public_vars;
	Display.print_string "."
	  )
      in
      error s
	) queries;
  public_vars

(* Prepare the queries *)

let prepare_queries public_secret_vars queries =
  let prepared_queries = ref empty_prepared_queries in
  List.iter (function
    | QSecret(x, pub_vars, opt) ->
	(* There can be at most one secrecy query for each variable,
	   by the elimination of redundant queries and the constraints on
	   public variables. *)
	assert (not (List.exists (fun (b,_) -> b == x) (!prepared_queries.secret_vars)));
	prepared_queries := { !prepared_queries with secret_vars = (x, opt) :: (!prepared_queries).secret_vars }
    | QEventQ(t1,t2,pub_vars) ->
	prepared_queries := { !prepared_queries with corresp = (t1,t2) :: (!prepared_queries).corresp }
    | QEquivalence _ ->
	prepared_queries := { !prepared_queries with has_equiv = true }
    | QDiffEquivalence _ ->
	prepared_queries := { !prepared_queries with has_diff_equiv = true }
    | QEquivalenceFinal _ -> assert false
    | AbsentQuery -> ()
	     ) queries;
  { !prepared_queries with
    public_vars = List.filter (fun x -> not (List.exists (fun (b,_) -> b == x) (!prepared_queries.secret_vars))) public_secret_vars }


(* Check that two implementations have the same oracles in the same modules *)

let compatible_oracle_data oracle1 oracle2 =
  (* Compatibility is tested only between elements that have the same
     key in the map, so they have the same name *)
  assert (oracle1.oracle_name = oracle2.oracle_name);
  if not (oracle1.under_repl = oracle2.under_repl) then
    begin
      let get_under_repl o =
	if o.under_repl then
	  " is under replication"
	else
	  " is not under replication"
      in
      error ("Oracle "^oracle1.oracle_name^(get_under_repl oracle1)^" on the real side and"^(get_under_repl oracle2)^" on the ideal side.\nIt should be either under replication on both sides and not under replication on both sides.")
    end;
  if not (match oracle1.previous_oracle, oracle2.previous_oracle with
  | None, None -> true
  | Some o1, Some o2 -> o1.oracle_name = o2.oracle_name
  | _ -> false) then
    begin
      let get_previous o =
	match o.previous_oracle with
	| None -> " has no previous oracle"
	| Some op -> " has previous oracle "^op.oracle_name
      in
      error ("Oracle "^oracle1.oracle_name^(get_previous oracle1)^" on the real side and"^(get_previous oracle2)^" on the ideal side.\nIt should have the same previous oracle on both sides.")
    end;
  let get_type tl =
    String.concat ", " (List.map (fun t -> t.tname) tl)
  in
  if not (Terms.equal_lists (==) oracle1.input_type oracle2.input_type) then
    error ("Oracle "^oracle1.oracle_name^" has input type "^(get_type oracle1.input_type)^" on the real side and "^(get_type oracle2.input_type)^" on the ideal side.\nIt should have the same input type on both sides.");
  begin
    match oracle1.output_type, oracle2.output_type with
    | None,_ | _,None -> ()
    | Some tl1, Some tl2 ->
	if not (Terms.equal_lists (==) tl1 tl2) then
	  error ("Oracle "^oracle1.oracle_name^" has output type "^(get_type tl1)^" on the real side and "^(get_type tl2)^" on the ideal side.\nIt should have the same output type on both sides.")
  end;
  true

let same_module_oracles (mod1, _, oracles1) (mod2, _, oracles2) =
  if mod1 = mod2 then
    begin
      if not (StringMap.equal compatible_oracle_data oracles1 oracles2) then
	begin
	  let get_oracles om =
	    StringMap.fold (fun o _ s ->
	      if s = "" then o else s ^ ", " ^ o) om ""
	  in
	  error ("Module "^mod1^ " contains oracle(s) "^(get_oracles oracles1)^" on the real side and "^(get_oracles oracles2)^" on the ideal side.\nIt should contain the same oracles on both sides.")
	end;
      true
    end
  else
    false

let check_same_modules_oracles oracles_for_modules1 oracles_for_modules2 =
  if not (Terms.equal_lists_sets same_module_oracles oracles_for_modules1 oracles_for_modules2) then
    error "When two F* implementations are generated, they should contain the same modules, with the same oracles inside each module"

(* Main function for generating implementations *)

let do_implementation filename impl equations proved_queries =
  let proved_queries = remove_redundant_queries proved_queries in
  let public_secret_vars = check_coherent_public_vars proved_queries in
  let prepared_queries = prepare_queries public_secret_vars proved_queries in
  List.iter get_corresp_types prepared_queries.corresp;
  let has_real_or_random_secrecy =
    List.exists (function
      | (_, (RealOrRandom _ | Bit)) -> true
      | _ -> false) prepared_queries.secret_vars
  in
  (* We revise the provided implementation(s) depending on whether
     equivalence is proved and whether real-or-random secrecy queries
     are present. *)
  let impl_list =
    match impl with
    | Impl0 -> assert false
    | Impl1 impl1 ->
	assert (prepared_queries.has_diff_equiv = false &&
		prepared_queries.has_equiv = false);
	prepare_letfun_1impl impl1;
	if has_real_or_random_secrecy then
	  [(side1^".", impl1); (side2^".", impl1)]
	else
	  ["",impl1]
    | Impl2 (impl1, impl2) ->
	assert (not (prepared_queries.has_diff_equiv && prepared_queries.has_equiv));
	prepare_letfun_2impl impl1 impl2;
	if prepared_queries.has_diff_equiv || prepared_queries.has_equiv then
	  [(side1^".", impl1); (side2^".", impl2)]
	else
	  begin
	    print_string "Warning: equivalence not proved; generating F* implementation for the first process only (supposed to be the protocol).\n";
	    if has_real_or_random_secrecy then
	      [(side1^".", impl1); (side2^".", impl1)]
	    else
	      ["",impl1]
	  end
  in

  let fstar_variables = fstar_all_vars prepared_queries in
  prepared_queries_ref := prepared_queries;

  set_protocol_name filename;

  (* Capitalize module names, since this is required by F* *)
  let impl_list =
    List.map (fun (side_prefix, (impl_letfuns, impl_processes)) ->
      let impl_processes = 
	List.map (fun (x, opt, p) ->
	  (String.capitalize_ascii (alphabetize_string x), opt, p)
	    ) impl_processes
      in
      (side_prefix, (impl_letfuns, impl_processes))
	 ) impl_list
  in

  List.iter (fun (side_prefix,impl) ->
    check_no_module_name_clash impl
      ) impl_list;

  (* Set translations for some built-in types *)
  Settings.t_bitstring.timplname <- Some "bytes";
  Settings.t_bitstring.tequal <- Some "eq_bytes";
  Settings.t_bitstringbot.timplname <- Some "(option bytes)";
  Settings.t_bitstringbot.tequal <- Some "eq_obytes";
  Settings.t_bool.trandom <- Some "Random.gen_bool";
  Settings.f_or.f_impl <- Func "( || )";

  let impl_list =
    List.map (fun (side_prefix,(impl_letfuns, impl_processes)) ->
      let oracles_for_modules =
	List.map
	  (fun (x, opt, p) ->
            oracles := StringMap.empty;
            ignore(get_iprocess_oracles p true None 0);
            (x, opt, !oracles)
	      ) impl_processes
      in
      List.iter (fun (f,bl,res) ->
	if f.f_impl == SepFun then
	  (* This letfun must be implemented in F* to run the protocol *)
	  get_term_types res
		) impl_letfuns;
      (side_prefix, impl_letfuns, impl_processes, oracles_for_modules)
	) impl_list
  in

  (* When we generate two implementations, check that they have the same
     oracles in the same modules *)
  begin
    match impl_list with
    | [(_,_,_, oracles_for_modules1); (_,_,_, oracles_for_modules2)] ->
	check_same_modules_oracles oracles_for_modules1 oracles_for_modules2
    | _ -> ()
  end;

  (* Determine which equations and letfuns we are actually going to implement
     in F*. We implement them when all useful functions have an implementation,
     or for letfuns, when they are needed [f.f_impl == SepFun] *)

  let translatable_equations = List.filter
    (fun (_, _, t, t_if, _, _) ->
      term_is_translatable t && term_is_translatable t_if)
    equations
  in

  let impl_list =
    List.map (fun (side_prefix, impl_letfuns, impl_processes, oracles_for_modules) ->
      let impl_letfuns =
	List.map (fun (f,bl,res) ->
	  (* There are two cases in which we want to translate a letfun:
	     1/ the function is needed to implement the protocol and it is
	     not provided a direct F* implementation. In this case,
	     [f.f_impl == SepFun].
	     2/ the function is useful to state a lemma saying that a letfun
	     matches its F* implementation. In this case, we are sure
	     that the letfun does not need the full state and has the
	     same implementation on both sides. As a consequence, the value
	     of [translate] is the same on both sides.
	     The flag [translate] slightly overapproximates these two cases,
	     in case a letfun is present in the input and not used at all. *)
	  let translate = f.f_impl == SepFun || ((not f.f_impl_needs_full_state) && (not f.f_impl_diff_side) && term_is_translatable res) in
	  (* When a letfun [f] is used to state a lemma saying that another
	     letfun matches its F* implementation, we must implement the
	     letfun [f] as a [SepFun]: the calls to [f] call the [letfun]. *)
	  if translate && f.f_impl = No_impl then f.f_impl <- SepFun;
	  (f,bl,res, translate)
        ) impl_letfuns
      in
      (side_prefix, impl_letfuns, impl_processes, oracles_for_modules)
	     ) impl_list
  in

  if List.length equations <> List.length translatable_equations then (
    info ("Number of translatable equations: " ^ string_of_int (List.length translatable_equations) ^
          " out of " ^ string_of_int (List.length equations) ^ " equations.")
  );

  (* collect types, functions, etc, that are needed to implement all translatable equations and letfuns *)
  List.iter
    (fun (_, _, t, t_if, _, _) -> get_term_types t; get_term_types t_if)
    translatable_equations;
  List.iter
    (fun (side_prefix, impl_letfuns, impl_processes, oracles_for_modules) ->
      List.iter (fun (f,bl,res,translate) ->
	(* Already done when [f.f_impl == SepFun] *)
	if translate && f.f_impl != SepFun then get_term_types res
		) impl_letfuns
    ) impl_list;

  (* The order of generation of modules is important: for example, generating
     the module Sessions may add serialization/deserialization to some types,
     which adds functions in module Types. *)
  List.iter (fun (side_prefix, impl_letfuns, impl_processes, oracles_for_modules) ->
    if List.exists (fun (_,_,_,translate) -> translate) impl_letfuns then
      begin
	current_side := side_prefix;
	print_string ("Generating "^side_prefix^"Letfun module ...\n");

        (* Inside the Letfun module, we do not need to explicitly use the namespace. *)
	letfun_prefix := "";
	print_to_file (!protocol_name_allcaps ^ "." ^ side_prefix ^ letfun_module ^ ".fst") (get_letfun_implementation letfun_module impl_letfuns)
      end
	) impl_list;

  print_string ("Generating Functions module ...\n");
  print_to_file (!protocol_name_allcaps ^ ".Functions.fsti") (gen_str_functions ());
  print_template (!protocol_name_allcaps ^ ".Functions.fst") (gen_str_functions_impl ());

  print_string ("Generating Tables module ...\n");
  print_to_file (!protocol_name_allcaps ^ ".Tables.fst") (gen_str_tables_impl ());

  print_string ("Generating Variables module ...\n");
  print_to_file (!protocol_name_allcaps ^ ".Variables.fst") (gen_str_variables_impl fstar_variables);

  print_string ("Generating Event module ...\n");
  print_to_file (!protocol_name_allcaps ^ ".Events.fst") (gen_str_events_impl ());

  print_string ("Generating Event.FStar module ...\n");
  print_template (!protocol_name_allcaps ^ ".Events.FStar.fst") (gen_str_fstar_events_impl ());

  List.iter (fun (side_prefix, impl_letfuns, impl_processes, oracles_for_modules) ->
    current_side := side_prefix;
    (* In all modules except Letfun, we call explicitly into the Letfun namespace. *)
    letfun_prefix := !protocol_name_allcaps ^ "." ^ side_prefix ^ letfun_module ^ ".";

    print_string ("Generating "^side_prefix^"Sessions module ...\n");
    print_to_file (!protocol_name_allcaps ^ "." ^ side_prefix ^ "Sessions.fsti") (gen_str_sessions_interface oracles_for_modules);
    print_to_file (!protocol_name_allcaps ^ "." ^ side_prefix ^ "Sessions.fst") (gen_str_sessions_impl oracles_for_modules);

    print_string ("Generating "^side_prefix^"Protocol module ...\n");
    print_to_file (!protocol_name_allcaps ^ "." ^ side_prefix ^ "Protocol.fst") (gen_str_protocol ());

    print_string ("Generating "^side_prefix^"Invariant module ...\n");
    print_template (!protocol_name_allcaps ^ "." ^ side_prefix ^ "Invariant.fst") (gen_str_invariant oracles_for_modules);

    print_string ("Generating "^side_prefix^"InvariantLemmas module ...\n");
    print_to_file (!protocol_name_allcaps ^ "." ^ side_prefix ^ "InvariantLemmas.fsti") (gen_str_invariant_lemmas_intf oracles_for_modules);
    print_template (!protocol_name_allcaps ^ "." ^ side_prefix ^ "InvariantLemmas.fst") (gen_str_invariant_lemmas_impl oracles_for_modules);

    print_string ("Generating "^side_prefix^"Effect module ...\n");
    print_to_file (!protocol_name_allcaps ^ "." ^ side_prefix ^ "Effect.fsti") (gen_str_effect_interface ());
    print_to_file (!protocol_name_allcaps ^ "." ^ side_prefix ^ "Effect.fst") (gen_str_effect_impl ());


    if List.exists (fun (_,opt) ->
      match opt with
      | RealOrRandom _ | Reachability false -> true
      | Reachability true | Bit -> false) prepared_queries.secret_vars then
      begin
 	print_string ("Generating "^side_prefix^"QueryLemmas module ...\n");
	print_to_file (!protocol_name_allcaps ^ "." ^ side_prefix ^ "QueryLemmas.fsti") (gen_str_querylemmas_interface ());
	print_template (!protocol_name_allcaps ^ "." ^ side_prefix ^ "QueryLemmas.fst") (gen_str_querylemmas_impl ());
      end;

    if prepared_queries.public_vars != [] ||
       prepared_queries.secret_vars != [] ||
       prepared_queries.corresp != [] then
      begin
	print_string ("Generating "^side_prefix^"Queries module ...\n");
	let corresp = List.map translate_corresp prepared_queries.corresp in
	print_to_file (!protocol_name_allcaps ^ "." ^ side_prefix ^ "Queries.fsti") (gen_str_queries_interface corresp);
	print_to_file (!protocol_name_allcaps ^ "." ^ side_prefix ^ "Queries.fst") (gen_str_queries_impl corresp);
      end
	    ) impl_list;

  print_string ("Generating Types module ...\n");
  print_to_file (!protocol_name_allcaps ^ ".Types.fsti") (gen_str_types ());
  print_template (!protocol_name_allcaps ^ ".Types.fst") (gen_str_types_impl ());

  print_string ("Generating Equations module ...\n");
  print_to_file (!protocol_name_allcaps ^ ".Equations.fsti") (gen_str_equations translatable_equations impl_list);
  print_template (!protocol_name_allcaps ^ ".Equations.fst") (gen_str_equations_impl translatable_equations impl_list);

  List.iter (fun (side_prefix, impl_letfuns, impl_processes, oracles_for_modules) ->
    current_side := side_prefix;
    (* Modules for oracles *)
    (* In all modules except Letfun, we call explicitly into the Letfun namespace. *)
    letfun_prefix := !protocol_name_allcaps ^ "." ^ side_prefix ^ letfun_module ^ ".";

    List.iter (fun (x, opt, oracles) ->
      print_string ("Generating implementation for module " ^ side_prefix ^ x ^ " ...\n");
      print_to_file (!protocol_name_allcaps ^ "." ^ side_prefix ^ x ^ ".Spec.fsti") (get_interface_spec x opt oracles);
      print_template (!protocol_name_allcaps ^ "." ^ side_prefix ^ x ^ ".Spec.fst") (get_implementation_spec x opt oracles);

      print_to_file (!protocol_name_allcaps ^ "." ^ side_prefix ^ x ^ ".fst") (get_implementation x opt oracles);
      print_to_file (!protocol_name_allcaps ^ "." ^ side_prefix ^ x ^ ".fsti") (get_interface x opt oracles)
	      ) oracles_for_modules
	    ) impl_list;

  prepared_queries_ref := empty_prepared_queries
