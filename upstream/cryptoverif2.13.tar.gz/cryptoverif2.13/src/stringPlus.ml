(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
(* String helper functions *)

(* [equal_substring s1 n1 s2 n2 len] returns true when
   the substring of [s1] starting at position [n1] of length [len]
   is equal to the substring of [s2] starting at position [n2] 
   of length [len].
   Assumes that [n1 >= 0, n2 >= 0, len >= 0],
   the length of [s1] is at least [n1+len]
   and the length of [s2] is at least [n2+len]. *)

let rec equal_substring s1 n1 s2 n2 len =
  (len == 0) ||
  ((s1.[n1] == s2.[n2]) && equal_substring s1 (n1+1) s2 (n2+1) (len-1))

(* [starts_with s sub] is true when the string [s] starts with
   [sub]. *)
	
let starts_with s sub =
  let len = String.length sub in
  (String.length s >= len) &&
  (equal_substring s 0 sub 0 len)

(* [ends_with s sub] is true when the string [s] ends with
   [sub]. *)
	
let ends_with s sub =
  let l_s = String.length s in
  let l_sub = String.length sub in
  (l_s >= l_sub) && (equal_substring s (l_s - l_sub) sub 0 l_sub)

(* [contains_from s sub n] is true when the substring of [s]
   starting at position [n] contains [sub] *)
    
let rec contains_from s sub n =
  let l_sub = String.length sub in
  (l_sub + n <= String.length s) &&
  ((equal_substring s n sub 0 l_sub) || contains_from s sub (n+1))

(* [contains s sub] is true when [s] contains [sub] *)
    
let contains s sub =
  contains_from s sub 0

(* [pos_from s sub n] returns [Some n'] when the substring of [s]
   starting at position [n] contains [sub] at position [n'], 
   and [None] when the substring of [s] starting at position [n] 
   does not contain [sub]. *)
    
let rec pos_from s sub n =
  let l_sub = String.length sub in
  if l_sub + n > String.length s then
    None
  else if equal_substring s n sub 0 l_sub then
    Some n
  else
    pos_from s sub (n+1)

(* [pos s sub] returns [Some n'] when [s] contains [sub] at 
   position [n'], and [None] when [s] does not contain [sub]. *)

let pos s sub =
  pos_from s sub 0

(* [case_insensitive_equal_substring s1 n1 s2 n2 len] returns true when
   the substring of [s1] starting at position [n1] of length [len]
   is equal to the substring of [s2] starting at position [n2] 
   of length [len]. Comparison is case insensitive.
   Assumes that [n1 >= 0, n2 >= 0, len >= 0],
   the length of [s1] is at least [n1+len]
   and the length of [s2] is at least [n2+len]. *)

let rec case_insensitive_equal_substring s1 n1 s2 n2 len =
  (len == 0) ||
  ((Char.lowercase_ascii s1.[n1] == Char.lowercase_ascii s2.[n2]) &&
   case_insensitive_equal_substring s1 (n1+1) s2 (n2+1) (len-1))

(* [case_insensitive_ends_with s sub] is true when the string [s] ends with
   [sub]. Comparison is case insensitive. *)
	
let case_insensitive_ends_with s sub =
  let l_s = String.length s in
  let l_sub = String.length sub in
  (l_s >= l_sub) &&
  (case_insensitive_equal_substring s (l_s - l_sub) sub 0 l_sub)

(* [case_insensitive_contains_from s sub n] is true when the substring of [s]
   starting at position [n] contains [sub]. Comparison is case insensitive. *)
    
let rec case_insensitive_contains_from s sub n =
  let l_sub = String.length sub in
  (l_sub + n <= String.length s) &&
  ((case_insensitive_equal_substring s n sub 0 l_sub) ||
  case_insensitive_contains_from s sub (n+1))

(* [case_insensitive_contains s sub] is true when [s] contains [sub]. 
   Comparison is case insensitive. *)
    
let case_insensitive_contains s sub =
  case_insensitive_contains_from s sub 0

(* [alphabetize_string] converts any string into a string that contains
   only alphanumeric characters (A..Z,a..z,0..9) and underscore.
   This function is injective. This is required to avoid clashes
   between OCaml/F* identifiers generated from CryptoVerif identifiers. *)

let is_alphabetic c =
  (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')

let hex_of_char buf c = Printf.bprintf buf "%02x" (int_of_char c)

let alphabetize_string s =
  let buf = Buffer.create 16 in
  String.iter
    (fun c ->
      if is_alphabetic c then
	Buffer.add_char buf c
      else if c = '_' then
	Buffer.add_string buf "__"
      else
	begin
	  Buffer.add_char buf '_';
	  hex_of_char buf c
	end)
    s;
  Buffer.contents buf

