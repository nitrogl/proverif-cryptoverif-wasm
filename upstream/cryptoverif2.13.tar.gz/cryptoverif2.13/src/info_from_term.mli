(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Types

(* [def_vars_and_facts_from_term g_opt expanded in_find t] extracts a list of defined 
   variables and a list of facts implied by [t]

   [expanded] is true when [t] is for sure already expanded.
   (Otherwise, it will be expanded internally.)

   When [in_find = true], it assumes that [t] is a condition
   of [find].
   When [in_find = false], it does not make such assumptions. *)
val def_vars_and_facts_from_term : game option -> bool -> bool -> term -> term list * binderref list * elsefind_fact list

(* [else_info_from_find_branch g_opt expanded br] returns 
   information certainly true when the condition in the branch [br] fails
   (elsefind facts) *) 
val else_info_from_find_branch : game option -> bool -> 'a findbranch -> elsefind_fact list
    
(* [add_else_info_find g_opt expanded l0] adds information collected 
   by [else_info_from_find_branch] to each branch of find in [l0] *)
val add_else_info_find : game option -> bool -> 'a findbranch list -> ('a findbranch * elsefind_fact list) list

(* [info_from_find_branch g_opt expanded br] returns a pair of
   information certainly true when the condition of find in the branch [br]
   succeeds (facts, defined variables, elsefind facts)
   and information certainly true when this condition fails
   (elsefind facts) *) 
val info_from_find_branch : game option -> bool -> 'a findbranch -> (term list * binderref list * elsefind_fact list) * elsefind_fact list

(* [add_info_find g_opt expanded l0] adds information collected 
   by [info_from_find_branch] to each branch of find in [l0] *)
val add_info_find : game option -> bool -> 'a findbranch list -> ('a findbranch * ((term list * binderref list * elsefind_fact list) * elsefind_fact list)) list
