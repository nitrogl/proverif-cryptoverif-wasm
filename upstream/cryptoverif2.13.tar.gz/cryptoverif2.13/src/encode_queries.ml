(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Types
  
let encode_queries ql p =
  let ql', p' = 
    List.fold_left (fun (ql_done, p) q ->
      match q with
      | QSecret(v, pub_vars, Reachability one_session) ->
	  let index_types = List.map (fun ri -> ri.ri_type) v.args_at_creation in
	  (* Build the new query adv_has_v(idx) ==> false *)
	  let adv_has_event =
	    Terms.create_event (Terms.fresh_id ("adv_has_"^v.sname)) []
	  in
          (* Adding the event to Stringmap.env so that it can be used in the "focus" command *)
	  Stringmap.env := Stringmap.StringMap.add adv_has_event.f_name (Stringmap.EEvent adv_has_event) (!Stringmap.env);
	  let event_var =
	    Terms.create_binder "i" Settings.t_bitstring []
	  in
	  let reveal_info =
	    if one_session || index_types = [] then
	      None
	    else
	      let reveal_param =
		{ pname = Terms.fresh_id "Nreveal";
		  psize = Settings.psize_DEFAULT }
	      in
	      let ty_reveal_param = Terms.type_for_param reveal_param in
	      let reveal_repl_idx =
		Terms.create_repl_index "ireveal" ty_reveal_param
	      in
	      let reveal_idx =
		List.map (fun ty ->
		  Terms.create_binder "u" ty [reveal_repl_idx]
		    ) index_types
	      in
	      let reveal_var =
		Terms.create_binder "reveal" v.btype [reveal_repl_idx]
	      in
              let reveal_query_process =
       		let pats_input = List.map (fun v -> PatVar v) reveal_idx in
		let reveal_o = { oname = Terms.fresh_id "o_reveal";
				 oindices_type = [ty_reveal_param];
				 oarg_type = index_types;
				 oret_type = None;
				 oret_ch = NoChan }
		in
		let reveal_decl = { ooracle = reveal_o;
				    oindices = [reveal_repl_idx] }
		in	
		let make_idx() =
		  List.map Terms.term_from_binder reveal_idx
		in
		let find_proc =
		  Terms.oproc_from_desc
		    (Find([[],[(v, make_idx())],Terms.make_true(), Terms.oproc_from_desc (Let(PatVar reveal_var, Terms.build_term_type v.btype (Var(v, make_idx())), Terms.oproc_from_desc Yield, Terms.oproc_from_desc Yield))],
			  Terms.oproc_from_desc Yield, Nothing))
		in
		let input_proc =
		  Terms.iproc_from_desc (OracleDecl(reveal_decl, pats_input, find_proc))
		in
		Terms.iproc_from_desc (Repl(reveal_repl_idx, input_proc))
	      in
	      Some (reveal_repl_idx, reveal_idx, reveal_var, reveal_query_process)
	  in
	  
	  let test_query_process =
	    let test_param =
	      { pname = Terms.fresh_id "Ntest";
		psize = Settings.psize_DEFAULT }
	    in
	    let ty_test_param = Terms.type_for_param test_param in
	    let test_repl_idx =
	      Terms.create_repl_index "itest" ty_test_param
	    in
	    let test_idx =
	      List.map (fun ty ->
		Terms.create_binder "u" ty [test_repl_idx]
		  ) index_types
	    in
	    let test_var =
	      Terms.create_binder v.sname v.btype [test_repl_idx]
	    in
	    let make_idx() =
	      List.map Terms.term_from_binder test_idx
	    in
	    let test_cond = 
	      Terms.make_equal
		(Terms.term_from_binder test_var)
		(Terms.build_term_type v.btype (Var(v, make_idx())))
	    in
	    let tupf = Settings.get_tuple_fun [ty_test_param] in
	    let tcur_array =
	      Terms.app tupf [Terms.term_from_repl_index test_repl_idx]
	    in
	    let event_proc =
	      Terms.oproc_from_desc (EventP(Terms.app adv_has_event [tcur_array], Terms.oproc_from_desc Yield))
	    in
	    let find_proc =
	      Terms.oproc_from_desc
		(Find([[],[(v, make_idx())],test_cond, event_proc],
		      Terms.oproc_from_desc Yield, Nothing))
	    in
	    let find2_proc =
	      match reveal_info with
	      | None -> find_proc
	      | Some(reveal_repl_idx, reveal_idx, reveal_var, _) ->
		  let find_idx_var = Terms.create_binder "u" reveal_repl_idx.ri_type [test_repl_idx] in
		  let find_idx = Terms.create_repl_index "ri"  reveal_repl_idx.ri_type in
		       
		  Terms.oproc_from_desc
		    (Find([ [find_idx_var, find_idx],
			    (reveal_var, [Terms.term_from_repl_index find_idx])::(List.map (fun ridx -> (ridx, [Terms.term_from_repl_index find_idx])) reveal_idx),
			    Terms.make_and_list (List.map2 (fun ridx tidx ->
			      Terms.make_equal (Terms.term_from_binderref (ridx, [Terms.term_from_repl_index find_idx]))
				(Terms.term_from_binder tidx)) reveal_idx test_idx),
			    Terms.oproc_from_desc Yield],
			  find_proc, Nothing))
	    in
	    let pats_input =
              (PatVar test_var)::(List.map (fun v -> PatVar v) test_idx)
	    in
	    let o =
	      { oname = Terms.fresh_id "o_test";
		oindices_type = [ty_test_param];
		oarg_type = v.btype::index_types;
		oret_type = None;
		oret_ch = NoChan }
	    in
	    let input_proc = Terms.iproc_from_desc
		(OracleDecl({ ooracle = o;
                              oindices = [test_repl_idx] },
			    pats_input,
                            find2_proc))
	    in
	    Terms.iproc_from_desc (Repl(test_repl_idx, input_proc))
	  in
	  let p' =
	    Terms.iproc_from_desc (Par(p, test_query_process))
	  in
	  let p'' =
	    match reveal_info with
	    | None -> p'
	    | Some (_,_,_,reveal_query_process) ->
		Terms.iproc_from_desc (Par(p', reveal_query_process))
	  in
	  let pub_vars' =
	    match reveal_info with
	    | None -> pub_vars
	    | Some (_,_,reveal_var,_) -> reveal_var::pub_vars
	  in
	  let q' = QEventQ([false, Terms.app adv_has_event [Terms.term_from_binder event_var]],
			   QTerm (Terms.make_false()), pub_vars')
	  in
	  ((q', Some q)::ql_done, p'') 
      | _ ->
	  ((q, None)::ql_done, p)
	    ) ([],p) ql
  in
  List.rev ql', p'
