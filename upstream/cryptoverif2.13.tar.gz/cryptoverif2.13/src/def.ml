(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Types

(* Empty tree of definition dependances 
   The treatment of TestE/FindE/LetE/ResE is necessary: build_def_process
   is called in check.ml (and on other non-expanded games).
*)


let rec empty_def_term t =
  t.t_facts <- None;
  begin
    match t.t_desc with
      Var(b,l) ->
	b.def <- []
    | FindE(l0,t3,_) ->
	List.iter (fun (bl,def_list,t1,t2) ->
	  List.iter (fun (b1,b2) -> b1.def <- []) bl) l0
    | ResE(b,t) -> b.def <- []
    | _ -> ()
  end;
  Terms.iter_subterm  empty_def_term empty_def_def_list empty_def_pattern t
    
and empty_def_term_list l = List.iter empty_def_term l

and empty_def_def_list def_list =
  List.iter (fun (b,l) -> b.def <- []; empty_def_term_list l) def_list

and empty_def_pattern = function
    PatVar b -> b.def <- []
  | pat -> Terms.iter_subpat empty_def_term empty_def_pattern pat

let rec empty_def_process p = 
  p.i_facts <- None;
  Terms.iter_subiproc empty_def_process
    (fun o patl p -> 
      List.iter empty_def_pattern patl;
      empty_def_oprocess p) p

and empty_def_oprocess p = 
  p.p_facts <- None;
  begin
  match p.p_desc with
  | Restr(b,p) ->
      b.def <- []
  | Find(l0,p2,_) ->
      List.iter (fun (bl,def_list,t,p1) ->
	List.iter (fun (b1,b2) -> b1.def <- []) bl) l0
  | _ -> ()
  end;
  Terms.iter_suboproc empty_def_oprocess empty_def_term empty_def_def_list
    empty_def_pattern empty_def_process p

let rec empty_def_fungroup = function
    ReplRestr(repl_opt, restr, funlist) ->
      List.iter (fun (b,ext,_) -> b.def <- []) restr;
      List.iter empty_def_fungroup funlist
  | Fun(ch, args, res, priority) ->
      List.iter (fun b -> b.def <- []) args;
      empty_def_term res

let empty_def_member l =
  List.iter (fun (fg, mode) -> empty_def_fungroup fg) l


(* Build tree of definition dependences
   The treatment of TestE/FindE/LetE/ResE is necessary: build_def_process
   is called in check.ml.

   The value of elsefind_facts is correct even if the game has not been expanded:
   we correctly discard elsefind_facts when their defined condition refers
   to a variable defined in a term.
   *)

let whole_game = ref None

(* Limit the length of fut_pps to avoid a performance bottleneck *)
let concat_fut_pps fut_pps1 fut_pps2 =
  match fut_pps1, fut_pps2 with
  | Some l1, Some l2 ->
      let l = l1 @ l2 in
      if !Settings.max_fut_pps_length = 0 ||
         List.length l <= !Settings.max_fut_pps_length
      then Some l
      else None
  | _ -> None

let fut_join (fut_binders1, fut_true_facts1, fut_pps1)
    (fut_binders2, fut_true_facts2, fut_pps2) =
  (* We cannot exploit that fut_pps1 = Some [] => case 1 cannot be
     executed if another block is executed afterwards, because
     the proof of correspondences uses future binders without guarantee
     that another block is executed afterwards. *)
  (Terms.intersect (==) fut_binders1 fut_binders2, 
   Terms.intersect Terms.equal_terms fut_true_facts1 fut_true_facts2,
   concat_fut_pps fut_pps1 fut_pps2)
   
	
let find_list_to_elsefind accu l =
  List.fold_left (fun accu (_, (_,efl)) ->
    List.fold_left (fun (fact_accu, else_find_accu) (bl, def_list, t1) ->
      if bl == [] && def_list == [] then
	((Terms.make_not t1)::fact_accu, else_find_accu)
      else
	(fact_accu, (bl, def_list, t1)::else_find_accu)
	  ) accu efl
	) accu l

let rec add_vars_from_pat accu = function
    PatVar b -> Terms.addq accu b
  | PatEqual t -> accu
  | PatTuple (f,l) -> add_vars_from_pat_list accu l

and add_vars_from_pat_list accu = function
    [] -> accu
  | (a::l) -> add_vars_from_pat_list (add_vars_from_pat accu a) l

let rec def_vars_term accu t = 
  match t.t_desc with
    Var(_,l) | FunApp(_,l) -> def_vars_term_list accu l
  | ReplIndex i -> accu
  | TestE(t1,t2,t3) -> 
      def_vars_term (def_vars_term (def_vars_term accu t1) t2) t3
  | FindE(l0, t3, _) ->
      let accu = ref (def_vars_term accu t3) in
      List.iter (fun (bl, def_list, t1, t2) ->
	(*Nothing to do for def_list: it contains only
          Var and Fun*)
	accu := Terms.unionq (List.map fst bl) (def_vars_term (def_vars_term (!accu) t1) t2)
	     ) l0;
      !accu
  | LetE(pat, t1, t2, topt) ->
      let accu' = match topt with
	None -> accu
      |	Some t3 -> def_vars_term accu t3 
      in
      def_vars_term (def_vars_pat (add_vars_from_pat (def_vars_term accu' t2) pat) pat) t1
  | ResE(b,t) ->
      Terms.addq (def_vars_term accu t) b
  | EventAbortE _ -> accu
  | EventE(t,p) ->
      def_vars_term (def_vars_term accu p) t
  | GetE(tbl,patl,topt,p1,p2,_) ->
      let accu' = match topt with
	None -> accu
      |	Some t -> def_vars_term accu t
      in
      def_vars_term (def_vars_term (def_vars_pat_list (add_vars_from_pat_list accu' patl) patl) p1) p2
  | InsertE(tbl,tl,p) ->
      def_vars_term_list (def_vars_term accu p) tl
      
and def_vars_term_list accu = function
    [] -> accu
  | (a::l) -> def_vars_term (def_vars_term_list accu l) a

and def_vars_pat accu = function
    PatVar b -> accu 
  | PatTuple (f,l) -> def_vars_pat_list accu l
  | PatEqual t -> def_vars_term accu t

and def_vars_pat_list accu = function
    [] -> accu
  | (a::l) -> def_vars_pat (def_vars_pat_list accu l) a

(* def_term is always called with  above_node.def_vars_at_def \subseteq def_vars
def_term returns a node n'. In this node n', we always have n'.def_vars_at_def \subseteq def_vars
Same property for def_term_list, def_term_def_list, def_pattern, def_pattern_list.
By induction. 
In cases ReplIndex, FindE, n' = above_node. 
In the other cases, we use the induction hypothesis. *)

let rec def_term event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts t =
  if (t.t_facts != None) then
    Parsing_helper.internal_error "Two terms physically equal: cannot compute facts correctly";
  t.t_facts <- Some
       { ppi_above_pp = above_pp;
	 ppi_cur_array = cur_array;
	 ppi_true_facts = true_facts;
	 ppi_elsefind_facts = elsefind_facts;
	 ppi_def_vars = def_vars;
	 ppi_future_true_facts = [];
	 ppi_future_binders = [];
	 ppi_future_pps = None;
	 ppi_above_node = above_node };
  let above_pp = (DTerm t) in
  match t.t_desc with
    Var(_,l) | FunApp(_,l) ->
      ignore (def_term_list_ef event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts l)
  | ReplIndex i -> ()
  | TestE(t1,t2,t3) ->
      let true_facts' = t1 :: true_facts in
      let true_facts'' = (Terms.make_not t1) :: true_facts in
      let elsefind_facts' = def_term_ef event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts t1 in
      def_term event_accu above_pp cur_array above_node true_facts' def_vars elsefind_facts' t2;
      def_term event_accu above_pp cur_array above_node true_facts'' def_vars elsefind_facts' t3
  | FindE(l0,t3,find_info) ->
      begin
	match event_accu, find_info with
	| Some accu, UniqueToProve f ->
	    accu := (Terms.event_term t.t_occ f cur_array, DTerm t) :: (!accu)
	| _ -> ()
      end;
      let l0_with_info = Info_from_term.add_info_find (!whole_game) false l0 in
      let (true_facts_else, elsefind_facts_else) = 
	find_list_to_elsefind (true_facts, elsefind_facts) l0_with_info
      in
      let unique = (Terms.is_unique (!whole_game) l0 find_info == Unique) in
      let rec find_l seen = function
	  [] -> ()
	| (((bl,def_list,t1,t2), (info_then, info_else)) as cur_branch)::l ->
	    find_l (cur_branch::seen) l;
	    let vars = List.map fst bl in
	    let repl_indices = List.map snd bl in
	    let vars_terms = List.map Terms.term_from_binder vars in
            let (sure_facts_t1, sure_def_list_t1, elsefind_t1) = info_then in
	    let sure_facts_t1 = List.map (Terms.subst repl_indices vars_terms) sure_facts_t1 in
	    let sure_def_list_t1 = Terms.subst_def_list repl_indices vars_terms sure_def_list_t1 in
	    let elsefind_t1 = List.map (Terms.subst_else_find repl_indices vars_terms) elsefind_t1 in

	    let (true_facts', elsefind_facts_then) =
	      if unique then
		(* When the find is Unique, I know that the other branches fail,
		   so I can add the corresponding elsefind facts *)
		find_list_to_elsefind (true_facts, elsefind_t1 @ elsefind_facts) (List.rev_append seen l)
	      else
		(true_facts, elsefind_t1 @ elsefind_facts)
	    in
            (* The variables defined in t are variables defined in conditions of find,
	       one cannot make array accesses to them, nor test their definition,
	       so they will not appear in defined conditions of elsefind_facts.
	       We need not take them into account to update elsefind_facts. *)
	    let elsefind_facts_then = List.map (Terms.update_elsefind_with_def vars) elsefind_facts_then in
	    let true_facts' = List.rev_append sure_facts_t1 true_facts' in
	    let accu = ref [] in
	    List.iter (Terms.close_def_subterm accu) def_list;
	    let def_list_subterms = !accu in 
	    let def_vars_t1 = def_list_subterms @ def_vars in
       	    let def_vars' =
              List.rev_append sure_def_list_t1
		(List.rev_append (Terms.subst_def_list repl_indices vars_terms def_list_subterms)
		   def_vars)
            in
	    let above_node' = { above_node = Some above_node; binders = vars; 
				true_facts_at_def = true_facts'; 
				def_vars_at_def = def_vars';
				elsefind_facts_at_def = elsefind_facts;
				future_binders = []; future_true_facts = []; 
				definition = DTerm t;
				definition_success = DTerm t2 } 
	    in
	    List.iter (fun b -> b.def <- above_node' :: b.def) vars;
	    def_term_def_list event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts def_list;
	    def_term event_accu above_pp (repl_indices @ cur_array) above_node true_facts def_vars_t1 elsefind_facts t1;
	    def_term event_accu above_pp cur_array above_node' true_facts' def_vars' elsefind_facts_then t2
      in
      find_l [] l0_with_info;
      def_term event_accu above_pp cur_array above_node true_facts_else def_vars elsefind_facts_else t3
  | LetE(pat, t1, t2, topt) ->
      let elsefind_facts' = def_term_ef event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts t1 in
      let accu = ref [] in
      let elsefind_facts'' = def_pattern_ef accu event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts' pat in
      let true_facts' = (Terms.fact_from_pat_t pat t1) :: true_facts in
      let above_node''' = { above_node = Some above_node; binders = !accu; 
			    true_facts_at_def = true_facts'; 
			    def_vars_at_def = def_vars;
			    elsefind_facts_at_def = elsefind_facts'';
			    future_binders = []; future_true_facts = []; 
			    definition = DTerm t;
			    definition_success = DTerm t2 } 
      in
      let elsefind_facts''' = List.map (Terms.update_elsefind_with_def (!accu)) elsefind_facts'' in
      List.iter (fun b -> b.def <- above_node''' :: b.def) (!accu);
      def_term event_accu above_pp cur_array above_node''' true_facts' def_vars elsefind_facts''' t2;
      begin
	match topt with
	  None -> ()
	| Some t3 -> 
	    let true_facts' = 
	      try
		(Terms.make_for_all_diff (Terms.gen_term_from_pat pat) t1) :: true_facts
	      with Terms.NonLinearPattern -> true_facts
	    in
	    def_term event_accu above_pp cur_array above_node true_facts' def_vars elsefind_facts'' t3
      end
  | ResE(b, t') ->
      let elsefind_facts' = List.map (Terms.update_elsefind_with_def [b]) elsefind_facts in
      let above_node' = { above_node = Some above_node; binders = [b]; 
			  true_facts_at_def = true_facts; 
			  def_vars_at_def = def_vars;
			  elsefind_facts_at_def = elsefind_facts;
			  future_binders = []; future_true_facts = []; 
			  definition = DTerm t;
			  definition_success = DTerm t' } 
      in
      b.def <- above_node' :: b.def;
      def_term event_accu above_pp cur_array above_node' true_facts def_vars elsefind_facts' t'
  | EventAbortE f ->
      begin
	match event_accu with
	  None -> ()
	| Some accu ->
	    accu := (Terms.event_term t.t_occ f cur_array, DTerm t) :: (!accu)
      end
  | EventE(t1,p) ->
      begin
	match event_accu with
	  None -> ()
	| Some accu -> accu := (t1, DTerm t) :: (!accu)
      end;
      let elsefind_facts' = def_term_ef event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts t1 in
      def_term event_accu above_pp cur_array above_node (t1 :: true_facts) def_vars elsefind_facts' p

  | GetE(tbl,patl,topt,p1,p2,_) ->
      let accu = ref [] in
      def_pattern_list accu event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts patl;
      begin
        match topt with 
          Some t -> def_term event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts t
        | None -> ()
      end;
      (* The variables defined in patl, topt are variables defined in conditions of find,
	 one cannot make array accesses to them, nor test their definition,
	 so they will not appear in defined conditions of elsefind_facts.
	 We need not update elsefind_facts. *)
      let elsefind_facts' = List.map (Terms.update_elsefind_with_def (!accu)) elsefind_facts in
      let above_node' = { above_node = Some above_node; binders = !accu; 
			  true_facts_at_def = true_facts; 
			  def_vars_at_def = def_vars;
			  elsefind_facts_at_def = elsefind_facts;
			  future_binders = []; future_true_facts = []; 
			  definition = DTerm t;
			  definition_success = DTerm p1 } 
      in
      def_term event_accu above_pp cur_array above_node' true_facts def_vars elsefind_facts' p1;
      def_term event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts p2
        
  | InsertE(tbl,tl,p) ->
      let elsefind_facts' = def_term_list_ef event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts tl in
      def_term event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts' p

	
(* same as [def_term] but additionally updates elsefind_facts to take into account
   the variables defined in [t] *) 
and def_term_ef event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts t =
  def_term event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts t;
  let vars_t = def_vars_term [] t in
  List.map (Terms.update_elsefind_with_def vars_t) elsefind_facts

(* [def_term_list_ef] also updates elsefind_facts to take into account
   the variables defined in the considered list of terms *)
and def_term_list_ef event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts = function
    [] -> elsefind_facts
  | (a::l) -> 
      let elsefind_facts' = def_term_ef event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts a in
      def_term_list_ef event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts' l

and def_term_def_list event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts = function
    [] -> ()
  | (b,l)::l' -> 
      let elsefind_facts' = def_term_list_ef event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts l in
      def_term_def_list event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts' l'

and def_pattern accu event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts = function
    PatVar b -> accu := b :: (!accu)
  | PatTuple (f,l) -> def_pattern_list accu event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts l
  | PatEqual t -> def_term event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts t

(* same as [def_pattern] but additionally updates elsefind_facts to take into account
   the variables defined in [pat] *) 
and def_pattern_ef accu event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts pat = 
  def_pattern accu event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts pat;
  let vars_pat = def_vars_pat [] pat in
  List.map (Terms.update_elsefind_with_def vars_pat) elsefind_facts

and def_pattern_list accu event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts = function
    [] -> () 
  | (a::l) -> 
      let elsefind_facts' = def_pattern_ef accu event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts a in
      def_pattern_list accu event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts' l

(* def_process is always called with above_node.def_vars_at_def \subseteq def_vars
   By induction, also using the properties of def_term, ...
   One case in which the two values are different is in the condition of find:
   def_vars contains the def_list, which is not included in above_node.def_vars_at_def. *)

let rec def_process event_accu above_pp cur_array above_node true_facts def_vars p' =
  if p'.i_facts != None then
    Parsing_helper.internal_error "Two processes physically equal: cannot compute facts correctly";
  p'.i_facts <- Some
       { ppi_above_pp = above_pp;
	 ppi_cur_array = cur_array;
	 ppi_true_facts = true_facts;
	 ppi_elsefind_facts = [];
	 ppi_def_vars = def_vars;
	 ppi_future_true_facts = [];
	 ppi_future_binders = [];
	 ppi_future_pps = None;
	 ppi_above_node = above_node };
  let above_pp = DInputProcess p' in
  match p'.i_desc with
    Nil -> ()
  | Par(p1,p2) -> 
      def_process event_accu above_pp cur_array above_node true_facts def_vars p1;
      def_process event_accu above_pp cur_array above_node true_facts def_vars p2
  | Repl(b,p) ->
      (* A node is needed here, even if the replication defines no
	 binders, because I rely on the node to locate the
	 replication in Simplify.CompatibleDefs.check_compatible *)
      let above_node' = { above_node = Some above_node; binders = [];
                          true_facts_at_def = true_facts;
                          def_vars_at_def = def_vars;
                          elsefind_facts_at_def = [];
                          future_binders = []; future_true_facts = []; 
                          definition = DInputProcess p';
			  definition_success = DInputProcess p }
      in
      def_process event_accu above_pp (b::cur_array) above_node' true_facts def_vars p
  | OracleDecl(o,patl,p) ->
      let accu = ref [] in
      def_pattern_list accu event_accu above_pp cur_array above_node true_facts def_vars [] patl;
      (* is_find_unique uses this node to test whether two variables are defined
	 in the same input/output block, so it's important to generate this
	 node even if the pattern pat defines no variable. *)
      let above_node''' = { above_node = Some above_node; binders = !accu; 
			    true_facts_at_def = true_facts; 
			    def_vars_at_def = def_vars;
			    elsefind_facts_at_def = [];
			    future_binders = []; future_true_facts = []; 
			    definition = DInputProcess p';
			    definition_success = DProcess p } 
      in
      List.iter (fun b -> b.def <- above_node''' :: b.def) (!accu);
      let (fut_binders, fut_true_facts, _) = 
	def_oprocess event_accu above_pp cur_array above_node''' true_facts def_vars [] p
      in
      above_node'''.future_binders <- fut_binders;
      above_node'''.future_true_facts <- fut_true_facts

and def_oprocess event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts p' =
  if p'.p_facts != None then
    Parsing_helper.internal_error "Two processes physically equal: cannot compute facts correctly";
  p'.p_facts <- Some
       { ppi_above_pp = above_pp;
	 ppi_cur_array = cur_array;
	 ppi_true_facts = true_facts;
	 ppi_elsefind_facts = elsefind_facts;
	 ppi_def_vars = def_vars;
	 ppi_future_true_facts = [];
	 ppi_future_binders = [];
	 ppi_future_pps = None;
	 ppi_above_node = above_node };
  let (fut_binders, fut_true_facts, fut_pps) as result =
  begin
  let above_pp = DProcess p' in
  match p'.p_desc with
    Yield -> 
      ([],[], Some [DProcess p'])
  | EventAbort f ->
      let t = Terms.event_term p'.p_occ f cur_array in 
      begin
	match event_accu with
	  None -> ()
	| Some accu -> 
	    accu := (t, DProcess p') :: (!accu)
      end;
      ([],[t], Some [])
  | Restr(b,p) ->
      let elsefind_facts' = List.map (Terms.update_elsefind_with_def [b]) elsefind_facts in
      let above_node' = { above_node = Some above_node; binders = [b]; 
			  true_facts_at_def = true_facts; 
			  def_vars_at_def = def_vars;
			  elsefind_facts_at_def = elsefind_facts;
			  future_binders = []; future_true_facts = []; 
			  definition = DProcess p';
			  definition_success = DProcess p } 
      in
      b.def <- above_node' :: b.def;
      let (fut_binders, fut_true_facts, fut_pps) = 
	def_oprocess event_accu above_pp cur_array above_node' true_facts def_vars elsefind_facts' p
      in
      above_node'.future_binders <- fut_binders;
      above_node'.future_true_facts <- fut_true_facts;
      (b::fut_binders, fut_true_facts, fut_pps)
  | Test(t,p1,p2) ->
      let elsefind_facts' = def_term_ef event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts t in
      let true_facts' = t :: true_facts in
      let true_facts'' = (Terms.make_not t) :: true_facts in
      let fut_facts1 =
	def_oprocess event_accu above_pp cur_array above_node true_facts' def_vars elsefind_facts' p1
      in
      let fut_facts2 = 
	def_oprocess event_accu above_pp cur_array above_node true_facts'' def_vars elsefind_facts' p2
      in
      fut_join fut_facts1 fut_facts2
  | Find(l0,p2,find_info) ->
      begin
	match event_accu, find_info with
	| Some accu, UniqueToProve f  -> 
	    accu := (Terms.event_term p'.p_occ f cur_array, DProcess p') :: (!accu)
	| _ -> ()
      end;
      let l0_with_info = Info_from_term.add_info_find (!whole_game) false l0 in
      let (true_facts', elsefind_facts') = 
	find_list_to_elsefind (true_facts, elsefind_facts) l0_with_info
      in
      let fut_facts2 = 
	def_oprocess event_accu above_pp cur_array above_node true_facts' def_vars elsefind_facts' p2
      in
      let unique = (Terms.is_unique (!whole_game) l0 find_info == Unique) in
      let rec find_l seen = function
	  [] -> fut_facts2
	| (((bl,def_list,t,p1), (info_then, info_else)) as cur_branch)::l ->
	    let fut_factsl = find_l (cur_branch::seen) l in
	    let vars = List.map fst bl in
	    let repl_indices = List.map snd bl in
	    let vars_terms = List.map Terms.term_from_binder vars in
            let (sure_facts_t, sure_def_list_t, elsefind_t) = info_then in
	    let sure_facts_t = List.map (Terms.subst repl_indices vars_terms) sure_facts_t in
	    let sure_def_list_t = Terms.subst_def_list repl_indices vars_terms sure_def_list_t in
	    let elsefind_t = List.map (Terms.subst_else_find repl_indices vars_terms) elsefind_t in
	    
	    let (true_facts', elsefind_facts_then) =
	      if unique then
		(* When the find is Unique, I know that the other branches fail,
		   so I can add the corresponding elsefind facts *)
		find_list_to_elsefind (true_facts, elsefind_t @ elsefind_facts) (List.rev_append seen l)
	      else
		(true_facts, elsefind_t @ elsefind_facts)
	    in
            (* The variables defined in t are variables defined in conditions of find,
	       one cannot make array accesses to them, nor test their definition,
	       so they will not appear in defined conditions of elsefind_facts.
	       We need not take them into account to update elsefind_facts. *)
	    let elsefind_facts_then = List.map (Terms.update_elsefind_with_def vars) elsefind_facts_then in
	    let true_facts' = List.rev_append sure_facts_t true_facts' in
	    let accu = ref [] in
	    List.iter (Terms.close_def_subterm accu) def_list;
	    let def_list_subterms = !accu in 
	    let def_vars_t = def_list_subterms @ def_vars in
       	    let def_vars' =
              List.rev_append sure_def_list_t
                (List.rev_append (Terms.subst_def_list repl_indices vars_terms def_list_subterms)
                   def_vars)
            in
	    let above_node' = { above_node = Some above_node; binders = vars; 
				true_facts_at_def = true_facts'; 
				def_vars_at_def = def_vars';
				elsefind_facts_at_def = elsefind_facts;
				future_binders = []; future_true_facts = []; 
				definition = DProcess p';
			        definition_success = DProcess p1 } 
	    in
	    List.iter (fun b -> b.def <- above_node' :: b.def) vars;
	    def_term_def_list event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts def_list;
	    def_term event_accu above_pp (repl_indices @ cur_array) above_node true_facts def_vars_t elsefind_facts t;
	    let (fut_binders1, fut_true_facts1, fut_pps1) = 
	      def_oprocess event_accu above_pp cur_array above_node' true_facts' def_vars' elsefind_facts_then p1
	    in
	    above_node'.future_binders <- fut_binders1;
	    above_node'.future_true_facts <- fut_true_facts1;
	    fut_join (vars @ fut_binders1, fut_true_facts1, fut_pps1) fut_factsl
      in
      find_l [] l0_with_info
  | Return(tl,p) ->
      let _ = def_term_list_ef event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts tl in
      def_process event_accu above_pp cur_array above_node true_facts def_vars p;
      ([],[],Some [above_pp])
  | Let(pat,t,p1,p2) ->
      let elsefind_facts' = def_term_ef event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts t in
      let accu = ref [] in
      let elsefind_facts'' = def_pattern_ef accu event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts' pat in
      let new_fact = Terms.fact_from_pat_t pat t in
      let true_facts' = new_fact :: true_facts in
      let elsefind_facts''' = List.map (Terms.update_elsefind_with_def (!accu)) elsefind_facts'' in
      let above_node''' = { above_node = Some above_node; binders = !accu; 
			    true_facts_at_def = true_facts'; 
			    def_vars_at_def = def_vars;
			    elsefind_facts_at_def = elsefind_facts'';
			    future_binders = []; future_true_facts = []; 
			    definition = DProcess p';
			    definition_success = DProcess p1 } 
      in
      List.iter (fun b -> b.def <- above_node''' :: b.def) (!accu);
      let (fut_binders1, fut_true_facts1, fut_pps1) = 
	def_oprocess event_accu above_pp cur_array above_node''' true_facts' def_vars elsefind_facts''' p1
      in
      above_node'''.future_binders <- fut_binders1;
      above_node'''.future_true_facts <- fut_true_facts1;
      let fut_facts1 = ((!accu) @ fut_binders1, new_fact :: fut_true_facts1, fut_pps1) in
      begin
	match p2.p_desc with
	  Yield when Terms.is_full_pattern pat ->  fut_facts1
	| _ -> 
	    let true_facts' = 
	      try
		(Terms.make_for_all_diff (Terms.gen_term_from_pat pat) t) :: true_facts
	      with Terms.NonLinearPattern -> true_facts
	    in
	    let fut_facts2 = 
	      def_oprocess event_accu above_pp cur_array above_node true_facts' def_vars elsefind_facts'' p2
	    in
	    fut_join fut_facts1 fut_facts2
      end
  | EventP(t,p) ->
      begin
	match event_accu with
	  None -> ()
	| Some accu -> accu := (t, DProcess p') :: (!accu)
      end;
      let elsefind_facts' = def_term_ef event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts t in
      let (fut_binders, fut_true_facts, fut_pps) = 
	def_oprocess event_accu above_pp cur_array above_node (t :: true_facts) def_vars elsefind_facts' p
      in
      (fut_binders, t::fut_true_facts, fut_pps)
  | Get(tbl,patl,topt,p1,p2,_) ->
      let accu = ref [] in
      def_pattern_list accu event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts patl;
      begin
        match topt with 
          Some t -> def_term event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts t
        | None -> ()
      end;
      (* The variables defined in patl, topt are variables defined in conditions of find,
	 one cannot make array accesses to them, nor test their definition,
	 so they will not appear in defined conditions of elsefind_facts.
	 We need not update elsefind_facts. *)
      let elsefind_facts' = List.map (Terms.update_elsefind_with_def (!accu)) elsefind_facts in
      let above_node' = { above_node = Some above_node; binders = !accu; 
			  true_facts_at_def = true_facts; 
			  def_vars_at_def = def_vars;
			  elsefind_facts_at_def = elsefind_facts;
			  future_binders = []; future_true_facts = []; 
			  definition = DProcess p';
			  definition_success = DProcess p1 } 
      in
      let fut_facts1 =
	def_oprocess event_accu above_pp cur_array above_node' true_facts def_vars elsefind_facts' p1
      in
      let fut_facts2 =
	def_oprocess event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts p2
      in
      fut_join fut_facts1 fut_facts2
        
  | Insert(tbl,tl,p) ->
      let elsefind_facts' = def_term_list_ef event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts tl in
      def_oprocess event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts' p
  | NewTable(tbl,p) ->
      def_oprocess event_accu above_pp cur_array above_node true_facts def_vars elsefind_facts p
  end
  in
  p'.p_facts <- Some
       { ppi_above_pp = above_pp;
	 ppi_cur_array = cur_array;
	 ppi_true_facts = true_facts;
	 ppi_elsefind_facts = elsefind_facts;
	 ppi_def_vars = def_vars;
	 ppi_future_true_facts = fut_true_facts;
	 ppi_future_binders = fut_binders;
	 ppi_future_pps = fut_pps;
	 ppi_above_node = above_node };
  result

let build_def_process g_opt event_accu p =
  whole_game := g_opt;
  empty_def_process p;
  let st_node = { above_node = None; 
		  binders = []; 
		  true_facts_at_def = []; 
		  def_vars_at_def = []; 
		  elsefind_facts_at_def = [];
		  future_binders = []; future_true_facts = []; 
		  definition = DNone;
		  definition_success = DNone } 
  in
  def_process event_accu DNone [] st_node [] [] p;
  whole_game := None

let rec build_def_fungroup cur_array above_node = function
  | ReplRestr(repl_opt, restr, funlist) ->
      let above_node2 =
	Terms.set_def (List.map (fun (b,ext,opt) -> b) restr) DFunRestr DNone (Some above_node)
      in
      let cur_array' = Terms.add_cur_array repl_opt cur_array in
      List.iter (build_def_fungroup cur_array' above_node2) funlist
  | Fun(ch, args, res, priority) ->
      let above_node1 =
	Terms.set_def args (DFunArgs res) DNone (Some above_node)
      in
      ignore(def_term None (DFunArgs res) cur_array above_node1 [] [] [] res)

let build_def_member l = 
  let rec st_node = Terms.set_def [] DNone DNone None in
  List.iter (fun (fg, mode) -> build_def_fungroup [] st_node fg) l
