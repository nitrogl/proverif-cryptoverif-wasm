(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Types

(* [implies_diff t l1 l2] returns true when we are sure that [t] implies [l1 <> l2] *)

let rec implies_diff t l1 l2 =
  if List.length l1 <> List.length l2 then false else
  if not (List.for_all2 (fun t1 t2 -> t1.t_type == t2.t_type) l1 l2) then false else
  let diff = Terms.make_or_list (List.map2 Terms.make_diff l1 l2) in
  let rec aux t = 
    match t.t_desc with
    | FunApp(f,[t1;t2]) when f == Settings.f_and ->
	aux t1 || aux t2 
    | _ ->
	Terms.equal_terms t diff
  in
  aux t


(* get_elsefind_facts *)

(* Reasoning that depends on assumptions on the order of definition
   of variables. *)

(* Dependency analysis taking into account the order of definition of the variables. 
   Here dep_info is a list of array ref defined after and a list of array ref defined before *)

let dependency_anal_order_hyp cur_array dep_info =
  let (defl_after, defl_before) = dep_info in
  let depinfo =
    { args_at_creation_only = false;
      dep = [];
      other_variables = true;
      nodep = defl_before }
  in
  let get_dep_info br =
    if Terms.mem_binderref br defl_after then
      (* The variables in [defl_before] do not depend on [br],
         since [br] is in [defl_after], so defined after the
         variables in [defl_before] *)
      depinfo
    else
      Facts.nodepinfo
  in
  let get_dep_info_for_indep (b,l) =
    (* reconstruct the initial list: indices may have been
       replaced with fresh replication indices to make them independent *)
    let linit = List.map (Terms.copy_term Terms.Links_RI) l in
    get_dep_info (b,linit)
  in
  let collision_test simp_facts t1 t2 =
    let t1' = Terms.try_no_var_rec simp_facts t1 in
    let t2' = Terms.try_no_var_rec simp_facts t2 in
    if !Settings.debug_elsefind_facts then
      begin
	print_string "dependency_anal_order_hyp: ";
	Display.display_term t1; print_string ", ";
	Display.display_term t2; print_newline ();
	print_string "simplified t1,t2=";
	Display.display_term t1'; print_string ", ";
	Display.display_term t2'; print_newline ();
      end;
    let res =
      Depanal.try_two_directions (Depanal.dependency_collision_rec cur_array simp_facts get_dep_info) t1' t2'
    in
    if !Settings.debug_elsefind_facts then
      begin
	match res with
	| None ->
	    print_string "Result: failed";
	    print_newline()
	| Some t ->
	    print_string "Result: success ";
	    Display.display_term t;
	    print_newline ()
      end;
    res
  in
  if !Settings.proba_zero then
    (Facts.default_indep_test get_dep_info_for_indep, Facts.no_collision_test)
  else
    (Facts.default_indep_test get_dep_info_for_indep, collision_test)
      
(* [add_vars_until_pps node stop_pps]:
   We assume that [node] is executed after a program point in [stop_pps].
   This function computes the variables defined before [node], known
   to be defined after a program point in [stop_pps].
   Only the order of variable definitions is important
   (e.g. the order of function applications does not matter),
   because we just need that the variables we add are defined after
   the variables in [def_vars_before] defined before [stop_pps].
   Occurrences of program points at which variable definitions succeed are
   increasing in the execution order. *)

let add_vars_until_pps node stop_pps =
  let pp_node = node.definition_success in
  let st_node = Incompatible.get_start_block_pp pp_node in
  let occ_st_node = Terms.occ_from_pp st_node in
  let rec min_acceptable_occ = function
    | [] ->
	(* We always stop at the beginning of the block *)
	occ_st_node
    | pp' :: rest ->
	let min_occ = min_acceptable_occ rest in
	let st_pp' = Incompatible.get_start_block_pp pp' in
	if 
          (* When [pp'] is in a different oracle..return block than [node],
             the full block of [node] is executed after [pp'] *)
	  not (Terms.equal_pp st_node st_pp') ||
          (* When [pp'] is not compatible with [node], they cannot be executed
	     with the same indices, hence the full block of [node] is executed
	     after [pp'] *)
	  not (Incompatible.is_compatible_pp pp_node pp') ||
          (* When [pp'] is after [node] in the execution order of the block,
	     [node] cannot be executed after [pp'] with the same indices,
	     hence the full block of [node] is executed after [pp'] *)
	  Terms.occ_from_pp pp_node <= Terms.occ_from_pp pp'
	then
	  (* In all these cases, we can ignore [pp'] *)
	  min_occ
	else
	  (* We stop at [pp'], [pp'] not counted *)
	  max (Terms.occ_from_pp pp' + 1) min_occ
  in
  let min_occ = min_acceptable_occ stop_pps in
  let rec aux n acc =
    match n.above_node with
    | None -> 
	if !Settings.debug_elsefind_facts then
          begin
	    print_string "Elsefind_fact add_vars root node";
	    print_newline ()
          end;
	acc
    | Some n' -> 
	let occ_n = Terms.occ_from_pp n.definition_success in
	if min_occ > occ_n then
	  begin
	    if !Settings.debug_elsefind_facts then
              begin
		print_string "Elsefind_fact add_vars stopped";
		print_newline ()
              end;
	    acc
	  end
	else
          (* When [n] is after [min_occ],
	     [n] is executed after [pp'], so we can add the variables of [n] *)
	  aux n' (n.binders @ acc)
  in
  aux node []
   
(* this function is used as the final function for match_among_collect_instance_list *)
let final_next3 bl def_list t result def_listi =
  Terms.ri_auto_cleanup (fun () ->
    let t' = Terms.copy_term Terms.Links_RI t in
    let def_list' = Terms.copy_def_list Terms.Links_RI def_list in
    result := (List.combine def_list' def_listi, t')::(!result));
  (* Backtrack *)
  raise NoMatch

(* this function is used as the final function for match_among_list *)
let final_next4 bl def_list t fact_accu () =
  Terms.ri_auto_cleanup (fun () ->
    let t' = Terms.copy_term Terms.Links_RI t in
    fact_accu := (Terms.make_not t')::(!fact_accu));
  (* Backtrack *)
  raise NoMatch

(* [add_eff cur_array tl elsefind l] adds the elsefind fact
   [elsefind], known to hold when [cur_array = tl] to the list [l] *)
let rec add_eff cur_array tl elsefind l =
  if List.exists (fun (cur_array',tl',elsefind') ->
    (Terms.equal_elsefind_facts elsefind elsefind') &&
    (Terms.equal_term_lists tl tl') &&
    (Terms.equal_lists (==) cur_array cur_array')) l
  then
    l
  else
    (cur_array, tl, elsefind) :: l

(* [collect_eff pps history def_list] returns elsefind facts
   known to hold when [def_list] is defined, with known
   program points [pps] and history [history]. Each collected
   elsefind fact [elsefind] comes with the appropriate mapping
   of replication indices [cur_array -> tl] in a triple
   [(cur_array, tl, elsefind)]. *)
let rec collect_eff pps history = function
    [] -> []
  | (b,bargs)::l ->
      let last_effl = collect_eff pps history l in
      let new_effl = 
	try
	  let nodes = Facts.get_compatible_def_nodes history pps b bargs in
          Terms.intersect_list Terms.equal_elsefind_facts (List.map (fun n -> n.elsefind_facts_at_def) nodes)
	with Contradiction ->
	  []
      in
      List.fold_right (add_eff b.args_at_creation bargs) new_effl last_effl


(* [above_return pp] returns the first program point above [pp] that is a return.
   Returns [None] in case of failure. *)
let rec above_return pp =
  match Incompatible.get_facts pp with
  | None -> None
  | Some ppi ->
      match ppi.ppi_above_pp with
      | DNone -> None
      | above_pp ->
	  match above_pp with
	  | DProcess {p_desc = Return _} ->
	      Some above_pp
	  | _ -> above_return above_pp


(* [pp_with_ef pp ef] returns a program point syntactically above [pp] that
   at which the elsefind_fact [ef] holds. *)
let rec pp_with_ef ef pp =
  match Incompatible.get_facts pp with
  | None -> raise Not_found
  | Some ppi -> 
      if List.exists (Terms.equal_elsefind_facts ef) ppi.ppi_elsefind_facts then
	pp
      else
	match ppi.ppi_above_pp with
	| DNone -> raise Not_found
	| above_pp ->
	    pp_with_ef ef above_pp 

(* [collect_eff_from_pps pps] collects elsefind facts known
   to hold assuming that the program points [pps] have been executed,
   in a list of triples [(ppl, tl, elsefind)] meaning that
   [elsefind] holds at [ppl[tl]].

   [collect_eff_from_ppl] is a helper function for a single program point.

  From a known program point, we also consider the returns that
  are syntactically above that program point.
  (The elsefind_facts are removed at each return, so if we do not consider
  the previous returns, we will miss lots of opportunities.)
  For program points with several choices: ([pp1; ...; ppn], tl),
  for each pp1' = pp1 and all returns above pp1, for each elsefind_fact
  at pp1', we try to find a program point ppi' above ppi (for all 2 <= i <= n)
  that contains the same elsefind_fact.
  Then we can consider ([pp1'; ...; ppn'], tl) with that elsefind_fact.
  *)
let collect_eff_from_ppl (ppl,args) =
  match ppl with
  | [] -> []
  | pp1::l ->
      let rec aux pp1 =
	match Incompatible.get_facts pp1 with
	| None -> []
	| Some ppi ->
	    (List.filter_map (fun ef ->
	      try 
		Some (((pp1::List.map (pp_with_ef ef) l),
		       Terms.lsuffix (List.length ppi.ppi_cur_array) args),
		      ef)
	      with Not_found ->
		None
		  ) ppi.ppi_elsefind_facts) @
	    match above_return pp1 with
	    | None -> []
	    | Some above_return_pp ->
		aux above_return_pp
      in
      aux pp1
  
	
let rec collect_eff_from_pps = function
  | [] -> []
  | ppl::pps ->
      let last_effl = collect_eff_from_pps pps in
      let new_effl = collect_eff_from_ppl ppl in
      new_effl @ last_effl
	

(* [get_fact_of_elsefind_fact] collects terms that are true, where
   - the program point ppl[tl] is known to be executed
   - the program point ppl is in the else branch of a find, so that 
     [elsefind_fact = (bl,def_list,t1)], which means [forall bl, not (defined(def_list) && t1)] 
     holds at ppl.
   - [cur_array] contains the current replication indices
   - [pps] are program points known to be executed
   - [history] is the current history
   - [def_vars] are variables known to be defined at the current program point.
   - [simp_facts] are facts known to be true at the current program point.

   - [term_accu] stores the proved terms
   - [g] is the current game

   [get_fact_of_elsefind_fact] uses the following reasoning:
   * we substitute [tl] for cur_array at [ppl] in the [elsefind_fact], and choose the indices [bl] such that
   the elements of [def_list] are defined at the current program point.
   * then, we know that not (defined(def_list) && t1) holds just before ppl[tl].
   * if the elements of def_list are defined before ppl[tl], we obtain not(t1).
   * otherwise, we try to show that, if an element of def_list is defined after ppl[tl], then
   t1 leads to a contradiction.
   * if this succeeds, we can conclude that not(t1) holds in all cases.
*)
let get_fact_of_elsefind_fact term_accu g cur_array pps history def_vars simp_facts (ppl,tl) ((bl,def_list,t1) as elsefind_fact) =
  if !Settings.debug_elsefind_facts then
    begin
      print_string "-----------------\n";
      print_string "Variables known to be currently defined: ";
      Display.display_def_list def_vars;
      print_newline();
      print_string "Program point known to be executed in an else branch of find: ";
      Display.display_ppl (ppl, tl);
      print_newline ();
      print_string "Elsefind_fact (before renaming): ";
      Display.display_elsefind elsefind_fact
    end;

  (* decompose def_list into subterms: all *subterms* of def_list must
     be defined before the find so that we can conclude not(t1) from
     the elsefind fact. *)
  let def_list_subterms = ref [] in
  List.iter (Terms.close_def_subterm def_list_subterms) def_list;
  let def_list = !def_list_subterms in

  (* transform the elsefind fact such that the program point (ppl,ppl_index) 
     for the original fact corresponds to our program point (ppl,tl),
     where ppl_index is the current replication indices at ppl:
     substitute ppl_index with tl. *)
  let ppl_index =
    match ppl with
    | [] -> assert false
    | pp::_ ->
	match Incompatible.get_facts pp with
	| None -> assert false
	| Some ppi -> ppi.ppi_cur_array
  in
  let ppl_nodes = List.map (fun pp ->
    match Incompatible.get_facts pp with
    | None -> assert false
    | Some ppi -> ppi.ppi_above_node) ppl
  in
  let (bl, def_list, t1) = Terms.subst_else_find ppl_index tl (bl, def_list, t1) in

  (* Variables defined before (ppl,tl) *)
  let def_vars_before = 
    try
      Facts.def_vars_before_ppl pps (ppl,tl) 
    with Contradiction -> 
      (* Contradiction may be raised when ppl can in fact not be executed. *)
      []
  in
  if !Settings.debug_elsefind_facts then
    begin
      print_string "Elsefind_fact_vars_before:\n";
      Display.display_list Display.display_term (List.map Terms.term_from_binderref def_vars_before);
      print_newline ()
    end;
  
  (* Optimization: if br1 and br2=(b2,tl2) are in def_list and
     br2 defined before (ppl,tl) implies that
     br1 defined before (ppl,tl), then we can remove br1 from def_list,
     since knowing that br2 is defined strictly before (ppl,tl) is enough to apply the elsefind fact. 
     This optimization does not seem to affect much the speed of the system. *)
  let def_list = Terms.setminus_binderref def_list def_vars_before in
  let rec filter_def_list already_seen = function
    | [] -> List.rev already_seen
    | ((b2,tl2)::l) ->
	let b2_nodes = Facts.get_compatible_def_nodes history pps b2 tl2 in
	let before_br2 = 
	  try
	    Facts.def_vars_before pps (b2, tl2)
	  with Contradiction -> 
	    (* Contradiction may be raised when b2 can in fact not be defined. *)
	    []	
	in
	(* When br2 = (b2,tl2) is defined before (ppl,tl), 
	   the variables in [before_ppl_tl] are also defined before (ppl,tl).
	   We can then remove them from [def_list]. *)
	let before_ppl_tl =
	  if not (List.exists (fun b2_n -> List.exists (fun b_n ->
	    Incompatible.may_be_before_same_block b2_n b_n
	      ) ppl_nodes) b2_nodes) then
	    (* When br2 = (b2,tl2) is defined before (ppl,tl), 
               the block that defines (b2,tl2) has been entirely executed before (ppl,tl) *)
	    let same_block_after_b2 =
	      try 
		(Terms.intersect_list (==)  (List.map (fun n -> n.binders @ n.future_binders) b2_nodes))
	      with Contradiction ->
		(* Happens when b2 is never defined *)
		[]
	    in
	    (List.map (fun b' -> (b', tl2)) same_block_after_b2) @ before_br2
	  else
	    before_br2
	in
	let already_seen' = Terms.setminus_binderref already_seen before_ppl_tl in
	let l' = Terms.setminus_binderref l before_ppl_tl in
	filter_def_list ((b2,tl2)::already_seen') l'
  in
  let def_list = filter_def_list [] def_list in

  if !Settings.debug_elsefind_facts then
    begin
      print_string "Elsefind_fact (after renaming): ";
      Display.display_elsefind (bl,def_list,t1)
    end;

  (* We have [elsefind_fact = (bl,def_list,t1)], which means [forall bl, not (defined(def_list) && t1)].
     We collect in variable [result] the pairs (def_list', t') instances of (def_list, t1) such that
     the elements of [def_list'] are defined at the current program point. (They are in [def_vars].)

     Inside [def_list'], two equal forms of each binderref are stored: the instance of [def_list]
     and the equal element of [def_vars]. They are equal using [simp_facts].
     Using both forms increases the chances of success of the intersection
     [Terms.inter_binderref def_vars vars_future_binders_n] below.
     For the test [implies_diff t' (snd br) tl] below, using [br] instance of [def_list] is better
     because [t'] is an instance of [t1], so that increases the chances that [br] and [t']
     use the same form.
     By using both forms for [future_vars], the dependency analysis should be more precise.
     For [Facts.get_compatible_def_nodes history pps (fst bri) (snd bri)] below, using [bri]
     in [def_vars] should be more precise, because it is also the form used in [pps].
     *)
  let result = ref [] in
  begin
    try 
      Facts.match_among_collect_instance_list (final_next3 bl def_list t1 result) simp_facts bl def_vars def_list
    with NoMatch -> ()
  end;
    
  List.iter (fun (def_list_with_i',t') ->

    let proba_state = Depanal.get_current_state() in
    if !Settings.debug_elsefind_facts then
      begin
        print_string "Elsefind_fact_try:\n";
        Display.display_term t';
        print_newline ();
        print_string "And the def_list':\n";
        Display.display_list Display.display_term (List.map (fun (br,bri) -> Terms.term_from_binderref br) def_list_with_i');
        print_newline ();
        print_string "equal to\n";
        Display.display_list Display.display_term (List.map (fun (br,bri) -> Terms.term_from_binderref bri) def_list_with_i');
        print_newline ()
      end;

    (* If \forall br \in def_list', br is defined before (ppl,tl), 
       then by applying the elsefind fact, (not t') is true.
       In the other case, we must prove that \forall br \in def_list', 
       if br is defined after or at (ppl,tl), t' => Contradiction. *)

(* TODO (optional, for speed)
   Could I optimize the runtime by considering that we want to prove that
   for all definitions (at [n, snd br]) of all binders in [def_list'],
       [n, snd br] after [ppl, tl] => [not t'],
   and eliminating case [n, snd br] when
       [n, snd br] after [ppl, tl] => [n', snd br'] after [ppl, tl]
   for some other tested [n', snd br'].
   Is it enough that [n', snd br'] is after [n, snd br] for that?
   Maybe not in case [ppl] is between [n] and [n'].
   No, in fact, I must first guarantee that [n, snd br] executed implies
   [n', snd br'] executed! => [n', snd br'] is before [n, snd br]
   and [ppl, tl] is not between [n] and [n'].
   So: [n', snd br'] is syntactically above [n, snd br]
   and [ppl, tl] is not between [n] and [n']. *)
    
    if (
      List.for_all (fun (br, bri) -> (* br and bri are two forms equal modulo simp_facts *)
	let same_br_bri = Terms.equal_binderref br bri in
        (* Let us suppose that br has been defined after or at (ppl,tl) *)
        if !Settings.debug_elsefind_facts then
          begin
            print_string "Let's assume that ";
	    Display.display_term (Terms.term_from_binderref br);
	    print_string " is defined after or simultaneously ";
	    Display.display_ppl (ppl,tl);
            print_newline ()
          end;

	(* Under the assumption that br has been defined after or at (ppl,tl),
	   all variables in def_vars_before are defined strictly before br.
	   If br is in def_vars_before, that's a contradiction, so the assumption 
	   that br is defined after or at the same time as (ppl,tl) never holds. *)
	(Terms.mem_binderref br def_vars_before) || (
        let order_assumptions = br,(ppl,tl) in
        List.for_all (fun n -> (* for each definition def_node of br *)
          try
            (* The elements of future_vars are defined after those of def_vars_before. 
	       Compute variables that are defined after (ppl,tl). *)
	    let full_block_n =
	      (* true when we are sure that the block of [n] is fully executed *)
	      match history with
	      | Some h ->
		  not (Incompatible.may_be_before_same_block_pp n.definition_success h.current_point)
	      | None -> false
	    in
	    let vars_future_binders_n =
	      (Terms.subst_def_list (fst br).args_at_creation (snd br)
		 (List.map Terms.binderref_from_binder n.future_binders))
	    in
	    let vars_future_binders_n =
	      if same_br_bri then
		vars_future_binders_n
	      else
  		Terms.union_binderref vars_future_binders_n
		  (Terms.subst_def_list (fst bri).args_at_creation (snd bri)
		     (List.map Terms.binderref_from_binder n.future_binders))
	    in
	    let future_vars =
	      if full_block_n then
		vars_future_binders_n
	      else
		Terms.inter_binderref def_vars vars_future_binders_n
	    in
            let future_binders =
	      (* We compute variables defined after (ppl,tl). *)
	      if implies_diff t' (snd br) tl then
	        (* When t' = ... && tl <> (snd br), as
		   built by Terms.update_elsefind_with_def
		   we do not need to stop at ppl_nodes:
		   - when tl = snd br, we know that not(t') is true,
		   so we do not need to prove it.
		   - so we can assume tl <> snd br. In this case, the block that executes
		   ppl[tl] is fully executed before the block that defines br,
		   provided we are not in the condition of a find with indices.
		   (When we are in the condition of a find, we can execute code with
		   different replication indices inside the same oracle...return block.
		   However, [br] is not defined in a condition of find, because we have an
		   array access on [br]. Since the implication is considered only when
		   [tl] and [snd br] have the same length, ppl[tl] cannot be in the
		   same block as the definition of [br] in the condition of a find with indices:
		   [tl] would have the length of [snd br] + the indices of find.) *)
		add_vars_until_pps n [] 
	      else
		(*  Add to the future variables of br the variables defined between the previous input 
		    point and the definition of br and after ppl *)
                add_vars_until_pps n ppl 
            in
	    let add_future_vars =
	      (Terms.subst_def_list (fst br).args_at_creation (snd br) (List.map Terms.binderref_from_binder future_binders))
	    in
	    let add_future_vars =
	      if same_br_bri then
		add_future_vars
	      else
		Terms.union_binderref add_future_vars
		  (Terms.subst_def_list (fst bri).args_at_creation (snd bri) (List.map Terms.binderref_from_binder future_binders))
	    in
	    let future_vars = add_future_vars @ future_vars in

	    (* by assumption, [br] is defined after ppl[tl] *)
	    let future_vars =
	      if not (Terms.mem_binderref br future_vars) then
		br :: future_vars
	      else
		future_vars
	    in
	    let future_vars =
	      if not (same_br_bri || Terms.mem_binderref bri future_vars) then
		bri :: future_vars
	      else
		future_vars
	    in
	    
	      (* Variables in [def_vars] are known to be defined.
                 If they cannot be defined before [(ppl,tl)],
		 or they cannot be defined before [(n, snd br)] (the selected def site of [br]),
		 or they cannot be defined before or at the same time as a binderref already in [future_vars], then they
	         are certainly defined after [def_vars_before], so we can add them
	         to [future_vars] *)
	    let future_vars = 
	      List.fold_left (fun future_vars br' ->
		if (not (Incompatible.may_def_before_ppl br' (ppl,tl) &&
			 Incompatible.may_def_before_ppl br' ([n.definition_success], snd br) &&
			 List.for_all (Incompatible.may_def_before br') future_vars)) &&
		  (not (Terms.mem_binderref br' future_vars)) 
		then
		  br' :: future_vars
		else
		  future_vars) future_vars def_vars
	    in

            if !Settings.debug_elsefind_facts then
              begin
                print_string "Elsefind_fact_future_vars:\n";
                Display.display_list Display.display_term (List.map Terms.term_from_binderref future_vars);
                print_newline ()
              end;

	      (* Elements of future_vars are defined after those of def_vars_before;
	         If they are in def_vars_before, that's a contradiction *)
	    if List.exists (fun future_br -> Terms.mem_binderref future_br def_vars_before) future_vars then
	      raise Contradiction;
	    
	    (* Elements of future_vars are defined after those of def_vars_before.
	       Therefore, the elements of def_vars_before are independent of the elements of future_vars
	       that are randomly chosen. *)
            let dep_info = (future_vars, List.map Terms.term_from_binderref def_vars_before) in
     
            if !Settings.debug_elsefind_facts then
              begin
                print_string "--Args to dependency_collision:\n";
                print_string "Cur_array=";
                Display.display_list Display.display_repl_index cur_array;
                print_string "\nOrder assumptions=";
                let ((b1,tl1),ppl) = order_assumptions in
                Display.display_var b1 tl1;
		print_string " defined after or at the same time as ";
		Display.display_ppl ppl;
                print_string "\nDepinfo=previous lists";
                print_string "\nFacts=\n";
                Display.display_facts simp_facts;
                print_string "\nt'=";
                Display.display_term t';
                print_string "\n--End of args"; print_newline ();
                Settings.debug_simplif_add_facts := true;
              end;
           
	    (* Get additional facts using again elsefind facts.
	       If an elsefind fact (bl, def_list, t1) holds at the
	       definition of b'[tl'] in future_vars, that is,
	       at the definition of b'[tl'], we have
	       forall bl, not (defined(def_list) && t1)
	       and furthermore all elements of def_list are in 
	       def_vars_before, so all elements of def_list are defined
	       at the definition of b[tl], so a fortiori at the
	       definition of b'[tl'], then we have not(t1). *)

            let (subst, facts, _) = simp_facts in
	    let fact_accu = ref [] in
	    let elsefind_facts =
	      (* Since I distinguish for each definition point [n] of [br],
		 I can add the elsefind facts at [n], instead of just the elsefind
		 facts that hold at all definitions of [br]. *)
	      List.fold_right (add_eff (fst br).args_at_creation (snd br)) n.elsefind_facts_at_def
		(collect_eff pps history future_vars)
	    in
	    let elsefind_facts =
	      if same_br_bri then
		elsefind_facts
	      else
		List.fold_right (add_eff (fst bri).args_at_creation (snd bri)) n.elsefind_facts_at_def
		  elsefind_facts
	    in
	    List.iter (fun (cur_array', tl', ef) ->
	      (* The "elsefind" fact [ef] holds at the definition of a variable in [future_vars],
		 The current indices at that point are [cur_array'], and the indices of the defined variable are [tl'] *)

	      (* Rename indices cur_array' -> tl' *)
	      let (bl, def_list, t1) = Terms.subst_else_find cur_array' tl' ef in
	      (* The elsefind fact [forall bl, not (defined(def_list) && t1)] holds after ppl[tl] *)

              (* We add to [fact_accu] the facts [not t'] where the pairs 
		 (def_list', t') are instances of (def_list, t1) such that
		 the elements of [def_list'] are defined at ppl[tl]. 
		 (They are in [def_vars_before].) *)
	      begin
		try 
		  Facts.match_among_list (final_next4 bl def_list t1 fact_accu) simp_facts bl def_vars_before def_list
		with NoMatch -> ()
	      end
		) elsefind_facts;

              (* Note: we re-add the facts that are already in simp_facts, 
                 because the dependency information can allow further 
                 simplifications on them as well. 
		 We add [t'] last, so that we can already exploit 
		 the values of variables known previously when using
		 the dependency analysis on [t']. *)
	    let dep_anal = dependency_anal_order_hyp cur_array dep_info in
            let simp_facts1 = Facts.simplif_add_list dep_anal ([],[],[]) subst in
	    let simp_facts2 = Facts.simplif_add_list dep_anal simp_facts1 facts in
	    let simp_facts3 = Facts.simplif_add_list dep_anal simp_facts2 (!fact_accu) in
	    let _ = Facts.simplif_add dep_anal simp_facts3 t' in
            if !Settings.debug_elsefind_facts then
              begin
                Settings.debug_simplif_add_facts := false;
                print_string "Failed to obtain a contradiction.";
                print_newline ()
              end;
            false
          with Contradiction -> 
            if !Settings.debug_elsefind_facts then
              begin
                Settings.debug_simplif_add_facts := false;
                print_string "Obtained a contradiction.";
                print_newline ()
              end;
            true
              ) (Facts.get_compatible_def_nodes history pps (fst bri) (snd bri))
	  )
          ) def_list_with_i'; 
      )
    then
      begin
        (* The term (not t') is true, add it *)
        let t = (Terms.make_not t') in
        term_accu := t :: (!term_accu);
        if !Settings.debug_elsefind_facts then
	  begin
	    print_string "Found a usable term: ";
	    Display.display_term t;
	    print_newline ()
	  end
      end
    else
      begin
	(* Nothing inferred, restore the old probability state.
	   The collisions that we eliminated were useless in the end. *)
	Depanal.restore_state proba_state;
        if !Settings.debug_elsefind_facts then
          begin
            print_string "Found no usable terms.";
            print_newline ()
          end
      end
	) (!result)


let get_facts_of_elsefind_facts g cur_array simp_facts pps history def_vars =
  if !Settings.debug_elsefind_facts then
    begin
      print_string "__________________\n";
      print_string "Elsefind begin\n";
      print_newline ()
    end; 
(*  print_string "Defined variables original:\n";
  Display.display_def_list_lines def_vars; *)
  let def_vars_tmp = ref [] in
  List.iter (fun (b,l) ->
    let br' = (b, List.map (Terms.try_no_var simp_facts) l) in
    Terms.add_binderref br' def_vars_tmp) def_vars;
  let def_vars = !def_vars_tmp in
(*  print_string "Defined variables simplified:\n";
    Display.display_def_list_lines def_vars; *)
  (* Simplify program points *)
  let pps =
    List.map (fun (pps,l) ->
      (pps, List.map (Terms.try_no_var simp_facts) l)
	) pps
  in
  
  let effl = collect_eff_from_pps pps in
  let term_accu = ref [] in
  List.iter (fun (ppl, eff) -> get_fact_of_elsefind_fact term_accu g cur_array pps history def_vars simp_facts ppl eff) effl;
  if !Settings.debug_elsefind_facts then
    begin
      print_string "__________________\n";
      print_string "Elsefind summary: these terms are true:\n";
      Display.display_list Display.display_term (!term_accu);
      print_newline ()
    end;
  !term_accu


