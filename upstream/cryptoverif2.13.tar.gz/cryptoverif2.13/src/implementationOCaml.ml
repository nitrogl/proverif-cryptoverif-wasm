(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Types


module StringMap = Map.Make(String)
module BinderSet = Set.Make(String)


(*informations to the user*)
let info mess = print_string ("Information: "^ mess^" (implementation)\n")
let error mess = Parsing_helper.user_error ("Error: "^mess^" (implementation)\n")

let letfun_module = "Letfun"

let letfun_prefix = ref ""
    
let string_list_sep = String.concat

let string_list_sep_ignore_empty sep t=
  string_list_sep sep (List.filter (fun s -> s <> "") t)

let alphabetize_string = StringPlus.alphabetize_string

let get_oracle_name name =
  "type_oracle_"^(alphabetize_string name)

let get_binder_name b =
  "var_"^(alphabetize_string b.sname)^"_"^(string_of_int b.vname)

let get_fun_name f =
  "fun_"^(alphabetize_string f.f_name)
					     

(*returns set of free and set of bound variables
  get_iprocess_bv returns the set of variables bound not under a replication
  The set of variables bound under a replication is stored in
  bound_vars_under_repl.
  The set of variables bound inside a term is stored in bound_vars_terms.
  The set of free variables is stored in free_vars. 
 *)

let empty_bv = BinderSet.empty
let bound_bv = BinderSet.singleton
let add_bv = BinderSet.union

let add_list_bv f l=
  List.fold_left (fun x y -> add_bv x (f y)) empty_bv l

let get_binderref_name ext (b,l) =
  if Terms.is_args_at_creation b l then
    get_binder_name b
  else
    Parsing_helper.input_error "There should not be any find variable (implementation)" ext

let free_vars = ref BinderSet.empty (* Contains all free variables; may contain some variables that are also bound *)
let bound_vars_under_repl = ref BinderSet.empty
let bound_vars_terms = ref BinderSet.empty

let add_bv_term bs =
  bound_vars_terms := BinderSet.union bs (!bound_vars_terms)
    
let free_var b=
  free_vars := BinderSet.add b (!free_vars);
  BinderSet.empty

let rec get_pattern_bv = function
    PatVar(b)->bound_bv (get_binder_name b)
  | PatTuple((fs,pl))-> add_list_bv get_pattern_bv pl
  | PatEqual(t)-> add_bv_term (get_term_bv t); empty_bv

and get_iprocess_bv p = 
  match p.i_desc with
    Nil -> empty_bv
  | OracleDecl(o,patl,p) ->      
        (List.fold_right add_bv (List.map get_pattern_bv patl)
        (get_oprocess_bv p))
  | Par (p1,p2) ->
      add_bv (get_iprocess_bv p1) (get_iprocess_bv p2)
  | Repl(b,p1) -> 
      let bv = get_iprocess_bv p1 in
      bound_vars_under_repl := BinderSet.union (!bound_vars_under_repl) bv;
      empty_bv

and get_term_bv t = match t.t_desc with
    Var(b,tl) -> 
      free_var (get_binderref_name t.t_loc (b,tl))
  | FunApp(fs,tl) -> add_list_bv get_term_bv tl
  | TestE(t1,t2,t3) -> 
      add_bv 
        (add_bv (get_term_bv t1) (get_term_bv t2)) 
        (get_term_bv t3)
  | LetE(pat,t1,t2,t3) -> 
      add_bv (get_pattern_bv pat)
	(add_bv (get_term_bv t1)
	   (add_bv (get_term_bv t2)
	      (match t3 with 
		None->empty_bv
              | Some(t)-> get_term_bv t)))
  | ResE(b,t) -> 
      add_bv (bound_bv (get_binder_name b))
        (get_term_bv t)
  | ReplIndex _ -> empty_bv
	(*Replication indices may also occur in events
	  Parsing_helper.input_error "Replication indices should occur only inside variables (implementation)" t.t_loc*)
  | EventAbortE _ -> empty_bv
  | EventE(t,p) ->
      add_bv (get_term_bv t) (get_term_bv p) 
  | FindE _ -> Parsing_helper.input_error "Find not supported (implementation)" t.t_loc
  | GetE(tbl,patl,topt,p1,p2,_) ->
      (List.fold_right add_bv (List.map get_pattern_bv patl)
         (add_bv 
            (match topt with Some t -> get_term_bv t | None -> empty_bv)
            (add_bv (get_term_bv p1) (get_term_bv p2))))
  | InsertE(tbl,tl,p) ->
      List.fold_right add_bv (List.map get_term_bv tl)
          (get_term_bv p)
      
and get_oprocess_bv p =
  match p.p_desc with
      Yield | EventAbort _ -> empty_bv
    | Restr(b,p) -> 
        add_bv 
          (bound_bv (get_binder_name b))
          (get_oprocess_bv p)
    | Test(t,p1,p2) ->
        add_bv_term (get_term_bv t);
        add_bv
          (get_oprocess_bv p1)
          (get_oprocess_bv p2)
    | Return(tl,p) -> 
        List.iter (fun x -> add_bv_term (get_term_bv x)) tl;
	get_iprocess_bv p
    | Let(pat,t,p1,p2) ->
        add_bv_term (get_term_bv t);
        add_bv (get_pattern_bv pat) 
          (add_bv (get_oprocess_bv p1) (get_oprocess_bv p2))
    | EventP(t,p)->
	add_bv_term (get_term_bv t);
        get_oprocess_bv p
    | Find(fl,ep,_) -> 
        error "Find not supported"
    | Get(tbl,patl,topt,p1,p2,_) ->
	begin
	  match topt with
	    Some t -> add_bv_term (get_term_bv t)
	  | None -> ()
	end;
        (List.fold_right add_bv (List.map get_pattern_bv patl)
           (add_bv (get_oprocess_bv p1) (get_oprocess_bv p2)))
    | Insert(tbl,tl,p) ->
        List.iter (fun t ->  add_bv_term (get_term_bv t)) tl;
        get_oprocess_bv p
    | NewTable _ ->
	error "Newtable not supported"

let display_vars (a,b)=
  print_string "Free vars : ";
  BinderSet.iter 
    (fun x -> 
       print_string (x^" "))
    a;
  print_newline ();
  print_string "Bound vars : ";
  BinderSet.iter 
    (fun x -> 
       print_string (x^" "))
    b;
  print_newline ()

        
let impl_get_vars p=
  free_vars := BinderSet.empty;
  bound_vars_under_repl := BinderSet.empty;
  bound_vars_terms := BinderSet.empty;
  let bv_no_repl = get_iprocess_bv p in
  let bv_repl = (!bound_vars_under_repl) in
  let bv_terms = (!bound_vars_terms) in
  (* This way of computing free variables is ok because the variables
     are renamed to distinct names *)
  let fv = BinderSet.diff (!free_vars)
      (BinderSet.union bv_no_repl (BinderSet.union bv_repl bv_terms)) in
  free_vars := BinderSet.empty;
  bound_vars_under_repl := BinderSet.empty;
  bound_vars_terms := BinderSet.empty;
  (fv, bv_no_repl, bv_repl, bv_terms)

(* Check if the free variables of roles are all written to files. *)
let impl_check impllist =
  let bf=StringMap.empty in
  let boundfiles = ref bf in
    
  let check_read (pn,p,vars,opt) =
    let rec read_opt1 ((fv,bv_no_repl,bv_repl,bv_terms) as vars) = function
        Read(b,f)::next ->
	  let bname = get_binder_name b in
          if BinderSet.mem bname fv then
            read_opt1 (BinderSet.remove bname fv,bv_no_repl,bv_repl,bv_terms) next
          else
            error ("Module "^pn^" reads variable "^bname^", which is not free.")
      | _::next ->
          read_opt1 vars next
      | [] -> vars
    in
    (pn,p,read_opt1 vars opt,opt)
  in
  let check_write (pn,p,vars,opt) =
    let rec read_opt2 ((fv,bv_no_repl,bv_repl,bv_terms) as vars) = function
      | Write(b,f)::next ->
	  let bname = get_binder_name b in
          if BinderSet.mem bname bv_no_repl then
            (
	      if BinderSet.mem bname bv_terms then
	        print_string ("Warning: Module "^pn^" writes variable "^bname^", which is bound both in a process and in a term.\nOnly the variable(s) bound in a process will be written to a file.\n");
              boundfiles := StringMap.add bname (b,f) (!boundfiles);
              read_opt2 (fv,BinderSet.remove bname bv_no_repl,bv_repl,bv_terms) next
            )
          else if BinderSet.mem bname bv_repl then
	    error ("Module "^pn^" writes variable "^bname^", which is bound under a replication in that module.")
	  else if BinderSet.mem bname bv_terms then
	    error ("Module "^pn^" writes variable "^bname^", which is bound locally inside a term in that module.")
	  else
            error ("Module "^pn^" writes variable "^bname^", which is not bound.")
      | _::next ->
          read_opt2 vars next
      | [] -> vars
    in
    (pn,p,read_opt2 vars opt,opt)
  in
  let add_files (pn,p,(fv,_,_,_),opt) =
    let opt = BinderSet.fold 
      (fun s opt -> 
         (*is it a variable written by a previous process ? *)
         try 
	   let (b,f) =  StringMap.find s (!boundfiles) in
           info (pn^" will read "^(s)^" from file "^f^".");
           (Read(b,f))::opt
         with Not_found -> 
           error ("Module "^pn^" needs to read the variable "^(s)^", but no module writes it.")
      ) fv opt
    in
    (pn,opt,p)
  in
  (*get variables *)
  let vars = List.map (fun ((pn,opt,p):impl_process) -> (pn,p,impl_get_vars p,opt)) impllist in
  List.map add_files 
    (List.map check_read (List.map check_write vars))

let rt = ref 0

let create_fresh_number () =
  rt := !rt + 1;
  !rt

let create_fresh_name prefix =
  prefix^(string_of_int (create_fresh_number ()))

let rec create_fresh_names prefix = function
    0 -> []
  | i -> (create_fresh_name prefix)::(create_fresh_names prefix (i-1))

let check_oracle_compatibility name (rt, o) (rt', o') =
  if (rt <> rt') then
    match !Settings.front_end with
      | Settings.Channels ->
          error ("The outputs following inputs on channel "^name^
                    " do not have the same type")
      | Settings.Oracles ->
          error ("The oracle "^name^
                    " does not have the same return types everywhere")
  else if (o <> o') then
    match !Settings.front_end with
      | Settings.Channels ->
          error ("The input channels after outputs after inputs on channel "^name^
                    " are not the same everywhere")
      | Settings.Oracles ->
          error ("The oracle "^name^
                    " does not have the same next oracles everywhere")

let check_argument_type_compatibility name at at' =
  if (at <> at') then
    match !Settings.front_end with
      | Settings.Channels ->
          error ("The messages of inputs on channel "^name^
                    " do not have the same types everywhere")
      | Settings.Oracles ->
          error ("The arguments of oracle "^name^
                    " do not have the same types everywhere")

let type_append = 
  StringMap.fold 
    (fun name (s,at) acc -> 
       try
         (
           let (s',at') = StringMap.find name acc in
           check_argument_type_compatibility name at at';
           match s,s' with
             | Some (rt,o), Some (rt',o') ->
                 check_oracle_compatibility name (rt, o) (rt', o');
                 acc
             | None, Some(rt,o) ->
                 acc
             | Some(rt,o), None ->
                 StringMap.add name (Some(rt,o),at) (StringMap.remove name acc)
             | None, None ->
                 acc
         )
       with Not_found -> 
         StringMap.add name (s,at) acc)

(* returns the next oracles. b represents if the oracle is under replication (false) or not (true) *)

let rec get_next_oracles b p =
  match p.i_desc with
    | Nil -> []
    | OracleDecl(o,patl,p) -> 
        [(b,o.ooracle.oname,patl,p)]
    | Par (p1,p2) ->
        (get_next_oracles b p1) @ (get_next_oracles b p2)
    | Repl(b,p) -> get_next_oracles false p

let rec get_oracle_types_oprocess name args_types p = 
  match p.p_desc with
    | Yield | EventAbort _ -> StringMap.add name (None, args_types) StringMap.empty
    | Restr(b,p) -> 
        get_oracle_types_oprocess name args_types p
    | Test(t,p1,p2) ->
        type_append (get_oracle_types_oprocess name args_types p1) (get_oracle_types_oprocess name args_types p2)
    | Return(tl,p) -> 
        let r = get_oracle_types_process p in
        let o = List.map (fun (b,n,_,_) -> (b,n)) (get_next_oracles true p) in
        let ra =  List.map (fun t -> t.t_type) tl
        in
          (
            try 
              let (s,a') = StringMap.find name r in
              check_argument_type_compatibility name a' args_types;
              match s with 
                | Some (ra',o') -> 
                    check_oracle_compatibility name (ra, o) (ra', o');
                    r        
                | None ->
                    type_append (StringMap.add name (Some(ra,o),args_types) StringMap.empty) r
            with
              | Not_found -> 
                  StringMap.add name (Some(ra,o),args_types) r
          )
    | Let(pat,t,p1,p2) ->
        type_append (get_oracle_types_oprocess name args_types p1) (get_oracle_types_oprocess name args_types p2)
    | EventP(t,p)->
        get_oracle_types_oprocess name args_types p
    | Find(_,_,_) -> 
        error "Find not supported"
    | Get(tbl,patl,topt,p1,p2,_) ->
        type_append (get_oracle_types_oprocess name args_types p1) (get_oracle_types_oprocess name args_types p2)
    | Insert(tbl,tl,p) ->
        get_oracle_types_oprocess name args_types p
    | NewTable _ ->
	error "Newtable not supported"          
          
and get_oracle_types_process p =
  match p.i_desc with
    | Nil -> StringMap.empty
    | OracleDecl(o,patl,p) -> 
        get_oracle_types_oprocess o.ooracle.oname (List.map Terms.get_type_for_pattern patl) p
    | Par (p1,p2) ->
        type_append (get_oracle_types_process p1) (get_oracle_types_process p2)
    | Repl(b,p) -> 
        get_oracle_types_process p

let get_type_name t =
  match t.timplname with
      Some s -> s
    | None -> error ("Type name required for type "^t.tname)

let get_oracles_type_string o =
  if o <> [] then
    "("^(string_list_sep " * " (List.map (fun (_,n) -> get_oracle_name n) o))^")" 
  else
    "unit"
  

let get_type_oracle name (s,args_types) =
  let (ret_types,o) = match s with
    | Some (rt,o) -> rt,o
    | None -> [],[]
  in
  let ol= get_oracles_type_string o in
    (get_oracle_name name)^
      " = "^
      (
        if args_types = [] then 
          "unit" 
        else
          "("^(string_list_sep " * " (List.map get_type_name args_types))^")"
      )^
      " -> "^
      (
        if ret_types = [] then
          ol
        else
          "("^ol^" * "^
            (string_list_sep " * " (List.map get_type_name ret_types))^
            ")"
      )

let get_oracles_types process = 
  "type "^
    string_list_sep "\n and " 
    (StringMap.fold 
       (fun name (s,at) acc -> 
          (get_type_oracle name (s,at))::acc)
       (get_oracle_types_process process) [])
  

let prefix=
  "open Base\n"^
  "open Crypto\n\n"

let get_type_predicate t =
  match t.tpredicate with
    | Some x -> x
    | None -> error ("Predicate for type "^t.tname^" required!")

let get_table_file tbl =
  if tbl.tbllocalopt <> None then
    error ("Local table "^tbl.tblname^" not supported"); 
  match tbl.tblfile with
    | None -> error ("No file given for the table "^tbl.tblname)
    | Some f -> f

let get_read_serial ty =
  match ty.tserial with
    | Some (_,s) -> s 
    | None -> error ("Serialization for type "^ty.tname^" required")

let get_write_serial ty =
  match ty.tserial with
    | Some (s,_) -> s 
    | None -> error ("Serialization for type "^ty.tname^" required")

let file_loading opt ind =
  let read_files acc = function
      Read (b,f) -> 
        let ser=get_read_serial b.btype in
          ("\n"^ind^"let "^(get_binder_name b)^"= exc_bad_file \""^f^"\" "^ser^" (input_string_from_file \""^f^"\") in")^acc
    | _ -> acc
  in
    List.fold_left read_files "" opt

let write_file opt b ind =
  match 
    (List.filter 
       (function
          | Write (b',_) -> b==b'
          | _ -> false
       ) opt) 
  with
    | Write(b,f)::_ -> 
        let ser=get_write_serial b.btype in
          "\n"^ind^"output_string_to_file \""^f^"\" ("^ser^" "^(get_binder_name b)^");"
    | _ -> ""

let random b ind =
  let rand = match b.btype.trandom with
      Some(r) -> r
    | None -> error ("Random generation function required for type "^b.btype.tname^" required.")
  in
    "let "^(get_binder_name b)^" = "^rand^" () in"

let rec term_needs_state t =
  match t.t_desc with
  | ReplIndex _ | Var _ -> false
  | FunApp(f,tl) ->
      f.f_impl_needs_full_state || List.exists term_needs_state tl
  | TestE(t1,t2,t3) ->
      term_needs_state t1 || term_needs_state t2 || term_needs_state t3
  | EventE(t,p)->
      term_needs_state t || term_needs_state p
  | FindE _ -> error "Find not supported"
  | LetE(pat,t1, t2, topt) ->
      pat_needs_state pat || term_needs_state t1 || term_needs_state t2 ||
      (match topt with
      | None -> false
      | Some t3 -> term_needs_state t3)
  | ResE(_,t) -> term_needs_state t
  | EventAbortE _ | GetE _ | InsertE _ -> true
	(* the order of evaluation is important for event_abort (because it raises Abort)
	   and for insert/get in tables *)

and pat_needs_state = function
  | PatVar _ -> false
  | PatTuple(_,l) -> List.exists pat_needs_state l
  | PatEqual t -> term_needs_state t
				   
let rec translate_oprocess opt p ind =
  match p.p_desc with
    | Yield -> "\n"^ind^"raise Match_fail"
    | EventAbort _ -> "\n"^ind^"raise Abort"
    | Restr(b,p) -> 
        "\n"^ind^(random b ind)^
        (write_file opt b ind)^
        (translate_oprocess opt p ind)
    | Test(t,p1,p2) ->
        "\n"^ind^"if "^(translate_term t ind)^" then\n"^ind^"begin"^
          (translate_oprocess opt p1 (ind^"  "))^
          "\n"^ind^"end\n"^ind^"else\n"^ind^"begin"^
          (translate_oprocess opt p2 (ind^"  "))^"\n"^ind^"end"
    | Return(tl,p) -> 
        if tl = [] then
          (translate_process opt p ind)
        else
          let prefix, tl' = translate_term_list tl ind in 
          let t' = string_list_sep ", " tl' in
          "\n"^ind^prefix^"("^(translate_process opt p (ind^"  "))^
            ",\n"^ind^t'^
            "\n"^ind^")"
    | Let(pat,t,p1,p2) ->
	let (prefixt, valt) =
	  if term_needs_state t then
	    let x = create_fresh_name "tvar_" in
	    "let "^x^" = "^(translate_term t (ind^"  "))^" in\n"^ind, x
	  else
	    "", translate_term t ind
	in
	let p2opt =
	  match p2.p_desc with
	  | Yield -> None
	  | _ -> Some ((fun b -> Terms.refers_to_oprocess b p1), translate_oprocess opt p2)
	in
	let prefix, next = match_pattern term_needs_state opt pat valt (translate_oprocess opt p1) p2opt false ind in
        "\n"^ind^prefixt^prefix^next
    | EventP(t,p)->
        "\n"^ind^(translate_event t ind)^
	(translate_oprocess opt p ind)
    | Find(_,_,_) -> 
        error "Find not supported"
    | Get(tbl,patl,topt,p1,p2,find_info) ->
        translate_get (fun b -> Terms.refers_to_oprocess b p1) opt tbl patl topt (translate_oprocess opt p1) (translate_oprocess opt p2) find_info ind
    | Insert(tbl,tl,p) ->
        let tfile=get_table_file tbl in
	let prefix, tl' = translate_term_list tl ind in
          "\n"^ind^prefix^"insert_in_table \""^tfile^"\" ["^(string_list_sep "; " (List.map2 (fun t ty -> "("^(get_write_serial ty)^" ("^t^"))") tl' tbl.tbltype))^"];\n"^
            (translate_oprocess opt p ind)
    | NewTable _ ->
	error "Newtable not supported"

(* p1 and p2 are functions that take the indentation level and returns the string corresponding to the program *)
and translate_get used opt tbl patl topt p1 p2 find_info ind =
  let pat_vars = Terms.vars_from_pat_list [] patl in
  let used_vars = List.filter used pat_vars in
  let match_res = "("^(string_list_sep "," (List.map get_binder_name used_vars))^")" in
  let tfile = get_table_file tbl in
  let list=create_fresh_name "list_" in
  let tvars1 = create_fresh_names "tvar_" (List.length tbl.tbltype) in
  let tvars = List.map2 (fun v t -> "(exc_bad_file \""^tfile^"\" "^(get_read_serial t)^" "^v^")") tvars1 tbl.tbltype in
  let non_simple t =
    match t.t_desc with
    | Var _ | FunApp({ f_impl = Const _ },[]) -> false
    | _ -> true
  in
  let prefix, matchfilt =
    match_pattern_list 
      non_simple opt patl tvars 
      (fun ind ->
        match topt with 
        | Some t -> "\n"^ind^"if ("^(translate_term t ind)^") then "^match_res^" else raise Match_fail"
        | None -> match_res)
      None
      false
      (ind^"        ")
  in
  let filterfun =
    ind^ "  (function\n"^ind^
    "      | ["^(string_list_sep "; " tvars1)^"] -> begin\n"^ind^
    matchfilt^"\n"^ind^
    "        end\n"^ind^
    "      | _ -> raise (Bad_file \""^tfile^"\"))"
  in
  if used_vars = [] then
    "\n"^
    ind^"begin\n"^
    ind^prefix^"if exists_in_table \""^tfile^"\"\n"^
      filterfun^" then begin "^
      (p1 (ind^"  "))^
      "\n"^ind^"end else begin "^
    (p2 (ind^"  "))^"\n"^
    ind^"end\n"^
    ind^"end"
  else if find_info = Unique then
    "\n"^
    ind^"begin\n"^
    ind^prefix^"match get_one_from_table \""^tfile^"\"\n"^ filterfun^" with\n"^
    ind^"| None ->\n"^
    ind^"  begin "^(p2 (ind^"  "))^"\n"^
    ind^"  end\n"^
    ind^"| Some "^match_res^" ->\n"^
    ind^"  begin "^(p1 (ind^"  "))^"\n"^
    ind^"  end\n"^
    ind^"end"
  else    
    "\n"^
    ind^"begin\n"^
    ind^prefix^"let "^list^" = get_from_table \""^tfile^"\"\n"^
      filterfun^" in\n"^ind^
      "if "^list^" = [] then begin "^
      (p2 (ind^"  "))^
      "\n"^ind^"end else begin\n"^ind^
      "  let "^match_res^" = rand_list "^list^" in"^
    (p1 (ind^"  "))^"\n"^
    ind^"  end\n"^
    ind^"end"

and translate_event t ind =
  match t.t_desc with
    ReplIndex _ -> ""
  | Var(_, tl) ->
      String.concat "" (List.map (fun t -> translate_event t ind) tl)
  | FunApp(f,tl) when not f.f_impl_needs_full_state ->
      (* When a letfun uses tables, we execute it *)
      String.concat "" (List.map (fun t -> translate_event t ind) tl)
  | EventE(t,p) ->
      (translate_event t ind) ^ (translate_event p ind)
  | _ ->
      if term_needs_state t then
	let transl_t = translate_term t (ind^"  ") in
	"let _ = " ^ transl_t ^ " in\n" ^ ind
      else
	""

and translate_term_list l ind =
  List.fold_right (fun t (accuprefix, accutl) ->
    if term_needs_state t then
      let x = create_fresh_name "tvar_" in
      "let "^x^" = "^(translate_term t (ind^"  "))^" in\n"^ind^accuprefix, x::accutl
    else
      accuprefix, (translate_term t ind)::accutl
					     ) l ("", [])
    
and translate_term t ind =
  let rec termlist sep = function
      [] -> "()"
    | [a] -> a
    | a::b -> a^sep^(termlist sep b)
  in
    match t.t_desc with
      | Var (b,tl) -> get_binderref_name t.t_loc (b,tl)
      | FunApp(f,tl) ->
	  let prefix, tl' = translate_term_list tl ind in
          if f.f_name = "" then
            "("^prefix^"compos ["^
            (string_list_sep ";" (List.map2 (fun t t' -> (get_write_serial t.t_type)^" "^t') tl tl'))^
            "])"
          else
            (match f.f_impl with 
            | Func x -> "("^prefix^x^" "^(termlist " " tl')^")"
            | Const x -> x
	    | FuncEqual -> "(" ^ prefix ^ "(=) " ^ (termlist " " tl') ^ ")"
	    | FuncDiff -> "(" ^ prefix ^ "(<>) " ^ (termlist " " tl') ^ ")"
	    | SepFun -> "("^prefix^(!letfun_prefix)^(get_fun_name f)^" "^(termlist " " tl')^")"
            | No_impl ->
		match f.f_cat with
		| Proj(f',n) ->
		    let invf' =
		      match f'.f_impl_inv with 
			Some(invf') -> invf' 
                      | _ -> error ("Inverse function of "^f'.f_name^" not registered. Add a line 'implementation fun "^f'.f_name^"=\"f1\" [inverse = \"f2\"].' in the source.")
		    in
		    "("^prefix^"let ("^
		    (String.concat ", " (List.mapi (fun i _ -> if i+1 = n then "pvar" else "_") (fst f'.f_type)))^") = "^invf'^"("^termlist " " tl'^") in pvar)"
		| _ -> error ("Function not registered:" ^ f.f_name)
            )
      | TestE(t1,t2,t3) -> "(if "^(translate_term t1 ind)^" then "^(translate_term t2 ind)^" else "^(translate_term t3 ind)^" )"
      | ReplIndex _ ->
	  Parsing_helper.input_error "Replication indices should occur only inside variables (implementation)" t.t_loc
      | EventAbortE _ -> "(raise Abort)"
      | EventE(t,p)->
          "("^(translate_event t ind)^
	  (translate_term p ind)^")"
      | GetE(tbl,patl,topt,p1,p2, find_info) ->
          translate_get (fun b -> Terms.refers_to b p1) [] tbl patl topt (translate_term p1) (translate_term p2) find_info ind
      | InsertE(tbl,tl,p) ->
          let tfile=get_table_file tbl in
	  let prefix, tl' = translate_term_list tl ind in
          "("^prefix^"insert_in_table \""^tfile^"\" ["^(string_list_sep "; " (List.map2 (fun t ty -> "("^(get_write_serial ty)^" ("^t^"))") tl' tbl.tbltype))^"];\n"^ind^
          (translate_term p ind)^")"
      | FindE _ -> Parsing_helper.input_error "Find not supported (implementation)" t.t_loc
      | ResE (b,t) -> "("^(random b ind)^"\n"^ind^(translate_term t ind)^")"
      | LetE (pat, t1, t2, topt) ->
	  let (prefix1, val1) =
	    if term_needs_state t1 then
	      let x = create_fresh_name "tvar_" in
	      "let "^x^" = "^(translate_term t1 (ind^"  "))^" in\n"^ind, x
	    else
	      "", translate_term t1 ind
	  in
	  let (prefix, next) = match_pattern term_needs_state [] pat val1 (translate_term t2) 
	    (match topt with 
	      Some t3-> Some ((fun b -> Terms.refers_to b t2), translate_term t3)
	    | None -> Some ((fun b -> false), fun ind -> Parsing_helper.internal_error "else branch of let called but not defined")) true ind
	  in
          "("^prefix1^prefix^next^")"
        
and match_pattern_complex must_expand opt patl sl p1 p2opt in_term ind =
  (* [p2opt] is either
     - [None] when the process [p2] just raises Match_fail
     - [Some(p1uses, p2)] where
     [p1uses b = true] if and only if p1 uses variable [b] (so [b] is needed
     as result of the pattern-matching)
     [p2 ind] is the OCaml code for [p2] with indentation [ind] *)
  (*decomposition of every function*)
  let rec decompos=function
    | PatVar(b) -> 
        ("",[],get_binder_name b,[])
    | PatEqual(t) -> 
        let n=create_fresh_name "bvar_" in
        (* evaluate all terms [t] such that [must_expand t] before starting the
	   pattern matching. 
	   In the semantics of CryptoVerif, terms in the pattern are
	   evaluated before pattern-matching starts. 
	   In general, it is enough to do it for terms that use tables;
	   the order of evaluation does not matter for other terms.
	   In this case, [must_expand = term_needs_state].
	   In [get], we preevaluate all terms that are not constants or 
	   variables, because the pattern-matching is performed for
	   each element of the table, so preevaluating terms is better
	   for efficiency and required for randomized terms. *)
	if must_expand t then
	  let x = create_fresh_name "tvar_" in
	  ("let "^x^" = "^(translate_term t (ind^"  "))^" in\n"^ind,
	   [], n, [(n,x)])
	else
          ("",[],n,[(n, translate_term t ind)])
    | PatTuple(f,pl) -> 
        let n=create_fresh_name "bvar_" in
        let func=
          if f.f_name = "" then
            let n = create_fresh_name "cvar_" in
            let l = create_fresh_name "lvar_" in
            let nl= create_fresh_names "cvar_" (List.length pl) in
              "(fun "^n^" -> let "^l^" = decompos "^n^" in match "^l^" with\n"^
                ind^"    | ["^(string_list_sep ";" nl)^"] -> ("^
                (string_list_sep "," (List.map2 (fun p n -> 
		  (get_read_serial (Terms.get_type_for_pattern p))^" "^n) pl nl))^")\n"^
                ind^"    | _ -> raise Match_fail)"
          else
            (
              match (f.f_impl_inv) with 
                  Some(f) -> f 
                | _ -> error ("Inverse function of "^f.f_name^" not registered. Add a line 'implementation fun "^f.f_name^"=\"f1\" [inverse = \"f2\"].' in the source.")
            )
        in
        let decompos_list = List.map decompos pl in
        (
	  String.concat "" (List.map (fun (p,x,y,z)->p) decompos_list),
          (n,func,List.map (fun (p,x,y,z)->y) decompos_list)::
            (List.concat (List.map (fun (p,x,y,z)->x) decompos_list)),
          n,
          List.concat (List.map (fun (p,x,y,z)-> z) decompos_list)
        )
  in
  let rec get_all_binders=function
    | PatVar(b) -> [b]
    | PatTuple(f,pl) -> List.concat (List.map get_all_binders pl)
    | _ -> []
  in
  let all_binders = List.concat (List.map get_all_binders patl) in
  let rec andlist = function
    | [] -> "true"
    | [x] -> x
    | x::y -> x^" && "^(andlist y)
  in
  let decompos_list = List.map decompos patl in
  let prefix = String.concat "" (List.map (fun (p,x,y,z)->p) decompos_list) in
  let func = List.concat (List.map (fun (p,x,y,z)->x) decompos_list) in
  let assign = List.map2 (fun (p,x,y,z) s -> (y,s)) decompos_list sl in
  let tests = List.concat (List.map (fun (p,x,y,z)-> z) decompos_list) in
  let match_text ind then_p =
    (* Returns [then_p] when pattern-matching succeeds;
       raises Match_fail when pattern-matching fails *)
    (String.concat "" (List.map (fun (name, s) -> "\n"^ind^"let "^name^"="^s^" in") assign))^
    (*decompos functions*)
      (List.fold_left (^) "" 
         (List.map 
            (fun (n,f,vl) -> 
               "\n"^ind^"let ("^(string_list_sep "," vl)^")="^
                 f^" "^n^" in") func)
      )^
      (*tests*)
    (let success_case =
      (if not in_term then
         (string_list_sep_ignore_empty "" 
            (
              (List.map (fun s -> 
                           write_file opt s (ind^"  ")) 
                 all_binders)
            ))
      else "")^
      then_p
    in
    if tests = [] then
      success_case
    else
      "\n"^ind^"if "^(andlist (List.map (fun (n,s)-> n^"="^s) tests))^
      " then begin "^success_case^
      "\n"^ind^"end\n"^ind^"else\n"^ind^"  raise Match_fail")
  in
  prefix,
  match p2opt with
  | None ->
      (* raise Match_fail when pattern-matching fails *)
      match_text ind (p1 (ind^"  "))
  | Some (p1uses, p2) ->
      (* execute p2 when pattern-matching fails *)
      let used_vars = List.filter p1uses all_binders in
      let used_vars_tuple = "("^(String.concat ", " (List.map get_binder_name used_vars))^")" in
      "\n"^
      ind^"match"^(match_text (ind^"  ") used_vars_tuple)^ "\n"^
      ind^"with\n"^
      ind^"| "^used_vars_tuple^" -> "^(p1 (ind^"    "))^"\n"^
      ind^"| exception Match_fail -> "^(p2 (ind^"    "))

and match_pattern must_expand opt (pat:Types.pattern) (var:string) (p1:string -> string) (p2opt: ((binder -> bool) * (string -> string)) option) (in_term:bool) ind =
  match pat with
    | PatVar(b) -> 
        "", "let "^(get_binder_name b)^" = "^var^" in "^(if (not in_term) then write_file opt b (ind^"  ") else "")^(p1 ind)
    | PatEqual(t) ->
	let prefix, t' =
	  if must_expand t then
	    let x = create_fresh_name "tvar_" in
	    "let "^x^" = "^(translate_term t (ind^"  "))^" in\n"^ind, x
	  else
	    "", translate_term t ind
	in
	let p2 =
	  match p2opt with
	  | Some (_,p2) -> p2
	  | None -> fun ind -> "\n"^ind^"raise Match_fail"
	in
        prefix,
	"if "^t'^" = "^var^" then\n"^ind^"begin "^
          (p1 (ind^"  "))^
          "\n"^ind^"end else begin "^
          (p2 (ind^"  "))^
          "\n"^ind^"end"
    | _ -> match_pattern_complex must_expand opt [pat] [var] p1 p2opt in_term ind

and match_pattern_list must_expand opt patl vars (p1:string -> string) (p2opt: ((binder -> bool) * (string -> string)) option) in_term ind =
  match patl, vars with
  | [pat], [var] ->
      match_pattern must_expand opt pat var p1 p2opt in_term ind
  | _ ->
      match_pattern_complex must_expand opt patl vars p1 p2opt in_term ind
	
and match_pattern_from_input opt pl (vars:string list) (next:string -> string) ind =
     let prefix, next' = match_pattern_list term_needs_state opt pl vars next None false ind in
     prefix ^ next'

and get_oracle_body opt (b,name,patl,p) ind =
  let args=create_fresh_names "input_" (List.length patl) in
  let token=create_fresh_name "token_" in
  let type_list= List.map Terms.get_type_for_pattern patl in
  let typecheck_list=List.map2 (fun t a ->
                                  let p = get_type_predicate t in
                                    if p = "always_true" then
                                      ""
                                    else
                                      ("("^p^" "^a^")")) type_list args in
  let filter_typecheck_list=List.filter (fun s -> s <> "") typecheck_list in
  let check_list=if b then ("(!"^token^")")::filter_typecheck_list else filter_typecheck_list in
    "\n"^ind^"begin\n"^ind^"  "^(
        if b then 
          "let "^token^" = ref true in\n"^ind^"  "
        else ""
      )^
      "fun ("^(string_list_sep ", " args)^") ->\n"^ind^"    "^
      (if check_list <> [] then 
         "if "^(string_list_sep " && " check_list)^" then\n"^ind^"    "^
           "begin\n"^ind^"      "^
           (if b then token^" := false;\n"^ind^"      " else "")^
           match_pattern_from_input opt patl args (translate_oprocess opt p) (ind^"      ")^
           "\n"^ind^"    "^"end\n"^ind^"    "^
           "else raise Bad_call"
       else
         match_pattern_from_input opt patl args (translate_oprocess opt p) (ind^"    ")
      )^"\n"^ind^"end"

and translate_process opt p ind =
  let l = get_next_oracles true p in
    "\n"^ind^"("^
      string_list_sep ("\n"^ind^",") (List.map (fun x -> x (ind^" ")) (List.map (get_oracle_body opt) l))^")"


let impl_init opt p = 
  "let token = ref false\n\n"^
  "let init () =\n"^
  "  if !token then raise Bad_call;\n"^
  "  token := true;\n"^
  (file_loading opt ("  "))^
  (translate_process opt p ("  "))
    
let get_interface opt p = 
  let o = List.map (fun (b,n,_,_) -> (b,n)) (get_next_oracles true p) in
  prefix^
  (get_oracles_types p)^"\n"^
    "val init : unit -> "^(get_oracles_type_string o)^"\n"

let get_implementation opt p =
  prefix^
  (get_oracles_types p)^"\n\n"^
    (impl_init opt p)

let get_letfun_interface letfuns =
  prefix^
  (string_list_sep "\n" (List.map (fun (f,bl,res) ->
    "val "^(get_fun_name f)^" : "^
    (if bl = [] then
      "unit"
    else
      (string_list_sep " -> " (List.map (fun b -> get_type_name b.btype) bl)))^
    " -> "^(get_type_name res.t_type)^"\n"
	      ) letfuns))

let get_letfun_implementation letfuns =
  prefix^
  (string_list_sep "\n" (List.map (fun (f,bl,res) ->
    f.f_impl_needs_full_state <- term_needs_state res;
    "let "^(get_fun_name f)^" "^
    (if bl = [] then
      "()"
    else
      (string_list_sep " " (List.map (fun b ->
	("("^(get_binder_name b)^" : "^(get_type_name b.btype)^")")
	  ) bl)))^
    " = "^(translate_term res "  ")^"\n"
	      ) letfuns))

let check_no_module_name_clash (impl_letfuns,impl_processes) =
  let basic_modules = ["Base"; "Crypto"] in
  let reserved_modules =
    if impl_letfuns <> [] then
      letfun_module :: basic_modules
    else
      basic_modules
  in
  let rec check_clash = function
    | [] -> ()
    | (x,_,_)::rest ->
	List.iter (fun m ->
	  if x = m then
	    error ("Module "^x^" clashes with reserved module");
	  if String.uppercase_ascii x = String.uppercase_ascii m then
	    error ("Module "^x^" clashes with reserved module "^m^" (filenames are case-insensitive on Windows)")
	      ) reserved_modules;
	List.iter (fun (x',_,_) ->
	  if String.uppercase_ascii x = String.uppercase_ascii x' then
	    error ("Module "^x^" clashes with module "^x'^" (filenames are case-insensitive on Windows)")
	      ) rest;
	check_clash rest
  in
  check_clash impl_processes
    
    
let do_implementation (impl_letfuns,impl_processes) =
  let impl_letfuns = 
    List.filter (fun (f, vardecl, res) -> f.f_impl = SepFun) impl_letfuns
  in
  let impl = 
    impl_check impl_processes
  in
  check_no_module_name_clash (impl_letfuns,impl);
  if impl_letfuns <> [] then
    begin
      print_string ("Generating implementation for letfuns...\n");
      letfun_prefix := "";
      let f=open_out (Filename.concat (!Settings.out_dir) (letfun_module^".ml")) in
      output_string f (get_letfun_implementation impl_letfuns);
      close_out f;
      let f'=open_out (Filename.concat (!Settings.out_dir) (letfun_module^".mli")) in
      output_string f' (get_letfun_interface impl_letfuns);
      close_out f';
      print_string ("Done.\n")
    end;
  letfun_prefix := letfun_module^".";
  List.iter (fun (x,opt,p)->
    print_string ("Generating implementation for module "^x^"...\n");
    let f=open_out (Filename.concat (!Settings.out_dir) (x^".ml")) in
    output_string f (get_implementation opt p);
    close_out f;
    let f'=open_out (Filename.concat (!Settings.out_dir) (x^".mli")) in
    output_string f' (get_interface opt p);
    close_out f';
    print_string ("Done.\n")
      ) impl

    
