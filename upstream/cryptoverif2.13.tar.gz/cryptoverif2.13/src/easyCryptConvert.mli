(*************************************************************
 *                                                           *
 *       Translation from CryptoVerif to EasyCrypt           *
 *                                                           *
 *       Bruno Blanchet, Pierre Boutry, Christian Doczkal,   *
 *       and Pierre-Yves Strub                               *
 *                                                           *
 *       Copyright INRIA, MPI-SP, Ecole Polytechnique,       *
 *	 2019-2026                                           *
 *                                                           *
 *************************************************************)

(*

    Copyright INRIA, MPI-SP, Ecole Polytechnique
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  Pierre Boutry, Pierre.Boutry@inria.fr
                  Christian Doczkal, Christian.Doczkal@mpi-sp.org
                  Pierre-Yves Strub, pierre-yves@strub.nu

This software is a computer program whose purpose is to translate
CryptoVerif security assumptions into EasyCrypt.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
(* [convert out eqv] converts the equiv [eqv] into EasyCrypt and *
   write the result to [out]. *)

val convert : Format.formatter -> Types.eqmember * Types.eqmember -> Types.setf list -> unit

(* [main s]
 * When the string [s] is <filename>:<equiv>, finds the equiv specified 
 * by <equiv> and converts it into EasyCrypt. The result is written to 
 * <filename>.
 * When the string [s] is <equiv>, the result is written to the standard output.
 * 
 * See [convert] for more information. *)

val main : string -> unit
