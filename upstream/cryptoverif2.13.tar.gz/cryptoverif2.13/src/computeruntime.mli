(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Types

(* [make_length_term accu_ref g t] modifies [accu_ref] so that it
   represents the maximum of [!accu_ref] and [Maxlength(g,t)] *)
val make_length_term : Polynom.minmax_accu ref -> game -> term -> unit

val compute_runtime_for_context : game -> equiv_nm ->
  (term -> term list * int * int * repl_index list * (binder list * term list) list) ->
  binder list -> polynom

val compute_runtime_for : game -> probaf

(* Two version of the function that computes the time to add when 
   we add a replication on top of an equiv statement
   [compute_add_time lhs rhs param opt2] computes
   an upper bound of 
     max(time(lhs),time(rhs)) * (param-1) when opt2 = Decisional
     time(lhs) when opt2 = Computational
   [compute_add_time_totcount] is similar, but uses #O counts
   to count the number of executions of oracles, which avoids
   having to multiply afterwards and gives better results when param >> 1.
   *)
val compute_add_time : fungroup -> fungroup -> param -> eqopt2 -> probaf
val compute_add_time_totcount : fungroup -> fungroup -> param -> eqopt2 -> probaf
    
val compute_runtime_for_term : game -> term -> probaf

(* [get_oracle_decl b] returns the oracle declaration in which [b] is defined.
   Raises [Not_found] in case of failure.
   [Def.build_def_process] must have been called on the current game
   for it to succeed. *)
val get_oracle_decl : binder -> oracle_decl

(* [get_ri_mul ri_list tl] returns an optimized version of the
   product of the bounds of [ri_list], assuming that the terms in
   [tl] are defined. *)
val get_ri_mul : repl_index list -> term list -> ri_mul_t 
