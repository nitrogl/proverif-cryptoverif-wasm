(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Types

let main revise_diff_encoding g =
  match revise_diff_encoding with
  | None -> g
  | Some b0 ->
      let rec full_transfo_t t =
	match t.t_desc with
	| TestE({t_desc = Var(b,[])} as t1,t2,t3) when (b == b0) &&
	  (Array_ref.no_effect g t2) && (Array_ref.no_effect g t3) ->
	    let if_fun = Settings.get_if_fun t.t_type in
	    Terms.build_term t (FunApp(if_fun, [t1;t2;t3]))
	| _ -> Terms.build_term t (Terms.map_subterm full_transfo_t (fun def_list -> def_list) full_transfo_pat t)

      and full_transfo_pat pat =
	Terms.map_subpat full_transfo_t full_transfo_pat pat
      in
      
      let rec full_transfo_i p =
	Terms.iproc_from_desc_loc p
	  (Terms.map_subiproc full_transfo_i (fun o patl p1 ->
	    (o,List.map full_transfo_pat patl,
	     full_transfo_p p1)) p) 
	
      and full_transfo_p p =
	Terms.oproc_from_desc_loc p
	  (Terms.map_suboproc full_transfo_p full_transfo_t
	     (fun def_list -> def_list) full_transfo_pat
	     full_transfo_i p)
	  
      in
      let p = full_transfo_i (Terms.get_process g) in
      let p = Terms.move_occ_process p in
      let g' = { g with proc = RealProcess p } in
      g'.current_queries <-
	 List.map (fun ((q,g), qinit_opt, proof) -> ((q,g'), qinit_opt, proof))
	   g'.current_queries;
      g'
