(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Types

(* [check_qterm known_facts t] tries to prove the term [t]
   using the known facts [known_facts].
   Returns true when it succeeds and false otherwise.

   [known_facts] is a sixtuple [(g, event_accu, simp_facts, pps, def_vars, repl_indices)]
   where
   - [g] is the current game
   - [event_accu] stores a correspondence between events and program points in the game
   - [simp_facts] is the set of facts that are known to hold, in simplified form, that is,
   [(substitutions, facts, elsefind facts)]
   - [pps] is a list of programs points known to be executed
   - [def_vars] is a list of variables known to be defined
   - [repl_indices] is the list of all occurring replication indices. *)
val check_qterm :
  game * (term * program_point) list * simp_facts *
  program_points_args list * binderref list * repl_index list (* [known_facts] *)
  -> qterm -> bool

(* [check_corresp event_accu corresp g] returns true when the
   correspondence [corresp] is proved (up to negligible probability).
   It is called from success.ml. [g] is the full game. In addition to the
   boolean result, when it is true, it also returns the probability of
   collisions eliminated to reach that result. *)
val check_corresp : 
    known_when_adv_wins ref option -> (term * program_point) list -> 
    (bool * term) list * qterm * binder list -> game -> bool * probaf

(* [remove_inj event_accu g q] returns
   - [Some(q',proba)] when [q] is an injective correspondence and 
   it managed to prove injectivity; [q'] is the non-injective
   query still proba and [proba] is the probability of breaking injectivity.
   - [None] otherwise. *)
val remove_inj : (term * program_point) list -> game -> query ->
  (query * setf list) option

(* [well_formed q] checks that [q] is well-formed, that is,
   for correspondence queries psi => phi, psi = psi{x'/x} => phi = phi{x'/x}
   where x represents the tuple of variables of psi, and x' is a tuple of fresh
   variables. 
   It displays a warning message when the proof of well-formedness fails. *)
val well_formed : query -> unit
