(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Types

val underscore_var_name : string
  
type frontend =
    Channels
  | Oracles

type impl_language =
  | OCaml
  | FStar
  | Prove (* Prove the protocol, do not generate an implementation *)
      
val get_implementation : impl_language ref
val easy_crypt_convert : string option ref
val easy_crypt_remove_tables : bool ref
val out_dir : string ref
val proof_output : string ref
val equiv_output : string ref
val command_output : string ref
    
val front_end : frontend ref

val lib_name : string list ref

val events_to_ignore_lhs : funsymb list ref
    
(* memory saving *)
val forget_old_games : bool ref
                      
(* debug settings *)
val debug_ghost : bool ref
val debug_instruct : bool ref
val debug_cryptotransf : int ref
val debug_find_unique : bool ref
val debug_elsefind_facts : bool ref
val debug_simplify : bool ref
val debug_simplif_add_facts : bool ref
val debug_corresp : bool ref
val debug_restriction : bool ref
val debug_event_adv_loses : bool ref

(* translation to F* *)
val fstar_debug : bool ref
val fstar_concurrent : bool ref
val fstar_minimal_functions : bool ref
    
(* To parse games output by CryptoVerif, 
set this variable to true: such games may contain
"defined" conditions on variables that are never defined. *)
val allow_undefined_var : bool ref

val proba_zero : bool ref

val use_oracle_count_in_result : bool ref

val max_efl : int ref
val max_depth_add_fact : int ref
val max_depth_is_indep_collect_args : int ref
val max_depth_try_no_var_rec : int ref
val max_replace_depth : int ref
val max_fut_pps_length : int ref
val elsefind_facts_in_replace : bool ref
val elsefind_facts_in_success : bool ref
val elsefind_facts_in_simplify : bool ref
val elsefind_facts_in_success_simplify : bool ref
val improved_fact_collection : bool ref
val corresp_cases : bool ref
val simplify_use_equalities_in_simplifying_facts : bool ref
val re_reduce_root_sides : bool ref
    
val diff_constants : bool ref
val constants_not_tuple : bool ref 

type diff_encoding =
  | FunWhenPossible
  | FunWhenSimple
  | AlwaysIf

val diff_encoding : diff_encoding ref

type success_simplify_pref_t =
  | SSPRemoveBranch
  | SSPEventAbort

val success_simplify_pref : success_simplify_pref_t ref
    
val use_known_equalities_crypto : bool ref
val priority_event_unchanged_rand : int ref

val normalize_in_match_funapp : bool ref
                                        
val expand_letxy : bool ref

val trust_size_estimates : bool ref
    
val max_advice_possibilities_beginning : int ref
val max_advice_possibilities_end : int ref

val minimal_simplifications : bool ref
val merge_branches : bool ref
val merge_arrays : bool ref
val unique_branch : bool ref
val unique_branch_reorg : bool ref
val infer_unique : bool ref

val guess_remove_unique : bool ref
    
val auto_sa_rename : bool ref
val auto_remove_assign_find_cond : bool ref
val auto_remove_if_find_cond : bool ref
val auto_move : bool ref
val auto_expand : bool ref
    
val ignore_small_times : int ref
val interactive_mode : bool ref
val auto_advice : bool ref
val no_advice_crypto : bool ref
val no_advice_globaldepanal : bool ref

val backtrack_on_crypto : bool ref
val simplify_after_sarename : bool ref


val max_iter_simplif : int ref
val max_iter_removeuselessassign : int ref

val detect_incompatible_defined_cond : bool ref

val do_set : string -> Ptree.pval -> unit

(* Parameter sizes *)
val psize_NONINTERACTIVE : int
val psize_PASSIVE : int
val psize_DEFAULT : int
val psize_SMALL : int

(* Type sizes *)
val tysize_LARGE : int

val min_exp : int
val max_exp : int
    
val tysize_MIN_Auto_Coll_Elim : int ref
val tysize_MIN_Coll_Elim : int ref
(* Determines the probabilities that are considered small enough to 
   eliminate collisions. It consists of a list of probability descriptions
   of the form ([(psize1, n1); ...; (psizek,nk)], tsize) 
   which represent probabilities of the form
   constant * (parameter of size <= psize1)^n1 * ... * 
   (parameter of size <= psizek)^nk / (type of size >= tsize) *) 
val allowed_collisions : ((int * int) list * int) list ref

val tysize_MAX_Guess : int ref
    
val parse_type_size_pcoll : string * Parsing_helper.extent -> (int * int) option * (int * int) option
val parse_pest : string * Parsing_helper.extent -> int
val parse_psize : string * Parsing_helper.extent -> int

(* Type options *)

(* Types consisting of all bitstrings of the same length *)
val tyopt_FIXED : int

(* Finite types *)
val tyopt_BOUNDED : int

(* Types for which the standard distribution for generating
   random numbers is non-uniform *)
val tyopt_NONUNIFORM : int

(* Types for which we can generate random numbers.
   Corresponds to one of the three options above *)
val tyopt_CHOOSABLE : int

(* Types that get erased when generating an implementation *)
val tyopt_GHOST : int
    
(* Function options *)

val fopt_COMPOS : int
val fopt_DECOMPOS : int
val fopt_UNIFORM : int
val fopt_AUTO_SWAP_IF : int
val fopt_BIJECTIVE : int

val tex_output : string ref

val t_bitstring : typet
val t_bitstringbot : typet
val t_bool : typet

(*For precise computation of the runtime only*)
val t_unit : typet
(* For events in terms; they have a type compatible with any type*)
val t_any : typet
val t_empty_idx : typet

val create_fun :  string -> typet list * typet -> 
  ?options:int -> ?eqth:eq_th -> ?impl:impl_name -> ?impl_inv: string option -> funcats -> funsymb
    
val c_true : funsymb
val c_false : funsymb

val f_comp : funcats -> typet -> typet -> funsymb
val f_or : funsymb
val f_and : funsymb
val sym_not : string
val f_not : funsymb

val get_tuple_fun : typet list -> funsymb
val empty_tuple : funsymb

val get_if_fun : typet -> funsymb
    
(*For precise computation of the runtime only*)
val t_interv : typet
val f_plus : funsymb
val f_mul : funsymb

(* get projections for bijective functions *)
val get_proj : funsymb -> funsymb list

(* Assumptions given in the input file *)
val equivs : equiv_gen list ref
val initial_statements : collision list ref (* statements before generalization with aliases *)
val statements : collision list ref
val collisions : collision list ref
    
val get_query_status : ((query * game) * query option * proof_t ref) -> proof_t
val get_public_vars0 : ?reach_1s: bool -> query list -> binder list
val get_public_vars : cur_queries_t -> binder list
val occurs_in_queries : binder -> cur_queries_t -> bool

val event_occurs_in_query : funsymb -> query -> bool
(* [event_occurs_in_queries f queries restrictions] returns true when the events [f]
   must be preserved in game transformations, that is, when [f] occurs
   in active queries or a restriction. All events are preserved when we prove 
   indistinguishability. *)
val event_occurs_in_queries_or_restrictions : funsymb -> cur_queries_t -> restriction list -> bool

(* Set when a game is modified *)
val changed : bool ref

(* Instructions are added in advise when an instruction I cannot be fully
   performed. The added instructions correspond to suggestions of instructions
   to apply before I so that instruction I can be better performed. *)
val advise : instruct list ref

