(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Types

(* Build the "incompatible" field for each program point [pp]. It
   contains the mapping of occurrences of program points [pp']
   incompatible with [pp] to the length [l] such that if [pp] with
   indices [arg] and [pp'] with indices [args'] are both executed,
   then the suffixes of length [l] of [args] and [args'] must be
   different.
   Supports LetE/FindE/ResE/TestE everywhere *)

(* Empty the "incompatible" field of all program points. *)

let rec empty_comp_pattern pat =
  Terms.iter_subpat empty_comp_term empty_comp_pattern pat

and empty_comp_term t =
  t.t_incompatible <- Occ_map.empty;
  Terms.iter_subterm empty_comp_term empty_comp_def_list empty_comp_pattern t

and empty_comp_def_list def_list =
  List.iter (fun (_,l) -> List.iter empty_comp_term l) def_list
    
let rec empty_comp_process p = 
  p.i_incompatible <- Occ_map.empty;
  Terms.iter_subiproc empty_comp_process (fun o patl p -> 
    List.iter empty_comp_pattern patl;
    empty_comp_oprocess p) p

and empty_comp_oprocess p =
  p.p_incompatible <- Occ_map.empty;
  Terms.iter_suboproc empty_comp_oprocess empty_comp_term empty_comp_def_list
    empty_comp_pattern empty_comp_process p

(* [map_max f l], where [f] is a function from list elements to integers,
   returns the maximum of [f a] for elements [a] in [l] *)

let rec map_max f = function
    [] -> 0
  | a::l -> max (f a) (map_max f l)

(* [max_dep_term cur_array t] returns the length of the suffix of [cur_array] on which [t] depends *)

let rec find_pos i cur_array =
  match cur_array with
  | [] -> assert false (* i should always belong to cur_array *)
  | i' :: r -> 
     if i == i' then List.length cur_array else find_pos i r

let rec max_dep_term cur_array t =
  match t.t_desc with
  | Var(_,l) | FunApp(_,l) ->
      map_max (max_dep_term cur_array) l
  | ReplIndex i -> 
      find_pos i cur_array
  | TestE(t1,t2,t3) -> 
      max (max_dep_term cur_array t1) (max (max_dep_term cur_array t2) (max_dep_term cur_array t3))
  | FindE(l0, t3, _) ->
      List.length cur_array (* The "defined" conditions of find can give 
        different results when the find is re-executed
        => the result may depend on all indices *)
  | LetE(pat, t1, t2, topt) ->
      max (max (max_dep_pat cur_array pat) (max_dep_term cur_array t1)) 
          (max (max_dep_term cur_array t2) 
               (match topt with
	        | None -> 0
	        | Some t3 -> max_dep_term cur_array t3))
  | ResE(b,t2) -> max_dep_term cur_array t2
  | EventAbortE _ -> 0
  | EventE(t,p) -> max (max_dep_term cur_array t) (max_dep_term cur_array p)
  | GetE _ | InsertE _ -> 
      Parsing_helper.internal_error "Get/Insert should have been reduced at this point"

and max_dep_pat cur_array pat = 
  match pat with
  | PatVar _ -> 0
  | PatTuple(_,l) -> map_max (max_dep_pat cur_array) l
  | PatEqual t -> max_dep_term cur_array t

(* Compute the "incompatible" field for all program points *)

let rec compatible_def_term cur_array cur_array_length current_incompatible t = 
  t.t_incompatible <- current_incompatible;
  match t.t_desc with
    Var(_,l) | FunApp(_,l) -> 
      List.iter (compatible_def_term cur_array cur_array_length current_incompatible) l
  | ReplIndex i -> 
      ()
  | TestE(t1,t2,t3) -> 
      compatible_def_term cur_array cur_array_length current_incompatible t1;
      compatible_def_term cur_array cur_array_length current_incompatible t2;
      let cond_max_dep = max_dep_term cur_array t1 in
      let t3_incompatible = Occ_map.add current_incompatible t2.t_occ t2.t_max_occ cond_max_dep in
      compatible_def_term cur_array cur_array_length t3_incompatible t3 
  | FindE(l0, t3, _) ->
      let accu_incompatible = ref current_incompatible in
      List.iter (fun (bl, def_list, t1, t2) ->
        let cur_array_cond = (List.map snd bl) @ cur_array in
	let cur_array_length_cond = cur_array_length + List.length bl in
	List.iter (fun (_,l) -> 
	  List.iter (compatible_def_term cur_array_cond cur_array_length_cond current_incompatible) l) def_list;
	compatible_def_term cur_array_cond cur_array_length_cond current_incompatible t1;
	compatible_def_term cur_array cur_array_length (!accu_incompatible) t2;
	accu_incompatible := (Occ_map.add (!accu_incompatible) t2.t_occ t2.t_max_occ cur_array_length)
	     ) l0;
      compatible_def_term cur_array cur_array_length (!accu_incompatible) t3
  | LetE(pat, t1, t2, topt) ->
      compatible_def_term cur_array cur_array_length current_incompatible t1;
      compatible_def_pat cur_array cur_array_length current_incompatible pat;
      compatible_def_term cur_array cur_array_length current_incompatible t2;
      begin
	match topt with
	  None -> ()
	| Some t3 -> 
            let cond_max_dep = max (max_dep_term cur_array t1) (max_dep_pat cur_array pat) in
	    let t3_incompatible = Occ_map.add current_incompatible t2.t_occ t2.t_max_occ cond_max_dep in
	    compatible_def_term cur_array cur_array_length t3_incompatible t3 
      end
  | ResE(b,t2) ->
      compatible_def_term cur_array cur_array_length current_incompatible t2
  | EventAbortE _ ->
      ()
  | EventE(t,p) ->
      compatible_def_term cur_array cur_array_length current_incompatible t;
      compatible_def_term cur_array cur_array_length current_incompatible p
  | GetE _ | InsertE _ -> 
      Parsing_helper.internal_error "Get/Insert should have been reduced at this point"

and compatible_def_pat cur_array cur_array_length current_incompatible = function
    PatVar b -> ()
  | PatTuple (f,l) -> List.iter (compatible_def_pat cur_array cur_array_length current_incompatible) l
  | PatEqual t -> compatible_def_term cur_array cur_array_length current_incompatible t

let rec compatible_def_process cur_array cur_array_length current_incompatible p =
  p.i_incompatible <- current_incompatible;
  match p.i_desc with
    Nil -> ()
  | Par(p1,p2) ->
      compatible_def_process cur_array cur_array_length current_incompatible p1;
      compatible_def_process cur_array cur_array_length current_incompatible p2
  | Repl(b,p) ->
      compatible_def_process (b::cur_array) (cur_array_length+1) current_incompatible p
  | OracleDecl(o,patl,p2) ->
      List.iter (compatible_def_pat cur_array cur_array_length current_incompatible) patl;
      compatible_def_oprocess cur_array cur_array_length current_incompatible p2 

and compatible_def_oprocess cur_array cur_array_length current_incompatible p =
  p.p_incompatible <- current_incompatible;
  match p.p_desc with
    Yield | EventAbort _ -> ()
  | Restr(b, p2) ->
      compatible_def_oprocess cur_array cur_array_length current_incompatible p2 
  | Test(t,p1,p2) ->
      compatible_def_term cur_array cur_array_length current_incompatible t;
      compatible_def_oprocess cur_array cur_array_length current_incompatible p1;
      let cond_max_dep = max_dep_term cur_array t in
      let p2_incompatible = Occ_map.add current_incompatible p1.p_occ p1.p_max_occ cond_max_dep in
      compatible_def_oprocess cur_array cur_array_length p2_incompatible p2 
  | Find(l0, p2, _) ->
      let accu_incompatible = ref current_incompatible in
      List.iter (fun (bl, def_list, t, p1) ->
        let cur_array_cond = (List.map snd bl) @ cur_array in
	let cur_array_length_cond = cur_array_length + List.length bl in
	List.iter (fun (_,l) -> 
	  List.iter (compatible_def_term cur_array_cond cur_array_length_cond current_incompatible) l) def_list;
	compatible_def_term cur_array_cond cur_array_length_cond current_incompatible t;
	compatible_def_oprocess cur_array cur_array_length (!accu_incompatible) p1;
	accu_incompatible := (Occ_map.add (!accu_incompatible) p1.p_occ p1.p_max_occ cur_array_length)
	     ) l0;
      compatible_def_oprocess cur_array cur_array_length (!accu_incompatible) p2
  | Return(tl,p) ->
      List.iter (compatible_def_term cur_array cur_array_length current_incompatible) tl;
      compatible_def_process cur_array cur_array_length current_incompatible p
  | Let(pat,t,p1,p2) ->
      compatible_def_term cur_array cur_array_length current_incompatible t;
      compatible_def_pat cur_array cur_array_length current_incompatible pat;
      compatible_def_oprocess cur_array cur_array_length current_incompatible p1;
      let cond_max_dep = max (max_dep_term cur_array t) (max_dep_pat cur_array pat) in
      let p2_incompatible = Occ_map.add current_incompatible p1.p_occ p1.p_max_occ cond_max_dep in
      compatible_def_oprocess cur_array cur_array_length p2_incompatible p2 
  | EventP(t,p) ->
      compatible_def_term cur_array cur_array_length current_incompatible t;
      compatible_def_oprocess cur_array cur_array_length current_incompatible p
  | Get _ | Insert _ | NewTable _ -> 
      Parsing_helper.internal_error "Get/Insert should have been reduced at this point"


let build_compatible_defs p = 
  compatible_def_process [] 0 Occ_map.empty p

(* [get_facts pp] returns the fact_info at program point [pp] *)

let get_facts pp =
  match pp with
    DProcess p -> p.p_facts
  | DInputProcess p -> p.i_facts
  | DTerm t ->  t.t_facts
  | _ -> None

(* [get_start_block_node n] returns the program point corresponding
   to the input that starts the input...output block of code that
   contains node [n]. *)

let rec get_start_block_pp pp =
  match pp with
  | DInputProcess({ i_desc = OracleDecl _}) as pp -> pp
  | _ -> 
      match get_facts pp with
      | None -> assert false
      | Some ppi ->
	  get_start_block_pp ppi.ppi_above_pp

let get_start_block_node n =
  (* Note: cannot be properly computed using [n.above_node], because
     it would not work for node in terms inside the patterns of inputs *)
  get_start_block_pp n.definition 
    
(* [incomp_from_pp pp] returns a triple containing
   - the occurrence of program point [pp]
   - the maximum occurrence of program points under [pp] in the syntax tree.
   (the occurrences of program points under [pp] are then
   in the interval [occurrence of [pp], max. occ. under [pp]])
   - the mapping of occurrences of program points [pp'] incompatible with [pp]
   to the length [l] such that if [pp] with indices [arg]
   and [pp'] with indices [args'] are both executed, then
   the suffixes of length [l] of [args] and [args'] must be different.
   Raises [Not_found] when [pp] does not uniquely identify a program point. *) 

let incomp_from_pp = function
    DProcess(p) -> p.p_occ, p.p_max_occ, p.p_incompatible
  | DTerm(t) -> t.t_occ, t.t_max_occ, t.t_incompatible
  | DInputProcess(p) -> p.i_occ, p.i_max_occ, p.i_incompatible
  | _ -> raise Not_found

(* [incompatible_suffix_length_pp pp pp'] returns a length [l] such
   that if [pp] with indices [args] and [pp'] with indices [args'] are
   both executed, then the suffixes of length [l] of [args] and
   [args'] must be different.
   Raises [Not_found] when [pp] with indices [args] and [pp'] with
   indices [args'] can be executed for any [args,args'].*)

let incompatible_suffix_length_pp pp pp' =
  let occ, _, occ_map = incomp_from_pp pp in
  let occ', _, occ_map' = incomp_from_pp pp' in
  try 
    Occ_map.find occ occ_map' 
  with Not_found ->
    Occ_map.find occ' occ_map 

(* [is_compatible_pp pp pp'] is true when [pp] and [pp'] can both be executed
   even with the same indices *)

let is_compatible_pp pp pp' = 
  try 
    ignore (incompatible_suffix_length_pp pp pp');
    false
  with Not_found -> 
    true

(* [both_pp (pp, args) (pp', args')] returns true when
   program point [pp] with indices [args] and 
   program point [pp'] with indices [args'] can both be executed. *)

let both_pp (pp, args) (pp', args') =
  try
    let suffix_l = incompatible_suffix_length_pp pp pp' in
    let args_skip = Terms.lsuffix suffix_l args in
    let args_skip' = Terms.lsuffix suffix_l args' in
    not (List.for_all2 Terms.equal_terms args_skip args_skip')
  with Not_found -> 
    true
     
(* [both_pp_add_fact fact_accu (pp, args) (pp', args')] 
   adds to [fact_accu] a fact inferred from the execution of both
   program point [pp] with indices [args] and 
   program point [pp'] with indices [args'], if any.*)
	
let both_pp_add_fact fact_accu (pp, args) (pp', args') =
  try
    let suffix_l = incompatible_suffix_length_pp pp pp' in
    let args_skip = Terms.lsuffix suffix_l args in
    let args_skip' = Terms.lsuffix suffix_l args' in
    (Terms.make_or_list (List.map2 Terms.make_diff args_skip args_skip')) :: fact_accu
  with Not_found ->
    fact_accu

(* [incompatible_suffix_length_pp_ppl pp ppl] returns a length [l] such
   that if [pp] with indices [args] is executed and
   a program point in [ppl] with indices [args'] is executed,
   then the suffixes of length [l] of [args] and
   [args'] must be different.
   Raises [Not_found] when [pp] with indices [args]  
   and a program point in [ppl] with indices [args'] can be executed
   for any [args,args'].*)

let incompatible_suffix_length_pp_ppl pp ppl =
  let pp_occ, _, pp_occ_map = incomp_from_pp pp in
  map_max (fun pp' ->
    let (occ', _, occ_map') = incomp_from_pp pp' in
    try 
      Occ_map.find pp_occ occ_map' 
    with Not_found ->
      Occ_map.find occ' pp_occ_map 
	) ppl

(* [both_pp_ppl (pp, args) (ppl', args')] returns true when
   program point [pp] with indices [args] and 
   a program point in [ppl'] with indices [args'] can both be executed. *)

let both_pp_ppl (pp, args) (ppl', args') =
  try
    let suffix_l = incompatible_suffix_length_pp_ppl pp ppl' in
    let args_skip = Terms.lsuffix suffix_l args in
    let args_skip' = Terms.lsuffix suffix_l args' in
    not (List.for_all2 Terms.equal_terms args_skip args_skip')
  with Not_found -> 
    true
     
(* [both_pp_ppl_add_fact fact_accu (pp, args) (ppl', args')] 
   adds to [fact_accu] a fact inferred from the execution of both
   program point [pp] with indices [args] and 
   a program point in [ppl'] with indices [args'], if any.*)
	
let both_pp_ppl_add_fact fact_accu (pp, args) (ppl', args') =
  try
    let suffix_l = incompatible_suffix_length_pp_ppl pp ppl' in
    let args_skip = Terms.lsuffix suffix_l args in
    let args_skip' = Terms.lsuffix suffix_l args' in
    (Terms.make_or_list (List.map2 Terms.make_diff args_skip args_skip')) :: fact_accu
  with Not_found ->
    fact_accu

(* [incompatible_suffix_length_ppl_ppl ppl ppl'] returns a length [l]
   such that if a program point in [ppl] with indices [args] and a
   program point in [ppl'] with indices [args'] are executed, then the
   suffixes of length [l] of [args] and [args'] must be different.
   Raises [Not_found] when a program point in [ppl] with indices
   [args] and a program point in [ppl'] with indices [args'] can be
   executed for any [args,args']. *)

let incompatible_suffix_length_ppl_ppl ppl ppl' = 
  map_max (fun pp -> incompatible_suffix_length_pp_ppl pp ppl') ppl

(* [both_ppl_ppl_add_fact fact_accu (ppl, args) (ppl', args')] 
   adds to [fact_accu] a fact inferred from the execution of both
   a program point in [ppl] with indices [args] and 
   a program point in [ppl'] with indices [args'], if any.*)
	
let both_ppl_ppl_add_fact fact_accu (ppl, args) (ppl', args') =
  try
    let suffix_l = incompatible_suffix_length_ppl_ppl ppl ppl' in
    let args_skip = Terms.lsuffix suffix_l args in
    let args_skip' = Terms.lsuffix suffix_l args' in
    (Terms.make_or_list (List.map2 Terms.make_diff args_skip args_skip')) :: fact_accu
  with Not_found ->
    fact_accu

let both_ppl_ppl_add_facts fact_accu ppl1 ppl2 = 
  List.fold_left (fun accu pp2 ->
    List.fold_left (fun accu pp1 ->
      both_ppl_ppl_add_fact accu pp1 pp2
	) accu ppl1
      ) fact_accu ppl2
      
(* [incompatible_suffix_length_pp_var pp b'] returns a length [l] such
   that if [pp] with indices [args] is executed and [b'[args]] 
   is defined, then the suffixes of length [l] of [args] and
   [args'] must be different.
   Raises [Not_found] when [pp] with indices [args] can be executed 
   and [b'[args']] can be defined for [args = args'].*)

let incompatible_suffix_length_pp_var pp b' =
  let pp_occ, _, pp_occ_map = incomp_from_pp pp in
  map_max (fun n' ->
    let (occ', _, occ_map') = incomp_from_pp n'.definition_success in
    try 
      Occ_map.find pp_occ occ_map' 
    with Not_found ->
      Occ_map.find occ' pp_occ_map 
	) b'.def

(* [incompatible_suffix_length_var_var b b'] returns a length [l] such that if
   [b[args]] and [b'[args']] are both defined, then the suffixes of
   length [l] of [args] and [args'] must be different.
   Raises [Not_found] when [b[args]] and [b'[args']] can both be defined 
   for [args = args']. *)

let incompatible_suffix_length_var_var b b' =
  map_max (fun n -> incompatible_suffix_length_pp_var n.definition_success b') b.def

(* [is_compatible (b,args) (b',args')] returns true when
   [b[args]] and [b'[args']] may both be defined *)

let is_compatible (b,args) (b',args') =
  (b == b') || 
  (try
    let suffix_l = incompatible_suffix_length_var_var b b' in
    let args_skip = Terms.lsuffix suffix_l args in
    let args_skip' = Terms.lsuffix suffix_l args' in
    (not (List.for_all2 Terms.equal_terms args_skip args_skip'))
  with Not_found -> true)

(* [both_def_add_fact fact_accu (b,args) (b',args')]
   adds to [fact_accu] a fact that always holds when
   [b[args]] and [b'[args']] are both defined, if any. *)

let both_def_add_fact fact_accu (b,args) (b',args') =
  if b != b' then 
    try
      let suffix_l = incompatible_suffix_length_var_var b b' in
      let args_skip = Terms.lsuffix suffix_l args in
      let args_skip' = Terms.lsuffix suffix_l args' in
      (Terms.make_or_list (List.map2 Terms.make_diff args_skip args_skip')) :: fact_accu
    with Not_found -> 
      fact_accu
  else
    fact_accu

(* [both_ppl_facts old_ppl ppl] returns facts
   inferred from the knowledge that the program points in [ppl] and
   [old_ppl] are both executed. It considers pairs 
   of variables in [ppl] and of one variable in [ppl]
   and one in [old_ppl], but does not consider pairs of variables
   in [old_ppl] as those should have been taken into account before.
   Uses the field "incompatible" set by Terms.build_compatible_defs
 *)

let rec accu_pair f accu = function
    [] -> accu
  | (a::l) -> 
      let accu = List.fold_left (fun accu' a' -> f accu' a a') accu l in
      accu_pair f accu l

let both_ppl_facts fact_accu old_ppl ppl =
  (* Remove the already executed program points from the list of new program points *)
  let new_ppl = List.filter (fun pp -> not (List.exists (Terms.equal_pps_args pp) old_ppl)) ppl in
  (* Check that the new program points are compatible with each other *)
  let fact_accu = accu_pair both_ppl_ppl_add_fact fact_accu new_ppl in
  (* ... and with all the previously defined variables *)
  both_ppl_ppl_add_facts fact_accu old_ppl new_ppl

(* [may_be_before_same_block_pp pp pp'] is true when the program point [pp]
   may be before [pp'] and in the same input...output block.
   Note that the time at which a program point is executed corresponds
   to the *beginning* of the execution of that program point. *)
	
let rec is_in_find_cond current_answer pp =
  match pp with
  | DTerm t ->
      begin
	match get_facts pp with
	| None -> assert false
	| Some ppi ->
	    match ppi.ppi_above_pp with
	    | (DTerm { t_desc = FindE(l0,_,_) }) as pp_above
		when List.exists (fun (bl,_,t',_) -> bl != [] && t == t') l0 ->
		  (* [pp] is in a condition of find with indices, but try to
		     see if it is in a condition of a bigger find *)
		  is_in_find_cond (Some t) pp_above
	    | DProcess { p_desc = Find(l0,_,_) }
		when List.exists (fun (bl,_,t',_) -> bl != [] && t == t') l0 ->
		  Some t
	    | pp_above -> is_in_find_cond current_answer pp_above
      end
  | _ -> current_answer

let same_find_cond pp occ_pp' = 
  match is_in_find_cond None pp with
  | None -> false
  | Some find_cond ->
      let r = find_cond.t_occ <= occ_pp' && occ_pp' <= find_cond.t_max_occ in
      (*if r then 
	print_string ("BOTH IN FIND COND "^(string_of_int occ_pp)^ " " ^(string_of_int occ_pp' ^ "\n"));*)
      r
	
let may_be_before_same_block_pp pp pp' =
  let occ_pp = Terms.occ_from_pp pp in
  let occ_pp' =  Terms.occ_from_pp pp' in
  (* [n] and [n'] are in the same oracle..return block *)
  let st_n = get_start_block_pp pp in
  let st_n' = get_start_block_pp pp' in
  Terms.equal_pp st_n st_n' &&
  ((* [n] may be executed before [n']: [n] is compatible with [n']
      and [occ of n <= occ of n'] because occurrences of program points
      at which definitions succeed are increasing in the execution order *)
   ((is_compatible_pp pp pp') && (occ_pp <= occ_pp')) ||
   (* or [n] and [n'] are in the same condition of find with indices.
      In this case, they can be executed in any order by repeating the 
      evaluation of the condition of find. *)
    (same_find_cond pp occ_pp'))
	
(* [may_be_before_same_block n n'] is true when the variable defined
   at [n] may be defined before the one defined at [n'] and within the
   same input...output block. *)

let may_be_before_same_block n n' =
  may_be_before_same_block_pp n.definition_success n'.definition_success

(* [not_after_suffix_length_pp strict pp pp'] returns
   the shortest length [l] such that the program point [pp] cannot be
   executed with indices [args] after the program point [pp']
   with indices [args'] when [args] and [args'] have a common suffix of
   length [l].  
   When [strict] is true and [pp' = pp], we consider that
   [pp'] is not after [pp] (it is not strictly after [pp]).
   When [strict] is false and [pp' = pp], we consider that
   [pp'] is after [pp].
   Raises [Not_found] when [pp] with indices [args] can be executed
   after the program point [pp'[args']] for any [args,args']. *)

let not_after_suffix_length_pp strict pp pp' =
  let pp_occ, pp_max_occ, pp_occ_map = incomp_from_pp pp in
  let (occ', _, occ_map') = incomp_from_pp pp' in
  try 
    Occ_map.find pp_occ occ_map' 
  with Not_found ->
    try
      Occ_map.find occ' pp_occ_map
    with Not_found ->
      let pp_start = get_start_block_pp pp in
      let pp_start_occ, pp_start_max_occ, _ = incomp_from_pp pp_start in
      if (* pp' is under pp_start and ... *)
	pp_start_occ <= occ' && occ' <= pp_start_max_occ &&
	(* either pp' is in a different oracle..return block than pp.
	   Then the oracle..return block of pp' is created after
	   the end of the block of pp when the indices at pp_start
	   are a prefix of the indices at pp',
	   so pp cannot be executed after pp' with the same prefix
	   of indices of length the indices at pp_start *)
	((not (Terms.equal_pp pp_start (get_start_block_pp pp'))) ||
         (* Now, we know that pp' is in the same oracle..return block
            as pp, so the program points with the same indices at pp_start are 
            executed in the order of occurrences, except when they are both 
            in the same condition of find with indices *)
	((if strict then pp_occ <= occ' else pp_occ < occ') && 
	 not (same_find_cond pp occ'))) then
	match get_facts pp_start with
	| None -> raise Not_found
	| Some ppi -> List.length ppi.ppi_cur_array
	              (* since pp' is under pp_start, pp' has more indices than pp_start *)
      else
	raise Not_found

(* [not_after_suffix_length_diff_block_pp] is the same as
   [not_after_suffix_length_pp] except that we already know that
   [pp] and [pp'] are not in the same execution of the same oracle block,
   so we can be more precise *)
	  
let not_after_suffix_length_diff_block_pp pp pp' =
  let pp = get_start_block_pp pp in
  let pp_occ, pp_max_occ, pp_occ_map = incomp_from_pp pp in
  let (occ', _, occ_map') = incomp_from_pp pp' in
  try 
    Occ_map.find pp_occ occ_map' 
  with Not_found ->
    try
      Occ_map.find occ' pp_occ_map
    with Not_found ->
      if pp_occ <= occ' && occ' <= pp_max_occ then
	match get_facts pp with
	| None -> raise Not_found
	| Some ppi -> List.length ppi.ppi_cur_array
	              (* since pp' is under pp, pp' has more indices than pp *)
      else
	raise Not_found

(* [not_after_suffix_length_pp_var strict pp b'] returns
   the shortest length [l] such that the program point [pp] cannot be
   executed with indices [args] after the definition of variable [b']
   with indices [args'] when [args] and [args'] have a common suffix of
   length [l].
   When [strict] is true and [b'] is defined at [pp], we consider that
   [b'] is not defined after [pp] (it is not defined strictly after [pp]).
   When [strict] is false and [b'] is defined at [pp], we consider that
   [b'] is defined after [pp] (it is not defined strictly after or at [pp]).
   Raises [Not_found] when [pp] with indices [args] can be executed
   after the definition of [b'[args']] for any [args,args']. *)

let not_after_suffix_length_pp_var strict pp b' =
  map_max (fun n' ->
    not_after_suffix_length_pp strict pp n'.definition_success
	) b'.def

(* [not_after_suffix_length_pp_ppl pp ppl] returns
   the shortest length [l] such that the program point [pp] cannot be
   executed with indices [args] after a program point in [ppl]
   with indices [args'] when [args] and [args'] have a common suffix of
   length [l].  
   Raises [Not_found] when [pp] with indices [args] can be executed
   after a program point in [ppl] with indices [args']] for any [args,args']. *)

let not_after_suffix_length_pp_ppl pp ppl =
  map_max (not_after_suffix_length_pp true pp) ppl

(* [incompatible_current_suffix_length history pp] returns the shortest
   length [l] such that the current program point of [history] cannot
   be executed with indices [args] after the program point [pp] with indices
   [args'] when [args] and [args'] have a common suffix of length [l].
   Raises [Not_found] when that program point with indices [args] can
   be executed after the node [n[args']] for any [args,args']. *)

let incompatible_current_suffix_length history pp =
  if history.current_in_different_block then
    not_after_suffix_length_diff_block_pp history.current_point pp
  else
    not_after_suffix_length_pp false history.current_point pp

(* [incompatible_nodelist_different_block_suffix_length (nl, args) pp]
   returns the shortest length [l] such that an input...output block
   containing a node in [nl] cannot be executed with indices [args]
   after the program point [pp] with indices [args'] when [args] and [args']
   have a common suffix of length [l].
   Raises [Not_found] when they can be executed for any [args,args']. *)

let incompatible_nodelist_different_block_suffix_length (nl, args) pp =
  map_max (fun n1 ->
    not_after_suffix_length_diff_block_pp n1.definition pp) nl

(* [incompatible_nodelist_same_block_suffix_length (nl, args) pp]
   returns the shortest length [l] such that a node in [nl] cannot be
   executed with indices [args] after the program point [pp] with indices
   [args'] when [args] and [args'] have a common suffix of length [l].
   Raises [Not_found] when they can be executed for any [args,args']. *)

let incompatible_nodelist_same_block_suffix_length (nl, args) pp =
  map_max (fun n1 ->
    not_after_suffix_length_pp false n1.definition pp) nl

(* [is_compatible_history (pp,args) history] returns true when 
   the information in [history] is compatible with the execution
   of program point [pp] with indices [args] before that history. *)
    
let is_compatible_history (pp,args) history =
  (try
    let suffix_l = incompatible_current_suffix_length history pp in
    (*print_string "is_compatible_history "; print_int suffix_l;
    print_string " args length: "; print_int (List.length args);
    print_string " cur_array length: "; print_int (List.length history.cur_array); print_newline(); *)
    let args_skip = Terms.lsuffix suffix_l args in
    let args_skip' = Terms.lsuffix suffix_l history.cur_array in
    (not (List.for_all2 Terms.equal_terms args_skip args_skip'))
  with Not_found -> true) &&
  (List.for_all (fun (nl',args') ->
    try
      let suffix_l = incompatible_nodelist_different_block_suffix_length (nl', args') pp in
      let args_skip = Terms.lsuffix suffix_l args in
      let args_skip' = Terms.lsuffix suffix_l args' in
      (not (List.for_all2 Terms.equal_terms args_skip args_skip'))
    with Not_found -> true
	) history.def_vars_in_different_blocks) && 
  (List.for_all (fun (nl',args') ->
    try
      let suffix_l = incompatible_nodelist_same_block_suffix_length (nl', args') pp in
      let args_skip = Terms.lsuffix suffix_l args in
      let args_skip' = Terms.lsuffix suffix_l args' in
      (not (List.for_all2 Terms.equal_terms args_skip args_skip'))
    with Not_found -> true
	) history.def_vars_maybe_in_same_block)

(* [facts_compatible_history fact_accu (ppl,args) history] returns
   [fact_accu] with additional facts inferred from the execution of a
   program point in [ppl] with indices [args] before the history [history]. *)

let facts_compatible_history fact_accu (ppl,args) history = 
  let fact_accu1 =
    try
      let suffix_l = map_max (incompatible_current_suffix_length history) ppl in
    (*print_string ("incompatible_suffix_length 1 " ^ b.sname ^ "_" ^ (string_of_int b.vname) ^ " " ^ b'.sname ^ "_" ^ (string_of_int b'.vname) ^ " = "); print_int suffix_l; print_newline(); *)
      let args_skip = Terms.lsuffix suffix_l args in
      let args_skip' = Terms.lsuffix suffix_l history.cur_array in
      (Terms.make_or_list (List.map2 Terms.make_diff args_skip args_skip')) :: fact_accu
    with Not_found -> fact_accu
  in
  let fact_accu2 =
    List.fold_left (fun fact_accu (nl',args') ->
      try
	let suffix_l = map_max (incompatible_nodelist_different_block_suffix_length (nl', args')) ppl in
	let args_skip = Terms.lsuffix suffix_l args in
	let args_skip' = Terms.lsuffix suffix_l args' in
	(Terms.make_or_list (List.map2 Terms.make_diff args_skip args_skip')) :: fact_accu
    with Not_found -> fact_accu
	) fact_accu1 history.def_vars_in_different_blocks
  in
  List.fold_left (fun fact_accu (nl',args') ->
    try
      let suffix_l = map_max (incompatible_nodelist_same_block_suffix_length (nl', args')) ppl in
      let args_skip = Terms.lsuffix suffix_l args in
      let args_skip' = Terms.lsuffix suffix_l args' in
      (Terms.make_or_list (List.map2 Terms.make_diff args_skip args_skip')) :: fact_accu
    with Not_found -> fact_accu
	) fact_accu2 history.def_vars_maybe_in_same_block
  
(* [ppl_at_pp_add_fact fact_accu (pp, args) (ppl,args')] adds to
   [fact_accu] a fact that always holds when a program point in 
   [ppl] is executed with indices [args']
   before the execution of program point [pp] with indices [args], if
   any. *)

let ppl_before_pp_add_fact fact_accu (pp, args) (ppl,args') =
  try
    let suffix_l = not_after_suffix_length_pp_ppl pp ppl in
    let args_skip = Terms.lsuffix suffix_l args in
    let args_skip' = Terms.lsuffix suffix_l args' in
    (Terms.make_or_list (List.map2 Terms.make_diff args_skip args_skip')) :: fact_accu
  with Not_found -> 
    fact_accu
    
(* [ppl_before_pp_facts pp_args def_list] returns facts
   inferred from the knowledge that the variables in [def_list]
   are defined before the execution of program point [pp] with indices [args].
   (Typically, that some indices in [args] are different
   from some indices of variables in [def_list].) *)

let ppl_before_pp_facts fact_accu pp_args ppls =
    List.fold_left (fun accu -> ppl_before_pp_add_fact accu pp_args) fact_accu ppls

(* [may_def_before (b,args) (b',args')] returns true when
   [b[args]] may be defined before or at the same time as [b'[args']] *)

let may_def_before (b,args) (b',args') =
  (* b defined at the same time as b' *)
  (b == b') || (List.exists (fun n -> List.memq b n.binders) b'.def) ||
  (* b[args] defined before b'[args'] *)
  (try
    let suffix_l = map_max (fun n -> not_after_suffix_length_pp_var true n.definition_success b) b'.def in
    let args_skip = Terms.lsuffix suffix_l args in
    let args_skip' = Terms.lsuffix suffix_l args' in
    (not (List.for_all2 Terms.equal_terms args_skip args_skip'))
  with Not_found -> true)

(* [may_def_before_ppl (b,args) (ppl,args')] returns true when
   [b[args]] may be defined before [ppl[args']].
   ("before" includes the case in which [b[args]] is defined
   immediately before [ppl[args']], that is, the program point
   at which the definition is done [n.definition_success] is in [ppl].) *)

let may_def_before_ppl (b,args) (ppl,args') =
  (* b[args] defined before ppl[args'] *)
  (try
    let suffix_l = map_max (fun pp -> not_after_suffix_length_pp_var false pp b) ppl in
    let args_skip = Terms.lsuffix suffix_l args in
    let args_skip' = Terms.lsuffix suffix_l args' in
    (not (List.for_all2 Terms.equal_terms args_skip args_skip'))
  with Not_found -> true)

(* [is_under pp pp'] returns true when the program point [pp] is
   syntactically under [pp']. *)

let is_under pp pp' =
  try 
    let occ = Terms.occ_from_pp pp in
    let occ', max_occ', _ = incomp_from_pp pp' in
    (occ' <= occ) && (occ <= max_occ')
  with Not_found -> false

(* [implies_ppl (ppl, args) (ppl', args')] returns true when the
   execution of a program point in [ppl] with indices [args]
   implies the execution of a program point in [ppl'] with
   indices [args'] (without taking into account defined conditions). *)

let implies_ppl (ppl, args) (ppl', args') =
  let l' = List.length args' in
  (List.length args >= l') &&
  (let args_suffix = Terms.lsuffix l' args in
  List.for_all2 Terms.equal_terms args_suffix args') &&
  (List.for_all (fun pp ->
    List.exists (fun pp' -> is_under pp pp') ppl'
      ) ppl)
