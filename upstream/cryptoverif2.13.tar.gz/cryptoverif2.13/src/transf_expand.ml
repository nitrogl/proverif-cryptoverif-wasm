(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Types

(* Expand all if, let, and find in expressions, so that they occur only in 
   processes. 

After expansion, if/let/find/res may occur in terms only in conditions of find.
*)

let whole_game = ref Terms.empty_game

let current_pass_transfos = ref []

(* Priorities for orienting equalities into rewrite rules *)
let current_max_priority = Facts.current_max_priority
let priority_list = Facts.priority_list

(* Check that a term/binderref contains no if, let, find, new *)
    
let check_no_ifletfind t =
  if not (Terms.check_simple_term t) then
    Parsing_helper.input_error "I cannot handle if, let, find, new inside the definition condition of a find. Sorry." t.t_loc

let check_no_ifletfind_br (_,l) =
  List.iter check_no_ifletfind l

(* Check if a term/pattern needs to be modified by expansion *)

let rec need_expand t =
  match t.t_desc with
    Var(_,l) | FunApp(_,l) -> List.exists need_expand l
  | ReplIndex _ -> false
  | _ -> true

let rec need_expand_pat = function
    PatVar _ -> false
  | PatTuple(_,l) -> List.exists need_expand_pat l
  | PatEqual t -> need_expand t

(* Initialization of probability counting *)  

let reset coll_elim g =
  whole_game := g;
  current_max_priority := 0;
  List.iter (fun b -> b.priority <- 0) (!priority_list);
  priority_list := [];
  Depanal.reset coll_elim g

(* [dependency_anal cur_array] provides a dependency analysis.
   See type [dep_anal] in types.ml *)

let dependency_anal cur_array =
  let collision_test simp_facts t1 t2 =
    let t1' = Terms.try_no_var_rec simp_facts t1 in
    let t2' = Terms.try_no_var_rec simp_facts t2 in
    Facts.reset_repl_index_list();
    Depanal.try_two_directions (Depanal.dependency_collision_rec cur_array simp_facts (fun _ -> Facts.nodepinfo)) t1' t2'
  in
  if !Settings.proba_zero then
    (Facts.indep_test_noinfo, Facts.no_collision_test)
  else
    (Facts.indep_test_noinfo, collision_test)
    
(* Note on the elimination of collisions in find conditions:
   The find indices are replaced with fresh replication indices,
   so that we correctly take into account that
   the condition of find is executed for every value of the indices. *)

(* Simplify a term knowing some true facts:
   we only consider two cases: we want to get "true" or to get a tuple. *)

let prove_true cur_array simp_facts t =
  try
    let _ = Facts.simplif_add (dependency_anal cur_array) simp_facts (Terms.make_not t) in
    false
  with Contradiction ->
    true

let rec get_tuple cur_array simp_facts t =
  if Terms.is_tuple t then t else
  let t' = Terms.try_no_var simp_facts t in
  if Terms.is_tuple t' then t' else
  let t'' = Facts.simplify_term (dependency_anal cur_array) simp_facts t' in
  if Terms.is_tuple t'' then t'' else
  match t''.t_desc with
    Var _ when (not (Terms.synt_equal_terms t' t'')) ->
      get_tuple cur_array simp_facts t''
  | _ -> t
	
(*
  The reason why we just simplify to true/false or tuples is subtle. 
  The high-level idea is that simplification during expansion mainly
  aims at cutting branches; the terms can be reduced in the simplification
  pass after expansion. 
  This is important in tls13-core-PSKandPSKDHE-NoCorruption.cv: 
  otherwise, we get a regression because of a subsequent simplification
  that cannot be done: if I make simplification here, the simplification
  is done in one branch of find and not in another yielding two
  different expressions for the same variable, hence CryptoVerif
	   cannot use the value of the variable. If I wait until the next
  simplification pass, the other simplification via DepAnal2 is done
  first, and the problem is solved... *)

(* [count_branches test bind] counts the branches generated by
   the expansion of tuples in [let]. *)

let rec count_branches_rec = function
  | (pat,_)::l ->
      if Terms.is_full_pattern pat then
	count_branches_rec l
      else
	1 + count_branches_rec l
  | [] -> 0
	
let count_branches test bind =
  let br_bind = 1 + count_branches_rec bind in
  if Terms.is_true test then br_bind else 1+br_bind

(* Simplification of terms with if/let/find/res.
   The simplifications are very similar to those performed
   on processes below. *)

let simplify_term_restr rec_simplif cur_array true_facts b p =
  let true_facts = Facts.update_elsefind_with_def [b] true_facts in
  let p' = rec_simplif cur_array true_facts p in
  Terms.build_term_type p'.t_type (ResE(b, p'))

let simplify_term_if rec_simplif pp cur_array true_facts t p1 p2 =
  try
    (* The facts that are true in the "else" branch *)
    let true_facts' = Facts.simplif_add (dependency_anal cur_array) true_facts (Terms.make_not t) in
    (* Simplify the "else" branch *)
    let p2' = rec_simplif cur_array true_facts' p2 in
    try
      (* The facts that are true in the "then" branch *)
      let true_facts' = Facts.simplif_add (dependency_anal cur_array) true_facts t in
      (* Simplify the "then" branch *)
      let p1' =  rec_simplif cur_array true_facts' p1 in
      Terms.build_term_type (Terms.merge_types p1'.t_type p2'.t_type) (TestE(t, p1', p2'))
    with Contradiction ->
      Settings.changed := true;
      current_pass_transfos := (STestFalse(pp)) :: (!current_pass_transfos);
      p2'
  with Contradiction ->
    Settings.changed := true;
    current_pass_transfos := (STestTrue(pp)) :: (!current_pass_transfos);
    rec_simplif cur_array true_facts p1

let simplify_term_let  rec_simplif pp cur_array true_facts pat t p1 p2 =
  let true_facts' = Facts.update_elsefind_with_def (Terms.vars_from_pat [] pat) true_facts in
  try
    let (transfos, bind1, test, bind2) = Terms.simplify_let_tuple cur_array (get_tuple cur_array true_facts) pat t in
    let (bind1, test, bind2) =
      (* If the expansion of tuples creates too many branches,
         do not do it. *)
      if count_branches test bind2 <= 3 then
	(bind1, test, bind2)
      else
	([], Terms.make_true(), [pat, t])
    in
    if transfos != [] then
      begin
	Settings.changed := true;
	current_pass_transfos := (SLetSimplifyPattern(pp, transfos)) :: (!current_pass_transfos);
      end;
    (* always_succeeds = true when the let never fails *)
    let always_succeeds =
      (Terms.is_true test) &&
      (List.for_all (fun (pat, _) -> Terms.is_full_pattern pat) bind2)
    in
    (* Simplify the process p2 if it will be used at least once *)
    let p2' =
      match p2 with
	None -> None
      | Some t3 ->
	  if always_succeeds then 
	    begin
	      Settings.changed := true;
              current_pass_transfos := (SLetElseRemoved(pp)) :: (!current_pass_transfos);
	      None
	    end
	  else
	    begin
	      try
		let true_facts_else =
		  try
		    Facts.simplif_add (dependency_anal cur_array) true_facts (Terms.make_for_all_diff (Terms.gen_term_from_pat pat) t) 
		  with Terms.NonLinearPattern -> true_facts
		in
		Some (rec_simplif cur_array true_facts_else t3)
	      with Contradiction ->
	        (* The else branch of the let will never be executed
		   => use some constant to simplify *)
		let (changed, t3') = Stringmap.make_cst t3 in
		if changed then
		  begin
		    Settings.changed := true;
		    current_pass_transfos := (SLetElseRemoved(pp)) :: (!current_pass_transfos);
                  end;
		Some t3'
	    end
    in
    (* Simplify the process p1 *)
    let rec add_true_facts true_facts = function
	[] -> true_facts
      | (pat, t)::l ->
	  add_true_facts
	    (Facts.simplif_add (dependency_anal cur_array) true_facts
	       (Terms.fact_from_pat_t pat t)) l
    in
    let true_facts_in = Facts.simplif_add (dependency_anal cur_array)
	(add_true_facts true_facts' (bind1 @ bind2)) test
    in
    let p1' = rec_simplif cur_array true_facts_in p1 in
      (* Put the lets in [bind2] *)
      let plet = Terms.put_lets_term bind2 p1' p2' in
      (* Put the test *)
      let ptest = 
	if Terms.is_true test then
	  plet
	else
	  try
	    let _ = Facts.simplif_add (dependency_anal cur_array) true_facts (Terms.make_not test) in
	    let p2'' = Terms.get_else p2' in
	    Terms.build_term_type (Terms.merge_types plet.t_type p2''.t_type) (TestE(test, plet, p2''))
	  with Contradiction ->
	    plet
      in
      (* Put the lets in [bind1] *)
      Terms.put_lets_term bind1 ptest p2'
  with
    Terms.Impossible | Contradiction ->
      Settings.changed := true;
      (*
      current_pass_transfos := (SLetSimplifyPattern(let_p, [pat, DImpossibleTuple])) :: (!current_pass_transfos); OR *)
      current_pass_transfos := (SLetRemoved(pp)) :: (!current_pass_transfos);
      rec_simplif cur_array true_facts (Terms.get_else p2)
    
exception OneBranchTerm of term findbranch

let simplify_term_find rec_simplif pp cur_array true_facts l0 t3 find_info =
  match l0 with
    [] ->
      rec_simplif cur_array true_facts t3
  | [([],def_list,t1,t2)] when
    Facts.reduced_def_list (Incompatible.get_facts pp) def_list = [] && 
    (Terms.check_simple_expanded t1) -> 
      Settings.changed := true;
      current_pass_transfos := (SFindtoTest pp) :: (!current_pass_transfos);
      simplify_term_if rec_simplif pp cur_array true_facts t1 t2 t3
  | _ ->
      let l0_with_info = Info_from_term.add_else_info_find (Some (!whole_game)) true l0 in
    try
      let (pps, def_vars, current_history) = Facts.get_def_vars_at pp in
      let t3' = 
	try
	  rec_simplif cur_array (Facts.add_elsefind (dependency_anal cur_array) def_vars true_facts l0_with_info) t3
	with Contradiction ->
	  (* The else branch of the find will never be executed
             => use some constant to simplify *)
	  let (changed, t3') = Stringmap.make_cst t3 in
	  if changed then
	    begin
	      Settings.changed := true;
              current_pass_transfos := (SFindElseRemoved(pp)) :: (!current_pass_transfos);
	    end;
	  t3'
      in
      let unique = (Terms.is_unique (Some(!whole_game)) l0 find_info == Unique) in
      let unique_no_abort = unique && (not (List.exists (fun (_,_,t,_) -> Terms.may_abort_counted (Some(!whole_game)) t) l0)) in
      let rec simplify_findl seen = function
	  [] -> []
	| (((bl, def_list, t1, t2), _) as cur_branch)::l ->
	    begin
	    let l' = simplify_findl (cur_branch::seen) l in
	    let vars = List.map fst bl in
	    let repl_indices = List.map snd bl in
	    let cur_array_cond = repl_indices @ cur_array in
	    let vars_terms = List.map Terms.term_from_binder vars in
	    try
	      let def_list' = Facts.reduced_def_list (Incompatible.get_facts pp) def_list in
	      let (facts_def_list, pps_init_and_cond, def_vars_cond) = Facts.facts_from_defined pps def_vars current_history def_list' in
	      let true_facts_t1 = Facts.simplif_add_list (dependency_anal cur_array_cond) true_facts facts_def_list in
	      let def_vars_init_and_cond = Terms.union_binderref def_vars_cond def_vars in
	      let facts_from_elsefind_facts =
		if !Settings.elsefind_facts_in_simplify then
		  Facts_of_elsefind.get_facts_of_elsefind_facts (!whole_game) cur_array_cond true_facts_t1 pps_init_and_cond current_history def_vars_init_and_cond
		else
		  []
	      in
	      let true_facts_t1 = Facts.simplif_add_list (dependency_anal cur_array_cond) true_facts_t1 facts_from_elsefind_facts in
	      (* Set priorities of variables defined by this find, 
	         to orient rewrite rules preferably in the direction
	         b[..] -> t where b \in bl *)
	      incr current_max_priority;
	      List.iter (fun b -> 
		b.priority <- (!current_max_priority); 
		priority_list := b :: (!priority_list)) vars;
	      let (t1', facts_cond, pps_init_and_cond', def_vars_cond', elsefind_cond) =
		if Terms.check_simple_expanded t1 then 
		  let t1' = if prove_true cur_array_cond true_facts_t1 t1 then Terms.make_true() else t1 in
		  (t1', t1' :: facts_from_elsefind_facts @ facts_def_list, pps_init_and_cond, def_vars_cond, [])
		else
                  let (sure_facts_t1, sure_def_vars_t1, elsefind_t1) = Info_from_term.def_vars_and_facts_from_term (Some (!whole_game)) true true t1 in
		  let then_node = Facts.get_initial_history (DTerm t2) in
                  let (facts_def_vars_t1, pps_init_and_cond', def_vars_t1) = Facts.facts_from_defined pps_init_and_cond def_vars_init_and_cond then_node sure_def_vars_t1 in
		  (t1, facts_def_vars_t1 @ sure_facts_t1 @ facts_from_elsefind_facts @ facts_def_list,
                   pps_init_and_cond', def_vars_t1 @ def_vars_cond, elsefind_t1)
	      in

	      (* [facts_cond] contains the facts that hold,
		 using repl_indices as indices. We substitute vars from them to obtain
		 the facts that hold in the then branch.*)
	      let facts_cond' = List.map (Terms.subst repl_indices vars_terms) facts_cond in
	      let elsefind_cond' = List.map (Terms.subst_else_find repl_indices vars_terms) elsefind_cond in
	      let tf' =
		(* When the find is Unique, I know that the other branches fail,
		   so I can add the corresponding elsefind facts *)
		if unique then 
		  Facts.add_elsefind (dependency_anal cur_array) def_vars true_facts (List.rev_append seen l)
		else
		  true_facts
	      in
	      let tf' = Terms.add_else_find elsefind_cond' tf' in
	      let tf' = Facts.update_elsefind_with_def vars tf' in
	      let tf' = Facts.simplif_add_list (dependency_anal cur_array) tf' facts_cond' in

	      (* Check that the "defined" conditions can hold,
		 if not remove the branch *)
	      (* [def_vars_cond] contains the variables that are certainly defined 
		 using repl_indices as indices. We substitute vars from them to obtain
		 the variables certainly defined in the then branch. *)
	      let def_vars_accu = Terms.subst_def_list repl_indices vars_terms def_vars_cond' in
	      let pps_init_and_cond_subst = Terms.subst_pps repl_indices vars_terms pps_init_and_cond' in
	      (* [Terms.def_list_at_pp_fact] adds facts inferred from the knowledge 
		 that the variables in [def_vars_accu] are defined
	         at the current program point *)
	      let cur_array_term = List.map Terms.term_from_repl_index cur_array in
	      let new_facts = Incompatible.ppl_before_pp_facts [] (DTerm t2, cur_array_term) pps_init_and_cond_subst in
	      let tf' = Facts.simplif_add_list (dependency_anal cur_array) tf' new_facts in
	      let def_vars' = 
		(* Using def_vars_accu instead of def_list' is more precise *)
	        def_vars_accu @ def_vars
	      in
	      let tf' = Facts.convert_elsefind (dependency_anal cur_array) def_vars' tf' in


	      let t2' = rec_simplif cur_array tf' t2 in

	      (* Update the defined condition *)
	      let (bl', def_list3, t1', t2') as find_branch = 
		Facts.update_def_list_term (pps, def_vars, current_history) (Some def_vars_cond) bl def_list' t1' t2' in
              if List.length def_list3 < List.length def_list then
                begin
                  Settings.changed := true;
                  current_pass_transfos := (SFindDeflist(pp, def_list, def_list3)) :: (!current_pass_transfos)
		end
              else if not (Facts.eq_deflists def_list def_list3)  then
		current_pass_transfos := (SFindDeflist(pp, def_list, def_list3)) :: (!current_pass_transfos);

              (* If the find is marked "unique", and we can prove that
	         the current branch succeeds, keep only that branch *)
              if (!Settings.unique_branch) &&
		(Terms.check_simple_expanded t1')
	      then 
		try 
		  Facts.branch_succeeds find_branch (dependency_anal cur_array_cond) true_facts def_vars;
		  find_branch :: l'
		with Facts.SuccessBranch(subst, keep_bl) ->
		  (* If the find has a single branch, which always succeeds, and the
	             indices defined by the find are not used, we can remove
	             the find, keeping only its then branch *)
		  if (unique_no_abort ||
		       ((Terms.is_not_unique_to_prove find_info) && (* the transformation is incorrect with UniqueToProve, even if there is a single branch: that branch may have several successful choices, and the find would abort in this case *)
		        (List.length l0 = 1 (* there is a single branch, and its condition is a simple term, so it does not abort*)))) &&
		    (not (List.exists (fun b -> Array_ref.has_array_ref_q b (!whole_game).current_queries || Terms.refers_to b t2') (List.map fst bl'))) then
		    begin
		      let def_list4 = Facts.filter_deflist_indices bl' def_list3 in
		      if (bl' != []) && (def_list4 != []) && (List.length l0 = 1) 
                          (* When def_list4 == [] or List.length l0 > 1, the change is recorded below *) then
			begin
			  Settings.changed := true;
			  current_pass_transfos := (SFindSingleBranch(pp,(bl', def_list3, t1', DTerm t2'))) :: (!current_pass_transfos);
			end;
		      raise (OneBranchTerm([], def_list4, Terms.make_true(), t2'))
		    end
		  else if not unique_no_abort then 
		    find_branch :: l' 
		  else
		    begin
		      (* Subst is a substitution for replication indices,
			 compute the substitution for the corresponding variables *)
		      let subst_repl_indices_source = List.map (fun (_,b,_) -> b) subst in
		      let subst_repl_indices_target = List.map (fun (_,_,b_im) -> b_im) subst in
		      let subst = List.map (fun (b, _, b_im) -> 
			(b, Terms.subst repl_indices vars_terms b_im)
			  ) subst 
		      in
		      if List.exists (fun (b, b_im) -> 
			List.exists (fun (b', b_im') -> Terms.refers_to b b_im') subst
			  ) subst
		      then raise (OneBranchTerm(find_branch));
		      if subst != [] then 
			begin
			  Settings.changed := true;
			  current_pass_transfos := (SFindIndexKnown(pp, (bl, def_list, t1, DTerm t2), subst)) :: (!current_pass_transfos)
			end;
		      let def_list_tmp = ref [] in
		      List.iter (fun br ->
			Terms.get_deflist_subterms def_list_tmp 
			  (Terms.subst subst_repl_indices_source subst_repl_indices_target (Terms.term_from_binderref br))) def_list3;
		      let def_list3 = !def_list_tmp in 
		      let t1' = Terms.update_args_at_creation ((List.map snd keep_bl) @ cur_array) 
			  (Terms.subst subst_repl_indices_source subst_repl_indices_target t1') in
		      let t2' = Facts.add_let_term (Terms.subst3 subst t2') subst in
		      raise (OneBranchTerm(keep_bl, def_list3, t1', t2'))
		    end
	      else
		find_branch :: l'

	    with Contradiction ->
	      if Terms.may_abort_counted (Some(!whole_game)) t1 then
		begin
		  (* The test may abort, we cannot remove it *)
		  let (changed, t2') = Stringmap.make_cst t2 in
		  if changed then
		    begin
		      Settings.changed := true;
		      current_pass_transfos := (SFindBranchNotTaken(pp,(bl, def_list, t1, DTerm t2))) :: (!current_pass_transfos)
		    end;
		  (bl, def_list, t1, t2') :: l'
		end
	      else
		begin
		  Settings.changed := true;
		  current_pass_transfos := (SFindBranchRemoved(pp,(bl, def_list, t1, DTerm t2))) :: (!current_pass_transfos);
		  l'
		end
	    end
      in
      try 
	let l0' = simplify_findl [] l0_with_info in
	if l0' == [] then
	  begin
	    Settings.changed := true;
	    current_pass_transfos := (SFindRemoved(pp)) :: (!current_pass_transfos);
	    t3'
	  end
	else
	  let find_info = Terms.is_unique (Some (!whole_game)) l0' find_info in
	  let rec get_type = function
	      [] -> t3'.t_type
	    | (_,_,_,t2')::rest ->
		Terms.merge_types t2'.t_type (get_type rest)
	  in
	  Terms.build_term_type (get_type l0') (FindE(l0', t3',find_info))
      with OneBranchTerm(find_branch) ->
	match find_branch with
	  ([],[],t1,t2) -> 
	    Settings.changed := true;
	    current_pass_transfos := (SFindSingleBranch(pp,([],[],t1,DTerm t2))) :: (!current_pass_transfos);
	    t2
	| (bl,def_list,t1,t2) ->
            (* The else branch of the find will never be executed
               => use some constant to simplify *)
	    let (changed, t3'') = Stringmap.make_cst t3' in
	    if List.length l0 > 1 then 
	      begin
		Settings.changed := true;
		current_pass_transfos := (SFindSingleBranch(pp,(bl,def_list,t1,DTerm t2))) :: (!current_pass_transfos)
	      end
	    else if changed then
	      begin
		Settings.changed := true;
                current_pass_transfos := (SFindElseRemoved(pp)) :: (!current_pass_transfos);
	      end;
	    Terms.build_term_type (Terms.merge_types t2.t_type t3''.t_type) (FindE([find_branch], t3'',find_info))
    with Contradiction ->
      (* The whole Find will never be executed.
         We just use the else branch as a simplification *)
      rec_simplif cur_array true_facts t3	
	      
(* Expand term to term. Useful for conditions of find when they cannot be expanded to processes.
   Guarantees the invariant that if/let/find/res terms occur only in
   - conditions of find
   - at [ ] positions in TestE(t,[then],[else]), ResE(b,[...]), LetE(b,t,[in],[else]), 
     FindE((bl,def_list,[cond],[then]) list,[else])

   context = fun term -> C[term]
*)

let rec pseudo_expand_term (cur_array: Types.repl_index list) true_facts t context =
  let pseudo_expand_term_rec cur_array true_facts t =
    pseudo_expand_term cur_array true_facts t context
  in
  match t.t_desc with
    Var(b,l) ->
      pseudo_expand_term_list cur_array true_facts l
	(fun cur_array true_facts li ->
	  context cur_array true_facts (Terms.build_term t (Var(b,li))))
  | ReplIndex _ -> context cur_array true_facts t
    (* optimize the expansion of && and ||:
       when the first argument is false (resp. true), 
       I do not need to compute the other one. *)
  | FunApp(f, [t1;t2]) when f == Settings.f_and ->
     pseudo_expand_term cur_array true_facts t1 (fun cur_array true_facts t1' ->
       if Terms.is_false t1' then
	 if Array_ref.no_effect (!whole_game) t2 then
           (* If [t2] has some effect, the following optimization is not sound:
	      [false && t2] still evaluates [t2] before returning [false].
	      Similar observation for other calls to [Array_ref.no_effect] below. *)
           context cur_array true_facts t1'
	 else
	   pseudo_expand_term cur_array true_facts t2 (fun cur_array true_facts t2' ->
             context cur_array true_facts t1')
       else if Terms.is_true t1' then
           pseudo_expand_term_rec cur_array true_facts t2
       else
	 pseudo_expand_term cur_array true_facts t2 (fun cur_array true_facts t2' ->
           if Terms.is_false t2' then
             context cur_array true_facts t2'
           else if Terms.is_true t2' then
             context cur_array true_facts t1'
           else
	     context cur_array true_facts (Terms.build_term t (FunApp(f,[t1';t2'])))))
  | FunApp(f, [t1;t2]) when f == Settings.f_or ->
     pseudo_expand_term cur_array true_facts t1 (fun cur_array true_facts t1' ->
       if Terms.is_true t1' then
	 if Array_ref.no_effect (!whole_game) t2 then
           context cur_array true_facts t1'
	 else
	   pseudo_expand_term cur_array true_facts t2 (fun cur_array true_facts t2' ->
	     context cur_array true_facts t1')
       else if Terms.is_false t1' then
         pseudo_expand_term_rec cur_array true_facts t2
       else
	 pseudo_expand_term cur_array true_facts t2 (fun cur_array true_facts t2' ->
           if Terms.is_true t2' then
             context cur_array true_facts t2'
           else if Terms.is_false t2' then
             context cur_array true_facts t1'
           else
	     context cur_array true_facts (Terms.build_term t (FunApp(f,[t1';t2'])))))
  | FunApp(f,l) ->
      pseudo_expand_term_list cur_array true_facts l
	(fun cur_array true_facts li ->
	  context cur_array true_facts (Terms.build_term t (FunApp(f,li))))
  | TestE(t1,t2,t3) ->
      pseudo_expand_term cur_array true_facts t1
	(fun cur_array true_facts t1i ->
	  (* Equivalent to TestE(t1i,  t2, t3) with simplification
	     and expansion of t2 and t3 *)
	  simplify_term_if pseudo_expand_term_rec (DTerm t) cur_array true_facts t1i t2 t3)
  | LetE(pat, t1, t2, topt) ->
      pseudo_expand_term cur_array true_facts t1 (fun cur_array true_facts t1i ->
	pseudo_expand_pat cur_array true_facts pat (fun cur_array true_facts pati ->
	  (* Equivalent to LetE(pati, t1i, t2, topt) with simplification
	     and expansion of t2 and topt *)
	  simplify_term_let pseudo_expand_term_rec (DTerm t) cur_array true_facts
	    pati t1i t2 topt))
  | FindE(l0, t3, find_info) ->
      let rec expand_cond_find_list cur_array true_facts l context =
	match l with
	  [] -> context cur_array true_facts []
	| ((bl, def_list, t1, t2)::restl) ->
	    List.iter check_no_ifletfind_br def_list;
                  (* I move something outside a condition of
                     "find" only when bl and def_list are empty.  
                     I could be more precise, I would need to
                     check not only that what I move out does not
                     refer to the indices of "find", but also that it
                     is does not refer to the variables in the
                     "defined" condition---otherwise, some variable
                     accesses may not be defined after the
                     transformation

		     Moving event_abort outside the condition would also
		     be problematic because in case there are several
		     event_abort in the conditions, it would execute the
		     first one in the order of the list instead of one
		     chosen randomly. *)
            if bl != [] || def_list != [] || Terms.may_abort t1 then
	      expand_cond_find_list cur_array true_facts restl (fun cur_array true_facts li ->
		context cur_array true_facts ((bl, def_list, local_final_pseudo_expand cur_array true_facts t1, t2)::li))
	    else
	      pseudo_expand_term cur_array true_facts t1 (fun cur_array true_facts t1i ->
		expand_cond_find_list cur_array true_facts restl (fun cur_array true_facts li ->
		  context cur_array true_facts ((bl, def_list, t1i, t2)::li)))
      in
      expand_cond_find_list cur_array true_facts l0 (fun cur_array true_facts l1i ->
	(* Equivalent to FindE(l1i, t3, find_info) after expansion
	   of the results in l1i and of t3 *)
	simplify_term_find pseudo_expand_term_rec (DTerm t) cur_array true_facts
	   l1i t3 find_info)
  | ResE(b, t1) ->
      (* Equivalent to ResE(b, t1) after simplification and expansion
	 of t1 *)
      simplify_term_restr pseudo_expand_term_rec cur_array true_facts b t1
  | EventAbortE f ->
      Terms.build_term_type t.t_type (EventAbortE f)
  | EventE _ ->
      Parsing_helper.internal_error "Events should not occur in conditions of find before expansion"
  | GetE _ | InsertE _ ->
      Parsing_helper.internal_error "Get/Insert should not appear in Transf_expand.pseudo_expand_term"

and pseudo_expand_term_list cur_array true_facts l context =
  match l with
    [] -> context cur_array true_facts []
  | (a::l) -> 
      pseudo_expand_term cur_array true_facts a (fun cur_array true_facts a' ->
	pseudo_expand_term_list cur_array true_facts l (fun cur_array true_facts l' ->
	  context cur_array true_facts (a'::l')))

and pseudo_expand_pat cur_array true_facts pat context =
  match pat with
    PatVar b -> context cur_array true_facts (PatVar b)
  | PatTuple (ft,l) ->
      pseudo_expand_pat_list cur_array true_facts l (fun cur_array true_facts li ->
	context cur_array true_facts (PatTuple (ft,li)))
  | PatEqual t ->
      pseudo_expand_term cur_array true_facts t (fun cur_array true_facts ti ->
	context cur_array true_facts (PatEqual ti))

and pseudo_expand_pat_list cur_array true_facts l context =
  match l with
    [] -> context cur_array true_facts []
  | (a::l) -> 
      pseudo_expand_pat cur_array true_facts a (fun cur_array true_facts a' ->
	pseudo_expand_pat_list cur_array true_facts l (fun cur_array true_facts l' ->
	  context cur_array true_facts (a'::l')))
	
and local_final_pseudo_expand cur_array true_facts t =
  pseudo_expand_term cur_array true_facts t (fun cur_array true_facts t -> t)

(* Version of final_pseudo_expand designed to be called from simplification
   It carries over the environment used in simplification *)

let final_pseudo_expand g cur_array true_facts t =
  whole_game := g;
  current_pass_transfos := [];
  let res = local_final_pseudo_expand cur_array true_facts t in
  whole_game := Terms.empty_game;
  let final_res = (!current_pass_transfos, res) in
  current_pass_transfos := [];
  final_res
  
    
(* Simplification of processes *)

let simplify_restr rec_simplif cur_array true_facts b p =
  let true_facts = Facts.update_elsefind_with_def [b] true_facts in
  let p' = rec_simplif cur_array true_facts p in
  Terms.oproc_from_desc (Restr(b, p'))

let simplify_if rec_simplif pp cur_array true_facts t p1 p2 =
  try
    (* The facts that are true in the "else" branch *)
    let true_facts' = Facts.simplif_add (dependency_anal cur_array) true_facts (Terms.make_not t) in
    (* Simplify the "else" branch *)
    let p2' = rec_simplif cur_array true_facts' p2 in
    try
      (* The facts that are true in the "then" branch *)
      let true_facts' = Facts.simplif_add (dependency_anal cur_array) true_facts t in
      (* Simplify the "then" branch *)
      let p1' =  rec_simplif cur_array true_facts' p1 in
      (* Merge "if t then yield else yield" *)
      if (p1'.p_desc == Yield) && (p2'.p_desc == Yield) then 
	begin
	  Settings.changed := true;
	  current_pass_transfos := (STestMerge(pp)) :: (!current_pass_transfos);
	  Terms.oproc_from_desc Yield
	end
      else
	Terms.oproc_from_desc (Test(t, p1', p2'))
    with Contradiction ->
      Settings.changed := true;
      current_pass_transfos := (STestFalse(pp)) :: (!current_pass_transfos);
      p2'
  with Contradiction ->
    Settings.changed := true;
    current_pass_transfos := (STestTrue(pp)) :: (!current_pass_transfos);
    rec_simplif cur_array true_facts p1

let get_loc_proc p = p.p_loc

let get_loc_term t = t.t_loc

let get_loc_term_opt = function
    None -> Parsing_helper.dummy_ext
  | Some t -> get_loc_term t

let is_yield_proc p = (p.p_desc == Yield)

let is_yield_term_opt = function
    None -> true
  | Some _ -> false

let is_yield_term t = false
      
let simplify_let rec_simplif1 rec_simplif2 is_yield2 get_loc pp cur_array true_facts pat t p1 p2 =
  let true_facts' = Facts.update_elsefind_with_def (Terms.vars_from_pat [] pat) true_facts in
  try
    let (transfos, bind1, test, bind2) = Terms.simplify_let_tuple cur_array (get_tuple cur_array true_facts) pat t in
    let (bind1, test, bind2) =
      (* If the expansion of tuples creates too many branches,
         do not do it. *)
      if count_branches test bind2 <= 3 then
	(bind1, test, bind2)
      else
	([], Terms.make_true(), [pat, t])
    in
    if transfos != [] then
      begin
	Settings.changed := true;
	current_pass_transfos := (SLetSimplifyPattern(pp, transfos)) :: (!current_pass_transfos);
      end;
    (* always_succeeds = true when the let never fails *)
    let always_succeeds =
      (Terms.is_true test) &&
      (List.for_all (fun (pat, _) -> Terms.is_full_pattern pat) bind2)
    in
    (* Simplify the process p2 if it will be used at least once *)
    let p2' =
      if is_yield2 p2 then
	Terms.oproc_from_desc Yield
      else if always_succeeds then 
	begin
	  Settings.changed := true;
          current_pass_transfos := (SLetElseRemoved(pp)) :: (!current_pass_transfos);
	  Terms.oproc_from_desc Yield
	end
      else
	begin
	  try
	    let true_facts_else =
	      try
		Facts.simplif_add (dependency_anal cur_array) true_facts (Terms.make_for_all_diff (Terms.gen_term_from_pat pat) t) 
	      with Terms.NonLinearPattern -> true_facts
	    in
	    rec_simplif2 cur_array true_facts_else p2
	  with Contradiction ->
	    Settings.changed := true;
            current_pass_transfos := (SLetElseRemoved(pp)) :: (!current_pass_transfos);
	    Terms.oproc_from_desc Yield
	end
    in
    (* Simplify the process p1 *)
    let rec add_true_facts true_facts = function
	[] -> true_facts
      | (pat, t)::l ->
	  add_true_facts
	    (Facts.simplif_add (dependency_anal cur_array) true_facts
	       (Terms.fact_from_pat_t pat t)) l
    in
    let true_facts_in = Facts.simplif_add (dependency_anal cur_array)
	(add_true_facts true_facts' (bind1 @ bind2)) test
    in
    let p1' = rec_simplif1 cur_array true_facts_in p1 in
    (* Merge if both branches are Yield and the variables are not needed *)
    if (p1'.p_desc == Yield) && (p2'.p_desc == Yield) &&
      (List.for_all (fun (pat, _) -> not (Facts.needed_vars_in_pat pat (!whole_game).current_queries)) bind2) then
      begin
	Settings.changed := true;
	current_pass_transfos := (SLetRemoved(pp)) :: (!current_pass_transfos);
	Terms.oproc_from_desc Yield
      end
    else
      (* Put the lets in [bind2] *)
      let plet = Terms.put_lets bind2 p1' p2' in
      (* Put the test *)
      let ptest = 
	if Terms.is_true test || prove_true cur_array true_facts test then
	  plet
	else
	  Terms.oproc_from_desc (Test(test, plet, p2'))
      in
      (* Put the lets in [bind1] *)
      Terms.put_lets bind1 ptest p2' 
  with
    Terms.Impossible | Contradiction ->
      Settings.changed := true;
      (*
      current_pass_transfos := (SLetSimplifyPattern(let_p, [pat, DImpossibleTuple])) :: (!current_pass_transfos); OR *)
      current_pass_transfos := (SLetRemoved(pp)) :: (!current_pass_transfos);
      rec_simplif2 cur_array true_facts p2  

exception OneBranchProcess of process findbranch

(* All conditions of find in l0 must have already been expanded *)

let simplify_find rec_simplif is_yield get_loc get_pp pp cur_array true_facts l0 p2 find_info =
  match l0 with
    [] ->
      rec_simplif cur_array true_facts p2
  | [([],def_list,t1,p1)] when
    (Facts.reduced_def_list (Incompatible.get_facts pp) def_list = []) && 
    (Terms.check_simple_expanded t1) -> 
      Settings.changed := true;
      current_pass_transfos := (SFindtoTest pp) :: (!current_pass_transfos);
      simplify_if rec_simplif pp cur_array true_facts t1 p1 p2
  | _ ->
      let l0_with_info = Info_from_term.add_else_info_find (Some (!whole_game)) true l0 in
    try
      let (pps, def_vars, current_history) = Facts.get_def_vars_at pp in
      let p2' = 
	if is_yield p2 then Terms.oproc_from_desc Yield else
	try
	  rec_simplif cur_array (Facts.add_elsefind (dependency_anal cur_array) def_vars true_facts l0_with_info) p2
	with Contradiction ->
	  Settings.changed := true;
          current_pass_transfos := (SFindElseRemoved(pp)) :: (!current_pass_transfos);
	  Terms.oproc_from_desc Yield
      in
      let unique = (Terms.is_unique (Some(!whole_game)) l0 find_info == Unique) in
      let unique_no_abort = unique && (not (List.exists (fun (_,_,t,_) -> Terms.may_abort_counted (Some(!whole_game)) t) l0)) in
      let rec simplify_findl seen l1 = 
	match l1 with
	  [] -> []
	| (((bl, def_list, t, p1), _) as cur_branch)::l ->
	    begin
	    let l' = simplify_findl (cur_branch::seen) l in
	    let vars = List.map fst bl in
	    let repl_indices = List.map snd bl in
	    let cur_array_cond = repl_indices @ cur_array in
	    let vars_terms = List.map Terms.term_from_binder vars in
	    try
	      let def_list' = Facts.reduced_def_list (Incompatible.get_facts pp) def_list in
	      let (facts_def_list, pps_init_and_cond, def_vars_cond) = Facts.facts_from_defined pps def_vars current_history def_list' in
	      let true_facts_t = Facts.simplif_add_list (dependency_anal cur_array_cond) true_facts facts_def_list in
	      let def_vars_init_and_cond = Terms.union_binderref def_vars_cond def_vars in
	      let facts_from_elsefind_facts =
		if !Settings.elsefind_facts_in_simplify then
		  Facts_of_elsefind.get_facts_of_elsefind_facts (!whole_game) cur_array_cond true_facts_t pps_init_and_cond current_history def_vars_init_and_cond
		else
		  []
	      in
	      let true_facts_t = Facts.simplif_add_list (dependency_anal cur_array_cond) true_facts_t facts_from_elsefind_facts in
	      (* Set priorities of variables defined by this find, 
	         to orient rewrite rules preferably in the direction
	         b[..] -> t where b \in bl *)
	      incr current_max_priority;
	      List.iter (fun b -> 
		b.priority <- (!current_max_priority);
		priority_list := b :: (!priority_list)) vars;
	      let (t', facts_cond, pps_init_and_cond', def_vars_cond', elsefind_cond) =
		if Terms.check_simple_expanded t then 
		  let t' = if prove_true cur_array_cond true_facts_t t then Terms.make_true() else t in
		  (t', t' :: facts_from_elsefind_facts @ facts_def_list, pps_init_and_cond, def_vars_cond, [])
		else
                  let (sure_facts_t, sure_def_vars_t, elsefind_t) = Info_from_term.def_vars_and_facts_from_term (Some (!whole_game)) true true t in
		  let then_node = Facts.get_initial_history (get_pp p1) in
                  let (facts_def_vars_t, pps_init_and_cond', def_vars_t) = Facts.facts_from_defined pps_init_and_cond def_vars_init_and_cond then_node sure_def_vars_t in
		  (t, facts_def_vars_t @ sure_facts_t @ facts_from_elsefind_facts @ facts_def_list,
                   pps_init_and_cond', def_vars_t @ def_vars_cond, elsefind_t)
	      in

	      (* [facts_cond] contains the facts that hold,
		 using repl_indices as indices. We substitute vars from them to obtain
		 the facts that hold in the then branch.
		 Same substitution for the dependency info. *)
	      let facts_cond' = List.map (Terms.subst repl_indices vars_terms) facts_cond in
	      let elsefind_cond' = List.map (Terms.subst_else_find repl_indices vars_terms) elsefind_cond in
	      let tf' =
		(* When the find is Unique, I know that the other branches fail,
		   so I can add the corresponding elsefind facts *)
		if unique then 
		  Facts.add_elsefind (dependency_anal cur_array) def_vars true_facts (List.rev_append seen l)
		else
		  true_facts
	      in
	      let tf' = Terms.add_else_find elsefind_cond' tf' in
	      let tf' = Facts.update_elsefind_with_def vars tf' in
	      let tf' = Facts.simplif_add_list (dependency_anal cur_array) tf' facts_cond' in

	      (* Check that the "defined" conditions can hold,
		 if not remove the branch *)
	      (* [def_vars_cond] contains the variables that are certainly defined 
		 using repl_indices as indices. We substitute vars from them to obtain
		 the variables certainly defined in the then branch. *)
	      let def_vars_accu = Terms.subst_def_list repl_indices vars_terms def_vars_cond' in
	      let pps_init_and_cond_subst = Terms.subst_pps repl_indices vars_terms pps_init_and_cond' in
	      (* [Terms.def_list_at_pp_facts] adds facts inferred from the knowledge 
		 that the variables in [def_vars_accu] are defined
	         at the current program point *)
	      let cur_array_term = List.map Terms.term_from_repl_index cur_array in
	      let new_facts = Incompatible.ppl_before_pp_facts [] (get_pp p1, cur_array_term) pps_init_and_cond_subst in
	      let tf' = Facts.simplif_add_list (dependency_anal cur_array) tf' new_facts in
	      let def_vars' = 
		(* Using def_vars_accu instead of def_list' is more precise *)
		def_vars_accu @ def_vars
	      in
	      let tf' = Facts.convert_elsefind (dependency_anal cur_array) def_vars' tf' in
	      

	      let p1' = rec_simplif cur_array tf' p1 in

	      (* Update the defined condition *)
	      let (bl', def_list3, t', p1') as find_branch = 
		Facts.update_def_list_process (pps, def_vars, current_history) (Some def_vars_cond) bl def_list' t' p1' in
              if List.length def_list3 < List.length def_list then
                begin
                  Settings.changed := true;
                  current_pass_transfos := (SFindDeflist(pp, def_list, def_list3)) :: (!current_pass_transfos)
		end
              else if not (Facts.eq_deflists def_list def_list3)  then
		current_pass_transfos := (SFindDeflist(pp, def_list, def_list3)) :: (!current_pass_transfos);

              (* If the find is marked "unique", and we can prove that
	         the current branch succeeds, keep only that branch *)
              if (!Settings.unique_branch) &&
		(Terms.check_simple_expanded t')
	      then 
		try
		  Facts.branch_succeeds find_branch (dependency_anal cur_array_cond) true_facts def_vars;
		  find_branch :: l'
		with Facts.SuccessBranch(subst, keep_bl) ->
		  (* If the find has a single branch, which always succeeds, and the
	             indices defined by the find are not used, we can remove
	             the find, keeping only its then branch *)
		  if (unique_no_abort ||
		       ((Terms.is_not_unique_to_prove find_info) && (* the transformation is incorrect with UniqueToProve, even if there is a single branch: that branch may have several successful choices, and the find would abort in this case *)
		        (List.length l0 = 1(* there is a single branch, and its condition is a simple term, so it does not abort*)))) &&
		    (not (List.exists (fun b -> Array_ref.has_array_ref_q b (!whole_game).current_queries || Terms.refers_to_oprocess b p1') (List.map fst bl'))) then
		    begin
		      let def_list4 = Facts.filter_deflist_indices bl' def_list3 in
		      if (bl' != []) && (is_yield p2) && (def_list4 != []) && (List.length l0 = 1) 
                          (* When p2.p_desc != Yield or def_list4 == [] or List.length l0 > 1, the change is recorded below *) then
			begin
			  Settings.changed := true;
			  current_pass_transfos := (SFindSingleBranch(pp,(bl', def_list3, t', DProcess p1'))) :: (!current_pass_transfos);
			end;
		      raise (OneBranchProcess([], def_list4, Terms.make_true(), p1'))
		    end
		  else if not unique_no_abort then 
		    find_branch :: l' 
		  else
	            begin
		      (* Subst is a substitution for replication indices,
		         compute the substitution for the corresponding variables *)
		      let subst_repl_indices_source = List.map (fun (_,b,_) -> b) subst in
		      let subst_repl_indices_target = List.map (fun (_,_,b_im) -> b_im) subst in
		      let subst = List.map (fun (b, _, b_im) -> 
			(b, Terms.subst repl_indices vars_terms b_im)
			  ) subst 
		      in
		      if List.exists (fun (b, b_im) -> 
			(List.exists (fun (b', b_im') -> Terms.refers_to b b_im') subst)
			  ) subst
		      then raise (OneBranchProcess(find_branch));
		      if subst != [] then 
			begin
			  Settings.changed := true;
			  current_pass_transfos := (SFindIndexKnown(pp, (bl, def_list, t, DNone(*Not used*)), subst)) :: (!current_pass_transfos)
			end;
		      let def_list_tmp = ref [] in
		      List.iter (fun br ->
			Terms.get_deflist_subterms def_list_tmp 
			  (Terms.subst subst_repl_indices_source subst_repl_indices_target (Terms.term_from_binderref br))) def_list3;
		      let def_list3 = !def_list_tmp in 
		      let t' = Terms.update_args_at_creation ((List.map snd keep_bl) @ cur_array) 
			  (Terms.subst subst_repl_indices_source subst_repl_indices_target t') in
		      let p1' = Facts.add_let (Terms.subst_oprocess3 subst p1') subst in
		      raise (OneBranchProcess(keep_bl, def_list3, t', p1'))
		    end
	      else
		find_branch :: l'

	      (*let t_or_and = Terms.or_and_form t' in
	      simplify_find true_facts' l' bl def_list' t_or_and p1 *)
	    with Contradiction ->
	      if Terms.may_abort_counted (Some(!whole_game)) t then
		begin
		  (* The test may abort, we cannot remove it *)
		  if not (is_yield p1) then
		    begin
		      Settings.changed := true;
		      current_pass_transfos := (SFindBranchNotTaken(pp,(bl, def_list, t, DNone(*Not needed*)))) :: (!current_pass_transfos)
		    end;
		  (bl, def_list, t, Terms.oproc_from_desc Yield) :: l'
		end
	      else
		begin
		  Settings.changed := true;
		  current_pass_transfos := (SFindBranchRemoved(pp,(bl, def_list, t, DNone(*Not needed*)))) :: (!current_pass_transfos);
		  l'
		end
	    end
      in
      try
	let l0' = simplify_findl [] l0_with_info in
	if l0' == [] then
	  begin
	    Settings.changed := true;
	    current_pass_transfos := (SFindRemoved(pp)) :: (!current_pass_transfos);
	    p2'
	  end
	else
	  begin
	    if (p2'.p_desc == Yield) &&
	      (List.for_all (fun (bl,_,t,p1) ->
		(p1.p_desc == Yield) &&
		(not (Terms.may_abort_counted (Some(!whole_game)) t)) &&
		(not (List.exists (fun b -> Array_ref.has_array_ref_q b (!whole_game).current_queries) (List.map fst bl)))
		  ) l0') &&
	      (Terms.is_not_unique_to_prove find_info)
	    then
	      begin
		Settings.changed := true;
		current_pass_transfos := (SFindRemoved(pp)) :: (!current_pass_transfos);
		Terms.oproc_from_desc Yield
	      end
	    else
	      let find_info = Terms.is_unique (Some(!whole_game)) l0' find_info in
	      Terms.oproc_from_desc (Find(l0', p2', find_info))
	  end
      with OneBranchProcess(find_branch) ->
	match find_branch with
	  ([],[],t1,p1) -> 
	    Settings.changed := true;
	    current_pass_transfos := (SFindSingleBranch(pp,([],[],t1,DProcess p1))) :: (!current_pass_transfos);
	    p1
	| (bl,def_list,t1,p1) ->
	    (* the else branch of the find will never be executed *)
	    if (List.length l0 > 1) || (not (is_yield p2)) then 
	      begin
		Settings.changed := true;
		current_pass_transfos := (SFindSingleBranch(pp,(bl,def_list,t1,DProcess p1))) :: (!current_pass_transfos);
	      end;
	    Terms.oproc_from_desc (Find([find_branch], Terms.oproc_from_desc Yield, find_info))
    with Contradiction ->
      (* The whole Find will never be executed *)
      Terms.oproc_from_desc Yield

	
let simplify_event rec_simplif cur_array true_facts t p = 
  match t.t_desc with
    FunApp(f,_) ->
      if not (Settings.event_occurs_in_queries_or_restrictions
                f (!whole_game).current_queries (!whole_game).restrictions) then
	rec_simplif cur_array true_facts p
      else
	Terms.oproc_from_desc (EventP(t, rec_simplif cur_array true_facts p))
  | _ ->
    Parsing_helper.internal_error "Events must be function applications"

let simplify_output rec_simplif cur_array true_facts tl p =
  (* Remove all "Elsefind" facts since variables may be defined 
     between the output and the following input *)
  let (subst, facts, _) = true_facts in
  let true_facts' = (subst, facts, []) in
  Terms.oproc_from_desc 
    (Return(tl, rec_simplif cur_array true_facts' p))


(* Expand term to process *)

let rec expand_term cur_array true_facts t context =
  let expand_term_rec cur_array true_facts t =
    expand_term  cur_array true_facts t context
  in
  match t.t_desc with
    Var(b,l) ->
      expand_term_list cur_array true_facts  l
	(fun cur_array true_facts li ->
	  context cur_array true_facts (Terms.build_term t (Var(b,li))))
  | ReplIndex _ -> context cur_array true_facts t
    (* optimize the expansion of && and ||:
       when the first argument is false (resp. true), 
       I do not need to compute the other one. *)
  | FunApp(f, [t1;t2]) when f == Settings.f_and ->
     expand_term cur_array true_facts t1 (fun cur_array true_facts t1' ->
       if Terms.is_false t1' then
	 if Array_ref.no_effect (!whole_game) t2 then
           context cur_array true_facts t1'
	 else
	   expand_term cur_array true_facts t2 (fun cur_array true_facts t2' ->
	     context cur_array true_facts t1')
       else if Terms.is_true t1' then
         expand_term_rec cur_array true_facts t2
       else
	 expand_term cur_array true_facts t2 (fun cur_array true_facts t2' ->
           if Terms.is_false t2' then
             context cur_array true_facts t2'
           else if Terms.is_true t2' then
             context cur_array true_facts t1'
           else
	     context cur_array true_facts (Terms.build_term t (FunApp(f,[t1';t2'])))))
  | FunApp(f, [t1;t2]) when f == Settings.f_or ->
     expand_term cur_array true_facts t1 (fun cur_array true_facts t1' ->
       if Terms.is_true t1' then
	 if Array_ref.no_effect (!whole_game) t2 then
           context cur_array true_facts t1'
	 else
	   expand_term cur_array true_facts t2 (fun cur_array true_facts t2' ->
	     context cur_array true_facts t1')
       else if Terms.is_false t1' then
         expand_term_rec cur_array true_facts t2
       else
	 expand_term cur_array true_facts t2 (fun cur_array true_facts t2' ->
           if Terms.is_true t2' then
             context cur_array true_facts t2'
           else if Terms.is_false t2' then
             context cur_array true_facts t1'
           else
	     context cur_array true_facts (Terms.build_term t (FunApp(f,[t1';t2'])))))
  | FunApp(f,l) ->
      expand_term_list cur_array true_facts l
	(fun cur_array true_facts li ->
	  context cur_array true_facts (Terms.build_term t (FunApp(f,li))))
  | TestE(t1,t2,t3) ->
      expand_term cur_array true_facts t1
	(fun cur_array true_facts t1i ->
	  (* Equivalent to Test(t1i,  t2, t3) with simplification
	     and expansion of t2 and t3 *)
	  simplify_if expand_term_rec (DTerm t) cur_array true_facts t1i t2 t3)

  | LetE(pat, t1, t2, topt) ->
      let expand_term_opt_rec cur_array true_facts = function
	  None -> Terms.oproc_from_desc Yield
	| Some t3 -> expand_term cur_array true_facts t3 context
      in
      expand_term cur_array true_facts t1 (fun cur_array true_facts t1i ->
	expand_pat cur_array true_facts pat (fun cur_array true_facts pati ->
	  (* Equivalent to Let(pati, t1i, t2, topt) with simplification
	     and expansion of t2 and topt *)
	    simplify_let  expand_term_rec expand_term_opt_rec
	    is_yield_term_opt get_loc_term_opt (DTerm t) cur_array true_facts pati t1i t2 topt))

  | FindE(l0, t3, find_info) ->
      let rec expand_cond_find_list cur_array true_facts l context =
	match l with
	  [] -> context cur_array true_facts []
	| ((bl, def_list, t1, t2)::restl) ->
	    List.iter check_no_ifletfind_br def_list;
                  (* I move something outside a condition of
                     "find" only when bl and def_list are empty.  
                     I could be more precise, I would need to
                     check not only that what I move out does not
                     refer to the indices of "find", but also that it
                     is does not refer to the variables in the
                     "defined" condition---otherwise, some variable
                     accesses may not be defined after the
                     transformation

		     Moving event_abort outside the condition would also
		     be problematic because in case there are several
		     event_abort in the conditions, it would execute the
		     first one in the order of the list instead of one
		     chosen randomly. *)
            if bl != [] || def_list != [] || Terms.may_abort t1 then
	      expand_cond_find_list cur_array true_facts restl (fun cur_array true_facts li ->
		context cur_array true_facts ((bl, def_list, local_final_pseudo_expand  cur_array true_facts t1, t2)::li))
	    else
	      expand_term cur_array true_facts t1 (fun cur_array true_facts t1i ->
		 expand_cond_find_list cur_array true_facts restl (fun cur_array true_facts li -> context cur_array true_facts ((bl, def_list, t1i, t2)::li)))
      in
      expand_cond_find_list cur_array true_facts l0 (fun cur_array true_facts l1i ->
	(* Equivalent to Find(l1i, t3, find_info) after expansion
	   of the results in l1i and of t3 *)
	simplify_find expand_term_rec is_yield_term get_loc_term (fun t -> DTerm t) (DTerm t) cur_array true_facts
	   l1i t3 find_info)
  | ResE(b, t) ->
      (* Equivalent to Restr(b, t) after simplification and expansion
	 of t *)
      simplify_restr expand_term_rec cur_array true_facts b t
  | EventAbortE(f) ->
      (* The event is expanded to a process that stops just after the event.
	 Events in terms are used only in the RHS of equivalences, and 
	 one includes their probability of execution in the probability of
	 breaking the protocol. *)
      Terms.oproc_from_desc (EventAbort f)
  | EventE(t,p) ->
      simplify_event expand_term_rec cur_array true_facts t p
  | GetE _ | InsertE _ ->
      Parsing_helper.internal_error "Get/Insert should not appear in Transf_expand.expand_term"

and expand_term_list cur_array true_facts l context =
  match l with
    [] -> context cur_array true_facts []
  | (a::l) -> 
      expand_term cur_array true_facts a (fun cur_array true_facts a' ->
	expand_term_list  cur_array true_facts l (fun cur_array true_facts l' ->
	  context cur_array true_facts (a'::l')))

and expand_pat cur_array true_facts pat context =
  match pat with
    PatVar b -> context cur_array true_facts (PatVar b)
  | PatTuple (ft,l) ->
      expand_pat_list  cur_array true_facts l (fun cur_array true_facts li ->
	context cur_array true_facts (PatTuple (ft,li)))
  | PatEqual t ->
      expand_term cur_array true_facts t (fun cur_array true_facts ti ->
	context cur_array true_facts (PatEqual ti))

and expand_pat_list  cur_array true_facts l context =
  match l with
    [] -> context cur_array true_facts []
  | (a::l) -> 
      expand_pat  cur_array true_facts a (fun cur_array true_facts a' ->
	expand_pat_list  cur_array true_facts l (fun cur_array true_facts l' ->
	  context cur_array true_facts (a'::l')))


(* Expand process to process *)

let rec expand_process cur_array true_facts p' = 
  match p'.i_desc with
    Nil -> Terms.iproc_from_desc Nil
  | Par(p1,p2) ->
      Terms.iproc_from_desc  (Par(expand_process cur_array true_facts p1,
				  expand_process cur_array true_facts p2))
  | Repl(b,p) ->
      Terms.iproc_from_desc (Repl(b, expand_process (b::cur_array) true_facts p))
  | OracleDecl(o,patl,p) ->
      begin
	match true_facts with
	  (_,_,[]) -> ()
	| _ -> Parsing_helper.internal_error "There should be no elsefind facts at inputs"
      end;
      if List.exists need_expand_pat patl then
        begin
	  let patl', p' = Terms.make_var_pats cur_array patl p in
          Terms.iproc_from_desc (OracleDecl(o,patl',
	    expand_oprocess cur_array true_facts p'))
	  (* The changes in the "let"s introduced by [make_var_pats] may
             not be properly localised *)
	end
      else
        Terms.iproc_from_desc (OracleDecl(o,patl,
	  expand_oprocess cur_array true_facts p))

and expand_oprocess cur_array true_facts p =
  let expand_oprocess' = expand_oprocess in
  match p.p_desc with 
    Yield -> Terms.oproc_from_desc Yield
  | EventAbort f -> Terms.oproc_from_desc (EventAbort f)
  | Restr(b,p) ->
      (* Equivalent to Restr(b, p) *)
      simplify_restr expand_oprocess' cur_array true_facts b p
  | Test(t,p1,p2) ->
      if need_expand t then
	begin
	  Settings.changed := true;
	  expand_term cur_array true_facts t (fun cur_array true_facts ti ->
	    simplify_if expand_oprocess' (DProcess p) cur_array true_facts ti p1 p2)
	end
      else
	simplify_if expand_oprocess' (DProcess p) cur_array true_facts t p1 p2
  | Find(l0, p2, find_info) ->
      let rec expand_find_list cur_array true_facts next_f = function
	  [] -> next_f cur_array true_facts []
	| ((bl, def_list, t, p1)::rest_l) ->
	    List.iter check_no_ifletfind_br def_list;
	    if need_expand t then
	      begin
		Settings.changed := true;
		if bl != [] || def_list != [] || Terms.may_abort t then
		  expand_find_list cur_array true_facts (fun cur_array true_facts rest_l' ->
		    next_f cur_array true_facts ((bl, def_list, local_final_pseudo_expand cur_array true_facts t, p1)::rest_l')) rest_l
		else
		  expand_term cur_array true_facts t (fun cur_array true_facts ti ->
		    expand_find_list cur_array true_facts (fun cur_array true_facts rest_l' ->
		      next_f cur_array true_facts ((bl, def_list, ti, p1)::rest_l')) rest_l)
	      end
	    else
	      expand_find_list cur_array true_facts (fun cur_array true_facts rest_l' ->
		next_f cur_array true_facts ((bl, def_list, t, p1)::rest_l')) rest_l
      in
      expand_find_list cur_array true_facts (fun cur_array true_facts l0' ->
	simplify_find expand_oprocess' is_yield_proc get_loc_proc (fun p -> DProcess p) (DProcess p)
	  cur_array true_facts l0' p2 find_info) l0
  | Return(tl,p) ->
      if (List.exists need_expand tl) then
	begin
	  Settings.changed := true;
	  expand_term_list cur_array true_facts tl (fun cur_array true_facts tli ->
	      simplify_output expand_process cur_array true_facts tli p)
	end
      else
	simplify_output expand_process cur_array true_facts tl p
  | Let(pat,t,p1,p2) ->
      if (need_expand_pat pat) || (need_expand t) then
	begin
	  Settings.changed := true;
	  expand_term cur_array true_facts t (fun cur_array true_facts ti ->
	    expand_pat cur_array true_facts pat (fun cur_array true_facts pati ->
	      simplify_let expand_oprocess' expand_oprocess' is_yield_proc get_loc_proc (DProcess p)
		cur_array true_facts pati ti p1 p2))
	end
      else
	simplify_let expand_oprocess' expand_oprocess' is_yield_proc get_loc_proc (DProcess p)
	  cur_array true_facts pat t p1 p2
  | EventP(t,p) ->
      if need_expand t then
	begin
	  Settings.changed := true;
	  expand_term cur_array true_facts t (fun cur_array true_facts ti ->
	    simplify_event expand_oprocess' cur_array true_facts ti p)
	end
      else
	simplify_event expand_oprocess' cur_array true_facts t p
  | Get _ | Insert _ | NewTable _ ->
      Parsing_helper.internal_error "Get/Insert should not appear here"


let expand_main g =
  reset [] g;
  current_pass_transfos := [];
  let g_proc = Terms.get_process g in
  Array_ref.array_ref_process g_proc;
  Improved_def.improved_def_game None g;
  let p' = expand_process [] ([],[],[]) g_proc in
  let current_transfos = !current_pass_transfos in
  current_pass_transfos := [];
  Array_ref.cleanup_array_ref();
  let proba = Depanal.final_add_proba() in
  Improved_def.empty_improved_def_game g;
  whole_game := Terms.empty_game;
  (Terms.build_transformed_game ~expanded: true p' g,
   proba, [DExpandIfFind(current_transfos)])
    
(* Main function for expansion of if and find
   Call auto_sa_rename after expand_process, so that facts associated with 
   nodes are emptied, and variables defined in
   conditions of find have a single definition. 
   Expansion is called only when there is no advice pending, so we can simply 
   ignore the list of done SArenamings.
*)

let expand_process g =
  if g.expanded then
    begin
      print_string "Game already expanded. "; flush stdout;
      (g, [], [])
    end
  else
    let (g2, proba2, ins2) = expand_main g in
    if !Settings.changed then 
      begin
	let (g3, proba3, ins3) = Transf_auto_sa_rename.auto_sa_rename g2 in
	(g3, proba3 @ proba2, ins3 @ ins2)
      end
    else
      begin
	(* Since we did not change anything, the initial game was already expanded *)
	g.expanded <- true;
	(g, [], [])
      end

    
