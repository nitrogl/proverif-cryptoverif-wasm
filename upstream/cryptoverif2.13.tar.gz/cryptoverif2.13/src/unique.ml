(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Types
open Parsing_helper

(* [infer_unique g cur_array simp_facts def_vars dep_info current_history l0' find_info]
   tries to prove that there is single possible choice in the find with
   branches [l0'], and if so it returns the modified [find_info] equal to
   [Unique]. It also returns a boolean set to true when a real change has been made.

   [g] is the current game
   [cur_array] the current replication indices
   [simp_facts] the facts known to hold at the current program point
   [def_vars] the variables known to be defined
   [dep_info] is a dependency analysis
   [current_history] is the known history at the find, at which [def_list]
   is tested (may be returned by [Facts.get_initial_history]) *)

let prove_unique g cur_array simp_facts pps def_vars dep_info node l0 =
  let l0' = List.map (fun (bl, def_list1, t1, _) ->
    let (sure_facts, defined_vars, _) = Info_from_term.def_vars_and_facts_from_term (Some g) g.expanded true t1 in
    (bl, defined_vars @ def_list1, sure_facts)
      ) l0
  in
  let unique_branch (bl, def_list1, tl1) =
    let repl_index1 = List.map snd bl in
    let repl_index1_term = List.map Terms.term_from_repl_index repl_index1 in
    let repl_index2 = List.map Terms.new_repl_index repl_index1 in
    let repl_index2_term = List.map Terms.term_from_repl_index repl_index2 in
    let def_list2 = Terms.subst_def_list repl_index1 repl_index2_term def_list1 in
    let tl2 = List.map (Terms.subst repl_index1 repl_index2_term) tl1 in
    try 
      let (facts_def_list1, pps1, def_vars1) = Facts.facts_from_defined pps def_vars node def_list1 in
      let (facts_def_list2, pps2, def_vars2) = Facts.facts_from_defined pps1 def_vars node def_list2 in
      let def_vars = Terms.union_binderref (Terms.union_binderref def_vars def_vars1) def_vars2 in
      let diff_ri1_ri2 = Terms.make_or_list (List.map2 Terms.make_diff repl_index1_term repl_index2_term) in
      let simp_facts = Facts.simplif_add_list dep_info simp_facts (diff_ri1_ri2 :: tl2 @ tl1 @ facts_def_list1 @ facts_def_list2) in
      let new_facts = Facts_of_elsefind.get_facts_of_elsefind_facts g cur_array simp_facts pps2 node def_vars in
      let _ = Facts.simplif_add_list dep_info simp_facts new_facts in
      false
    with Contradiction -> true
  in
  let incompatible_branch (bl1, def_list1, tl1) (bl2, def_list2_orig, tl2_orig) =
    let repl_index2_orig = List.map snd bl2 in
    let repl_index2 = List.map Terms.new_repl_index repl_index2_orig in
    let repl_index2_term = List.map Terms.term_from_repl_index repl_index2 in
    let def_list2 = Terms.subst_def_list repl_index2_orig repl_index2_term def_list2_orig in
    let tl2 = List.map (Terms.subst repl_index2_orig repl_index2_term) tl2_orig in
    try 
      let (facts_def_list1, pps1, def_vars1) = Facts.facts_from_defined pps def_vars node def_list1 in
      let (facts_def_list2, pps2, def_vars2) = Facts.facts_from_defined pps1 def_vars node def_list2 in
      let def_vars = Terms.union_binderref (Terms.union_binderref def_vars def_vars1) def_vars2 in
      let simp_facts = Facts.simplif_add_list dep_info simp_facts (tl2 @ tl1 @ facts_def_list1 @ facts_def_list2) in
      let new_facts = Facts_of_elsefind.get_facts_of_elsefind_facts g cur_array simp_facts pps2 node def_vars in
      let _ = Facts.simplif_add_list dep_info simp_facts new_facts in
      false
    with Contradiction -> true
  in
  (List.for_all unique_branch l0') &&
  (let rec incompatible_branches = function
    | [] | [_] -> true
    | branch1 :: rest -> 
        (List.for_all (incompatible_branch branch1) rest) &&
        (incompatible_branches rest)
  in
  incompatible_branches l0')

(* Prove that the inserted find[unique] are really unique *)

let whole_game = ref Terms.empty_game
let initial = ref false
let transfo_done = ref []
    
let prove_unique1 pp l0 find_info ext =
  match Terms.is_unique (Some (!whole_game)) l0 find_info with
  | (UniqueToProve e) as find_info' ->
      begin
	let proved() =
	  (*TODO when we insert a find[unique], the program point pp
	    in fact refers to a game that is not displayed*)
	  transfo_done :=  (DProveUnique pp) ::(!transfo_done);
	  Unique
	in
	try 
	  let cur_array =
	    match Incompatible.get_facts pp with
	    | Some ppi -> ppi.ppi_cur_array
	    | None -> failwith "(missing information, should not happen)"
	  in
	  let (true_facts1, pps, def_vars, current_history) = Facts.get_facts_at pp in
	  let true_facts = Facts.simplif_add_list Facts.no_dependency_anal Terms.simp_facts_id true_facts1 in
	  if prove_unique (!whole_game) cur_array true_facts pps def_vars Facts.no_dependency_anal current_history l0 then
	    proved()
	  else
	    failwith ""
	with
	| Failure comment ->
	    begin
	      if !initial then
		input_warning ("The initial game contains a find[unique] or get[unique] but I could not prove that it is really unique"^comment^". I will try to prove it unique later.") ext
	      else
		input_warning ("You inserted a find[unique] or the initial game contains a find[unique] or get[unique] but I could not prove yet that it is really unique"^comment^". I will try to prove it unique later.") ext
	    end;
	    find_info'
	| Contradiction ->
	    (* The find[unique] is unreachable, I can consider it unique without problem *)
	    proved()
      end;
  | find_info -> find_info
	
let rec prove_uniquet t =
  match t.t_desc with
    ResE(b,p) ->
      Terms.build_term t (ResE(b, prove_uniquet p))
  | EventE(t1,p) ->
      Terms.build_term t (EventE(prove_uniquet t1, prove_uniquet p))
  | GetE _ | InsertE _ ->
      Parsing_helper.internal_error "get, insert should not occur as term"
  | TestE(t1,t2,t3) ->
      let t1' = prove_uniquet t1 in
      let t2' = prove_uniquet t2 in
      let t3' = prove_uniquet t3 in
      Terms.build_term t (TestE(t1',t2',t3'))
  | LetE(pat,t1,t2,topt) ->
      let pat' = prove_uniquepat pat in
      let t1' = prove_uniquet t1 in
      let t2' = prove_uniquet t2 in
      let topt' = 
	match topt with
	  None -> None
	| Some t3 -> Some (prove_uniquet t3)
      in
      Terms.build_term t (LetE(pat',t1',t2',topt'))
  | FindE(l0,t3, find_info) ->
      let find_info' = prove_unique1 (DTerm t) l0 find_info t.t_loc in
      let t3' = prove_uniquet t3 in
      let l0' = List.map (fun (bl, def_list, tc, p) ->
	let p' = prove_uniquet p in
	let tc' = prove_uniquet tc in
	(bl, def_list, tc', p')
	  ) l0 
      in
      Terms.build_term t (FindE(l0',t3',find_info'))
  | Var(b,l) ->
      Terms.build_term t (Var(b, List.map prove_uniquet l))
  | FunApp(f,l) ->
      Terms.build_term t (FunApp(f, List.map prove_uniquet l))      
  | ReplIndex _ | EventAbortE _ -> t 

and prove_uniquepat = function
  | PatVar b -> PatVar b
  | PatTuple(f,l) -> PatTuple(f, List.map prove_uniquepat l)
  | PatEqual t -> PatEqual (prove_uniquet t)
	
let rec prove_uniquei p =
    Terms.iproc_from_desc_loc p (
    match p.i_desc with
      Nil -> Nil
    | Par(p1,p2) -> 
	Par(prove_uniquei p1,
	    prove_uniquei p2)
    | Repl(b,p) ->
	Repl(b, prove_uniquei p)
    | OracleDecl(o, patl, p) ->
	OracleDecl(o, List.map prove_uniquepat patl, prove_uniqueo p))

and prove_uniqueo p =
  Terms.oproc_from_desc_loc p (
    match p.p_desc with
      Yield -> Yield
    | EventAbort f -> EventAbort f
    | Restr(b,p) -> Restr(b, prove_uniqueo p)
    | Test(t,p1,p2) -> Test(prove_uniquet t,
			    prove_uniqueo p1,
			    prove_uniqueo p2)
    | Find(l0,p2,find_info) ->
	let find_info' = prove_unique1 (DProcess p) l0 find_info p.p_loc in
	Find(List.map (fun (bl,def_list,t,p1) ->
	       (bl,def_list,prove_uniquet t,
	        prove_uniqueo p1)) l0,
	     prove_uniqueo p2, find_info')
    | Return(tl,p) ->
	Return(List.map prove_uniquet tl, prove_uniquei p)
    | Let(pat,t,p1,p2) ->
	Let(prove_uniquepat pat,
	    prove_uniquet t,prove_uniqueo p1,
	    prove_uniqueo p2)
    | EventP(t,p) ->
	EventP(prove_uniquet t, prove_uniqueo p)
    | Get _ | Insert _ | NewTable _ ->
	Parsing_helper.internal_error "Get/Insert should not appear here")

let prove_unique_game initial_game g =
  Terms.move_occ_game g;
  let g_proc = Terms.get_process g in
  whole_game := g;
  initial := initial_game;
  transfo_done := [];
  Array_ref.array_ref_process g_proc;
  Improved_def.improved_def_game None g;
  Depanal.reset [] g;
  let cleanup() =
    Array_ref.cleanup_array_ref();
    Improved_def.empty_improved_def_game g;
    whole_game := Terms.empty_game;
    transfo_done := []
  in
  let p' =
    try
      prove_uniquei g_proc
    with Error(mess, extent) ->
      cleanup();
      raise (Error(mess, extent))
  in
  let g' = Terms.build_transformed_game p' g in
  let transfos = !transfo_done in
  cleanup();
  match transfos with
  | [] -> (g, [], [])
  | _ ->
      Settings.changed := true;
      (g', Depanal.final_add_proba(), transfos)
    
let infer_unique g cur_array simp_facts pps def_vars dep_info node l0' find_info =
  let prove() =
    if prove_unique g cur_array simp_facts pps def_vars dep_info node l0' then
      (Unique, true)
    else
      (find_info, false)
  in
  match Terms.is_unique (Some g) l0' find_info with
  | Unique -> (Unique, false)
  | UniqueToProve _ -> prove()
  | Nothing ->
      if !Settings.infer_unique then
	prove()
      else
	(find_info, false)
         
