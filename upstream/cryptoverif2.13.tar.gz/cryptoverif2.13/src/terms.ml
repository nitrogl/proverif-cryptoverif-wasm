(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Types
open Parsing_helper

let simp_facts_id = ([],[],[])
let try_no_var_id t = t

let add_else_find else_find' (facts, subst, else_find) =
  (facts, subst, else_find' @ else_find)

let collector_set_no_info collector =
  match collector with
  | None -> ()
  | Some coll_ref ->
      coll_ref := [CollectorNoInfo]

let is_collector_no_info = function
  | [CollectorNoInfo] -> true
  | _ -> false

let collector_useless = function
  | None -> true
  | Some coll_ref ->
      is_collector_no_info (!coll_ref)
	
let add_to_collector collector elem =
  match collector with
  | None -> ()
  | Some coll_ref ->
      if not (is_collector_no_info (!coll_ref)) then
	coll_ref := elem :: (!coll_ref)

(* [for_all_collector collector f l] computes [List.for_all f l]
   but applies [f] to all elements of [l] in case [collector] 
   is not [None] *)
			    
let rec for_all_collector collector f = function
  | [] -> true
  | a::l ->
      let av = f a in
      if av = false && collector_useless collector then false else
      let lv = for_all_collector collector f l in
      av && lv

(* Returns a list containing n times element x *)

let rec repeat n x =
  if n = 0 then [] else x :: (repeat (n-1) x)

(* Returns l without its n first elements *)

let rec skip n l = 
  try
    if n = 0 then l else skip (n-1) (List.tl l)
  with Failure _ ->
    failwith "Terms.skip"

(* Split l into two lists, first its n first elements, second
   the remaining of l *)

let rec split n l = 
  if n = 0 then ([],l) else
  match l with
    [] -> Parsing_helper.internal_error "split"
  | (a::l') -> let l1,l2 = split (n-1) l' in (a::l1,l2)


(* Find x in list l and return its position *)

let rec find_in_list x = function
    [] -> raise Not_found
  | (a::l) -> if x == a then 0 else 1 + find_in_list x l

(* Take a suffix of length n *)

let lsuffix n l =
  try
    skip (List.length l - n) l
  with Failure _ ->
    failwith "Terms.lsuffix"

(* Remove a suffix of length n *)

let remove_suffix n l =
  let (res, _) = split (List.length l - n) l in
  res

(* [is_included_distinct eq l1 l2] returns true when [l1] is included 
   in [l2], considered as multisets. [eq] is the equality function 

   [remove_fail eq l1 l2] returns the list representing the multiset
   [l1] minus [l2]. [eq] is the equality function.
   [l2] must be included in [l1] (as multisets), otherwise, an assertion 
   fails *)

let rec remove_one eq idx = function
  | [] -> raise Not_found
  | a::l ->
      if eq a idx then l else
      a::(remove_one eq idx l)

let remove eq linit lrem =
  List.fold_left (fun accu i -> remove_one eq i accu) linit lrem  

let is_included_distinct eq lrem linit =
  try
    ignore (remove eq linit lrem);
    true
  with Not_found ->
    false

let remove_fail eq linit lrem =
  try
    remove eq linit lrem
  with Not_found -> assert false

(* [get_same eq f l] returns the result of [f x] for all [x] in the list [l],
   when [f x] has the same value for all such [x]. Otherwise, it raises 
   [Not_found]. [eq] is used to test equality of the results. *)

let rec get_same eq f = function
  | [] -> raise Not_found
  | [a] -> f a
  | a::l ->
      let x = get_same eq f l in
      if eq (f a) x then 
	x
      else
	raise Not_found
      
(** [assq_rest a l] returns the value associated with key [a] in the list of
   pairs [l], as well as the list of other elements of [l]. That is,
   [assq_rest a [ ...; (a,b); ...] = (b, lrest)]
   if [(a,b)] is the leftmost binding of [a] in list [l] and
   [lrest] is [l] with [(a,b)] removed.
   Raise [Not_found] if there is no value associated with [a] in the
   list [l]. Uses physical equality to compare keys. *)

let assq_rest x l =
  let rec aux seen x = function
    | [] -> raise Not_found
    | ((a,b) as elem)::l ->
	if a == x then (b, List.rev_append seen l) else aux (elem::seen) x l
  in
  aux [] x l 

(* [add_cur_array repl_opt cur_array] adds [repl_opt] to [cur_array] *) 
    
let add_cur_array repl_opt cur_array =
  match repl_opt with
  | Some repl -> repl::cur_array
  | None -> cur_array
    
(* [equiv_same_vars b b'] returns true when [b] and [b'] are
   considered matching variables in the left and right-hand sides
   of an equiv (same string name, same number, same type). *)

let equiv_same_vars b b' =
  (b.sname = b'.sname) &&
  (b.vname == b'.vname) &&
  (b.btype == b'.btype)
    
(* Addition of integers bounded by max_exp.
   The second argument must be >= 0, so that there is no overflow.  *)
	
let plus x y =
  if x >= Settings.max_exp - y (* x + y >= max_exp *) then Settings.max_exp else x + y
      
(* [sum_list f l] is the sum of [f x] for all [x] in [l],
   bounded by max_exp*)
	
let rec sum_list f = function
  | [] -> 0
  | a::l -> plus (f a) (sum_list f l) 

(* [max_list f l] is the maximum of [f x] for all [x] in [l].
   Assumes [f x >= 0]. *)

let rec max_list f = function
  | [] -> 0
  | a::lr -> max (f a) (max_list f lr)

let rec min_list f = function
  | [] -> max_int
  | a::l -> min (f a) (min_list f l)
    

let get_size_high ty =
  match ty.tsize with
  | Some (min, max) -> max
  | None -> Settings.max_exp

let get_size_low ty =
  match ty.tsize, ty.tpcoll with
  | Some (min, max), _ -> min
  | None, None -> 0
  | None, Some (ncoll_min, ncoll_max) -> ncoll_min (* The maximum probability of collision with a random element, 1/2^{pcoll estimate} is at least 1/|ty| = 1/2^{size estimate}, so pcoll estimate <= size estimate *)

(* Note: using just - x to take the opposite of x requires
   min_exp = -max_exp *)
	
let get_pcoll1_high ty =
  match ty.tpcoll with
  | Some (min, max) -> - min (* The probability of collision is at most 2^{-min} *)
  | None -> 0 (* The probability is at most 1 = 2^0 *)

let get_pcoll1_low ty =
  match ty.tsize, ty.tpcoll with
  | _, Some (min, max) -> - max (* The probability of collision is at least 2^{-max} *)
  | None, None -> Settings.min_exp
  | Some (nsize_min, nsize_max), None -> - nsize_max

let get_pcoll2_high = get_pcoll1_high (* The probability of collision Pcoll2rand(ty) is at most Pcoll1rand(ty) *)

let get_pcoll2_low ty =
  match ty.tsize with
  | None -> Settings.min_exp
  | Some (nsize_min, nsize_max) -> - nsize_max
     (* The probability Pcoll2rand(ty) is at least 1/|ty| = 2^{-nsize}.
        Let Pr[X = a] = 1/|ty| + p_a for all a \in ty.
        sum_{a \in ty} p_a = 0 because sum_{a \in ty} Pr[X = a] = 1.
	Pcoll2rand(ty) = sum_{a \in ty} Pr[X = a]^2
                       = sum_{a \in ty} (1/|ty|+p_a)^2
                       = sum_{a \in ty} (1/|ty|^2 + 2 p_a/|ty| + p_a^2)
                       = 1/|ty| + 2/|ty|sum_{a \in ty} p_a + \sum_{a \in ty} p_a^2
                       = 1/|ty| + \sum_{a \in ty} p_a^2 >= 1/|ty|     *)
	
(* Adds an element if it is not already in (for physical equality) *)

let addq accu b =
  if List.memq b accu then accu else b::accu

let addq_ref accu b =
  if not (List.memq b (!accu)) then accu := b::(!accu)
					   
(* Compute intersections *)

let mem eqtest a l = List.exists (eqtest a) l

let intersect eqtest l1 l2 = List.filter (fun a2 -> mem eqtest a2 l1) l2

let rec intersect_list eqtest = function
    [] -> raise Contradiction
  | [a] -> a
  | (a::l) -> intersect eqtest a (intersect_list eqtest l)

(* union eqtest l1 l2 = l1 union l2 *)

let rec union eqtest l1 = function
    [] -> l1
  | (a::l) -> 
      if List.exists (eqtest a) l1 then
	union eqtest l1 l
      else
	a::(union eqtest l1 l)
	  
(* [map_union eqtest f l] = union of all [f a] for [a] in [l] *)

let rec map_union eqtest f = function
    [] -> []
  | (a::l) -> union eqtest (f a) (map_union eqtest f l)

(* [get_actual_equiv] converts an equivalence of type [equiv_gen]
   into one of type [equiv_nm] *)

let get_actual_equiv equiv =
  match equiv.eq_fixed_equiv, equiv.eq_name_mapping with
  | Some(lm,rm,p,opt2), Some nm ->
      (equiv.eq_name, lm, rm, p, equiv.eq_prio, equiv.eq_auto, opt2), nm
  | _ ->
      Parsing_helper.internal_error "get_actual_equiv"
	
(* Iterators *)

(* Exists *)
	
let exists_subterm f f_def_list f_pat t =
  match t.t_desc with
    Var(_,tl) | FunApp(_,tl) ->
      List.exists f tl
  | ReplIndex _ -> false
  | TestE(t1,t2,t3) ->
      (f t1) ||
      (f t2) ||
      (f t3)
  | FindE(l,t3,_) ->
      (f t3) ||
      (List.exists (fun (_,def_list,t1,t2) ->
	(f_def_list def_list) || (f t1)|| (f t2)) l)
  | LetE(pat,t1,t2,topt) ->
      (f_pat pat) ||
      (f t1) ||
      (f t2) ||
      (match topt with
	None -> false
      | Some t3 -> f t3)
  | ResE(_,t1) -> f t1
  | EventAbortE _ -> false
  | EventE(t1,p) ->
      (f t1) ||
      (f p)
  | InsertE(_,tl,p) ->
      (List.exists f tl) ||
      (f p)
  | GetE(_, patl, topt, p1, p2, _) ->
      (List.exists f_pat patl) ||
      (match topt with
	  None -> false
	| Some t -> f t) ||
      (f p1) ||
      (f p2)

let exists_subpat f f_pat = function
    PatVar _ -> false
  | PatTuple(_,l) -> List.exists f_pat l
  | PatEqual t -> f t

let exists_subiproc f f_input p =
  match p.i_desc with
    Nil -> false
  | Par(p1,p2) -> (f p1) || (f p2)
  | Repl(b,p) -> f p
  | OracleDecl(o,patl,p) -> 
      f_input o patl p

let exists_suboproc f f_term f_def_list f_pat f_iproc p =
  match p.p_desc with
    Yield | EventAbort _ -> false
  | Restr(_,p) -> f p
  | Test(t,p1,p2) -> (f_term t) || (f p1) ||
    (f p2)
  | Find(l0,p2, find_info) ->
      (List.exists (fun (bl,def_list,t,p1) ->
	(f_def_list def_list) ||
        (f_term t) || (f p1)) l0) || 
      (f p2)
  | Return(tl,p) ->
      (List.exists f_term tl) || (f_iproc p)
  | EventP(t,p) ->
      (f_term t) || (f p)
  | Let(pat,t,p1,p2) ->
      (f_term t) || (f_pat pat) || 
      (f p1) ||(f p2)
  | Get(tbl,patl,topt,p1,p2,_) ->
      (List.exists f_pat patl) || 
      (match topt with None -> false | Some t -> f_term t) || 
      (f p1) ||(f p2)
  | Insert(tbl,tl,p) ->
      (List.exists f_term tl) || (f p)
  | NewTable(tbl,p) -> f p

let exists_qterm f f_term = function
  | QEvent(_,t) -> f_term t
  | QTerm t -> f_term t
  | QNot t -> f t
  | QAnd(t1,t2) | QOr(t1,t2) ->
      f t1 || f t2
  | QExists(_,t) | QForall(_,t) -> f t
	
(* Iter *)

let iter_subterm f f_def_list f_pat t =
  match t.t_desc with
    Var(_,l) | FunApp(_,l) -> 
      List.iter f l
  | ReplIndex _ -> ()
  | TestE(t1,t2,t3) ->
      f t1;
      f t2;
      f t3
  | LetE(pat,t1, t2, topt) -> 
      f_pat pat; f t1;
      f t2; 
      begin
	match topt with
	  None -> ()
	| Some t3 -> f t3
      end
  | FindE(l0,t3,_) ->
      List.iter (fun (bl,def_list,t1,t2) ->
	f_def_list def_list;
	f t1;
	f t2
	      ) l0;
      f t3      
  | ResE(b,t) ->
      f t
  | EventAbortE _ -> ()
  | EventE(t,p) ->
      f t;
      f p
  | InsertE(_,tl,p) ->
      List.iter f tl;
      f p
  | GetE(_, patl, topt, p1, p2, _) ->
      List.iter f_pat patl;
      (match topt with
	  None -> ()
	| Some t -> f t);
      f p1;
      f p2
	
let iter_subpat f f_pat = function
    PatVar b -> ()
  | PatTuple (f,l) -> List.iter f_pat l
  | PatEqual t -> f t

let iter_subiproc f f_input p =
  match p.i_desc with
    Nil -> ()
  | Par(p1,p2) -> f p1; f p2
  | Repl(b,p) -> f p
  | OracleDecl(o,patl,p) -> 
      f_input o patl p
	
let iter_suboproc f f_term f_def_list f_pat f_iproc p =
  match p.p_desc with
    Yield | EventAbort _ -> ()
  | Restr(_,p) | NewTable(_,p) -> f p
  | Test(t,p1,p2) ->
      f_term t; f p1; f p2
  | Find(l0,p2, find_info) ->
      List.iter (fun (bl,def_list,t,p1) ->
	f_def_list def_list;
        f_term t; f p1) l0;
      f p2
  | Return(tl,p) ->
      List.iter f_term tl; f_iproc p
  | EventP(t,p) ->
      f_term t; f p
  | Let(pat,t,p1,p2) ->
      f_term t; f_pat pat;
      f p1; f p2
  | Get(tbl,patl,topt,p1,p2,_) ->
      List.iter f_pat patl;
      (match topt with None -> () | Some t -> f_term t);
      f p1; f p2
  | Insert(tbl,tl,p) ->
      List.iter f_term tl; f p

(* Map *)

let map_subterm f f_def_list f_pat t =
  match t.t_desc with
  | Var(b,l) -> Var(b, List.map f l)
  | ReplIndex i -> ReplIndex i
  | FunApp(fs,l) -> FunApp(fs, List.map f l)
  | TestE(t1,t2,t3) -> 
      let t1' = f t1 in
      let t2' = f t2 in
      let t3' = f t3 in 
      TestE(t1', t2', t3')
  | FindE(l0,t3, find_info) -> 
      let l0' = List.map (fun (bl,def_list,t1,t2) ->
	let def_list' = f_def_list def_list in
	let t1' = f t1 in
	let t2' = f t2 in
	(bl, def_list', t1', t2')) l0
      in
      let t3' = f t3 in
      FindE(l0', t3', find_info)
  | LetE(pat, t1, t2, topt) ->
      let t1' = f t1 in
      let pat' = f_pat pat in
      let t2' = f t2 in
      let topt' = match topt with
	None -> None
      | Some t3 -> Some (f t3)
      in
      LetE(pat', t1', t2', topt')
  | ResE(b,t) ->
      ResE(b, f t)
  | EventAbortE f -> EventAbortE f 
  | EventE(t,p) ->
      let t' = f t in
      let p' = f p in
      EventE(t', p')
  | GetE(tbl,patl,topt,p1,p2,find_info) -> 
      let patl' = List.map f_pat patl in
      let topt' = 
	match topt with 
	  Some t -> Some (f t) 
	| None -> None
      in
      let p1' = f p1 in
      let p2' = f p2 in	  
      GetE(tbl,patl',topt',p1', p2',find_info)
  | InsertE (tbl,tl,p) -> 
      let tl' = List.map f tl in
      let p' = f p in
      InsertE(tbl, tl', p')

let map_subpat f f_pat = function
    PatVar b -> PatVar b
  | PatTuple (fs,l) -> PatTuple(fs,List.map f_pat l)
  | PatEqual t -> PatEqual(f t)

let map_subiproc f f_input p =
  match p.i_desc with
    Nil -> Nil
  | Par(p1,p2) -> 
      let p1' = f p1 in
      let p2' = f p2 in
      Par(p1', p2')
  | Repl(b,p) -> Repl(b, f p)
  | OracleDecl(o,patl,p) ->
      let o',patl',p' = f_input o patl p in
      OracleDecl(o', patl', p')

let map_suboproc f f_term f_def_list f_pat f_iproc p =
  match p.p_desc with
  | Yield -> Yield
  | EventAbort f -> EventAbort f
  | Restr(b,p) -> Restr(b, f p)
  | Test(t,p1,p2) -> 
      let t' = f_term t in
      let p1' = f p1 in
      let p2' = f p2 in
      Test(t', p1', p2')
  | Find(l0, p2, find_info) -> 
      let l0' = List.map (fun (bl, def_list, t, p1) -> 
	let def_list' = f_def_list def_list in
	let t' = f_term t in
	let p1' = f p1 in
	(bl, def_list', t', p1')) l0
      in
      let p2' = f p2 in
      Find(l0', p2', find_info)
  | Let(pat,t,p1,p2) ->
      let t' = f_term t in
      let pat' = f_pat pat in
      let p1' = f p1 in
      let p2' = f p2 in	  
      Let(pat', t', p1', p2')
  | Return(tl,p) ->
      let tl' = List.map f_term tl in
      let p' = f_iproc p in
      Return(tl', p')
  | EventP(t,p) ->
      let t' = f_term t in
      let p' = f p in
      EventP(t', p')
  | Get(tbl,patl,topt,p1,p2,find_info) -> 
      let patl' = List.map f_pat patl in
      let topt' = 
	match topt with 
	  Some t -> Some (f_term t) 
	| None -> None
      in
      let p1' = f p1 in
      let p2' = f p2 in	  
      Get(tbl,patl',topt',p1', p2', find_info)
  | Insert (tbl,tl,p) -> 
      let tl' = List.map f_term tl in
      let p' = f p in
      Insert(tbl, tl', p')
  | NewTable(tbl,p) ->
      NewTable(tbl, f p)
	
(* Create an interval type from a parameter *)

module ParamHash =
  struct
    type t = param
    let equal = (==) (* using physical equality for parameters.
	                important because in Check.add_repl we may create
                        a fresh parameter with an already used name *)
    let hash = Hashtbl.hash
  end

module ParamHashtbl = Hashtbl.Make(ParamHash)
	
let type_for_param_table = ParamHashtbl.create 7

let type_for_param p =
  try 
    ParamHashtbl.find type_for_param_table p 
  with Not_found ->
    let t = { tname = "[1," ^ p.pname ^"]";
	      tcat = Interv p;
	      toptions = Settings.tyopt_BOUNDED;
	      tsize = Some (0, p.psize);
	      tpcoll = None;
              timplsize = None;
              tpredicate = None;
              timplname = None;
              tserial = None;
              tfstar_serial = None;
              trandom = None;
	      tequal = None }
    in
    ParamHashtbl.add type_for_param_table p t;
    t

(* Get a parameter from an interval type *)

let param_from_type t =
  match t.tcat with
    Interv p -> p
  | _ -> internal_error "Interval type expected"

(* New occurrence *)

let occ = ref 0
let max_occ = ref 100

let new_occ() =
  incr occ;
  if !occ > !max_occ then max_occ := !occ;
  !occ

(* [occ_from_pp pp] returns the occurrence of program point [pp] *)

let occ_from_pp = function
    DProcess(p) -> p.p_occ
  | DTerm(t) -> t.t_occ
  | DInputProcess(p) -> p.i_occ
  | _ -> raise Not_found

(* Get the else branch of let for terms *)

let get_else = function
    None -> Parsing_helper.internal_error "missing else branch of let"
  | Some t -> t
    
(* Binder from term *)

let binder_from_term t =
  match t.t_desc with
    Var(b,_) -> b
  | _ -> internal_error "Binder term expected"

let binderref_from_term t =
  match t.t_desc with
    Var(b,l) -> (b,l)
  | _ -> internal_error "Binder term expected"

let repl_index_from_term t =
  match t.t_desc with
    ReplIndex(b) -> b
  | _ -> internal_error "Replication index term expected"

let build_term_type_occ ty occ desc =
  { t_desc = desc;
    t_type = ty;
    t_occ = occ;
    t_max_occ = 0;
    t_loc = Parsing_helper.dummy_ext;
    t_incompatible = Occ_map.empty;
    t_facts = None }

let new_term ty ext desc =
  { t_desc = desc;
    t_type = ty;
    t_occ = -1;
    t_max_occ = 0;
    t_loc = ext;
    t_incompatible = Occ_map.empty;
    t_facts = None }  
    
let build_term t desc = new_term t.t_type t.t_loc desc

let build_term_type ty desc =
  new_term ty Parsing_helper.dummy_ext desc

(* build_term2 is the same as build_term, except that it keeps the
   occurrence of t. This is useful in particular so that occurrences
   are kept in fact manipulations, to preserve the occurrence of
   "begin" events during the proof of correspondences and to keep
   occurrences of terms to apply the [terms: ...] indication
   of the crypto command. *)

let build_term2 t desc =
  { t_desc = desc;
    t_type = t.t_type;
    t_occ = t.t_occ;
    t_max_occ = 0;
    t_loc = t.t_loc;
    t_incompatible = Occ_map.empty;
    t_facts = None }
    
let term_from_repl_index b =
  build_term_type b.ri_type (ReplIndex b)

let term_from_binder b =
  build_term_type b.btype (Var(b, List.map term_from_repl_index b.args_at_creation))

let term_from_binderref (b,l) =
  build_term_type b.btype (Var(b, l))

let binderref_from_binder b =
  (b, List.map term_from_repl_index b.args_at_creation)

let is_repl_index ri t =
  match t.t_desc with
    ReplIndex ri' -> ri == ri'
  | _ -> false
    
let is_args_at_creation b l =
  List.for_all2 is_repl_index b.args_at_creation l

let app f l =
  build_term_type (snd f.f_type) (FunApp(f,l)) 

let app_tuple l =
  let f = Settings.get_tuple_fun (List.map (fun t -> t.t_type) l) in
  app f l

let event_term occ f cur_array =
  let idx = app_tuple (List.map term_from_repl_index cur_array) in
  build_term_type_occ Settings.t_bool occ (FunApp(f, [idx]))
    
let merge_types t1 t2 =
  if t1 == Settings.t_any then t2 else
  if t2 == Settings.t_any then t1 else
  begin
    if not (t1 == t2) then
      Parsing_helper.internal_error (t1.tname^" should be compatible with "^t2.tname);
    t1
  end

(* Process from desc *)

let new_iproc d ext = { i_desc = d; i_occ = -1; i_max_occ = 0; i_loc = ext;
			i_incompatible = Occ_map.empty; i_facts = None }

let new_oproc d ext = { p_desc = d; p_occ = -1; p_max_occ = 0; p_loc = ext;
			p_incompatible = Occ_map.empty; p_facts = None }

let iproc_from_desc d = new_iproc d Parsing_helper.dummy_ext

let oproc_from_desc d = new_oproc d Parsing_helper.dummy_ext

let iproc_from_desc_loc p d = new_iproc d p.i_loc

let oproc_from_desc_loc p d = new_oproc d p.p_loc

let iproc_from_desc_at p d = { i_desc = d; i_occ = p.i_occ; i_max_occ = p.i_max_occ; i_loc = p.i_loc;
			     i_incompatible = p.i_incompatible; 
			     i_facts = p.i_facts }

let oproc_from_desc_at p d = { p_desc = d; p_occ = p.p_occ; p_max_occ = p.p_max_occ; p_loc = p.p_loc;
			     p_incompatible = p.p_incompatible; 
			     p_facts = p.p_facts }

let empty_game = { proc = RealProcess (iproc_from_desc Nil); expanded = true; game_number = -1; current_queries = []; restrictions = [] }

(* Used the designate the LHS and RHS of an equivalence *)
let lhs_game = { proc = RealProcess (iproc_from_desc Nil); expanded = true; game_number = -2; current_queries = []; restrictions = [] }
let rhs_game = { proc = RealProcess (iproc_from_desc Nil); expanded = true; game_number = -3; current_queries = []; restrictions = [] }
let lhs_game_nodisplay = { proc = RealProcess (iproc_from_desc Nil); expanded = true; game_number = -4; current_queries = []; restrictions = [] }
    
let get_process g =
  match g.proc with
  | RealProcess q -> q
  | Forgotten _ ->
     Parsing_helper.internal_error "Game forgotten"

let build_transformed_game ?expanded p g =
  { proc = RealProcess p;
    expanded =
      begin
	match expanded with
	| None -> g.expanded
	| Some ex -> ex
      end;
    game_number = -1;
    current_queries = g.current_queries;
    restrictions = g.restrictions}
                                   
(* Is a variable defined by a restriction ? *)

let is_restr b =
  (* if b.def == [] then
    print_string ("Warning: is_restr with empty def " ^ b.sname ^ "_" ^ (string_of_int b.vname) ^ "\n"); *)
  List.for_all (function 
      { definition = DProcess { p_desc = Restr _} } -> true
    | { definition = DTerm { t_desc = ResE _} } -> true
    | { definition = DFunRestr } -> true
    | _ -> false) b.def

(* Is a variable defined by an assignment ? *)

let is_assign b =
  List.for_all (function 
      { definition = DProcess { p_desc = Let _} } -> true
    | { definition = DTerm { t_desc = LetE _ }} -> true
    | _ -> false) b.def

let def_kind = function
  | DProcess { p_desc = Let(PatVar _,{ t_desc = Var(b',l) },_,_) }
  | DTerm { t_desc = LetE(PatVar _, { t_desc = Var(b',l) },_,_) } ->
      AssignDef(b',l)
  | DProcess { p_desc = Restr _ } 
  | DTerm { t_desc = ResE _} ->
      RestrDef
  | _ -> OtherDef
	
(* Links *)

let current_bound_vars = ref []

let link v l =
  current_bound_vars := v :: (!current_bound_vars);
  v.link <- l

let get_tlink v =
  match v.link with
  | TLink t -> t
  | _ -> assert false
       
let cleanup () =
  List.iter (fun v -> v.link <- NoLink) (!current_bound_vars);
  current_bound_vars := []

let auto_cleanup f =
  let tmp_bound_vars = !current_bound_vars in
  current_bound_vars := [];
  try
    let r = f () in
    List.iter (fun v -> v.link <- NoLink) (!current_bound_vars);
    current_bound_vars := tmp_bound_vars;
    r
  with x ->
    List.iter (fun v -> v.link <- NoLink) (!current_bound_vars);
    current_bound_vars := tmp_bound_vars;
    raise x

(* Links for replication indices *)

let current_bound_ri = ref []

let ri_link v l =
  current_bound_ri := v :: (!current_bound_ri);
  v.ri_link <- l

let ri_cleanup () =
  List.iter (fun v -> v.ri_link <- NoLink) (!current_bound_ri);
  current_bound_ri := []

let rec cleanup_until l l' = 
  if l' == l then () else
  match l' with
    [] -> Parsing_helper.internal_error "cleanup_until"
  | (v::r) -> 
      v.ri_link <- NoLink;
      cleanup_until l r

let ri_auto_cleanup f =
  let tmp_bound_ri = !current_bound_ri in
  current_bound_ri := [];
  try
    let r = f () in
    List.iter (fun v -> v.ri_link <- NoLink) (!current_bound_ri);
    current_bound_ri := tmp_bound_ri;
    r
  with x ->
    List.iter (fun v -> v.ri_link <- NoLink) (!current_bound_ri);
    current_bound_ri := tmp_bound_ri;
    raise x

let ri_auto_cleanup_failure f =
  let tmp_bound_ri = !current_bound_ri in
  try
    f() 
  with x ->
    cleanup_until tmp_bound_ri (!current_bound_ri);
    current_bound_ri := tmp_bound_ri;
    raise x

(* Equality tests *)

let equal_lists eq l1 l2 =
  (List.length l1 == List.length l2) && 
  (List.for_all2 eq l1 l2)

let equal_lists_sets eq l1 l2 =
  (* Verifies both inclusions for equality [eq] *)
  (List.for_all (fun x1 -> List.exists (eq x1) l2) l1) &&
  (List.for_all (fun x2 -> List.exists (eq x2) l1) l2)

let equal_lists_sets_q l1 l2 =
  (* Equivalent to [equal_lists_sets (==) l1 l2] *)
  (List.for_all (fun x1 -> List.memq x1 l2) l1) &&
  (List.for_all (fun x2 -> List.memq x2 l1) l2)

let equal_mset mset1 mset2 =
  match (mset1, mset2) with
    (MBinders l1, MBinders l2) -> equal_lists_sets_q l1 l2
  | MUp(b1,occ1,_), MUp(b2,occ2,_) -> b1 == b2 && occ1 == occ2
  | x, y -> x == y

let equal_rset rset1 rset2 =
  match (rset1, rset2) with
    (Minimal, Minimal) | (FindCond, FindCond) | (NoRemAssign, NoRemAssign) -> true
  | (Binders l1, Binders l2) -> equal_lists_sets_q l1 l2
  | _ -> false

let equal_merge_mode m1 m2 =
  match (m1,m2) with
    (MNoBranchVar, MNoBranchVar) | (MCreateBranchVar, MCreateBranchVar) -> true
  | (MCreateBranchVarAtProc (pl1, cur_array1), MCreateBranchVarAtProc (pl2, cur_array2)) ->
      (equal_lists (==) pl1 pl2) && (equal_lists (==) cur_array1 cur_array2)
  | (MCreateBranchVarAtTerm (tl1, cur_array1), MCreateBranchVarAtTerm (tl2, cur_array2)) ->
      (equal_lists (==) tl1 tl2) && (equal_lists (==) cur_array1 cur_array2)
  | _ -> false

let rec equal_terms_ren t1 t2 =
  match t1.t_desc, t2.t_desc with
  | Var(b1,l1), Var(b2,l2) ->
      assert(l1 == [] && l2 == []);
      begin
	match b1.link, b2.link with
	| NoLink, NoLink ->
	    link b1 (TLink t2);
	    link b2 (TLink t1)
	| TLink { t_desc = Var(b2', []) },
	    TLink { t_desc = Var(b1', []) } when b1' == b1 && b2' == b2 -> ()
	| _ -> raise NoMatch
      end
  | FunApp(f1, l1), FunApp(f2, l2) ->
      if f1 != f2 then raise NoMatch;
      List.iter2 equal_terms_ren l1 l2
  | _ -> raise NoMatch

let rec equal_qterms_ren t1 t2 =
  match t1, t2 with
  | QEvent(b1, t1'), QEvent(b2, t2') ->
      if b1 != b2 then raise NoMatch;
      equal_terms_ren t1' t2'
  | QTerm t1', QTerm t2' ->
      equal_terms_ren t1' t2'
  | QAnd(t1', t1''), QAnd(t2', t2'') ->
      equal_qterms_ren t1' t2';
      equal_qterms_ren t1'' t2''
  | QOr(t1', t1''), QOr(t2', t2'') ->
      equal_qterms_ren t1' t2';
      equal_qterms_ren t1'' t2''
  | QNot t1', QNot t2' ->
      equal_qterms_ren t1' t2';
  | QExists _, QExists _
  | QForall _, QForall _ -> assert false
  | _ -> raise NoMatch

let equal_query_any_pubvars q1 q2 =
  match q1, q2 with
  | QSecret(b1,pub_vars1,options1), QSecret(b2,pub_vars2,options2) ->
      (b1 == b2) && 
      (options1 = options2)
  | QEventQ(hyp1, concl1, pub_vars1), QEventQ(hyp2, concl2, pub_vars2) ->
      (List.length hyp1 == List.length hyp2) &&
      (auto_cleanup (fun () ->
	try
	  List.iter2 (fun (inj1,t1) (inj2,t2) ->
	    if inj1 != inj2 then raise NoMatch;
	    equal_terms_ren t1 t2) hyp1 hyp2;
	  equal_qterms_ren concl1 concl2;
	  true
	with NoMatch ->
	  false))
  | QEquivalence _, QEquivalence _ 
  | QEquivalenceFinal _, QEquivalenceFinal _
  | AbsentQuery, AbsentQuery -> true
  | _ -> false

let equal_pubvars q1 q2 =
  match q1, q2 with
  | QSecret(_,pub_vars1,_), QSecret(_,pub_vars2,_) 
  | QEventQ(_,_, pub_vars1), QEventQ(_,_, pub_vars2) 
  | QEquivalence(_, pub_vars1, _), QEquivalence(_, pub_vars2, _) 
  | QEquivalenceFinal(_, pub_vars1), QEquivalenceFinal(_, pub_vars2) ->
      equal_lists_sets_q pub_vars1 pub_vars2
  | AbsentQuery, AbsentQuery -> true
  | _ -> false

let equal_query q1 q2 =
  (equal_query_any_pubvars q1 q2) &&
  (equal_pubvars q1 q2)

let eq_pair (a1,b1) (a2,b2) =
  a1 == a2 && b1 == b2
	
let equal_user_info i1 i2 =
  match i1,i2 with
    VarList(bl1,b1),VarList(bl2,b2) -> (equal_lists (==) bl1 bl2) && (b1 == b2)
  | Detailed(vmopt1,tmopt1), Detailed(vmopt2,tmopt2) ->
     (match vmopt1, vmopt2 with
       None, None -> true
     | Some(ml1,l1,b1), Some(ml2,l2,b2) ->
	 (equal_lists eq_pair ml1 ml2) && (equal_lists (==) l1 l2) && (b1 == b2)
     | _ -> false) &&
      (match tmopt1, tmopt2 with
	None, None -> true
      | Some(ml1,b1), Some(ml2,b2) ->
	  (equal_lists eq_pair ml1 ml2) && (b1 == b2)
      | _ -> false)
  | _ -> false

let eq_merge_spec (o1,_,c1) (o2,_,c2) =
  o1 == o2 && c1 = c2 (* structural equality is ok for merge_command *)
	
let equal_instruct i1 i2 =
  match i1,i2 with
  | (ExpandGetInsert_ProveUnique, ExpandGetInsert_ProveUnique) -> true
  | (Expand, Expand) -> true
	(* We overapproximate by saying that simplify instructions
	   are not equal when they contain known_when_adv_wins.
	   Ok since we use equal_instruct to eliminate duplicates *)
  | (Simplify(None, l1), Simplify(None, l2)) -> equal_lists (=) l1 l2
  | (SimplifyNonexpanded, SimplifyNonexpanded) -> true
  | (GlobalDepAnal (b1,l1), GlobalDepAnal (b2,l2)) -> (b1 == b2) && (equal_lists (=) l1 l2)
  | (RemoveAssign (b1, rset1), RemoveAssign (b2, rset2)) -> b1 == b2 && equal_rset rset1 rset2
  | (SArenaming b1, SArenaming b2) -> b1 == b2
  | (MoveNewLet mset1, MoveNewLet mset2) -> equal_mset mset1 mset2
  | (CryptoTransf (eq1, bl1), CryptoTransf (eq2, bl2)) -> 
      (eq1 == eq2) && (equal_user_info bl1 bl2)
  | (InsertEvent(s1,_,n1,_), InsertEvent(s2,_,n2,_)) ->
      (s1 = s2) && (n1 == n2)
  | (InsertInstruct(s1,_,n1,_), InsertInstruct(s2,_,n2,_)) ->
      (s1 = s2) && (n1 == n2)
  | (ReplaceTerm(s1,_,n1,_,check_opt1), ReplaceTerm(s2,_,n2,_,check_opt2)) ->
      (s1 = s2) && (n1 == n2) && (check_opt1 = check_opt2)
  | (MergeArrays(bl1,m1), MergeArrays(bl2,m2)) ->
      (equal_lists (equal_lists (fun (b1,ext1) (b2, ext2) -> (b1 == b2) && (ext1 = ext2))) bl1 bl2) &&
      (equal_merge_mode m1 m2)
  | (MergeBranches l1, MergeBranches l2) ->
      equal_lists eq_merge_spec l1 l2
  | (Proof ql1, Proof ql2) ->
      equal_lists (fun ((q1,n1),p1) ((q2,n2),p2) -> (equal_query q1 q2) && (n1 = n2) && (p1 = p2)) ql1 ql2
  | _ -> false

let add_eq a l =
  if List.exists (equal_instruct a) l then l else a::l

let equal_find_info f1 f2 =
  match f1, f2 with
  | Unique, Unique
  | Nothing, Nothing -> true
  | UniqueToProve e1, UniqueToProve e2 -> e1 == e2
  | _ -> false
							
(*************************************************************************)
	
(* [remove_elem f l] returns list [l] with one
   occurrence of an element satisfying [f] removed. 
   When [l] does not contain any element satisfying [f],
   raises [Not_found]. *)

let rec remove_elem f = function
    [] -> raise Not_found 
  | a::l -> if f a then l else a::(remove_elem f l)

(* [remove_rel reduced rel l] returns list [l]
   after removing pairs of elements related by [rel]. 
   This function can be used to remove duplicate elements when [rel]
   tests equality between elements or to remove inverses when [rel]
   tests whether an element is inverse of the other.
   [reduced] is set to true when some elements have been removed. *)

let rec remove_rel reduced rel = function
    [] -> []
  | (a::l) ->
      try 
	let l' = remove_elem (rel a) l in
	reduced := true;
	remove_rel reduced rel l'
      with Not_found ->
	a::(remove_rel reduced rel l)

(* [remove_common_prefix sub_eq reduced l1 l2] returns a pair
   of lists [(l1', l2')] equal to [(l1,l2)] without their common prefix.
   [sub_eq] tests equality between elements.
   [reduced] is as above. *)
	      
let rec remove_common_prefix sub_eq reduced l1 l2 = 
  match (l1,l2) with
    t1::r1, t2::r2 when sub_eq t1 t2 -> 
      reduced := true;
      remove_common_prefix sub_eq reduced r1 r2
  | _ -> (l1,l2)
      
(* [remove_common_suffix sub_eq reduced l1 l2] returns a pair
   of lists [(l1', l2')] equal to [(l1,l2)] without their common suffix.
   [sub_eq] and [reduced] are as above. *)

let remove_common_suffix sub_eq reduced l1 l2 = 
  let l1rev = List.rev l1 in
  let l2rev = List.rev l2 in
  let (l1rev',l2rev') = remove_common_prefix sub_eq reduced l1rev l2rev in
  (List.rev l1rev', List.rev l2rev')

(* [equal_up_to_order sub_eq l1 l2] returns true when the
   lists [l1] and [l2] are equal up to the ordering of their
   elements. 
   The function [sub_eq] is used to test equality between elements. *)

let rec equal_up_to_order sub_eq l1 l2 =
  match l1,l2 with
    [],[] -> true
  | [],_ | _,[] -> false
  | (a::l,_) ->
      try
	let l2' = remove_elem (sub_eq a) l2 in
	equal_up_to_order sub_eq l l2'
      with Not_found ->
	false

(* [equal_up_to_roll sub_eq l1 l2] returns true when [l1]
   contains the same elements as [l2], in the same order,
   but the lists may be rotated, that is,
   l1 = [t1;...;tn] and l2 = [tk;...;tn;t1;...;t_{k-1}].
   Function [sub_eq] is used to test equality between elements. *)

let rec equal_up_to_roll_rec sub_eq l1 seen2 rest2 =
  (List.for_all2 sub_eq l1 (rest2 @ (List.rev seen2))) ||
  (match rest2 with
    [] -> false
  | (a::rest2') ->
      equal_up_to_roll_rec sub_eq l1 (a::seen2) rest2'
	)

let equal_up_to_roll sub_eq l1 l2 =
  (List.length l1 == List.length l2) && 
  (equal_up_to_roll_rec sub_eq l1 [] l2)

(* [remove_inverse_ends simp_facts reduced group_th l] removes the
   inverse elements at the two ends of the list [l]. In a non-commutative group,
   the product of the elements [l] is the neutral element if and only if the
   product of the resulting list is: x * t * x^-1 = e iff t = e by multiplying
   on the left by x^-1 and on the right by x.
   [is_inv t1 t2] tests whether [t1] is inverse of [t2]
   [reduced] is set to true when some elements have been removed. *)

let rec cut_list n accu l = 
  if n = 0 then (accu, l) else
  match l with
    [] -> (accu, [])
  | a::l' -> cut_list (n-1) (a::accu) l'

let rec remove_inverse_prefix reduced is_inv l1 l2 =
  match l1, l2 with
    t1::r1, t2::r2 when is_inv t1 t2 -> 
      reduced := true;
      remove_inverse_prefix reduced is_inv r1 r2
  | _ -> (l1,l2)    

let remove_inverse_ends reduced is_inv l = 
  let n = (List.length l) / 2 in
  let half1, half2 = cut_list n [] l in
  let half1', half2' = remove_inverse_prefix reduced is_inv (List.rev half1) (List.rev half2) in
  List.rev_append (List.rev half1') (List.rev half2')

(* [remove_consecutive_inverse reduced is_inv seen_l l]
   removes consecutive elements of [l] that are inverses of one another.
   [reduced] and [is_inv] are as above. *)

let remove_consecutive_inverse reduced is_inv l =
  (* [seen_l] corresponds to the part of [l] already examined by the algorithm,
     in reverse order. The algorithm always tries to eliminate the first
     element of [seen_l] and the first element of [l]. *)
  let rec aux seen_l l =
    match (seen_l, l) with
      [],[] -> []
    | [],a::l' -> aux [a] l'
    | _ ,[] -> List.rev seen_l
    | a::seen_l', a'::l' ->
	if is_inv a a' then
	  begin
	    reduced := true;
	    aux seen_l' l'
	  end
	else
	  aux (a'::seen_l) l'
  in
  aux [] l

(*******************************************************************)

(* [get_neutral f] returns the neutral element of the equational
   theory of the function symbol [f]. *)

let get_neutral f =
  let neut =
    match f.f_eq_theories with
      ACUN(_,n) | Group(_,_,n) | CommutGroup(_,_,n) | AssocN(_,n) | AssocCommutN(_,n) -> n
    | _ -> Parsing_helper.internal_error "equational theory has no neutral element in Terms.get_neutral"
  in
  app neut []

(* [get_prod try_no_var t] returns the equational theory of the root
   function symbol of term [t], when it is a product
   in a group or xor. *)

let get_prod try_no_var t =
  match (try_no_var t).t_desc with
    FunApp(f,[_;_]) ->
      begin
       match f.f_eq_theories with
         Group(prod,_,_) | CommutGroup(prod,_,_)
       | ACUN(prod,_) when prod == f ->
           f.f_eq_theories
       | _ -> NoEq
      end
  | _ -> NoEq

(* [get_prod_list try_no_var l] returns the equational theory of the root
   function symbol of a term in [l], when it is a product
   in a group or xor. *)

let rec get_prod_list try_no_var = function
    [] -> NoEq
  | t::l ->
      match (try_no_var t).t_desc with
	FunApp(f,[_;_]) ->
          begin
            match f.f_eq_theories with
              Group(prod,_,_) | CommutGroup(prod,_,_)
            | ACUN(prod,_) when prod == f ->
		f.f_eq_theories
            | _ -> get_prod_list try_no_var l
          end
      | _ -> get_prod_list try_no_var l

(* [compute_inv try_no_var reduced (f, inv, n) t] returns a term equal to
   [inv(t)].
   [(f, inv,n)] is supposed to be a group, with product [f],
   inverse function [inv], and neutral element [n].
   [reduced] is set to true when a simplification occurred
   during the computation.
   [try_no_var] is explained in the function [simp_main_fun]. *)

let rec compute_inv try_no_var reduced (f, inv, n) t =
  let t_no_var = try_no_var t in
  match t_no_var.t_desc with
    FunApp(inv', [t']) when inv' == inv ->
      (* inv(inv(x)) = x *)
      reduced := true;
      t'
  | FunApp(f', [t1;t2]) when f' == f ->
      (* inv(x.y) = inv(y).inv(x) *)
      reduced := true;
      app f [compute_inv try_no_var reduced (f,inv,n) t2; compute_inv try_no_var reduced (f,inv,n) t1]
  | FunApp(n', []) when n' == n ->
      (* inv(n) = n *)
      reduced := true;
      t_no_var
  | _ ->
      app inv [t]

(* Simplification function:
   [simp_main_fun try_no_var reduced f t] simplifies term [t].
   [f] is a binary function with an equational theory.
   [simp_main_fun] returns a list of terms [l], such that [t] is equal to
   the product of the elements of [l] by function [f].
   [reduced] is set to true when [t] has really been simplified.
   [try_no_var] is a function from terms to terms that tries to replace
   variables with their values. It leaves non-variable terms unchanged.
   It can be the identity when we do not have information on the values
   of variables.
   ([simp_main_fun] does not consider cancellations between terms in
   ACUN or group equational theories, which are considered below by
   function [simp_prod].) *)

let rec simp_main_fun try_no_var reduced f t =
  match f.f_eq_theories, (try_no_var t).t_desc with
    (Assoc | AssocN _ | AssocCommut | AssocCommutN _ | ACUN _ |
     Group _ | CommutGroup _), FunApp(f', [t1;t2]) when f == f' ->
      (simp_main_fun try_no_var reduced f t1) @
      (simp_main_fun try_no_var reduced f t2)
  | (Group(f'',inv,n) | CommutGroup(f'',inv,n)), FunApp(inv', [t1]) when inv' == inv ->
      let reduced' = ref false in
      let t' = compute_inv try_no_var reduced' (f'',inv,n) t1 in
      if !reduced' then
       begin
         reduced := true;
         simp_main_fun try_no_var reduced f t'
       end
      else
       [t]
  | (AssocN(_,n) | AssocCommutN(_,n) | ACUN(_,n) | Group(_,_,n) |
     CommutGroup(_,_,n)), FunApp(n', []) when n == n' ->
      (* Eliminate the neutral element *)
      reduced := true;
      []
  | _ -> [t]

(* [is_inv simp_facts inv t1 t2] is true when [t1 = inv t2] for the
   inverse function [inv]. For best precision, [t1] and [t2]
   should not be products, which is guaranteed since products are decomposed
   before *)

let rec is_inv simp_facts inv t1 t2 =
  let t1_no_var = try_no_var simp_facts t1 in
  match t1_no_var.t_desc with
  | FunApp(inv', [t']) when inv' == inv ->
      simp_equal_terms simp_facts true t' t2
  | _ ->
      let t2_no_var = try_no_var simp_facts t2 in
      match t2_no_var.t_desc with
      | FunApp(inv', [t']) when inv' == inv ->
         simp_equal_terms simp_facts true t1 t'
      | _ -> false

(* Simplification function:
   [simp_prod simp_facts reduced f t] simplifies term [t].
   [f] is a binary function with an equational theory.
   [simp_prod] returns a list of terms [l], such that [t] is equal to
   the product of the elements of [l] by function [f].
   [simp_facts] collects the rewrite rules corresponding to known equalities
   and other known facts, which we use in order to replace variables with their values and
   to test equality between terms.
   [reduced] is set to true when [t] has really been simplified. *)
	  
and simp_prod simp_facts reduced f t =
  let l = simp_main_fun (try_no_var simp_facts) reduced f t in
  match f.f_eq_theories with
    ACUN _ ->
      (* Remove duplicates from the list, since they cancel out *)
      remove_rel reduced (simp_equal_terms simp_facts true) l
  | Group(f',inv,n) ->
      (* Remove pairs formed of an element immediately followed by its inverse,
         since they cancel out. *)
      remove_consecutive_inverse reduced (is_inv simp_facts inv) l
  | CommutGroup(f',inv,n) ->
      (* Remove pairs of an element and its inverse since they cancel out *)
      remove_rel reduced (is_inv simp_facts inv) l
  | _ -> l

and simp_prod_root simp_facts normalize_root reduced f t =
  if normalize_root then
    simp_prod simp_facts reduced f t
  else
    (* When [normalize_root] is false, we are careful not to 
       use rewrite rules at the root. When the term is a variable,
       we cannot find a product in it. 
       When the term is not a variable, we can apply the standard function,
       since [try_no_var simp_facts] does not apply any rewrite rule
       in this case. *)
    match t.t_desc with
    | Var _ | ReplIndex _ -> [t]
    | _ -> simp_prod simp_facts reduced f t

(* [try_no_var simp_facts t] returns [t] unchanged when it
   is a function application and tries to replace it with its value
   using the rewrite rules in [simp_facts] when it is a variable.
   See facts.ml for additional information on [simp_facts].

   The functions [apply_subst_list] and [normalize_var] are helper functions
   to define [try_no_var].

   [apply_subst_list t subst] applies a rewrite rule in [subst]
   to the term [t] (only at the root of [t]) and returns the reduced
   term, if possible. Otherwise, it just returns [t] itself. *)

and apply_subst_list t = function
    [] -> t
  | tsubst::rest -> 
     match tsubst.t_desc with
       FunApp(f,[redl;redr]) when f.f_cat == Equal || f.f_cat == LetEqual ->
         begin
           if equal_terms t redl then 
	     redr
           else
	     apply_subst_list t rest
         end
     | _ -> Parsing_helper.internal_error "substitutions should be Equal or LetEqual terms"

(* [normalize_var subst t] normalizes the term [t] (which must contain
   only variables and replication indices) using the rewrite rules
   in [subst].
   Since the RHS of rewrite rules is already normalized,
   it is enough to apply rewrite rules once at each variable 
   symbol from the inside to the outside to normalize the term. *)

and normalize_var subst2 t =
  match t.t_desc with
    Var(b,l) ->
      let l' = List.map (normalize_var subst2) l in
      let t' = build_term2 t (Var(b,l')) in
      apply_subst_list t' subst2
  | ReplIndex _ -> 
      apply_subst_list t subst2
  | FunApp _ ->
      (* This case may happen with constant replication
         indices introduced by the "guess" transformation.
	 Subterms of variables may contain these constants. *)
      t
  | TestE _ | FindE _ | LetE _ | ResE _ | EventAbortE _ | EventE _ | GetE _ | InsertE _ -> 
      Parsing_helper.internal_error "If, find, let, and new should not occur in normalize_var"

and try_no_var (subst2, _, _) t =
  if subst2 == [] then t else
  match t.t_desc with
    Var _ | ReplIndex _ -> 
      normalize_var subst2 t
  | _ -> t

(* Equality test *)

(* [simp_equal_terms simp_facts normalize_root t1 t2] returns true when
   the terms [t1] and [t2] are equal. It uses the rewrite rules in
   [simp_facts] to reduce the terms in order to infer more equalities.
   When [normalize_root] is false, the rewrite rules in [simp_facts]
   are not applied at the root of the terms [t1] and [t2]. *)

and simp_equal_terms simp_facts normalize_root t1 t2 = 
  if (simp_facts == simp_facts_id) || (not normalize_root) then
    simp_equal_terms1 simp_facts normalize_root t1 t2
  else
    (simp_equal_terms1 simp_facts_id true t1 t2) ||
    (let t1' = normalize simp_facts t1 in
    let t2' = normalize simp_facts t2 in
    simp_equal_terms1 simp_facts normalize_root t1' t2')

and simp_equal_terms1 simp_facts normalize_root t1 t2 =
  match (t1.t_desc, t2.t_desc) with
    Var(b1,l1),Var(b2,l2) ->
      (b1 == b2) && (List.for_all2 equal_terms l1 l2)
  | ReplIndex b1, ReplIndex b2 -> b1 == b2
  | FunApp(f1, [t1;t1']), FunApp(f2, [t2;t2']) when 
      f1 == f2 && (f1.f_cat == Equal || f1.f_cat == Diff) ->
	(* It is important to test this case before the commutative
	   function symbols: = and <> are also commutative function
	   symbols. *)
	begin
	  (* In a group, when t1/t1' = t2/t2', we have t1 = t1' if and only if t2 = t2'.
	     With xor, when t1 xor t1' = t2 xor t2', we have t1 = t1' if and only if t2 = t2'. *)
	  match get_prod_list (try_no_var simp_facts) [t1;t1';t2;t2'] with
	    ACUN(xor,_) ->
	      simp_equal_terms simp_facts true (app xor [t1;t1']) (app xor [t2;t2'])
	  | CommutGroup(prod,inv,_) ->
	      (simp_equal_terms simp_facts true (app prod [t1; app inv [t1']])
		(app prod [t2; app inv [t2']])) ||
	      (simp_equal_terms simp_facts true (app prod [t1; app inv [t1']]) 
		(app prod [t2'; app inv [t2]]))
	  | Group(prod,inv,neut) ->
	      (* For non-commutative groups, I can still commute a term
		 and its inverse, so I try all possibilities. 
		 t1 = t1' iff t1/t1' = neut iff the product of the elements of [l1] is neut 
		          iff the product of the elements of [l1'] is neut 
		 Similarly, t2 = t2' iff the product of the elements of [l2'] is neut.
		 The product of the elements of [l2''] is the inverse of 
		 the product of the elements of [l2'],
		 so one is neut iff the other is.
		 *)
	      let l1 = simp_prod simp_facts (ref false) prod (app prod [t1; app inv [t1']]) in
	      let l1' = remove_inverse_ends (ref false) (is_inv simp_facts inv) l1 in
	      let l2 = simp_prod simp_facts (ref false) prod (app prod [t2; app inv [t2']]) in
	      let l2' = remove_inverse_ends (ref false) (is_inv simp_facts inv) l2 in
	      (equal_up_to_roll (simp_equal_terms simp_facts true) l1' l2') || 
	      (let l2'' = List.rev (List.map (compute_inv (try_no_var simp_facts) (ref false) (prod, inv, neut)) l2') in
	      equal_up_to_roll (simp_equal_terms simp_facts true) l1' l2'')
	  | _ -> 
	      ((simp_equal_terms simp_facts true t1 t2) && (simp_equal_terms simp_facts true t1' t2')) ||
	      ((simp_equal_terms simp_facts true t1 t2') && (simp_equal_terms simp_facts true t1' t2))
	end
  | FunApp(f1,[t1;t1']),FunApp(f2,[t2;t2']) when f1 == f2 && f1.f_eq_theories = Commut ->
      (* Commutative function symbols *)
      ((simp_equal_terms simp_facts true t1 t2) && (simp_equal_terms simp_facts true t1' t2')) ||
      ((simp_equal_terms simp_facts true t1 t2') && (simp_equal_terms simp_facts true t1' t2))
  | FunApp({f_eq_theories = (Group(f,inv',n) | CommutGroup(f,inv',n)) } as inv, [t1']), _ when inv' == inv ->
      (* inv is an inverse function *)
      let reduced = ref false in
      let t1_simp = compute_inv (try_no_var simp_facts) reduced (f,inv',n) t1' in
      if !reduced then simp_equal_terms simp_facts true t1_simp t2 else 
      begin
        match t2.t_desc with
          FunApp({f_eq_theories = (Group(f2,inv2',n2) | CommutGroup(f2,inv2',n2)) } as inv2, [t2']) when inv2' == inv2 ->
            (* inv2 is an inverse function *)
            let reduced = ref false in
            let t2_simp = compute_inv (try_no_var simp_facts) reduced (f2,inv2',n2) t2' in
            if !reduced then simp_equal_terms simp_facts true t1 t2_simp else 
            (inv == inv2) && (simp_equal_terms simp_facts true t1' t2')
        | FunApp(f2, [_;_]) when f2.f_eq_theories != NoEq && f2.f_eq_theories != Commut ->
            (* f2 is a binary function with an equational theory that is
	       not commutativity nor inverse -> it is a product-like function *)
            let l2 = simp_prod_root simp_facts normalize_root (ref false) f2 t2 in
            begin
	      match l2 with
	        [] -> simp_equal_terms simp_facts true t1 (get_neutral f2)
	      | [t] -> simp_equal_terms simp_facts true t1 t
	      | _ -> (* t2 is a product and t1 is not (it is an inverse), so they cannot be equal *)
	         false
            end
        | _ -> (* t2 is not an inverse nor a product, it cannot be equal to t1 *) false
      end
  | FunApp(f1,[_;_]),_ when f1.f_eq_theories != NoEq && f1.f_eq_theories != Commut ->
      (* f1 is a binary function with an equational theory that is
	 not commutativity nor inverse -> it is a product-like function *)
      let l1 = simp_prod_root simp_facts normalize_root (ref false) f1 t1 in
      begin
	match l1 with
	  [] -> simp_equal_terms simp_facts true (get_neutral f1) t2
	| [t] -> simp_equal_terms simp_facts true t t2
	| _ -> 
	    let l2 = simp_prod_root simp_facts normalize_root (ref false) f1 t2 in
	    match f1.f_eq_theories with
	      NoEq | Commut -> Parsing_helper.internal_error "equal_terms: cases NoEq, Commut should have been eliminated"
	    | AssocCommut | AssocCommutN _ | CommutGroup _ | ACUN _ ->
		(* Commutative equational theories: test equality up to ordering *)
		(List.length l1 == List.length l2) &&
		(equal_up_to_order (simp_equal_terms simp_facts true) l1 l2)
	    | Assoc | AssocN _ | Group _ -> 
		(* Non-commutative equational theories: test equality in the same order *)
		equal_lists (simp_equal_terms simp_facts true) l1 l2		
      end
  | _, FunApp({f_eq_theories = (Group(f,inv',n) | CommutGroup(f,inv',n)) } as inv, [t2']) when inv == inv' ->
      (* inv is an inverse function *)
      let reduced = ref false in
      let t2_simp = compute_inv (try_no_var simp_facts) reduced (f,inv',n) t2' in
      if !reduced then simp_equal_terms simp_facts true t1 t2_simp else 
      (* t1 is not a product nor an inverse, otherwise the previous cases 
         would have been triggered, so t1 cannot be equal to t2 *)
      false
  | _, FunApp(f2, [_;_]) when f2.f_eq_theories != NoEq && f2.f_eq_theories != Commut ->
      (* f2 is a binary function with an equational theory that is
	 not commutativity nor inverse -> it is a product-like function *)
      let l2 = simp_prod_root simp_facts normalize_root (ref false) f2 t2 in
      begin
	match l2 with
	  [] -> simp_equal_terms simp_facts true t1 (get_neutral f2)
	| [t] -> simp_equal_terms simp_facts true t1 t
	| _ -> (* t2 is a product and t1 is not (otherwise the previous case
		  would have been triggered), so they cannot be equal *)
	    false
      end
  | FunApp(f1,l1),FunApp(f2,l2) ->
      (f1 == f2) && (List.for_all2 (simp_equal_terms simp_facts true) l1 l2)
  | TestE(t1,t2,t3), TestE(t1',t2',t3') ->
      (simp_equal_terms simp_facts true t1 t1') && (simp_equal_terms simp_facts true t2 t2') && (simp_equal_terms simp_facts true t3 t3')
  | FindE(l,t3,find_info),FindE(l',t3',find_info') ->
      (* Could do modulo renaming of bl and bl'! *)
      (equal_lists (fun (bl,def_list,t1,t2) (bl',def_list',t1',t2') ->
	(equal_lists (fun (b1,b2) (b1', b2') -> (b1 == b1') && (b2 == b2')) bl bl') && 
	(equal_def_lists def_list def_list') && 
	(simp_equal_terms simp_facts true t1 t1') && (simp_equal_terms simp_facts true t2 t2')) l l') && 
      (simp_equal_terms simp_facts true t3 t3') &&
      (equal_find_info find_info find_info')
  | LetE(pat, t1, t2, topt), LetE(pat', t1', t2', topt') ->
      (equal_pats simp_facts pat pat') &&
      (simp_equal_terms simp_facts true t1 t1') &&
      (simp_equal_terms simp_facts true t2 t2') &&
      (match topt, topt' with
	None, None -> true
      | Some t3, Some t3' -> simp_equal_terms simp_facts true t3 t3'
      | _ -> false)
  | ResE(b,t), ResE(b',t') ->
      (b == b') && (simp_equal_terms simp_facts true t t')
  | EventAbortE(f), EventAbortE(f') -> 
      f == f'
  | EventE(t,p), EventE(t',p') ->
      (simp_equal_terms simp_facts true t t') &&
      (simp_equal_terms simp_facts true p p')
  | (GetE _, GetE _) | (InsertE _, InsertE _) ->
      Parsing_helper.internal_error "get and insert should not occur in simp_equal_terms"
  | _ -> false

and equal_terms t1 t2 = simp_equal_terms1 simp_facts_id true t1 t2

and equal_def_lists def_list def_list' =
  equal_lists equal_binderref def_list def_list'

and equal_binderref (b,l) (b',l') =
  (b == b') && (List.for_all2 equal_terms l l')

and equal_pats simp_facts p1 p2 =
  match p1,p2 with
    PatVar b, PatVar b' -> b == b'
  | PatTuple (f,l), PatTuple (f',l') -> (f == f') && (List.for_all2 (equal_pats simp_facts) l l')
  | PatEqual t, PatEqual t' -> simp_equal_terms simp_facts true t t'
  | _ -> false

(* [apply_subst_list_fun simp_facts t subst] applies a 
   rewrite rule [subst] to the term [t] (only at the root)
   and returns the reduced term, if possible. Otherwise,
   it just returns [t] itself.
   It uses the equalities in [simp_facts] to help establishing
   that [t] is equal to the left-hand side of a rewrite rule.
   The equalities in [simp_facts] are applied only to strict 
   subterms of [t] and of the LHS of a rewrite rule, because
   applying them at the root of [t]  would mean applying another 
   rewrite rule, and applying them at the root of the LHS of a
   rewrite rule is impossible since the root of rewrite rules
   is already normalized.
 *)

and apply_subst_list_fun simp_facts t froot seen = function
    [] -> t
  | tsubst::rest -> 
     match tsubst.t_desc with
       FunApp(f,[redl;redr]) when f.f_cat == Equal || f.f_cat == LetEqual ->
         begin
	   (* Excluding the rewrite rule redl->redr that we want to test
              from the rules that can be used to test equality between t and redl.
              This avoids an infinite loop.
	      For instance, when t = H(M') and redl = H(H(M)),
	      normalizing t calls simp_equal_terms [...] false H(M') H(H(M)),
	      which calls normalize on H(M). If the rewrite rule redl->redr
	      with redl = H(H(M)) is still present, it will call 
	      simp_equal_terms [...] false H(M) H(H(M)),
	      which again calls normalize on H(M). *)
	   let applies =
	     (* optimization: avoid reconstructing [simp_facts] when 
		[redl->redr] clearly cannot apply to [t] *)
	     match redl.t_desc with
	       FunApp(froot', _) when froot == froot' ||
	       (froot.f_eq_theories != NoEq && froot.f_eq_theories != Commut) ||
	       (froot'.f_eq_theories != NoEq && froot'.f_eq_theories != Commut) ->
		 let (_,facts,elsefind) = simp_facts in
		 let simp_facts' = (List.rev_append seen rest, facts,elsefind) in
		 simp_equal_terms1 simp_facts' false t redl
	     | _ -> false
	   in
	   if applies then 
	     redr
	   else
	     apply_subst_list_fun simp_facts t froot (tsubst::seen) rest
         end
     | _ -> Parsing_helper.internal_error "substitutions should be Equal or LetEqual terms"

(* [normalize simp_facts t] normalizes the term [t]
   using the rewrite rules in [simp_facts]. 
   The root of [t] is guaranteed to be normalized.
   Rewrite rules of [simp_facts] may still be applicable
   to strict subterms of the result. 
   When [t] is a variable, we use [normalize_var].
   When it is a function symbol, we apply a rewrite rule of
   [simp_facts] once at the root (possibly applying rewrite rules
   of [simp_facts] to strict subterms to allow this rewriting),
   if possible. This is enough because the RHS of rewrite rules is 
   already normalized at the root. *)
	   
and normalize ((subst2, _, _) as simp_facts) t =
  match t.t_desc with
    FunApp(f,l) ->
      apply_subst_list_fun simp_facts t f [] subst2
  | Var _ | ReplIndex _ -> 
      normalize_var subst2 t 
  | TestE _ | FindE _ | LetE _ | ResE _ | EventAbortE _ | EventE _ | GetE _ | InsertE _ -> 
      t

let equal_pats p1 p2 =
  equal_pats simp_facts_id p1 p2

let rec try_no_var_rec depth simp_facts t =
  if depth = 0 then t else 
  let t' = try_no_var simp_facts t in(* Risk of non-termination? *)
  match t'.t_desc with
    FunApp(f,l) -> 
      build_term2 t' (FunApp(f, List.map (try_no_var_rec (depth-1) simp_facts) l))
  | _ -> t'

let try_no_var_rec simp_facts t =
  try_no_var_rec (!Settings.max_depth_try_no_var_rec) simp_facts t

let equal_term_lists l1 l2 =
  equal_lists equal_terms l1 l2

let equal_pp pp1 pp2 =
  match pp1, pp2 with
  | DProcess p1, DProcess p2 -> p1 == p2
  | DInputProcess p1, DInputProcess p2 -> p1 == p2
  | DTerm t1, DTerm t2
  | DFunArgs t1, DFunArgs t2 -> t1 == t2
  | DFunRestr, DFunRestr
  | DGenVar, DGenVar
  | DNone, DNone -> true
  | _ -> false

let equal_pps_args (ppl1,args1) (ppl2,args2) = 
  (equal_lists_sets equal_pp ppl1 ppl2) &&
  (equal_term_lists args1 args2)
	
let equal_action a1 a2 =
  match a1, a2 with
    AFunApp f, AFunApp f' -> f == f'
  | APatFunApp f, APatFunApp f' -> f == f'
  | AReplIndex, AReplIndex -> true
  | AArrayAccess n, AArrayAccess n' -> n == n'
  | ANew t, ANew t' -> t == t'
  | ANewOracle, ANewOracle -> true
  | AIf, AIf -> true
  | AFind n, AFind n' -> n == n'
  | _ -> false

let equal_cat cat cat' = 
  match cat, cat' with 
  | Complex, Complex -> true
  | Context(g), Context(g') -> g == g'
  | Game(g), Game(g') -> g == g'
  | _ -> false

let equal_q (q1,popt_ref1) (q2,popt_ref2) =
  (equal_query q1 q2) && (popt_ref1 == popt_ref2)
	
let rec equal_probaf p1 p2 =
  match p1, p2 with
    Proba(p, l), Proba(p',l') -> (p == p') && (equal_lists equal_probaf l l')
  | Count p, Count p' -> p == p'
  | OCount (c,n), OCount (c',n') -> c == c' && n == n'
  | Cst f, Cst f' -> f = f'
  | Zero, Zero -> true
  | Card t, Card t' -> t == t'
  | AttTime, AttTime -> true
  | Time (cnt,cat,p), Time (cnt',cat',p') -> (cnt == cnt') && (equal_cat cat cat') && (equal_probaf p p')
  | ActTime(a,l), ActTime(a',l') -> (equal_action a a') && (equal_lists equal_probaf l l')
  | Add(p1,p2), Add(p1',p2') -> (equal_probaf p1 p1') && (equal_probaf p2 p2')
  | Mul(p1,p2), Mul(p1',p2') -> (equal_probaf p1 p1') && (equal_probaf p2 p2')
  | Sub(p1,p2), Sub(p1',p2') -> (equal_probaf p1 p1') && (equal_probaf p2 p2')
  | Div(p1,p2), Div(p1',p2') -> (equal_probaf p1 p1') && (equal_probaf p2 p2')
  | Power(p,n), Power(p', n') -> (equal_probaf p p') && (n == n')
  | Max l, Max l' -> equal_lists equal_probaf l l'
  | Min l, Min l' -> equal_lists equal_probaf l l'
  | Maxlength(n,t),Maxlength(n',t') -> (n == n') && (equal_terms t t')
  | TypeMaxlength(t),TypeMaxlength(t') -> t == t'
  | Length(f,l), Length(f',l') -> (f == f') && (equal_lists equal_probaf l l')
  | EpsFind, EpsFind -> true
  | EpsRand t, EpsRand t' -> t == t'
  | PColl1Rand t, PColl1Rand t' -> t == t'
  | PColl2Rand t, PColl2Rand t' -> t == t'
  | OptimIf(cond,p1,p2), OptimIf(cond',p1',p2') ->
      (equal_optim_cond cond cond') &&
      (equal_probaf p1 p1') && (equal_probaf p2 p2')
  | Advt(g1, cur_q1, ql1), Advt(g2, cur_q2, ql2) ->
      (g1 == g2) && (cur_q1 == cur_q2) &&
      (equal_lists_sets equal_q ql1 ql2)
  | ProbaAssume, ProbaAssume -> true
  | _ -> false

and equal_optim_cond cond cond' =
  match cond, cond' with
  | OCProbaFun(s,l), OCProbaFun(s',l') ->
      (s = s') && (List.for_all2 equal_probaf l l')
  | OCBoolFun(s,l), OCBoolFun(s', l') ->
      (s = s') && (List.for_all2 equal_optim_cond l l')
  | _ -> false
    
let equal_elsefind_facts (bl1,def_list1,t1) (bl2,def_list2,t2) =
  equal_lists (==) bl1 bl2 && 
  equal_def_lists def_list1 def_list2 && 
  equal_terms t1 t2

(* syntactic equality, possibly modulo associativity and commutativity,
   but no other equations *)

let rec dec_prod f t =
  match t.t_desc with
    FunApp(f',[t1;t2]) when f' == f ->
      (dec_prod f t1) @ (dec_prod f t2)
  | _ -> [t]

let rec synt_equal_terms t1 t2 =
  match (t1.t_desc, t2.t_desc) with
    Var(b1,l1),Var(b2,l2) ->
      (b1 == b2) && (List.for_all2 equal_terms l1 l2)
  | ReplIndex b1, ReplIndex b2 -> b1 == b2
  | FunApp(f1,[t1;t1']),FunApp(f2,[t2;t2']) when f1 == f2 && f1.f_eq_theories = Commut ->
      (* Commutative function symbols *)
      ((synt_equal_terms t1 t2) && (synt_equal_terms t1' t2')) ||
      ((synt_equal_terms t1 t2') && (synt_equal_terms t1' t2))
  | FunApp(f1,[_;_]),FunApp(f2,[_;_]) when f1 == f2 && 
      f1.f_eq_theories != NoEq && f1.f_eq_theories != Commut ->
      (* f1 is a binary function with an equational theory that is
	 not commutativity nor inverse -> it is a product-like function *)
	begin
	  let l1 = dec_prod f1 t1 in
	  let l2 = dec_prod f1 t2 in
	  match f1.f_eq_theories with 
	    NoEq | Commut -> Parsing_helper.internal_error "Terms.synt_equal_terms: cases NoEq, Commut should have been eliminated"
	  | AssocCommut | AssocCommutN _ | CommutGroup _ | ACUN _ ->
	      (* Commutative equational theories: test equality up to ordering *)
	      (List.length l1 == List.length l2) &&
	      (equal_up_to_order synt_equal_terms l1 l2)
	  | Assoc | AssocN _ | Group _  ->
	      (* Non-commutative equational theories: test equality in the same order *)
	      equal_lists synt_equal_terms l1 l2		
	end
  | FunApp(f1,l1),FunApp(f2,l2) ->
      (f1 == f2) && (List.for_all2 synt_equal_terms l1 l2)
  | TestE(t1,t2,t3), TestE(t1',t2',t3') ->
      (synt_equal_terms t1 t1') && (synt_equal_terms t2 t2') && (synt_equal_terms t3 t3')
  | FindE(l,t3,find_info),FindE(l',t3',find_info') ->
      (* Could do modulo renaming of bl and bl'! *)
      (equal_lists (fun (bl,def_list,t1,t2) (bl',def_list',t1',t2') ->
	(equal_lists (fun (b1,b2) (b1', b2') -> (b1 == b1') && (b2 == b2')) bl bl') && 
	(equal_def_lists def_list def_list') && 
	(synt_equal_terms t1 t1') && (synt_equal_terms t2 t2')) l l') && 
      (synt_equal_terms t3 t3') &&
      (equal_find_info find_info find_info')
  | LetE(pat, t1, t2, topt), LetE(pat', t1', t2', topt') ->
      (synt_equal_pats pat pat') &&
      (synt_equal_terms t1 t1') &&
      (synt_equal_terms t2 t2') &&
      (match topt, topt' with
	None, None -> true
      |	Some t3, Some t3' -> synt_equal_terms t3 t3'
      |	_ -> false)
  | ResE(b,t), ResE(b',t') ->
      (b == b') && (synt_equal_terms t t')
  | EventAbortE(f), EventAbortE(f') -> 
      f == f'
  | EventE(t,p), EventE(t',p') ->
      (synt_equal_terms t t') &&
      (synt_equal_terms p p')
  | (GetE _, GetE _) | (InsertE _, InsertE _) ->
      Parsing_helper.internal_error "get and insert should not occur in synt_equal_terms"
  | _ -> false

and synt_equal_pats p1 p2 =
  match p1,p2 with
    PatVar b, PatVar b' -> b == b'
  | PatTuple (f,l), PatTuple (f',l') -> (f == f') && (List.for_all2 synt_equal_pats l l')
  | PatEqual t, PatEqual t' -> synt_equal_terms t t'
  | _ -> false


(* Compute a product *)

let rec make_prod prod = function
    [] -> 
      begin
	(* Look for the neutral element of the product *)
	match prod.f_eq_theories with
	  Group(_,_,n) | CommutGroup(_,_,n) | AssocN(_,n) 
	| AssocCommutN(_,n) | ACUN(_,n) -> 
	    app n []
	| _ -> 
	    Parsing_helper.internal_error "Empty product impossible without a neutral element"
      end
  | [t] -> t
  | t::l -> app prod [t; make_prod prod l]
  
(* [make_inv_prod eq_th l1 t l2] computes the product 
   inv (product (List.rev l1)) * t * inv(product l2) *)

let make_inv_prod eq_th l1 t l2 =
  match eq_th with
    ACUN(prod, neut) ->
      make_prod prod (l1 @ (t::l2))
  | Group(prod, inv, neut) | CommutGroup(prod, inv, neut) ->
      let compute_inv = compute_inv try_no_var_id (ref false) (prod, inv, neut) in
      let inv_rev_l1 = List.map compute_inv l1 in
      let inv_l2 = List.map compute_inv (List.rev l2) in
      make_prod prod (inv_rev_l1 @ (t :: inv_l2))
  | _ -> Parsing_helper.internal_error "No product in make_inv_prod"


(* [is_subterm t1 t2] returns [true] when [t1] is a subterm of [t2] *)

let rec is_subterm t1 t2 =
  if equal_terms t1 t2 then true else
  match t2.t_desc with
    Var(_,l) | FunApp(_,l) -> List.exists (is_subterm t1) l
  | ReplIndex _ -> false
  | _ -> Parsing_helper.internal_error "is_subterm only for Var/FunApp/ReplIndex terms"

let rec is_synt_subterm t1 t2 =
  if synt_equal_terms t1 t2 then true else
  match t2.t_desc with
    Var(_,l) | FunApp(_,l) -> List.exists (is_synt_subterm t1) l
  | ReplIndex _ -> false
  | _ -> Parsing_helper.internal_error "is_synt_subterm only for Var/FunApp/ReplIndex terms"

(* Compute the length of the longest common prefix *)

let rec len_common_prefix l1 l2 =
  match (l1, l2) with
    [], _ | _, [] -> 0
  | (a1::l1,a2::l2) ->
      if equal_terms a1 a2 then 1 + len_common_prefix l1 l2 else 0

(* Compute the length of the longest common suffix *)

let len_common_suffix l1 l2 =
  len_common_prefix (List.rev l1) (List.rev l2)

(* Term from pattern *)

let rec term_from_pat = function
    PatVar b -> term_from_binder b
  | PatTuple (f,l) -> 
      app f (List.map term_from_pat l)
  | PatEqual t -> t

(* Type of a pattern *)

let get_type_for_pattern = function
    PatVar b -> b.btype
  | PatTuple(f,_) -> snd f.f_type
  | PatEqual t -> t.t_type

(* Count the number of variables in a term *)

let rec count_var t =
  match t.t_desc with
    FunApp(f,l) -> sum_list count_var l
  | Var _ -> 1
  | ReplIndex _ -> 0
  | _ -> Parsing_helper.internal_error "Only Var/FunApp/ReplIndex expected in count_var"

let rec size t =
  match t.t_desc with
    FunApp(_,l) | Var(_,l) -> sum_list size l
  | ReplIndex _ -> 1
  | _ -> Parsing_helper.internal_error "Only Var/FunApp/ReplIndex expected in size"

(* New variable name *)

(* These functions are used to guarantee the freshness of new identifiers 
   Each identifier is represented by a pair (s,n):
   - if n = 0, then (s,n) is displayed s
   - otherwise, (s,n) is displayed s_n
   Invariant: n has at most 9 digits (supports one billion of variables);
   when n = 0, s is never of the form N_xxx where xxx is a non-zero
   number of at most 9 digits. 
   This guarantees that for each identifier, (s,n) is unique.
   We guarantee the freshness by changing the value of n
*)

(* [get_id_n s] converts [s] into a pair [(s',n)] displayed [s] *)

let get_id_n s =
  let l = String.length s in
  if '0' <= s.[l-1] && s.[l-1] <= '9' then
    let rec underscore_number n = 
      if (n > 0) && (l-n<=10) then
        if s.[n] = '_' then
	  n 
        else if '0' <= s.[n] && s.[n] <= '9' then
	  underscore_number (n-1)
	else
	  raise Not_found
      else
	raise Not_found
    in
    try 
      let pos_underscore = underscore_number (l-2) in
      if s.[pos_underscore+1] = '0' then raise Not_found;
      let n' = int_of_string (String.sub s (pos_underscore+1) (l-pos_underscore-1)) in
      let s' = String.sub s 0 pos_underscore in
      (* print_string (s ^ " split into " ^ s' ^ "  " ^ (string_of_int n') ^ "\n"); *)
      (s',n')
    with Not_found ->
      (* s does not end with _xxx *)
      (s,0)
  else
    (s,0)

(* Counter incremented to generate fresh variable names.
   We use a different counter for each string name,
   stored in a hash table. *)
let vcounter = ref (Hashtbl.create 7)

(* Set of pairs (s,n) used, stored in a hash table. 
   All pairs (s,n) where 0 < n <= !vcounter(s) are considered as always used,
   so we need not add them to the hash table.
   All pairs (s,n) in [used_ids] satisfy [n <= !max_source_idx] *)
let used_ids = ref (Hashtbl.create 7)

(* The maximum xxx such N_xxx occurs and xxx does not come from vcounter *)
let max_source_idx = ref 0

type var_num_state = int * (string, int) Hashtbl.t * (string * int, unit) Hashtbl.t

let get_var_num_state() =
  (!max_source_idx, Hashtbl.copy (!vcounter), Hashtbl.copy (!used_ids))

let set_var_num_state (n,x,y) =
  max_source_idx := n;
  vcounter := x;
  used_ids := y

let get_reset_var_num_state () =
  let res = (!max_source_idx, !vcounter, !used_ids) in
  max_source_idx := 0;
  vcounter := Hashtbl.create 7;
  used_ids := Hashtbl.create 7;
  res
  

(* [record_id s ext] records the identifier [s] so that it will not be reused elsewhere.
   [record_id] must be called only before calls to [fresh_id] or [new_var_name], so that
   [s] cannot collide with an identifier generated by [fresh_id] or [new_var_name].
   Moreover, !vcounter(s) = 0, there are no pairs (s,n) with 0 < n <= !vcounter(s),
   so the used pairs are exactly those in the hash table used_ids. *)

let record_id s ext =
  let (_,n) as s_n = get_id_n s in
  if n > !max_source_idx then max_source_idx := n;
  (* Adds s_n to used_ids if it is not already in *)
  Hashtbl.replace (!used_ids) s_n ()
    
(* [new_var_name s] creates a fresh pair [(s,n)] using [!vcounter(s)]. *) 

let rec new_var_name_counter counter s =
  let n = counter+1 in
  if (n <= !max_source_idx) && (Hashtbl.mem (!used_ids) (s,n)) then
    new_var_name_counter n s
  else
    n

let new_var_name s =
  let counter = (try Hashtbl.find (!vcounter) s with Not_found -> 0) in
  let counter' = new_var_name_counter counter s in
  Hashtbl.replace (!vcounter) s counter';
  (s, counter')
      
(* [fresh_id s] creates a fresh identifier [s'] corresponding to
   identifier [s], preferably [s] itself. If [s] is already used,
   create a fresh identifier by changing the number suffix of [s], or
   adding a number suffix to [s] if there is none, using [new_var_name] *)

let fresh_id s =
  let ((s',n) as s_n) = get_id_n s in
  let counter = (try Hashtbl.find (!vcounter) s' with Not_found -> 0) in
  if ((n != 0) && (n <= counter)) || (Hashtbl.mem (!used_ids) s_n) then
    let n' = new_var_name_counter counter s' in
    Hashtbl.replace (!vcounter) s' n';
    s' ^ "_" ^ (string_of_int n')
  else
    begin
      if n > !max_source_idx then max_source_idx := n;
      Hashtbl.add (!used_ids) s_n ();
      s
    end

(* [fresh_id_keep_s s] creates a fresh pair [(s',n)] corresponding to 
   identifier [s], preferably one that display as [s] itself. 
   If [s] is already used, create a fresh identifier by changing 
   the number suffix of [s], or adding a number suffix to [s] if 
   there is none, using [new_var_name] *) 

let fresh_id_keep_s s =
  let ((s',n) as s_n) = get_id_n s in
  let counter = (try Hashtbl.find (!vcounter) s' with Not_found -> 0) in
  if ((n != 0) && (n <= counter)) || (Hashtbl.mem (!used_ids) s_n) then
    let n' = new_var_name_counter counter s' in
    Hashtbl.replace (!vcounter) s' n';
    (s', n')
  else
    begin
      if n > !max_source_idx then max_source_idx := n;
      Hashtbl.add (!used_ids) s_n ();
      s_n
    end
        
let new_binder b0 =
  (* Invariant: 
     if vname = 0, then sname never contains N_xxx where xxx is a non-zero 
     number of at most 9 digits. As a consequence, we don't need to split 
     v.sname using fresh_id_n. *)
  let (s, n) = new_var_name b0.sname in
  { sname = s;
    vname = n;
    btype = b0.btype;
    args_at_creation = b0.args_at_creation;
    def = b0.def;
    link = NoLink;
    count_def = 0;
    root_def_array_ref = false;
    root_def_std_ref = false;
    array_ref = false;
    std_ref = false;
    count_array_ref = 0;
    count_exclude_array_ref = 0;
    priority = 0 }

let new_repl_index b0 =
  let (s, n) = new_var_name b0.ri_sname in
  { ri_sname = s;
    ri_vname = n;
    ri_type = b0.ri_type;
    ri_link = NoLink }

let create_binder_internal s n t a =
  { sname = s;
    vname = n;
    btype = t;
    args_at_creation = a;
    def = [];
    link = NoLink;
    count_def = 0;
    root_def_array_ref = false;
    root_def_std_ref = false;
    array_ref = false;
    std_ref = false;
    count_array_ref = 0;
    count_exclude_array_ref = 0;
    priority = 0 }

let create_binder s t a =
  let (s', n) = fresh_id_keep_s s in
  create_binder_internal s' n t a

let create_binder0 s t a =
  let (s', n) = get_id_n s in
  create_binder_internal s' n t a
    
let create_repl_index s t =
  let (s', n) = fresh_id_keep_s s in  
  { ri_sname = s';
    ri_vname = n;
    ri_type = t;
    ri_link = NoLink }

(* [get_name_proj s] returns [Some(s1,s2)] when [s] starts with numbers,
   followed by "-proj-", where [s1] consists of numbers followed by
   "-proj-" and [s2] is the rest of the string [s].
   The name of projections as generated by Settings.get_proj
   satisfies this condition, and no other function does.
   (In particular, identifiers chosen by the user cannot
   satisfy it, because they cannot contain "-".) *)

let rec get_name_proj_aux n s =
  if String.length s < n+6 then None else
  if ('0' <= s.[n]) && ('9' >= s.[n]) then get_name_proj_aux (n+1) s else
  if (String.sub s n 6) = "-proj-" then
    Some (String.sub s 0 (n+6), String.sub s (n+6) (String.length s-n-6))
  else
    None

let get_name_proj s = get_name_proj_aux 0 s
    
(* Set the definition point of binders, with no other information;
   returns the definition node *)

let set_def binders pp pp_success above_node_opt =
  let node =
    { above_node = above_node_opt;
      binders = binders;
      true_facts_at_def = [];
      def_vars_at_def = [];
      elsefind_facts_at_def = [];
      future_binders = []; future_true_facts = []; 
      definition = pp; definition_success = pp_success }
  in
  List.iter (fun b -> b.def <- node :: b.def) binders;
  node

let dummy_def b = 
  (* Make sure that [b] has at least one definition,
     because otherwise, it may be considered erroneously
     as random choice (when a variable has no definition,
     all its definitions are random choices!) *)
  ignore (set_def [b] DNone DNone None);
  b.count_def <- 1
    
(* Event *)

let create_event s tyl =
  Settings.create_fun s
    (* Add a bitstring argument to store the current indices *)
    (Settings.t_bitstring :: tyl, Settings.t_bool)
    Event 
    
let create_nonunique_event() =
  Settings.create_fun (fresh_id "non_unique")
    (* Add a bitstring argument to store the current indices *)
    ([Settings.t_bitstring], Settings.t_bool)
    NonUniqueEvent 
    
let e_adv_loses =
  let event_set = ref None in
  fun () ->
    match !event_set with
    | None ->
	let r = create_event (fresh_id "adv_loses") [] in
	event_set := Some r;
	r
    | Some r -> r

let e_bad_guess =
  let event_set = ref None in
  fun () ->
    match !event_set with
    | None ->
	let r = create_event (fresh_id "bad_guess") [] in
	event_set := Some r;
	r
    | Some r -> r

(* Create a term containing general variables that corresponds to a pattern *)

exception NonLinearPattern

let gvar_name = "?x"

let create_gvar b = 
  let b' = create_binder gvar_name b.btype [] in
  ignore (set_def [b'] DGenVar DNone None);
  b'

let gen_term_from_pat pat = 
  let rec gterm_from_pat = function
      PatVar b ->
	let b' = create_gvar b in
	if b.link != NoLink then raise NonLinearPattern;
	let bt = term_from_binder b' in
	link b (TLink bt);
	bt
    | PatTuple (f,l) -> 
	app f (List.map gterm_from_pat l)
    | PatEqual t -> t
  in
  auto_cleanup (fun () -> gterm_from_pat pat)

let rec single_occ_gvar seen_list t = 
  match t.t_desc with
    Var (b,l) -> 
      if b.sname == gvar_name then
	begin
	  if List.memq b (!seen_list) then false else
	  begin
	    seen_list := b :: (!seen_list);
	    true
	  end
	end
      else
	List.for_all (single_occ_gvar seen_list) l
  | ReplIndex _ -> true
  | FunApp(_,l) -> List.for_all (single_occ_gvar seen_list) l
  | _ -> Parsing_helper.internal_error "Only Var/FunApp/ReplIndex expected in single_occ_gvar"



(* Find out whether a term is a conjunction of "defined(...)" conditions *)

let mem_binderref br l = List.exists (equal_binderref br) l

let add_binderref a accu =
  if mem_binderref a (!accu) then () else accu := a :: (!accu)

let setminus_binderref s1 s2 =
  List.filter (fun br -> not (mem_binderref br s2)) s1

let inter_binderref s1 s2 =
  List.filter (fun br -> mem_binderref br s2) s1

let union_binderref s1 s2 = 
  s2 @ (setminus_binderref s1 s2)

(* get def_list subterms *)

let get_deflist_subterms accu t =
  let rec aux_t t = 
    match t.t_desc with
      Var(b,l) -> add_binderref (b,l) accu
    | _ -> iter_subterm aux_t (fun _ -> ()) aux_pat t
	(* The cases TestE, FindE, LetE, RestE, EventAbortE are probably not used *)
  and aux_pat pat =
    iter_subpat aux_t aux_pat pat
  in
  aux_t t
    
(* Change the occurrences and make sure nodes associated with Find
   are distinct for different occurrences of Find *)

let rec move_occ_term t = 
  let x_occ = new_occ() in
  let desc = map_subterm move_occ_term move_occ_def_list move_occ_pat t in
  { t_desc = desc;
    t_type = t.t_type;
    t_occ = x_occ;
    t_max_occ = !occ;
    t_loc = t.t_loc;
    t_incompatible = Occ_map.empty;
    t_facts = None }

and move_occ_pat pat =
  map_subpat move_occ_term move_occ_pat pat

and move_occ_def_list def_list = List.map (fun (b,l) -> (b, List.map move_occ_term l)) def_list

let rec move_occ_process p = 
  let x_occ = new_occ() in
  let desc = map_subiproc move_occ_process (fun o patl p ->
    let patl' = List.map move_occ_pat patl in
    let p' = move_occ_oprocess p in
    (o, patl', p')) p
  in
  { i_desc = desc;
    i_occ = x_occ; 
    i_max_occ = !occ;
    i_loc = p.i_loc;
    i_incompatible = Occ_map.empty; 
    i_facts = None }

and move_occ_oprocess p =
  let x_occ = new_occ() in
  let desc = map_suboproc move_occ_oprocess move_occ_term move_occ_def_list
      move_occ_pat move_occ_process p
  in
  { p_desc = desc;
    p_occ = x_occ;
    p_max_occ = !occ;
    p_loc = p.p_loc;
    p_incompatible = Occ_map.empty; 
    p_facts = None }

let move_occ_process p =
  occ := 0;
  move_occ_process p

let move_occ_game g =
  match g.proc with
  | RealProcess p ->
     g.proc <- RealProcess (move_occ_process p)
  | Forgotten _ -> ()

(* Does not change the term, but removes any information stored
   in it (known facts, occurrence, incompatible program points),
   to make sure that information that is no longer valid is not used,
   and creates a distinct physical copy for each term.
   (needed for [build_def_process]). *)

let rec delete_info_term t = 
  let desc = map_subterm delete_info_term delete_info_def_list delete_info_pat t in
  build_term t desc

and delete_info_pat pat =
  map_subpat delete_info_term delete_info_pat pat

and delete_info_def_list def_list = List.map (fun (b,l) -> (b, List.map delete_info_term l)) def_list

(* Copy a term
   Preserves occurrences of the original term. This is useful so that
   we can designate variables by occurrences in simplify coll_elim;
   otherwise, occurrences would be modified before they are tested.

   Several transformations are possible
 *)

type copy_transf =
  | DeleteFacts
  | Links_RI (* Substitutes replication indices that are linked *)
  | Links_Vars 
     (* Substitutes variables that are linked, when their arguments are args_at_creation
	The linked variables are supposed to be defined above the copied terms/processes *)
  | Links_RI_Vars (* Combines Links_RI and Links_Vars *)
  | Links_Vars_then_RI (* Same as Links_Vars, but then applies Links_RI to the
         substituted terms *)
  | OneSubst of binder * term * bool ref 
     (* OneSubst(b,t,changed) substitutes t for b[b.args_at_creation].
	Sets changed to true when such a substitution has been done.
	b is assumed to be defined above the copied terms/processes *) 
  | OneSubstArgs of binderref * term 
     (* OneSubstArgs(br,t) substitutes t for the accesses br.
	It is assumed that br and t are already guaranteed to be defined,
	so br is removed from defined conditions if it occurs. *)
  | SubstArgs of (binderref * term) list
     (* Same as OneSubstArgs but performs several substitutions *)
  | Rename of term list * binder * binder
     (* Rename(args, b, b') replaces array accesses b[args] with b'[args] *)
  | RenameIdxSuffix of term list * binder * binder * binder list 
     (* RenameIdxSuffix(args, b, b', exclude_binders) replaces array accesses
	b[l] with b'[l] when [args] is a suffix of [l]. Raises [Bad_copy]
	when b''[l] occurs with [b'' != b], [b'' \in exclude_binders],
	and [args] is a suffix of [l]. *)
  | Links_Vars_Args of (binder * binder) list
     (* Links_Vars_Args(replacement_def_list) substitutes variables that are 
	linked, for any arguments: if b is linked to M, b[l] is
	replaced with M{l/b.args_at_creation}. replacement_def_list defines
	variable replacements to do in defined conditions. *)

exception Bad_copy
	
(* Helper function for copy_def_list in case Links_Vars_Args *)

let rec get_remassign_subterms accu (b,l) =
  List.iter (get_remassign_terms accu) l;
  match b.link with
    NoLink -> ()
  | TLink _ -> add_binderref (b,l) accu
  | _ -> assert false

and get_remassign_terms accu t =
  match t.t_desc with
    Var(b,l) -> get_remassign_subterms accu (b,l)
  | ReplIndex(b) -> ()
  | FunApp(f,l) -> List.iter (get_remassign_terms accu) l
  | _ -> Parsing_helper.internal_error "if/let/find forbidden in defined conditions of find"

(* Copy functions *)

let rec copy_binder transf (b,l) =
  match transf with
    Rename(cur_array, b0, b0') ->
      let l' = List.map (copy_term transf) l in
      if (b == b0) && (List.for_all2 equal_terms l cur_array) then
	(b0', l')
      else
	(b,l')
  | RenameIdxSuffix(cur_array_suffix, b0, b0', exclude_binders) ->
      let l' = List.map (copy_term transf) l in
      if b == b0 then
	if List.for_all2 equal_terms (lsuffix (List.length cur_array_suffix) l) cur_array_suffix then
	  (b0',l')
	else
	  (b, l')
      else if List.memq b exclude_binders then
	if List.for_all2 equal_terms (lsuffix (List.length cur_array_suffix) l) cur_array_suffix then
	  raise Bad_copy
	else
	  (b, l')	
      else
	(b,l')
  | _ -> 
      Parsing_helper.internal_error "copy_binder allowed only with transformations Rename and RenameIdxSuffix"

and copy_term transf t = 
  match t.t_desc with
    ReplIndex b -> 
      begin
	match transf with
	| DeleteFacts -> build_term2 t t.t_desc
	| Links_Vars | Links_Vars_then_RI | OneSubst _ | OneSubstArgs _
	| SubstArgs _ | Rename _ | RenameIdxSuffix _ | Links_Vars_Args _ -> t
	| Links_RI | Links_RI_Vars -> 
	    match b.ri_link with
	      NoLink -> t
	    | TLink t' -> delete_info_term t' (* Delete information stored in [t'] *)
	    | _ -> assert false
      end
  | Var(b,l) ->
      begin
        match transf with
          OneSubst(b',t',changed) ->
            if (b == b') && (is_args_at_creation b l) then
	      begin
		changed := true;
                delete_info_term t' (* Delete information stored in [t'] *)
	      end
            else
	      build_term2 t (Var(b,List.map (copy_term transf) l))
	| OneSubstArgs((b',l'), t') ->
	    if (b == b') && (List.for_all2 equal_terms l l') then
	      delete_info_term t' (* Delete information stored in [t'] *)
	    else
	      build_term2 t (Var(b,List.map (copy_term transf) l))
	| SubstArgs(lsubst) ->
	    begin
	      try
		let (_, t') =
		  List.find (fun ((b',l'), t') ->
		    (b == b') && (List.for_all2 equal_terms l l')
		      ) lsubst
		in
		delete_info_term t' (* Delete information stored in [t'] *)
	      with Not_found ->
		build_term2 t (Var(b,List.map (copy_term transf) l))
	    end
	| Rename _ | RenameIdxSuffix _ ->
	    let (b',l') = copy_binder transf (b,l) in
	    build_term2 t (Var(b',l'))
	| Links_Vars_Args _ -> 
	    begin
	      let l' = List.map (copy_term transf) l in
	      match b.link with
		NoLink -> build_term2 t (Var(b,l'))
	      | TLink t ->
		  let t = copy_term transf t in
                  (* Rename array indices *)
		  subst b.args_at_creation l' t
	      | _ -> assert false
	    end
	| DeleteFacts | Links_RI ->  build_term2 t (Var(b,List.map (copy_term transf) l))
	| Links_Vars_then_RI ->
	    begin
	      match b.link with
		TLink t' when is_args_at_creation b l -> copy_term Links_RI t'
	      | _ -> build_term2 t (Var(b,List.map (copy_term transf) l))
	    end
	| Links_Vars | Links_RI_Vars ->
	    match b.link with
	      TLink t' when is_args_at_creation b l ->
		delete_info_term t' (* Delete information stored in [t'] *)
	    | _ -> build_term2 t (Var(b,List.map (copy_term transf) l))
      end
  | _ ->
      build_term2 t (map_subterm (copy_term transf)
		       (copy_def_list transf) (copy_pat transf) t)

and copy_def_list transf def_list =
  let copy_br (b,l) = (b, List.map (copy_term transf) l) in
  match transf with
    OneSubst(b',t',changed) ->
      (* When removing assignments in_scope_only, and I am removing
         assignments on b, I know that b is in scope, so
         b[b.args_at_creation] is always defined, and I can remove that
         defined condition *)
      List.map copy_br
       (List.filter (fun (b,l) ->
          not ((b == b') && (is_args_at_creation b l))) def_list)
  | OneSubstArgs(br', t') ->
      List.map copy_br
       (List.filter (fun br ->
         not (equal_binderref br br')) def_list)
  | SubstArgs(lsubst) ->
      List.map copy_br
	(List.filter
	   (fun br -> not (List.exists (fun (br', t') -> equal_binderref br br') lsubst))
	   def_list)
  | Rename _ | RenameIdxSuffix _ ->
      List.map (copy_binder transf) def_list
  | Links_Vars_Args(replacement_def_list) ->
      (* Update def_list, following removal of assignments *)
      (* 1: root_remassign = subterms of def_list whose root is
         a variable on which we remove assignments *)
      let root_remassign = ref [] in
      List.iter (get_remassign_subterms root_remassign) def_list;
      (* 2: not_root_remassign = elements of def_list whose root is
         not a variable on which we remove assignments *)
      let not_root_remassign =
	List.filter (fun (b,l) ->
	  match b.link with
	    NoLink -> true
	  | TLink _ -> false
	  | _ -> assert false
	      ) def_list 
      in
      (* 3: compute the new def_list *)
      let accu = ref 
	  (List.map copy_br ((!root_remassign) @ not_root_remassign))
      in
      List.iter (fun br -> get_deflist_subterms accu
	(copy_term transf (term_from_binderref br))) (!root_remassign);
      (* 4: replace defined(b) with defined(b') when b was used
	 only in defined conditions and it is defined when b' is defined.
	 Remove duplicate elements. *)
      List.fold_right (fun (b,l) accu' ->
	let br' = 
	  try 
	    (List.assq b replacement_def_list, l)
	  with Not_found ->
	    (b,l)
	in
	if mem_binderref br' accu' then accu' else br'::accu') (!accu) [];
  | DeleteFacts | Links_RI -> List.map copy_br def_list
  | Links_Vars | Links_RI_Vars | Links_Vars_then_RI ->
      (* When we substitute b (b.link != NoLink), we know that b is in scope, so
	 we can remove the condition that b is defined. *)
      List.map copy_br
       (List.filter (fun (b,l) ->
          not ((b.link != NoLink) && (is_args_at_creation b l))) def_list)
      
and copy_pat transf pat =
  map_subpat (copy_term transf) (copy_pat transf) pat

(* Compute term { l / cur_array } *)

and subst cur_array l term =
  List.iter2 (fun b t -> b.ri_link <- (TLink t)) cur_array l;
  let term' = copy_term Links_RI term in
  List.iter (fun b -> b.ri_link <- NoLink) cur_array;
  term'

let copy_elsefind (bl, def_vars, t) =
  (* The links define a substitution. 
     We want to apply this substitution to the elsefind fact (bl, def_vars, t).
     bl binds variables; they will not be modified by the substitution.
     To avoid capture, the image of the substitution must not contain replication indices in bl.
     (The image of the substitution may be fresh replication indices.) *)
  let old_links = List.map (fun ri ->
    let link = ri.ri_link in
    ri.ri_link <- NoLink;
    (ri, link)) bl
  in
  let res = (bl, copy_def_list Links_RI def_vars, copy_term Links_RI t) in
  List.iter (fun (ri, link) -> ri.ri_link <- link) old_links;
  res

let rec copy_process transf p = 
  iproc_from_desc_loc p (map_subiproc (copy_process transf) (fun o patl p ->
    (o,
     List.map (copy_pat transf) patl,
     copy_oprocess transf p)) p)

and copy_oprocess transf p =
  oproc_from_desc_loc p
    (map_suboproc (copy_oprocess transf) (copy_term transf)
       (copy_def_list transf) (copy_pat transf) (copy_process transf) p)

let rec copy_fungroup transf = function
  | ReplRestr(repl_opt, restr, funlist) ->
      ReplRestr(repl_opt, restr, List.map (copy_fungroup transf) funlist)
  | Fun(ch, args, res, priority) ->
      Fun(ch, args, copy_term transf res, priority)

let copy_eqside transf rm = 
  List.map (fun (fg, mode) ->
    (copy_fungroup transf fg, mode)
      ) rm
    
(* Compute element{l/cur_array}, where element is def_list, simp_facts
   Similar to what subst does for terms. *)

let subst_def_list cur_array l def_list =
  List.iter2 (fun b t -> b.ri_link <- (TLink t)) cur_array l;
  let def_list' = copy_def_list Links_RI def_list in
  List.iter (fun b -> b.ri_link <- NoLink) cur_array;
  def_list'

let subst_else_find cur_array l (bl, def_list, t) =
  (* First, we rename bl to fresh replication indices to avoid capture *)
  let bl_ren = List.map (fun ri -> create_repl_index "@ri" ri.ri_type) bl in
  List.iter2 (fun ri ri_ren -> ri.ri_link <- (TLink (term_from_repl_index ri_ren))) bl bl_ren;
  let def_list_ren = copy_def_list Links_RI def_list in
  let t_ren = copy_term Links_RI t in
  List.iter (fun ri -> ri.ri_link <- NoLink) bl;
  (* Then we substitute l for cur_array in the obtained elsefind fact *)
  List.iter2 (fun b t -> b.ri_link <- (TLink t)) cur_array l;
  let elsefind_fact' = (bl_ren, copy_def_list Links_RI def_list_ren, copy_term Links_RI t_ren) in
  List.iter (fun b -> b.ri_link <- NoLink) cur_array;
  elsefind_fact'

let subst_simp_facts cur_array l (substs, facts, elsefind) =
  List.iter2 (fun b t -> b.ri_link <- (TLink t)) cur_array l;
  let substs' = List.map (copy_term Links_RI) substs in
  let facts' = List.map (copy_term Links_RI) facts in
  List.iter (fun b -> b.ri_link <- NoLink) cur_array;
  (substs', facts', List.map (subst_else_find cur_array l) elsefind)

let subst_pps cur_array l ppsl =
  List.iter2 (fun b t -> b.ri_link <- (TLink t)) cur_array l;
  let ppsl' = List.map (fun (ppl, args) -> (ppl, List.map (copy_term Links_RI) args)) ppsl in
  List.iter (fun b -> b.ri_link <- NoLink) cur_array;
  ppsl'
    
(* Substitution of v[v.args_at_creation] only
   Preserves occurrences of the original term. This is useful so that
   we can designate variables by occurrences in simplify coll_elim;
   otherwise, occurrences would be modified before they are tested. *)

let subst3 subst t =
  auto_cleanup (fun () ->
    List.iter (fun (b,t') -> link b (TLink t')) subst;
    copy_term Links_Vars t)

let subst_def_list3 subst def_list =
  auto_cleanup (fun () ->
    List.iter (fun (b,t') -> link b (TLink t')) subst;
    copy_def_list Links_Vars def_list)

let subst_oprocess3 subst p =
  auto_cleanup (fun () ->
    List.iter (fun (b,t') -> link b (TLink t')) subst;
    copy_oprocess Links_Vars p)

(* [find_some f l] returns [f a] for the first element
   [a] of the list [l] such that [f a <> None].
   It returns [None] if [f a = None] for all [a] in [l]. *)

let rec find_some f = function
    [] -> None
  | a::l ->
      match f a with
	None -> find_some f l
      |	x -> x

(* [replace l1 l0 t] replaces all terms in [l1] with the 
   corresponding term in [l0] inside [t] *)

let rec assoc l1 l0 t =
  match l1, l0 with
    [], [] -> raise Not_found
  | a1::l1, a0::l0 ->
      if equal_terms a1 t then a0 else assoc l1 l0 t
  | _ ->
      Parsing_helper.internal_error "Lists should have the same length in Terms.assoc"
    
let rec replace l1 l0 t =
  try
    assoc l1 l0 t
  with Not_found ->
    match t.t_desc with
      FunApp(f,l) ->
	build_term2 t (FunApp(f, List.map (replace l1 l0) l))
    | ReplIndex _ -> t
    | Var(b,l) ->
	build_term2 t (Var(b, List.map (replace l1 l0) l))
    | _ -> Parsing_helper.internal_error "Var/Fun/ReplIndex expected in Terms.replace"

(* Check whether a term t refers to a binder b0 *)

let no_def = ref false

let rec refers_to b0 t = 
  (match t.t_desc with
    Var (b,l) -> 
      (b == b0) ||
      (match b.link with
	 TLink t -> refers_to b0 t
      | _ -> false)
  | _ -> false) ||
  (exists_subterm (refers_to b0) (refers_to_def_list b0) (refers_to_pat b0) t)

and refers_to_br b0 (b,l) =
  ((not (!no_def)) && (b == b0)) || List.exists (refers_to b0) l
      
and refers_to_def_list b0 def_list = List.exists (refers_to_br b0) def_list

and refers_to_pat b0 pat =
  exists_subpat (refers_to b0) (refers_to_pat b0) pat

let rec refers_to_process b0 p =
  exists_subiproc (refers_to_process b0) (fun o patl p ->
    (List.exists (refers_to_pat b0) patl) ||
    (refers_to_oprocess b0 p)
      ) p

and refers_to_oprocess b0 p =
  exists_suboproc (refers_to_oprocess b0) (refers_to b0) (refers_to_def_list b0)
    (refers_to_pat b0) (refers_to_process b0) p

let rec refers_to_fungroup b = function
    ReplRestr(_,_,funlist) ->
      List.exists (refers_to_fungroup b) funlist
  | Fun(_,_,res,_) -> refers_to b res

let rec refers_to_qterm b t = 
  exists_qterm (refers_to_qterm b) (refers_to b) t
	
let refers_to_nodef b0 t =
  no_def := true;
  let res = refers_to b0 t in
  no_def := false;
  res

let refers_to_process_nodef b0 p =
  no_def := true;
  let res = refers_to_oprocess b0 p in
  no_def := false;
  res

(* Test if a term uses a function symbol *)

let rec uses_f f t =
  match t.t_desc with
  | FunApp(f',_) when f == f' -> true
  | _ -> exists_subterm (uses_f f) (List.exists (fun (_,l) -> List.exists (uses_f f) l)) (uses_pat_f f) t

and uses_pat_f f = function
  | PatTuple(f',_) when f == f' -> true
  | pat -> exists_subpat (uses_f f) (uses_pat_f f) pat

(* Collect all function symbols in a term, in a side of an equiv *)

let rec collect_f funs t =
  match t.t_desc with
  | FunApp(f,l) -> addq_ref funs f; List.iter (collect_f funs) l
  | _ -> iter_subterm (collect_f funs) (List.iter (fun (_,l) -> List.iter (collect_f funs) l)) (collect_pat_f funs) t

and collect_pat_f funs = function
  | PatVar _ -> ()
  | PatTuple(f,l) ->
      addq_ref funs f; List.iter (collect_pat_f funs) l
  | PatEqual t -> collect_f funs t

let rec collect_fg_f funs = function
  | ReplRestr(_,_,fl) -> List.iter (collect_fg_f funs) fl
  | Fun(_,_,t,_) -> collect_f funs t

let collect_eqmember_f funs m =
  List.iter (fun (fg,_) -> collect_fg_f funs fg) m
	
(* Collect variables from correspondence queries *)

let rec collect_vars accu t =
  match t.t_desc with
    Var(b,[]) -> addq_ref accu b 
  | FunApp(f,l) -> List.iter (collect_vars accu) l
  | _ -> Parsing_helper.internal_error "expecting variable or function in collect_vars"

let collect_vars_hyp t1 =
  let vars_t1 = ref [] in
  List.iter (fun (_, t) -> collect_vars vars_t1 t) t1;
  (!vars_t1)

(* Collect universal and existential variables of a correspondence query for display *)
    
let collect_vars_event accu t =
  match t.t_desc with
  | FunApp(_,idx::l) ->
      (* Do not display replication index variables *)
      List.iter (collect_vars accu) l
  | _ -> assert false
    
let rec collect_vars_qterm accu accu_event_t = function
  | QEvent(_,t) -> collect_vars_event accu_event_t t 
  | QTerm t -> collect_vars accu_event_t t
  | QNot(QEvent(_,t)) -> collect_vars_event accu t
  | QNot _ | QExists _ | QForall _ ->
      assert false
  | QAnd(t1,t2) | QOr(t1,t2) -> 
      collect_vars_qterm accu accu_event_t t1;
      collect_vars_qterm accu accu_event_t t2

let collect_vars_corresp t1 t2 =
  let vars_t1 = ref [] in
  List.iter (fun (_, t) -> collect_vars_event vars_t1 t) t1;
  let vars_t1 = (!vars_t1) in
  let vars_t2_event_t = ref [] in
  let vars_t2_not_event = ref [] in
  collect_vars_qterm vars_t2_not_event vars_t2_event_t t2;
  let exists = List.filter (fun b -> not (List.memq b vars_t1)) (!vars_t2_event_t) in
  let forall = List.filter (fun b -> not (List.memq b vars_t1) && not (List.memq b (!vars_t2_event_t))) (!vars_t2_not_event) in
  (vars_t1, exists, forall)
					    
(* Extract defined variables from a pattern *)

let rec vars_from_pat accu = function
    PatVar b -> b::accu
  | PatEqual t -> accu
  | PatTuple (f,l) -> vars_from_pat_list accu l

and vars_from_pat_list accu = function
    [] -> accu
  | (a::l) -> vars_from_pat_list (vars_from_pat accu a) l


(* Test if a variable occurs (in pattern position) in a pattern *)

let rec occurs_in_pat b = function
    PatVar b' -> b' == b
  | PatTuple (f,l) -> List.exists (occurs_in_pat b) l
  | PatEqual t -> false

(* Check that a term is a basic term (no if/let/find/new/event/get/insert) *)

let rec check_simple_term t =
  match t.t_desc with
  | Var(_,l) | FunApp(_,l) ->
      List.for_all check_simple_term l
  | ReplIndex _ -> true
  | TestE _ | FindE _ | LetE _ | ResE _ | EventAbortE _ | EventE _ | GetE _ | InsertE _ ->
      false

(* Check that a term has no effect (no change in state: no definition
   of a variable, which may have array accesses, no events, no changes in
   tables). That allows "if" in addition to simple terms. *)
	
let rec no_effect t =
  match t.t_desc with
  | Var(_,l) | FunApp(_,l) ->
     List.for_all no_effect l
  | ReplIndex _ -> true
  | TestE(t1,t2,t3) ->
     (no_effect t1) && (no_effect t2) && (no_effect t3)
  | LetE _ | FindE _ | ResE _ | EventE _ | EventAbortE _ | GetE _ | InsertE _ ->
     false

(* Check that an expanded term is a basic term (no if/let/find/new/event/get/insert).
   Because the term is expanded, if if/let/find/new/event/get/insert occurred in it,
   it would occur at the top, so we do not need to inspect the whole term. *)

let check_simple_expanded t =
  match t.t_desc with
  | Var _ | FunApp _ | ReplIndex _ -> true
  | TestE _ | FindE _ | LetE _ | ResE _ | EventAbortE _ | EventE _ | GetE _ | InsertE _ ->
      false
       
(* Check if a term may abort *)

let rec may_abort t =
  let rec aux_t t =
    match t.t_desc with
    | EventAbortE _ -> true
    | FindE(l0,t3,find_info) ->
	((find_info != Nothing) &&
	 (match l0 with
	 | [([],_,_,_)] -> (* there is unique choice (one branch, no index),
	     so that find never aborts even if it is marked [unique] *) false
	 | _ -> true)) ||
	   (exists_subterm aux_t (fun br -> false) aux_pat t)
    | GetE(_,_,_,_,_,find_info) ->
	(find_info != Nothing) ||
	(exists_subterm aux_t (fun br -> false) aux_pat t)
    | _ -> exists_subterm aux_t (fun br -> false) aux_pat t

  and aux_pat pat =
    exists_subpat aux_t aux_pat pat

  in
  aux_t t

(* Testing boolean values *)

let is_true t =
  match t.t_desc with
    FunApp(f,[]) when f == Settings.c_true -> true
  | _ -> false

let is_false t =
  match t.t_desc with
    FunApp(f,[]) when f == Settings.c_false -> true
  | _ -> false

(* Applying boolean functions *)

let make_true () =
  app Settings.c_true []
  
let make_false () =
  app Settings.c_false []

let make_and_ext ext t t' =
  if (is_true t) || (is_false t' && no_effect t) then t' else
  if (is_true t') || (is_false t && no_effect t') then t else
  new_term Settings.t_bool ext (FunApp(Settings.f_and, [t;t']))

let make_and t t' =  
  make_and_ext Parsing_helper.dummy_ext t t'

let make_or_ext ext t t' =
  if (is_false t) || (is_true t' && no_effect t) then t' else
  if (is_false t') || (is_true t && no_effect t') then t else
  new_term Settings.t_bool ext (FunApp(Settings.f_or, [t;t']))

let make_or t t' =  
  make_or_ext Parsing_helper.dummy_ext t t'

let make_and_list = function
    [] -> make_true()
  | [a] -> a
  | (a::l) -> List.fold_left make_and a l
	
let rec split_and accu t = 
  match t.t_desc with
    FunApp(f, [t1;t2]) when f == Settings.f_and ->
      split_and (split_and accu t1) t2
  | _ -> 
      if no_effect t && List.exists (fun t' -> equal_terms t t') accu then
	accu
      else
	t::accu

(* [make_and_list [t1; ...; tn] ] is equivalent to
   [t1 && ... && tn], with [t1] evaluated first and [tn] last *)
let make_and_list l =
  let l' = List.fold_left split_and [] l in
  make_and_list (List.rev l')

let make_or_list = function
    [] -> make_false()
  | [a] -> a
  | (a::l) -> List.fold_left make_or a l

let rec split_or accu t = 
  match t.t_desc with
    FunApp(f, [t1;t2]) when f == Settings.f_or ->
      split_or (split_or accu t1) t2
  | _ -> 
      if no_effect t && List.exists (fun t' -> equal_terms t t') accu then
	accu
      else
	t::accu

(* [make_or_list [t1; ...; tn] ] is equivalent to
   [t1 || ... || tn], with [t1] evaluated first and [tn] last *)
let make_or_list l =
  let l' = List.fold_left split_or [] l in
  make_or_list (List.rev l')

let make_not t =
  app Settings.f_not [t]
  
let make_equal_ext ext t t' =
  new_term Settings.t_bool ext
    (FunApp(Settings.f_comp Equal t.t_type t'.t_type, [t;t']))

let make_equal t t' = 
  if equal_terms t t' then make_true() else
  make_equal_ext Parsing_helper.dummy_ext t t'

let make_let_equal t t' =
  begin
    match t.t_desc with
      Var _ -> ()
    | _ -> Parsing_helper.internal_error "make_let_equal:  LetEqual terms should have a variable in the left-hand side"
  end;
  app (Settings.f_comp LetEqual t.t_type t'.t_type) [t;t']

let fact_from_pat_t pat t =
  match pat with
  | PatVar b -> make_let_equal (term_from_binder b) t
  | _ -> make_equal (term_from_pat pat) t
    
let make_diff_ext ext t t' =
  new_term Settings.t_bool ext
    (FunApp(Settings.f_comp Diff t.t_type t'.t_type, [t;t']))

let make_diff t t' = 
  if equal_terms t t' then make_false() else
  make_diff_ext Parsing_helper.dummy_ext t t'

let make_for_all_diff t t' =
  app (Settings.f_comp ForAllDiff t.t_type t'.t_type) [t;t']

let build_term_at t desc =
  { t_desc = desc;
    t_type = t.t_type;
    t_occ = t.t_occ;
    t_max_occ = t.t_max_occ;
    t_loc = t.t_loc;
    t_incompatible = t.t_incompatible;
    t_facts = t.t_facts }

let make_true_at t0 =
  build_term_at t0 (FunApp(Settings.c_true, []))
  
let make_false_at t0 =
  build_term_at t0 (FunApp(Settings.c_false, []))

let make_and_at t0 t t' =
  if (is_true t) || (is_false t' && no_effect t) then t' else
  if (is_true t') || (is_false t && no_effect t') then t else
  build_term_at t0 (FunApp(Settings.f_and, [t;t']))

let make_or_at t0 t t' =
  if (is_false t) || (is_true t' && no_effect t) then t' else
  if (is_false t') || (is_true t && no_effect t') then t else
  build_term_at t0 (FunApp(Settings.f_or, [t;t']))

let make_not_at t0 t =
  if is_false t then make_true_at t0 else
  if is_true t then make_false_at t0 else
  build_term_at t0 (FunApp(Settings.f_not, [t]))

(* Put a term in the form or (and (...)) *)

let rec get_or t =
  match t.t_desc with
    FunApp(f, [t1;t2]) when f == Settings.f_or ->
      (get_or t1) @ (get_or t2)
  | _ -> [t]

let rec make_and1 a = function
    [] -> Parsing_helper.internal_error "make_and1 empty"
  | [b] -> make_and b a
  | (b::l2) -> make_or (make_and a b) (make_and1 a l2)

let rec make_and2 l1 = function
    [] -> Parsing_helper.internal_error "make_and2 empty"
  | [a] -> make_and1 a l1
  | (a::l2) -> make_or (make_and1 a l1) (make_and2 l1 l2)

let make_and_distr t1 t2 =
  if (is_false t1 && no_effect t2) || (is_false t2 && no_effect t1) then make_false() else
  if is_true t1 then t2 else
  if is_true t2 then t1 else
  if no_effect t1 && no_effect t2 then
  (* If t1 or t2 is "or", distribute *)
    make_and2 (get_or t1) (get_or t2)
  else
    make_and t1 t2

let rec or_and_form t =
  match t.t_desc with
    FunApp(f, [t1;t2]) when f == Settings.f_and ->
      make_and_distr (or_and_form t1) (or_and_form t2)
  | FunApp(f, [t1;t2]) when f == Settings.f_or ->
      make_or (or_and_form t1) (or_and_form t2)
  | _ -> t

(* Test for tuples *)

let is_tuple t =
  match t.t_desc with
    FunApp(f, _) when (f.f_options land Settings.fopt_COMPOS) != 0 -> true
  | _ -> false

let is_pat_tuple = function
    PatTuple (f,_) -> true
  | _ -> false

(* Patterns that match all values *)

let rec is_full_pattern = function
  | PatVar _ -> true
  | PatEqual _ -> false
  | PatTuple(f,l) ->
      (f.f_options land Settings.fopt_BIJECTIVE != 0) &&
      (List.for_all is_full_pattern l)
	
(* Tuple builder for patterns *)

let build_pat_tuple patl =
  let tpatl = List.map get_type_for_pattern patl in
  PatTuple(Settings.get_tuple_fun tpatl, patl)

(* Building lets *)

let rec put_lets l p1 p2 = 
  match l with
    [] -> p1
  | (a1,a2)::lr ->
      oproc_from_desc (Let(a1, a2, put_lets lr p1 p2,
			   if is_full_pattern a1 then
			     oproc_from_desc Yield
			   else
			     p2))

let rec put_lets_term l p1 p2 = 
  match l with
    [] -> p1
  | (a1,a2)::lr ->
      build_term_type p1.t_type (LetE(a1, a2, put_lets_term lr p1 p2,
				      if is_full_pattern a1 then
					None
				      else
					p2))
	
(* [simplify_let_tuple pat t] serves to simplify "let pat = t in ..."
   when pat is a tuple.
   It returns 
   - the list of performed transformations
   - a list [(pat1, t1);...;(patn, tn)] meant to be transformed into
   "let pat1 = t1 in ... let patn = tn in ..."  where the patterns are
   always fresh variables created by [simplify_let_tuple].
   These variables may store the initial term [t] and some of its
   projections (inverse of bijective tuples), as well as terms
   with effects inside [pat].
   We make sure that terms with effects of [t] are evaluated first,
   then terms with effects inside [pat], and all this happens before
   testing whether the matching [pat = t] succeeds.
   - a term [test] meant to be transformed into a test 
   "if test then ... else ..." 
   after the previous [let] and before the following ones (no test 
   should be generated when [test] is true)
   - a list [(pat1, t1);...;(patn, tn)] meant to be transformed into
   "let pat1 = t1 in ... let patn = tn in ...".
   It makes sure that, when the initial pattern matching fails,
   none of the variables of pat is defined in the transformed let.
   It raises the exception [Impossible] when the initial pattern 
   matching always fails. *)
	
exception Impossible

let rec split_term f0 t = 
  match t.t_desc with
    Var(_,_) -> 
      (* TO DO when the variable is created by a restriction,
         it is different from a tuple with high probability *)
      raise Not_found
  | ReplIndex i -> 
      (* A replication index cannot occur because the split term must be of a bitstring type *)
      Parsing_helper.internal_error "A replication index should not occur in Terms.split_term"
  | FunApp(f,l) when f == f0 -> l
  | FunApp(f,l) -> 
      if f0.f_cat == Tuple && (f.f_cat == Tuple || (f.f_cat == Std && l == [] && (!Settings.constants_not_tuple))) then
	raise Impossible
      else
	raise Not_found
  | TestE _ | FindE _ | LetE _ | ResE _ | EventAbortE _ | EventE _ | GetE _ | InsertE _ ->
      (* Modified to support non-expanded processes in remove_assign *)
      raise Not_found

(* [collect_terms_with_effects cur_array accu pat] collects in [accu]
   bindings for the terms with effects inside [pat], in reverse order
   of evaluation. It returns the pattern [pat] with variables instead
   of those terms. *)
let rec collect_terms_with_effects cur_array accu = function
  | (PatEqual t) as pat ->
      if no_effect t then
	pat
      else
	begin
	  let v = create_binder "v" t.t_type cur_array in
	  dummy_def v;
	  accu := (PatVar v, t) :: (!accu);
	  PatEqual (term_from_binder v)
	end
  | PatTuple(f,l) -> PatTuple(f, List.map (collect_terms_with_effects cur_array accu) l)
  | (PatVar _) as pat -> pat
	
(* [rename_var_except_last rename_accu lbind] renames all bound variables
   in patterns in [lbind], except in the last pattern of the list. *)
let rec rename_var_pat rename_accu = function
    (PatEqual t) as pat -> pat
  | PatTuple(f,l) -> PatTuple(f, List.map (rename_var_pat rename_accu) l)
  | PatVar b ->
      let b' = new_binder b in
      dummy_def b';
      rename_accu := (PatVar b, term_from_binder b') :: (!rename_accu);
      PatVar b'
	
let rec rename_var_except_last rename_accu = function
    [] -> []
  | [a] -> [a]
  | (pat,t)::l -> (rename_var_pat rename_accu pat, t) :: (rename_var_except_last rename_accu l)

(* [simplify_let_tuple_aux cur_array get_tuple [] [] [] pat t] aims to
   simplify the pattern-matching [pat = t] by decomposing tuples.
   It returns [(transfo_accu, accu0, accu)] where
   - [transfo_accu] is a list of performed transformations
   - [accu0] contains bindings for the initial term [t] and some of its
   projections, in reverse order of evaluation.
   - [accu] contains sub-pattern matchings of [pat = t], without effects
   provided the initial pattern [pat] does not contain terms with effects. *)
let rec simplify_let_tuple_aux cur_array get_tuple transfo_accu accu0 accu pat t =
  let default() = 
    if no_effect t then
      transfo_accu, accu0, (pat, t) :: accu
    else
      let var = create_binder "v" t.t_type cur_array in
      dummy_def var;
      transfo_accu, (PatVar var, t) :: accu0, (pat, term_from_binder var) :: accu
  in
  match pat with
    PatTuple(f, l) ->
      begin
      try 
	let l' = split_term f (get_tuple t) in
	simplify_let_tuple_aux_list cur_array get_tuple ((pat, DExpandTuple)::transfo_accu) accu0 accu l l'
      with Not_found ->
	if f.f_options land Settings.fopt_BIJECTIVE != 0 then
	  begin
	    let (var, m0) =
	      match t.t_desc with
	      | Var _ -> (t, [])
	      | _ ->
		  let var = create_binder "v" t.t_type cur_array in
		  dummy_def var;
		  (term_from_binder var, [PatVar var, t])
	    in
	    let projs = Settings.get_proj f in
	    let tl = List.map (fun proj -> app proj [var]) projs in
	    let transfo_accu' = (pat, DExpandBijTuple) :: transfo_accu in
	    simplify_let_tuple_aux_list cur_array get_tuple transfo_accu'
	      (m0 @ accu0) accu l tl
	  end
	else
	  default()
      end
  | _ -> default()
				   
and simplify_let_tuple_aux_list cur_array get_tuple transfo_accu accu0 accu patl tl =
  match patl, tl with
    [], [] -> transfo_accu, accu0, accu
  | (pat::patr, t::tr) ->
      let transfo_accu', accu0', accu' = 
	simplify_let_tuple_aux cur_array get_tuple transfo_accu accu0 accu pat t
      in
      simplify_let_tuple_aux_list cur_array get_tuple transfo_accu' accu0' accu' patr tr
  | _ -> Parsing_helper.internal_error "simplify_let_tuple_aux_list: lists should have same length"

let simplify_let_tuple cur_array get_tuple pat t =
  let lbind_terms_effects = ref [] in
  let pat = collect_terms_with_effects cur_array lbind_terms_effects pat in
  let lbind_terms_effects = List.rev (!lbind_terms_effects) in
  (* [lbind_terms_effects] now contains bindings for the terms with effects
     in [pat] in order of evaluation *)
  let transfo_accu, lbind0, lbind =
    simplify_let_tuple_aux cur_array get_tuple [] [] [] pat t
  in
  (* [lbind0] now contains bindings for the terms with effects in [t]
     in reverse order of evaluation as well as bindings for
     projections of bijective tuples.
     [lbind] now contains sub-pattern matchings of [pat = t],
     without effects. Hence they can be evaluated in any order,
     but we must make sure that all variables of [pat] are bound
     only when all matchings succeed. *)
  let lbind_eq = List.filter (function (PatEqual _, _) -> true | _ -> false) lbind in
  let lbind_tup = List.filter (function (PatTuple _, _) -> true | _ -> false) lbind in
  let lbind_var = List.filter (function (PatVar _, _) -> true | _ -> false) lbind in
  (* Introduce temporay variables for tuple matchings *)
  let rename_accu = ref [] in
  let renamed_lbind_tup = rename_var_except_last rename_accu lbind_tup in
  let pat_remaining = List.append renamed_lbind_tup (List.rev_append (!rename_accu) lbind_var) in
  let transfo_accu = (List.map (fun (pat, t') -> (pat, DEqTest)) lbind_eq) @ transfo_accu in
  let test =
    make_and_list (List.rev_map (function
      | (PatEqual t, t') -> make_equal t t'
      | _ -> Parsing_helper.internal_error "Should have PatEqual") lbind_eq)
  in
  if transfo_accu == [] then
    [], [], make_true(), [pat, t]
  else
    transfo_accu, List.rev_append lbind0 lbind_terms_effects, test, pat_remaining

(* Transform make all patterns of oracle declaration variables or tuples of variables
   Make sure that all terms (with effects) in the patterns are evaluated as soon as
   the oracle call is performed, even if the pattern-matching fails.
   Make sure that all variables in the patterns are bound only when the pattern-matching
   fully succeeds. *)

let rec make_var_pats cur_array patl p =
  let lbind_terms_effects = ref [] in
  let patl' = List.map (collect_terms_with_effects cur_array lbind_terms_effects) patl in
  let lbind_terms_effects = List.rev (!lbind_terms_effects) in
  (* [lbind_terms_effects] now contains bindings for the terms with effects
     in [pat] in order of evaluation *)
  (* Transform all patterns into fresh variables, adding collecting in
     [accu_bind] the matchings with the initial variables *)
  let accu_bind = ref [] in
  let patl'' = List.map (fun pat ->
    let b' = create_binder "patv" (get_type_for_pattern pat) cur_array in
    dummy_def b';
    accu_bind := (pat, term_from_binder b') :: (!accu_bind);
    PatVar b'
      ) patl'
  in
  let lbind = !accu_bind in
  (* [lbind] now contains pattern matchings equivalent to [patl],
     without effects. Hence they can be evaluated in any order,
     but we must make sure that all variables of [pat] are bound
     only when all matchings succeed. *)
  let lbind_eq = List.filter (function (PatEqual _, _) -> true | _ -> false) lbind in
  let lbind_tup = List.filter (function (PatTuple _, _) -> true | _ -> false) lbind in
  let lbind_var = List.filter (function (PatVar _, _) -> true | _ -> false) lbind in
  (* Introduce temporay variables for tuple matchings *)
  let rename_accu = ref [] in
  let renamed_lbind_tup = rename_var_except_last rename_accu lbind_tup in
  let pat_remaining = List.append renamed_lbind_tup (List.rev_append (!rename_accu) lbind_var) in
  let test =
    make_and_list (List.rev_map (function
      | (PatEqual t, t') -> make_equal t t'
      | _ -> Parsing_helper.internal_error "Should have PatEqual") lbind_eq)
  in
  let p_let = put_lets pat_remaining p (oproc_from_desc Yield) in
  let p_test =
    if is_true test then
      p_let
    else
      oproc_from_desc (Test(test, p_let, oproc_from_desc Yield))
  in
  let p' = put_lets lbind_terms_effects p_test (oproc_from_desc Yield) in
  (patl'', p')

(* Build the query event(f) ==> false public_vars pub_vars *)
    
let build_event_query f pub_vars =
  let b = create_binder "!l" Settings.t_bitstring [] in
  let idx = term_from_binder b in
  let t = app f [idx] in
  QEventQ([false, t], QTerm (make_false()), pub_vars)

(* Test if a query is event(f) ==> false public_vars ... *)
    
let is_event_query f' ((q,_),_,_) =
  match q with
  | QEventQ([false, { t_desc = FunApp(f,[_]) }], QTerm t_false, pub_vars) ->
      f' == f && is_false t_false
  | _ -> false

let get_event_query = function
  | QEventQ([false, { t_desc = FunApp(f,[_]) }], QTerm t_false, pub_vars) ->
      if is_false t_false then Some f else None
  | _ -> None
	
let has_event_query f' l =
  List.exists (fun q ->
    (Settings.get_query_status q == ToProve) && (is_event_query f' q)
      ) l
	
let is_nonunique_event_query ((q,_),_,_) =
  match q with
  | QEventQ([false, { t_desc = FunApp(f,[_]) }], QTerm t_false, pub_vars) ->
      f.f_cat == NonUniqueEvent && is_false t_false
  | _ -> false

let get_nonunique_event_query ((q,_),_,_) =
  match q with
  | QEventQ([false, { t_desc = FunApp(f,[_]) }], QTerm t_false, pub_vars) ->
      if f.f_cat == NonUniqueEvent && is_false t_false then
	Some f
      else
	None
  | _ -> None
	
(* [is_unique l0' find_info] returns Unique when a [find] is unique,
   that is, at runtime, there is always a single possible branch 
   and a single possible value of the indices:
   either it is marked [Unique] in the [find_info],
   or it has a single branch with no index.
   [l0'] contains the branches of the considered [find]. *)

let is_unique g_opt l0' find_info =
  match l0' with
    [([],_,_,_)] -> Unique
  | _ ->
      match find_info, g_opt with
      | UniqueToProve e, Some g ->
	  if has_event_query e g.current_queries then
	    find_info
	  else
	    (* The event [e] is not to prove, we can consider the [find] as unique *)
	    Unique
      | _ -> find_info

(* Check if a term may abort in a trace that is counted in the probabilities,
   that is, proved find/get[unique] are not considered to abort. *)
	    
let rec may_abort_counted g_opt t =
  let rec aux_t t =
    match t.t_desc with
    | EventAbortE _ -> true
    | FindE(l0,t3,find_info) ->
	(match is_unique g_opt l0 find_info with
	| UniqueToProve _ -> true
	| _ -> false) ||
	  (exists_subterm aux_t (fun br -> false) aux_pat t)
    | GetE(_,_,_,_,_,find_info) ->
	(match find_info with
	| UniqueToProve _ -> true
	| _ -> false) ||
	(exists_subterm aux_t (fun br -> false) aux_pat t)
    | _ -> exists_subterm aux_t (fun br -> false) aux_pat t

  and aux_pat pat =
    exists_subpat aux_t aux_pat pat

  in
  aux_t t    
    
(* Check if a term may abort by an event other than [f] in a trace
   counted in the probability *)

let other_abort g_opt f t =
  let rec aux_t t =
    match t.t_desc with
    | EventAbortE f' -> f' != f
    | FindE(l0,t3,find_info) ->
	(match is_unique g_opt l0 find_info with
	| UniqueToProve f' -> f' != f
	| _ -> false) ||
	  (exists_subterm aux_t (fun br -> false) aux_pat t)
    | GetE(_,_,_,_,_,find_info) ->
	(match find_info with
	| UniqueToProve f' -> f' != f
	| _ -> false) ||
	(exists_subterm aux_t (fun br -> false) aux_pat t)
    | _ -> exists_subterm aux_t (fun br -> false) aux_pat t

  and aux_pat pat =
    exists_subpat aux_t aux_pat pat

  in
  aux_t t
    
(* [is_unique_no_abort l0 find_info] returns true when the find is unique 
   and its conditions do not abort in traces counted in the probability *)

let is_unique_no_abort g_opt l0 find_info =
  (is_unique g_opt l0 find_info == Unique) &&
  not (List.exists (fun (bl, def_list, t1, _) ->
    may_abort_counted g_opt t1) l0)

let is_not_unique_to_prove = function
  | Unique | Nothing -> true
  | UniqueToProve _ -> false
    
(* Functions used for updating elsefind facts when a new variable
   is defined.

If we have the elsefind fact "for all j, not (defined(x[j]...) && cond)"
and we define the variable x[i], we transform the elsefind fact into
"for all j, not (defined(x[j]...) && cond && i <> j)"
Indeed:
For i = j, i<>j is false, so defined(x[j]...) && cond && i <> j is
   false, so not (defined(x[j]...) && cond && i <> j) is true.
For i<>j, not (defined(x[j]...) && cond && i <> j) is equivalent to
   not (defined(x[j]...) && cond) so it is true because it was true
   before the definition of x[i]. 

[collect_ineq_def_list bl args_at_creation def_list] generates the inequalities
[i <> j] where [i = args_at_creation] is the current replication indices, the
indices at which the variables in [bl] are newly defined,
and [j] is the indices with which variables in [bl] occur in [def_list].

[update_elsefind_with_def bl elsefind] updates the [elsefind] fact
as outlined above, where the newly defined variables (x above)
are the variables in [bl].
*)


let collect_ineq_def_list bl args_at_creation def_list =

  let rec collect_ineq_term accu t =
    match t.t_desc with
      Var(b,l) ->
	collect_ineq_br accu (b,l)
    | FunApp(f,l) ->
	List.fold_left collect_ineq_term accu l
    | ReplIndex _ -> accu
    | _ -> Parsing_helper.internal_error "if/let/find/new should not occur in defined conditions"

  and collect_ineq_br accu (b,l) =
    if List.memq b bl then  
      let new_fact = make_or_list (List.map2 make_diff args_at_creation l) in
      List.fold_left collect_ineq_term (new_fact::accu) l
    else
      List.fold_left collect_ineq_term accu l
  
  in
  List.fold_left collect_ineq_br [] def_list
  
let update_elsefind_with_def bl ((bl',def_list,t) as elsefind) =
  if bl == [] then elsefind else
  (* all variables in [bl] have the same [args_at_creation],
     corresponding to the current replication indices *)
  let args_at_creation = List.map term_from_repl_index (List.hd bl).args_at_creation in
  let new_facts = collect_ineq_def_list bl args_at_creation def_list in
  if new_facts == [] then
    elsefind
  else
    (bl', def_list, make_and_list (t::new_facts))

let rec close_def_subterm accu (b,l) =
  add_binderref (b,l) accu;
  List.iter (close_def_term accu) l

and close_def_term accu t =
  match t.t_desc with
    Var(b,l) -> close_def_subterm accu (b,l)
  | ReplIndex i -> ()
  | FunApp(f,l) -> List.iter (close_def_term accu) l
  | _ -> Parsing_helper.input_error "if/find/let/new/event/get/insert forbidden in defined conditions of find" t.t_loc

let defined_refs_find bl def_list defined_refs =
  (* Compute the defined references in the condition *)
  let accu = ref defined_refs in
  List.iter (close_def_subterm accu) def_list;
  let defined_refs_cond = !accu in
  (* Compute the defined references in the then branch *)
  let vars = List.map fst bl in
  let repl_indices = List.map snd bl in
  let def_list' = subst_def_list repl_indices (List.map term_from_binder vars) def_list in
  let accu = ref ((List.map binderref_from_binder vars) @ defined_refs) in
  List.iter (close_def_subterm accu) def_list';
  let defined_refs_branch = !accu in
  (defined_refs_cond, defined_refs_branch)

let rec unionq l1 = function
    [] -> l1
  | (a::l) -> 
      if List.memq a l1 then unionq l1 l else
      a::(unionq l1 l)


(* Add to [accu] the variables defined above the node [n] *)

let rec add_def_vars_node accu n =
  let accu' = n.binders @ accu in
  match n.above_node with
  | None -> accu'
  | Some n' -> add_def_vars_node accu' n'


(* Update args_at_creation: since variables in conditions of find have
as args_at_creation the indices of the find, transformations of the
find may lead to changes in these indices.  This function updates
these indices. It relies on the invariant that variables in conditions
of find have no array accesses, and that new/event do not occur in
conditions of find. It creates fresh variables for all variables
defined in the condition of the find. *)

let rec update_args_at_creation cur_array t =
  match t.t_desc with
    Var(b,l) ->
      begin
      match b.link with
	NoLink -> build_term2 t (Var(b, List.map (update_args_at_creation cur_array) l))
      |	TLink t' -> 
	  (* Variable b is defined in the current find condition, 
             it has no array accesses *)
	  t'
      | _ -> assert false
      end
  | ReplIndex b -> t
  | FunApp(f,l) -> build_term2 t (FunApp(f, List.map (update_args_at_creation cur_array) l))
  | ResE(b,t1) ->
      let b' = create_binder b.sname b.btype cur_array in
      link b (TLink (term_from_binder b'));
      build_term2 t (ResE(b', update_args_at_creation cur_array t1))
  | EventAbortE _ -> t
  | EventE _ | GetE _ | InsertE _ ->
      Parsing_helper.internal_error "new/event/event_abort/get/insert should not occur as term in find condition" 
  | TestE(t1,t2,t3) ->
       build_term2 t (TestE(update_args_at_creation cur_array t1,
			    update_args_at_creation cur_array t2,
			    update_args_at_creation cur_array t3))
  | FindE(l0,t3,find_info) ->
      let l0' = 
	List.map (fun (bl, def_list, t1, t2) ->
	  let repl_indices = List.map snd bl in
	  let cur_array_cond = repl_indices @ cur_array in
	  let def_list' = List.map (update_args_at_creation_br cur_array_cond) def_list in
	  let t1' = update_args_at_creation cur_array_cond t1 in
	  let bl' = List.map (fun (b,b') ->
	    let b1 = create_binder b.sname b.btype cur_array in
	    link b (TLink (term_from_binder b1));
	    (b1, b')) bl 
	  in
	  let t2' = update_args_at_creation cur_array t2 in
	  (bl', def_list', t1', t2')
	  ) l0
      in
      build_term2 t (FindE(l0',
				 update_args_at_creation cur_array t3,
				 find_info))
  | LetE(pat, t1, t2, topt) ->
      let t1' = update_args_at_creation cur_array t1 in
      let pat' = update_args_at_creation_pat cur_array pat in
      let t2' = update_args_at_creation cur_array t2 in
      let topt' = 
	match topt with
	  None -> None
	| Some t3 -> Some (update_args_at_creation cur_array t3)
      in
      build_term2 t (LetE(pat', t1', t2', topt'))

and update_args_at_creation_br cur_array (b,l) =
  begin
    match b.link with
      NoLink -> (b, List.map (update_args_at_creation cur_array) l)
    | TLink t' -> 
        (* Variable b is defined in the current find condition, 
           it has no array accesses *)
	binderref_from_term t'
    | _ -> assert false
  end

and update_args_at_creation_pat cur_array = function
    PatVar b ->
      let b' = create_binder b.sname b.btype cur_array in
      link b (TLink (term_from_binder b'));
      PatVar b'
  | PatTuple(f,l) ->
      PatTuple(f, List.map (update_args_at_creation_pat cur_array) l)
  | PatEqual t ->
      PatEqual (update_args_at_creation cur_array t)
      

let update_args_at_creation cur_array t =
  auto_cleanup (fun () ->
    update_args_at_creation cur_array t)

(* get needed def_list elements *)

let rec get_needed_deflist_term defined accu t =
  match t.t_desc with
    Var(b,l) -> 
      let br = (b,l) in
      if not (mem_binderref br defined) then
	add_binderref br accu
  | ReplIndex i -> ()
  | FunApp(f,l) -> List.iter (get_needed_deflist_term defined accu) l
  | TestE(t1,t2,t3) -> 
      get_needed_deflist_term defined accu t1;
      get_needed_deflist_term defined accu t2;
      get_needed_deflist_term defined accu t3
  | FindE(l0,t3, find_info) ->
      List.iter (fun (bl, def_list, t, t1) ->
	let (defined_t, defined_t1) = defined_refs_find bl def_list defined in
	get_needed_deflist_term defined_t accu t;
	get_needed_deflist_term defined_t1 accu t1
	) l0;
      get_needed_deflist_term defined accu t3
  | LetE(pat,t1,t2,topt) ->
      get_needed_deflist_pat defined accu pat;
      get_needed_deflist_term defined accu t1;
      let bpat = vars_from_pat [] pat in
      let defs = List.map binderref_from_binder bpat in
      get_needed_deflist_term (defs @ defined) accu t2;
      begin
	match topt with
	  None -> ()
	| Some t3 -> get_needed_deflist_term defined accu t3
      end
  | ResE(b,t) -> get_needed_deflist_term ((binderref_from_binder b)::defined) accu t
  | EventAbortE f -> ()
  | EventE(t,p) ->
      get_needed_deflist_term defined accu t;
      get_needed_deflist_term defined accu p
  | GetE(tbl,patl,topt,p1,p2, find_info) ->
      List.iter (get_needed_deflist_pat defined accu) patl;
      let bpat = List.fold_left vars_from_pat [] patl in
      let defs = (List.map binderref_from_binder bpat) @ defined in
      (match topt with None -> () | Some t -> get_needed_deflist_term defs accu t);
      get_needed_deflist_term defs accu p1;
      get_needed_deflist_term defined accu p2
  | InsertE(tbl,tl,p) ->
      List.iter (get_needed_deflist_term defined accu) tl;
      get_needed_deflist_term defined accu p

and get_needed_deflist_pat defined accu = function
    PatVar _ -> ()
  | PatTuple(f,l) -> List.iter (get_needed_deflist_pat defined accu) l
  | PatEqual t -> get_needed_deflist_term defined accu t

let rec get_needed_deflist_process defined accu p = 
  match p.i_desc with
    Nil -> ()
  | Par(p1,p2) -> get_needed_deflist_process defined accu p1;
      get_needed_deflist_process defined accu p2
  | Repl(b,p) -> get_needed_deflist_process defined accu p
  | OracleDecl(o,patl,p) ->
      List.iter (get_needed_deflist_pat defined accu) patl;
      let bpat = vars_from_pat_list [] patl in
      let defs = List.map binderref_from_binder bpat in
      get_needed_deflist_oprocess (defs @ defined) accu p

and get_needed_deflist_oprocess defined accu p =
  match p.p_desc with
    Yield | EventAbort _ -> ()
  | Restr(b,p) -> get_needed_deflist_oprocess ((binderref_from_binder b)::defined) accu p
  | Test(t,p1,p2) -> 
      get_needed_deflist_term defined accu t;
      get_needed_deflist_oprocess defined accu p1;
      get_needed_deflist_oprocess defined accu p2
  | Find(l0,p2, find_info) ->
      List.iter (fun (bl, def_list, t, p1) ->
	let (defined_t, defined_p1) = defined_refs_find bl def_list defined in
	get_needed_deflist_term defined_t accu t;
	get_needed_deflist_oprocess defined_p1 accu p1
	) l0;
      get_needed_deflist_oprocess defined accu p2
  | Let(pat,t,p1,p2) ->
      get_needed_deflist_pat defined accu pat;
      get_needed_deflist_term defined accu t;
      let bpat = vars_from_pat [] pat in
      let defs = List.map binderref_from_binder bpat in
      get_needed_deflist_oprocess (defs @ defined) accu p1;
      get_needed_deflist_oprocess defined accu p2
  | Return(tl,p) ->
      List.iter (get_needed_deflist_term defined accu) tl;
      get_needed_deflist_process defined accu p
  | EventP(t,p) ->
      get_needed_deflist_term defined accu t;
      get_needed_deflist_oprocess defined accu p
  | Get(tbl,patl,topt,p1,p2,find_info) ->
      List.iter (get_needed_deflist_pat defined accu) patl;
      let bpat = List.fold_left vars_from_pat [] patl in
      let defs = (List.map binderref_from_binder bpat) @ defined in
      (match topt with None -> () | Some t -> get_needed_deflist_term defs accu t);
      get_needed_deflist_oprocess defs accu p1;
      get_needed_deflist_oprocess defined accu p2
  | Insert(tbl,tl,p) ->
      List.iter (get_needed_deflist_term defined accu) tl;
      get_needed_deflist_oprocess defined accu p
  | NewTable(tbl,p) ->
      get_needed_deflist_oprocess defined accu p

(********** Use the equational theory to simplify a term *************)

(* Remark: applying remove_consecutive_inverse and remove_inverse_ends
to t1 * inv(t2) does the same job as applying 
- remove_consecutive_inverse to t1 and to t2, 
- remove_common_prefix and remove_common_suffix to the obtained t1 t2, 
- and remove_inverse_ends to t1 in case t2 is the neutral element and conversely.
We do the latter below. (One advantage is that the form of the simplified
term is then closer to the initial term.) *)

let is_fun f t =
  match t.t_desc with
    FunApp(f',_) -> f == f' 
  | _ -> false

(* collect_first_inverses inv [] [inv(t1); ... inv(tn); rest] 
   is ([tn; ...; t1], rest) *)

let rec collect_first_inverses inv accu = function
    [] -> (accu, [])
  | (t::l) ->
      match t.t_desc with
	FunApp(f,[tinv]) when f == inv -> 
	  collect_first_inverses inv (tinv::accu) l
      |	_ -> (accu, t::l)

(* when l = inv(t1) * ... * inv(tn) * rest' * inv(t'_n') * ... * inv(t'_1),
   collect_first_and_last_inverses is
   (l1',l2') = (tn * ... * t1 * l1 * t'_1 * ... * t'_n', rest)
   so that l = l1 is equivalent to l1' = l2'.
   (Lists represent products.) *)

let collect_first_and_last_inverses reduced inv l1 l =
  let (first_inv, rest) = collect_first_inverses inv [] l in
  (* first_inv = tn * ... * t1, rest = rest' * inv(t'_n') * ... * inv(t'_1) *)
  let rest_rev = List.rev rest in
  (* rest_rev = inv(t'_1) * ... * inv(t'_n') * List.rev rest' *)
  let (last_inv_rev, rest_rev') = collect_first_inverses inv [] rest_rev in
  (* last_inv_rev = t'_n' * ... * t'_1, rest_rev' = List.rev rest' *)
  if first_inv != [] || last_inv_rev != [] then reduced := true;
  (first_inv @ l1 @ (List.rev last_inv_rev), List.rev rest_rev')

(* apply_eq_reds implements reduction rules coming from the
   equational theories, as well as
     not (x = y) -> x != y
     not (x != y) -> x = y
     x = x -> true
     x != x -> false
     ?x != t -> false where ?x is a general variable (universally quantified)
(These rules cannot be stored in file default, because there are several
functions for = and for !=, one for each type.)

This function works only when [t] is a simple term (contains only
Var/FunApp/ReplIndex). In particular, it would not be correct
if [t] may abort (contains EventAbortE/FindE[unique]) or has an effect
(executes events, defines variables with array accesses, ...) because of
the simplifications of && and ||.
*)

let rec apply_eq_reds simp_facts reduced t =
  match t.t_desc with
(* not (x = y) -> x != y
   not (x != y) -> x = y *)
    FunApp(fnot, [t']) when fnot == Settings.f_not ->
      begin
      let t' = try_no_var simp_facts t' in
      match t'.t_desc with
	FunApp(feq, [t1;t2]) when feq.f_cat == Equal ->
	  reduced := true;
	  apply_eq_reds simp_facts reduced (make_diff t1 t2)
      |	FunApp(fdiff, [t1;t2]) when fdiff.f_cat == Diff ->
	  reduced := true;
	  apply_eq_reds simp_facts reduced (make_equal t1 t2)
      |	_ -> make_not (apply_eq_reds simp_facts reduced t')
      end

(* simplify inv(M): inv(neut) -> neut; inv(inv(M)) -> M; inv(M * M') -> inv(M') * inv(M) *)
  | FunApp({f_eq_theories = (Group(f,inv',n) | CommutGroup(f,inv',n)) } as inv, [t']) when inv' == inv ->
      (* inv is an inverse function *)
      let t' = apply_eq_reds simp_facts reduced t' in
      compute_inv (try_no_var simp_facts) reduced (f,inv',n) t'

(* Simplify and/or when one side is known to be true/false
   It is important that this case is tested before the more general case below. *)
  | FunApp(f,[t1;t2]) when f == Settings.f_and ->
      let t1' = apply_eq_reds simp_facts reduced t1 in
      let t2' = apply_eq_reds simp_facts reduced t2 in
      if (is_true t1') || (is_false t2') then
	begin
	  reduced := true; t2'
	end
      else if (is_true t2') || (is_false t1') then
	begin
	  reduced := true; t1'
	end
      else if equal_terms t1' t2' then
	begin
	  reduced := true; t1'
	end
      else
	build_term2 t (FunApp(f, [t1';t2']))
  | FunApp(f,[t1;t2]) when f == Settings.f_or ->
      let t1' = apply_eq_reds simp_facts reduced t1 in
      let t2' = apply_eq_reds simp_facts reduced t2 in
      if (is_false t1') || (is_true t2') then
	begin
	  reduced := true; t2'
	end
      else if (is_false t2') || (is_true t1') then
	begin
	  reduced := true; t1'
	end
      else if equal_terms t1' t2' then
	begin
	  reduced := true; t1'
	end
      else
	build_term2 t (FunApp(f, [t1';t2']))

(* simplify products: eliminate factors that cancel out *)
  | FunApp(f,[t1;t2]) when f.f_eq_theories != NoEq && f.f_eq_theories != Commut &&
    f.f_eq_theories != Assoc && f.f_eq_theories != AssocCommut ->
      (* f is a binary function with an equational theory that is
	 not commutativity nor inverse -> it is a product-like function *)
      begin
	match f.f_eq_theories with
	  NoEq | Commut | Assoc | AssocCommut -> 
	    Parsing_helper.internal_error "Terms.apply_eq_reds: cases NoEq, Commut, Assoc, AssocCommut should have been eliminated"
	| AssocN(_, neut) | AssocCommutN(_, neut) -> 
	    (* eliminate the neutral element *)
	    if is_fun neut t1 then 
	      begin
		reduced := true;
		apply_eq_reds simp_facts reduced t2
	      end
	    else if is_fun neut t2 then
	      begin
		reduced := true;
		apply_eq_reds simp_facts reduced t1
	      end
	    else
	      build_term2 t (FunApp(f, [ apply_eq_reds simp_facts reduced t1;
					 apply_eq_reds simp_facts reduced t2 ]))	      
	| Group _ | CommutGroup _ | ACUN _ ->
	    (* eliminate factors that cancel out and the neutral element *)
	    let reduced' = ref false in
	    let l1 = simp_prod simp_facts reduced' f t in
	    if !reduced' then
	      begin
		reduced := true;
		let l1 = List.map (apply_eq_reds simp_facts reduced) l1 in
		make_prod f l1
	      end
	    else
	      build_term2 t (FunApp(f, [ apply_eq_reds simp_facts reduced t1;
					 apply_eq_reds simp_facts reduced t2 ]))
      end

(* simplify equalities and inequalities:
     x = x -> true
     x != x -> false
as well as equalities between products *)
  | FunApp(f, [t1;t2]) when (f.f_cat == Equal || f.f_cat == Diff) ->
      begin
	if simp_equal_terms simp_facts true t1 t2 then
	  begin
	    reduced := true;
	    match f.f_cat with
	      Equal -> make_true()
	    | Diff -> make_false()
	    | _ -> assert false
	  end
	else
	match get_prod_list (try_no_var simp_facts) [t1;t2] with
	  ACUN(xor,neut) ->
	    let reduced' = ref false in
	    let l1 = simp_prod simp_facts reduced' xor (app xor [t1;t2]) in
	    if !reduced' then
	      begin
		reduced := true;
		let l1 = List.map (apply_eq_reds simp_facts reduced) l1 in
		match l1 with
		  [] -> 
		    begin
		      match f.f_cat with
			Equal -> make_true()
		      | Diff -> make_false()
		      | _ -> assert false
		    end
		| t1::l -> build_term2 t (FunApp(f,[t1;make_prod xor l]))
		      (* The number of terms that appear here is always strictly
			 less than the initial number of terms:
			 the number of terms in l1 is strictly less than the number of terms
			 in t1 plus t2; make_prod introduces an additional neutral
			 term when l = []; in this case, we have two terms 
			 in the final result, and at least 3 in the initial t1 = t2,
			 since the side that contains the XOR symbol returned by get_prod_list
			 contains at least two terms. 
			 Hence, we always really simplify the term. *)
	      end
	    else
	      build_term2 t (FunApp(f, [ apply_eq_reds simp_facts reduced t1;
					 apply_eq_reds simp_facts reduced t2 ]))
	| CommutGroup(prod,inv,neut) ->
	    let reduced' = ref false in
	    let lmix =
	      if is_fun neut t1 then
		let l2 = simp_main_fun (try_no_var simp_facts) reduced' prod t2 in
		reduced' := (!reduced') || (List.exists (is_fun inv) l2);
		l2
	      else if is_fun neut t2 then
		let l1 = simp_main_fun (try_no_var simp_facts) reduced' prod t1 in
		reduced' := (!reduced') || (List.exists (is_fun inv) l1);
		l1
	      else
		let l1 = simp_main_fun (try_no_var simp_facts) reduced' prod t1 in
		let l2 = simp_main_fun (try_no_var simp_facts) reduced' prod t2 in
		reduced' := (!reduced') || (List.exists (is_fun inv) l1) ||
		  (List.exists (is_fun inv) l2);
		l1 @ (List.map (compute_inv (try_no_var simp_facts) reduced' (prod, inv, neut)) l2)
	        (* t2 = t1 is equivalent to t1 * t2^-1 = neut *)

	      (* It is important to treat the cases t1 or t2 neutral specially above.
		 Otherwise, we would leave M1 * M2 = neut unchanged, while still setting
		 reduced to true because simp_prod eliminates neut.

		 reduced' is set when t1 or t2 contains an inverse,
		 since this inverse will be removed by the final
		 building of the result below. *)
	    in
	    let l1 = remove_rel reduced' (is_inv simp_facts inv) lmix in
	    if !reduced' then
	      begin
		reduced := true;
		let l1 = List.map (apply_eq_reds simp_facts reduced) l1 in
		match l1 with
		  [] -> 
		    begin
		      match f.f_cat with
			Equal -> make_true()
		      | Diff -> make_false()
		      | _ -> assert false
		    end
		| l -> 
		    let linv, lno_inv = List.partition (is_fun inv) l in
		    let linv_removed = List.map (function { t_desc = FunApp(f,[t]) } when f == inv -> t | _ -> assert false) linv in
		    build_term2 t (FunApp(f, [ make_prod prod lno_inv; 
					       make_prod prod linv_removed ]))
	      end
	    else
	      build_term2 t (FunApp(f, [ apply_eq_reds simp_facts reduced t1;
					 apply_eq_reds simp_facts reduced t2 ]))
	| Group(prod,inv,neut) ->
	    let reduced' = ref false in
	    let l1 = 
	      (* When t1 is the neutral element, applying simp_prod would
		 set reduced' to true, so one would iterate simplification.
		 However, the neutral element will be reintroduced by
		 make_prod below, so that could lead to a loop. 
		 We detect this special case, and avoid setting reduced'
		 in this case. *)
	      if is_fun neut t1 then [] else
	      simp_prod simp_facts reduced' prod t1 
	    in
	    let l2 = 
	      if is_fun neut t2 then [] else
	      simp_prod simp_facts reduced' prod t2 
	    in
	    let sub_eq = simp_equal_terms simp_facts true in
	    let (l1',l2') = remove_common_prefix sub_eq reduced' l1 l2 in
	    let (l1'',l2'') = remove_common_suffix sub_eq reduced' l1' l2' in
	    let l1'' = if l2'' == [] then remove_inverse_ends reduced' (is_inv simp_facts inv) l1'' else l1'' in
	    let l2'' = if l1'' == [] then remove_inverse_ends reduced' (is_inv simp_facts inv) l2'' else l2'' in
	    let (l1'', l2'') = collect_first_and_last_inverses reduced' inv l1'' l2'' in
	    let (l1'', l2'') = collect_first_and_last_inverses reduced' inv l2'' l1'' in
	    if !reduced' then
	      begin
		reduced := true;
		let l1 = List.map (apply_eq_reds simp_facts reduced) l1'' in
		let l2 = List.map (apply_eq_reds simp_facts reduced) l2'' in
		match l1,l2 with
		  [],[] -> 
		    begin
		      match f.f_cat with
			Equal -> make_true()
		      | Diff -> make_false()
		      | _ -> assert false
		    end
		| _ -> 
		    build_term2 t (FunApp(f, [ make_prod prod l1; 
					       make_prod prod l2 ]))
	      end
	    else
	      build_term2 t (FunApp(f, [ apply_eq_reds simp_facts reduced t1;
					 apply_eq_reds simp_facts reduced t2 ]))
	| _ -> 
	    build_term2 t (FunApp(f, [ apply_eq_reds simp_facts reduced t1;
				       apply_eq_reds simp_facts reduced t2 ]))
      end

(* if true then t1 else t2 -> t1
   if false then t1 else t2 -> t2
   if t0 then t1 else t2 -> t1 *)
  | FunApp(f,[t1;t2;t3]) when f.f_cat == If ->
      let t1' = apply_eq_reds simp_facts reduced t1 in
      let t2' = apply_eq_reds simp_facts reduced t2 in
      let t3' = apply_eq_reds simp_facts reduced t3 in
      if is_true t1' then
	begin
	  reduced := true; t2'
	end
      else if is_false t1' then
	begin
	  reduced := true; t3'
	end
      else if simp_equal_terms simp_facts true t2' t3' then
	begin
	  reduced := true; t2'
	end
      else
	build_term2 t (FunApp(f, [t1';t2';t3']))
	
(* ?x <> t is always false when ?x is a general variable (universally quantified) *)
  | FunApp(f,[{t_desc = Var(b,[])};t2]) when f.f_cat == ForAllDiff && 
    b.sname == gvar_name && not (refers_to b t2) -> 
      reduced := true;
      make_false()      
  | FunApp(f,[t2;{t_desc = Var(b,[])}]) when f.f_cat == ForAllDiff && 
    b.sname == gvar_name && not (refers_to b t2) -> 
      reduced := true;
      make_false()      

(* simplify f(t1...tn) <> f(t1'...tn') with universally quantified variables *)
  | FunApp(f,[t1;t2]) when f.f_cat == ForAllDiff ->
      let t1' = try_no_var simp_facts t1 in
      let t2' = try_no_var simp_facts t2 in
      begin
      match (t1'.t_desc, t2'.t_desc) with
	(FunApp(f1,l1), FunApp(f2,l2)) when
	(f1.f_options land Settings.fopt_COMPOS) != 0 && f1 == f2 -> 
	  let vars = ref [] in
	  if List.for_all (single_occ_gvar vars) l1 && List.for_all (single_occ_gvar vars) l2 then
	    begin
	      reduced := true;
	      make_or_list (List.map2 (fun t1' t2' -> apply_eq_reds simp_facts reduced (make_for_all_diff t1' t2')) l1 l2)
	    end
	  else
	    t
      | _ -> t
      end

  (* transform f(...,if t1 then t2 else t3,...) into
     if t1 then f(...,t2,...) else f(...,t3,...) *)
  | FunApp(f,l) when f.f_options land Settings.fopt_AUTO_SWAP_IF != 0 ->
      let l' = List.map (apply_eq_reds simp_facts reduced) l in
      let rec find_if before = function
	| [] -> None
	| a::l ->
	    match (try_no_var simp_facts a).t_desc with
	    | FunApp(if_f, [t1;t2;t3]) when if_f.f_cat == If ->
		Some (before, (t1,t2,t3), l)
	    | _ -> find_if (a::before) l
      in
      begin
	match find_if [] l' with
	| Some (before, (t1,t2,t3), after) ->
	    let l2 = List.rev_append before (t2::after) in
	    let t2' = app f l2 in
	    let l3 = List.rev_append before (t3::after) in
	    let t3' = app f l3 in
	    let if_fun = Settings.get_if_fun (snd f.f_type) in
	    reduced := true;
	    build_term2 t (FunApp(if_fun, [t1; t2'; t3']))
	| None -> 
	    build_term2 t (FunApp(f, l'))
      end
	
(* Simplify subterms *)
  | FunApp(f,l) ->
      build_term2 t (FunApp(f, List.map (apply_eq_reds simp_facts reduced) l))
  | _ -> t


(* Iterators on probability formulas *)

(* Map *)

let rec map_optim_cond f = function
  | OCProbaFun(s,l) -> OCProbaFun(s, List.map f l)
  | OCBoolFun(s,l) -> OCBoolFun(s, List.map (map_optim_cond f) l)

let map_sub_probaf f = function
  | AttTime | Cst _ | Count _ | Zero | Card _ | TypeMaxlength _
  | EpsFind | EpsRand _ | PColl1Rand _ | PColl2Rand _ | OCount _
  | Maxlength _ | Advt _ | ProbaAssume as x -> x
  | Time(cnt,cat,p) -> Time(cnt,cat,f p)
  | Proba(p,l) -> Proba(p, List.map f l)
  | ActTime(f1,l) -> ActTime(f1, List.map f l)
  | Length(f1,l) -> Length(f1, List.map f l)
  | Mul(x,y) -> Mul(f x, f y)
  | Add(x,y) -> Add(f x, f y)
  | Sub(x,y) -> Sub(f x, f y)
  | Div(x,y) -> Div(f x, f y)
  | Power(x,n) -> Power(f x, n)
  | Max(l) -> Max(List.map f l)
  | Min(l) -> Min(List.map f l)
  | OptimIf(cond,x,y) -> OptimIf(map_optim_cond f cond, f x, f y)

(* Exists *)

let rec exists_optim_cond f = function
  | OCProbaFun(_,l) -> List.exists f l
  | OCBoolFun(_,l) -> List.exists (exists_optim_cond f) l
	
let exists_sub_probaf f = function
  | AttTime | Cst _ | Count _ | Zero | Card _ | TypeMaxlength _
  | EpsFind | EpsRand _ | PColl1Rand _ | PColl2Rand _ | OCount _
  | Maxlength _ | Advt _ | ProbaAssume ->
      false
  | Time(_,_,p) -> f p
  | Proba(_,l) | Max(l) | Min(l) | ActTime(_,l) | Length(_,l) ->
      List.exists f l
  | Add(p1,p2) | Mul(p1,p2) | Sub(p1,p2) | Div(p1,p2) ->
      (f p1) || (f p2)
  | Power(p,n) -> f p
  | OptimIf(cond,x,y) -> (exists_optim_cond f cond) || (f x) || (f y)

(* Merging of types *)

let merge_types t1 t2 =
  if t1 == Settings.t_any then
    t2
  else if t2 == Settings.t_any then
    t1
  else 
    begin
      if t1 != t2 then
	raise IncompatibleTypes;
      t1
    end

let merge_type_lists tl1 tl2 = 
  if List.length tl1 != List.length tl2 then
    raise IncompatibleTypes;
  List.map2 merge_types tl1 tl2

let mergetypesopt topt1 topt2 = 
  match topt1,topt2 with
    None,_ -> topt2
  | _,None -> topt1
  | Some tl1,Some tl2 ->
      Some (merge_type_lists tl1 tl2)

(* Create collision and equation statements *)
	
let create_collision name restr forall t1 proba t2 indep_cond side_cond
    restr_may_be_equal active alias_gen =
  { c_name = name; c_restr = restr; c_forall = forall;
    c_redl = t1; c_proba = proba; c_redr = t2;
    c_indep_cond = indep_cond; c_side_cond = side_cond;
    c_restr_may_be_equal = restr_may_be_equal;
    c_active = active;
    c_aliased = alias_gen }

let create_statement name forall t1 t2 side_cond active alias_gen = 
  create_collision name [] forall t1 Zero t2 IC_True side_cond false active alias_gen
	
(* Remove aliases *)

let rec unalias f = 
  match f.f_cat with
  | Alias f' -> unalias f'
  | _ -> f
	
