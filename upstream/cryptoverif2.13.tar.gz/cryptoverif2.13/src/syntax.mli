(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Types

(* [parse_from_string parse_fun (s, ext)] parses the string [s] with
   extent [ext] using the parsing function [parse_fun]. *)
val parse_from_string : ((Lexing.lexbuf -> Parser.token) -> Lexing.lexbuf -> 'a) -> ?lex : (Lexing.lexbuf -> Parser.token) -> ident -> 'a

val read_file : string -> (statement list) * (collision list) * (equiv_gen list) * ((query * query option) list) * restriction list * Ptree.command list option * impl_info * final_process * binder option(*diff_encoding_to_revise*)

(* Transform a parsed query into a query as used by CryptoVerif
   Raises Error in case of error. *)
val check_query : Ptree.query_e -> query
val queries_map_vars : (ident * Ptree.ty) list -> Ptree.query_e list -> Ptree.query_e list
    
val check_special_equiv_coll : Stringmap.env_type -> expect_t -> Ptree.special_equiv_coll_t -> special_equiv_collision

val check_eqstatement : bool -> Ptree.eqstatement -> equiv_gen
