(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Types

type state_t =
  | ToDo of int * Parsing_helper.extent * reorder_find_command
  | Done of program_point * reorder_find_command

let state = ref (ToDo(0,Parsing_helper.dummy_ext,CBranches[]) : state_t)


let is_ident l =
  let rec aux n = function
    | [] -> true
    | n'::l -> (n = n') && (aux (n+1) l)
  in
  aux 1 l

let rec check_distinct = function
  | [] -> ()
  | (a,ext)::l ->
      if List.exists (fun (a',_) -> a = a') l then
	Parsing_helper.raise_error ("Index "^a^" listed several times") ext;
      check_distinct l
    
let perform_transfo pp cur_array (l0 : 'a findbranch list) find_info =
  match !state with
  | Done _ -> assert false
  | ToDo(occ, ext, command) ->
      let nbranches = List.length l0 in
      match command with
      | CBranches l ->
	  if List.length l != nbranches then
	    Parsing_helper.raise_error
	      ("The find at "^(string_of_int occ)^" has "^
	       (string_of_int nbranches)^
	       " branches but the reordered list has "^
	       (string_of_int (List.length l))^" elements") ext;
	  List.iter (fun n ->
	    if not (n >= 1 && n <= nbranches) then
	      Parsing_helper.raise_error ("Branch number "^(string_of_int n)^" should be between 1 and the number of branches of the find, "^(string_of_int nbranches)) ext
		) l;
	  if is_ident l then
	    Parsing_helper.raise_error "The reordering list actually leaves the order of branches unchanged" ext;
	  let used = Array.make nbranches false in
	  List.iter (fun n ->
	    if used.(n-1) then
	      Parsing_helper.raise_error ("Branch number "^(string_of_int n)^" listed several times") ext;
	    used.(n-1) <- true
		 ) l;
	  Proba.add_proba_find cur_array l0 find_info;
	  state := Done(pp, command);
	  List.map (fun n -> List.nth l0 (n-1)) l
      | CIndices l -> 
	  List.iter (fun (n,_) ->
	    if not (n >= 1 && n <= nbranches) then
	      Parsing_helper.raise_error ("Branch number "^(string_of_int n)^" should be between 1 and the number of branches of the find, "^(string_of_int nbranches)) ext
		) l;
	  let used = Array.make nbranches false in
	  List.iter (fun (n,_) ->
	    if used.(n-1) then
	      Parsing_helper.raise_error ("Branch number "^(string_of_int n)^" listed several times") ext;
	    used.(n-1) <- true
		 ) l;
	  let result = 
	    List.mapi (fun n branch ->
	      try
		let indexorder = List.assq (n+1) l in
		let (bl, def_list, t1, p2) = branch in
		if List.length bl != List.length indexorder then
		  Parsing_helper.raise_error
		    ("In the find at "^(string_of_int occ)^", branch "^
		     (string_of_int (n+1))^" has "^
		     (string_of_int (List.length bl))^
		     " indices but the reordered list has "^
		     (string_of_int (List.length indexorder))^" elements") ext;
		check_distinct indexorder;
		let bl' =
		  List.map (fun (a,ext) ->
		    try 
		      List.find (fun (b,ri) -> Display.binder_to_string b = a) bl
		    with Not_found ->
		      Parsing_helper.raise_error
			("Index "^a^" not found in the find at "^
			 (string_of_int occ)^
			 ", branch "^(string_of_int (n+1))) ext
			) indexorder
		in
		(bl', def_list, t1, p2)     
	      with Not_found ->
		branch
		  ) l0
	  in
	  state := Done(pp, command);
	  result
	    
let rec full_transfo_t cur_array t =
  match t.t_desc with
  | FindE(l0,p3,find_info) ->
      begin
	match !state with
	| ToDo(occ,ext,command) when occ == t.t_occ ->
	    let l0' = perform_transfo (DTerm t) cur_array l0 find_info in
	    Terms.build_term t (FindE(l0',p3,find_info))
	| _ ->
	    let l0' = 
	      List.map (fun (bl, def_list, t1, p2) ->
		(bl, def_list,
		 full_transfo_t ((List.map snd bl) @ cur_array) t1,
		 full_transfo_t cur_array p2)
		  ) l0
	    in
	    let p3' = full_transfo_t cur_array p3 in
	    Terms.build_term t (FindE(l0',p3',find_info))
      end
  | _ -> Terms.build_term t (Terms.map_subterm (full_transfo_t cur_array) (fun def_list -> def_list) (full_transfo_pat cur_array) t)

and full_transfo_pat cur_array pat =
  Terms.map_subpat (full_transfo_t cur_array) (full_transfo_pat cur_array) pat

let rec full_transfo_i cur_array p =
  match p.i_desc with
  | Repl(ri,p1) ->
      let p1' = full_transfo_i (ri::cur_array) p1 in
      Terms.iproc_from_desc_loc p (Repl(ri,p1'))
  | _ -> 
      Terms.iproc_from_desc_loc p
	(Terms.map_subiproc (full_transfo_i cur_array) (fun o patl p1 ->
	  (o,List.map (full_transfo_pat cur_array) patl,
	   full_transfo_p cur_array p1)) p) 
	
and full_transfo_p cur_array p =
  match p.p_desc with
  | Find(l0,p3,find_info) ->
      begin
	match !state with
	| ToDo(occ,ext,command) when occ == p.p_occ ->
	    let l0' = perform_transfo (DProcess p) cur_array l0 find_info in
	    Terms.oproc_from_desc_loc p (Find(l0', p3, find_info))
	| _ ->
	    let l0' =
	      List.map (fun (bl, def_list, t1, p2) ->
		(bl, def_list,
		 full_transfo_t ((List.map snd bl) @ cur_array) t1,
		 full_transfo_p cur_array p2)
		  ) l0
	    in
	    let p3' = full_transfo_p cur_array p3 in
	    Terms.oproc_from_desc_loc p (Find(l0', p3', find_info))
      end
  | _ ->
      Terms.oproc_from_desc_loc p
	(Terms.map_suboproc (full_transfo_p cur_array) (full_transfo_t cur_array)
	   (fun def_list -> def_list) (full_transfo_pat cur_array)
	   (full_transfo_i cur_array) p)

	
let reorder_find occ ext command g =
  state := ToDo(occ, ext, command);
  Proba.reset [] g;
  let p = Terms.get_process g in
  let p' = full_transfo_i [] p in
  let g' = Terms.build_transformed_game p' g in
  let proba = Proba.final_add_proba [] in
  match !state with
  | ToDo _ ->
      Parsing_helper.raise_error ("Find construct not found at program point "^(string_of_int occ)) ext
  | Done(pp, command) ->
      Settings.changed := true;
      (g', proba, [DReorder_find(pp, command)])
