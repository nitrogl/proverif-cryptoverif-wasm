(******************************************************************
 *                                                                *
 * Cryptographic protocol verifier                                *
 *                                                                *
 * Bruno Blanchet, David Cadé, Aymeric Fromherz, Charlie Jacomme, *
 * and Benjamin Lipp                                              *
 *                                                                *
 * Copyright (C) ENS, CNRS, INRIA, MPI-SP, 2005-2026              *
 *                                                                *
 ******************************************************************)

(*

    Copyright ENS, CNRS, INRIA, MPI-SP
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé
                  Aymeric Fromherz, Aymeric.Fromherz@inria.fr
                  Charlie Jacomme, Charlie.Jacomme@inria.fr
                  Benjamin Lipp, benjamin.lipp@mpi-sp.org

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Types
open Parsing_helper

exception Failed

let whole_game = ref Terms.empty_game

let has_array_ref b =
  Array_ref.has_array_ref_non_exclude b || Settings.occurs_in_queries b (!whole_game).current_queries

(*
A merge is stored as
- the main process/term to merge (if/let/find)
- the list of branches to merge
  (these branches must be in the same order as the one output by
  form_advise, that is, result of the merge first, then the other branches in
  the same order as they appear in the process)
  For if and let, the result of the merge is always the else branch.
  For find, it may not be the else branch when the else branch is unreachable.
- the value of cur_array at that point
- the value of all_branches_var_list
- the list of variables that must have no array accesses for the 
  merge to be feasible (!var_no_array_ref)
- the list of other merges that must be done for this merge to be feasible
  (!required_merges)
- a list of pairs (variables, number of array accesses to that 
  variable that can be removed by the merge)
- a flag that say whether the merge is feasible; initially true and set to
  false if we discover that the merge is in fact not feasible 
*)

type merge_t =
    MergeTerm of term * term list
  | MergeProcess of process * process list

type merge_tt =
    { m_merge : merge_t;
      m_cur_array : repl_index list;
      m_all_branches_var_list : (binder * binder) list list;
      m_var_no_array_ref : binder list; (* variables that must have no array references for the merge to be feasible *)
      m_required_merges : merge_tt list; (* other merges that must be done for this merge to be feasible *)
      m_remove_array_ref : (binder * int) list; (* array references that are removed when the merge is done *)
      mutable m_feasible : bool (* initially true and set to false if we discover that the merge is in fact not feasible *)
    }

type result_t =
  | RTrue
  | RFalse of string (* explanation in case the result is false *)

let rec for_all_result f = function
  | [] -> RTrue
  | a::l ->
      match f a with
      | RTrue -> for_all_result f l
      | r -> r
	
let rec for_all2_result f l1 l2 =
  match l1, l2 with
  | [],[] -> RTrue
  | a1::l1,a2::l2 ->
      begin
	match f a1 a2 with
	| RTrue -> for_all2_result f l1 l2
	| r -> r
      end
  | _ -> assert false

type cond_t =
  | CIf of term
  | CLet of pattern * term

type group_side_t =
    { mutable merge_candidates_t : term list;
      mutable merge_candidates_p : process list }
	
type merge_group_t =
    { merge_cond : cond_t;
      curarray_suffix_opt : repl_index list option;
      left : group_side_t;
      right : group_side_t;
      mutable result : result_t option
    } 
	
module Equal :
    sig
      (* Inputs to this module *)
      val branch1_name : string ref
      val branch2_name : string ref
      val sure_merges_to_do : bool ref
      val allow_a_posteriori_array_ref_removal : bool ref
      val advise_merge_arrays : bool ref
      val merges_to_do : merge_tt list ref

      (* Outputs *)
      val required_merges : merge_tt list ref
      val var_no_array_ref : binder list ref
      val all_branches_var_list : (binder * binder) list list ref

      val start_reset : unit -> unit
      val reset : unit -> unit

      val simplif_add : simp_facts -> term -> simp_facts
      val simplif_add_list : simp_facts -> term list -> simp_facts

      val simp_equal_def_list : simp_facts -> program_points_args list -> binderref list ->
	known_history option -> binderref list -> binderref list -> bool

      (* The first compared argument is the one that will be removed
	 in the merge, the second one is the one that will be kept.
	 This is important, because the comparison functions are not
	 symmetric: they use the facts known at the first argument
	 to compare terms. *)
      val terms : repl_index list option -> term -> term -> result_t
      val processes : repl_index list option -> process -> process -> result_t
      val fullprocesses : repl_index list option -> inputprocess -> inputprocess -> result_t

      val group : merge_group_t -> result_t
	  
    end
    =
  struct

let branch1_name = ref ""
let branch2_name = ref ""
    (* Names of branches for error messages *)
    
let cur_branch_var_list = ref []
    (* List of pairs (variable in current branch, variable in else branch)
       for variables with array references, a single definition, and
       a different name in different branches *)

let all_branches_var_list = ref []
    (* All lists cur_branch_var_list for the various branches *)

let sure_merges_to_do = ref false
    (* When [true], we are sure that the merges in [merges_to_do] we will
       performed (or the whole transformation fails) *)
    
let allow_a_posteriori_array_ref_removal = ref false
    (* When true, allow considering some processes are equal, assuming that the array
       references to some variables will be removed. Those variables are added to [var_no_array_ref].
       [allow_a_posteriori_array_ref_removal] is true in merge and false in merge_arrays.
       [var_no_array_ref] is used only when this variable is true *)

let advise_merge_arrays = ref false
    (* When true, the equality test generates pairs of variables in
       [cur_branch_var_list] such that merging these variables via merge_arrays
       could make the equality be true. These pairs of variables are then
       moved to [all_branches_var_list]. *)
    
let var_no_array_ref = ref []
    (* Variables that must not have array references in the final game *)

let merges_to_do = ref ([] : merge_tt list)
    (* Candidate merges *)
    
let required_merges = ref ([] : merge_tt list)
    (* Merges that must be done for the equality between branches to hold *)
    
let global_map = ref []
    (* List of pairs of variables, to map variables with array references *)

let eq_oblig = ref []
    (* Equality obligations between terms *)

let eq_oblig_def_list = ref []
    (* Equality obligations between def_lists *)

let ok_arrays_first_branch = ref []
let ok_arrays_second_branch = ref []
    (* [ok_arrays_first_branch] contains the list of variables that
       are defined and used only in the first merged branch, and such that 
       all array accesses have curarray_suffix as suffix of the argument.
       [ok_arrays_second_branch] is similar for the second branch.
       These variables are allowed to be renamed during the merge,
       even though they have array references. *)

let random_supply = ref ([] : (binder option ref * binder option ref) list)
    (* [random_supply] is a list of variables for random number generations:
       when a randomly generated variable has no array accesses,
       we remove the random generation and replace it with one of these
       variables, trying to use matching variables in both processes we want
       to prove equivalent.
       New variables are added to the head. *)

let start_reset() = 
  assert (!var_no_array_ref == []);
  assert (!required_merges == []);
  assert (!all_branches_var_list == [])
    
let reset() = 
  var_no_array_ref := [];
  required_merges := [];
  all_branches_var_list := []
        
let diff_message occ1 occ2 msg =
  RFalse ("At "^(string_of_int occ1)^
	  " "^(!branch1_name)^" and at "^(string_of_int occ2)^
	  " "^(!branch2_name)^", "^msg^".\n")
    
(* [merge_var next_f map b b'] records that variable [b] in the first branch to merge
   corresponds to variable [b'] in the second branch. 
   This may be done by adding (b,b') to [map] (for variables without array accesses after merge) 
   or to [global_map] (for variables with array accesses but local to one of the branches).
   In case of success, it calls [next_f] with the updated [map].
   In case of failure, it returns false. *)

let merge_var occ occ' next_f map b b' =
  if b == b' then
    (* Note: when b == b', b and b' cannot be in ok_arrays_first_branch / ok_arrays_second_branch,
       because for a variable to be in ok_arrays_first_branch / ok_arrays_second_branch, it must
       be defined only in one of the branches. Here, b == b' is defined in both branches.
       Hence b, b' are not in global_map, so matching b with b' does not conflict with global_map. *)
    next_f map
  else if (b.btype != b'.btype) then
    diff_message occ occ'
      ("variables "^(Display.binder_to_string b)^" "^(!branch1_name)^" and "^(Display.binder_to_string b')^" "^(!branch2_name)^" have different types")
  else if Settings.occurs_in_queries b (!whole_game).current_queries then
    diff_message occ occ'
      ("variables "^(Display.binder_to_string b)^" "^(!branch1_name)^" and "^(Display.binder_to_string b')^" "^(!branch2_name)^" should be merged but "^(Display.binder_to_string b)^" occurs in queries")
  else if (Settings.occurs_in_queries b' (!whole_game).current_queries) then
    diff_message occ occ'
      ("variables "^(Display.binder_to_string b)^" "^(!branch1_name)^" and "^(Display.binder_to_string b')^" "^(!branch2_name)^" should be merged but "^(Display.binder_to_string b')^" occurs in queries")
  else 
    let ar_b = Array_ref.has_array_ref_non_exclude b in
    let ar_b' = Array_ref.has_array_ref_non_exclude b' in
    if (not ar_b) && (not ar_b') then
      next_f ((Terms.term_from_binder b,Terms.term_from_binder b')::map)
    else if (List.memq b (!ok_arrays_first_branch)) &&
            (List.memq b' (!ok_arrays_second_branch)) then
      begin
	(* check no previous entry with b or b' but not both in global_map *)
        match for_all_result (fun (b1, b1') ->
	  let result = (b == b1 && b' != b1') || (b != b1 && b' == b1') in
	  if result then
	    diff_message occ occ'
	      ("incoherent renaming: variables "^(Display.binder_to_string b)^" "^(!branch1_name)^" is mapped "^(Display.binder_to_string b')^" "^(!branch2_name)^", but "^(Display.binder_to_string b1)^" was already mapped to "^(Display.binder_to_string b1'))
	  else
	    RTrue
	    ) (!global_map) 
	with
	| RTrue ->
	    (* Do not add if same entry already present. *)
	    if not (List.exists (fun (b1,b1') -> b == b1 && b' == b1') (!global_map)) then
	      global_map := (b,b') :: (!global_map);
	    next_f map
	| r -> r
      end
    else if !allow_a_posteriori_array_ref_removal then
      begin
	if ar_b then var_no_array_ref := b :: (!var_no_array_ref);
	if ar_b' then var_no_array_ref := b' :: (!var_no_array_ref);
	if !advise_merge_arrays && ar_b && ar_b' && (b.count_def == 1) && (b'.count_def == 1) then
          (* When there are variables with different names in the various
             branches and they have array references, we advise MergeArrays. *)
	  cur_branch_var_list := (b,b') :: (!cur_branch_var_list);
	next_f ((Terms.term_from_binder b,Terms.term_from_binder b')::map)
      end
    else 
      diff_message occ occ'
	("variables "^(Display.binder_to_string b)^" "^(!branch1_name)^" and "^(Display.binder_to_string b')^" "^(!branch2_name)^" have array references that prevent renaming")


(* [merge_var_list] is the same as [merge_var] but for lists of variables *)

let rec merge_var_list occ occ' next_f map bl bl' =
  match bl,bl' with
    [], [] -> next_f map
  | [], _ | _, [] ->
      diff_message occ occ'
	"find with different number of indices"
  | ((b,_)::bl, (b',_)::bl') ->
      merge_var occ occ'
	(fun map' -> merge_var_list occ occ' next_f map' bl bl') map b b'

let get_bitlink side b =
  match b.link with
  | BiTLink(l1,l2) ->
      if side = 1 then l1 else l2
  | NoLink -> None
  | _ -> assert false
      
let rec follow_bitlink side t =
  match t.t_desc with
  | Var(b,l) ->
      begin
	match get_bitlink side b with
	| Some t' ->
	    (* [b] must not have array accesses when we link it with [BiTLink],
	       either now, or later when the merge is successful
	       because [b] is stored in [var_no_array_ref].
	       If we have an array access to [b] inside the branches we try to merge,
	       we consider that the merge fails. *)
	    if Terms.is_args_at_creation b l then
	      follow_bitlink side t'
	    else
	      raise Failed
	| None ->
	    Terms.build_term2 t (Var(b, List.map (follow_bitlink side) l))
      end
  | FunApp(f,l) ->
      Terms.build_term2 t (FunApp(f, List.map (follow_bitlink side) l))
  | ReplIndex _ -> t
  | _ -> assert false (* [follow_bitlink] applies only with simple terms *)

let br_follow_bitlink side (b,l) =
  match get_bitlink side b with
  | Some t' ->
      (* [b] must not have array accesses when we link it with [BiTLink],
	 either now, or later when the merge is successful
	 because [b] is stored in [var_no_array_ref].
	 If we have an array access to [b] inside the branches we try to merge,
	 we consider that the merge fails. *)
      if Terms.is_args_at_creation b l then
	None
      else
	raise Failed
  | None ->
      Some (b, List.map (follow_bitlink side) l)
	
(* [equal_terms_ren map t t'] records in [eq_oblig] the constraint
   that [t] must be equal to the inverse image by [map], [random_supply],
   and [global_map] of the term [t'].
   We are careful not to modify [t] because we use the facts known at [t]
   to perform the comparison. That is why we rename [t'].
   This constraint is verified in [equal_store_arrays] after the 
   whole processes/terms have been compared.
   The inverse image by [map] and [random_supply] is computed in [equal_terms_ren], while
   the inverse image by [global_map] is computed at test time in [equal_store_arrays].
   [equal_terms_ren] always returns true when the terms have the same type. *)

let equal_terms_ren map t0 t0' = 
  if t0.t_type != t0'.t_type then
    diff_message t0.t_occ t0'.t_occ
      "terms have different types"
  else
    try
      let t = follow_bitlink 1 t0 in
      let t' = follow_bitlink 2 t0' in
      List.iter (fun (t1,t1') ->
	match t1'.t_desc with
	  Var(b,_) -> b.link <- TLink t1
	| ReplIndex b -> b.ri_link <- TLink t1
	| _ -> Parsing_helper.internal_error "Mergebranches.equal_terms_ren: map should contain only Var/ReplIndex") map;
      List.iter (fun (b_ref,b_ref') ->
	match !b_ref, !b_ref' with
	| Some b, Some b' ->  b'.link <- TLink (Terms.term_from_binder b)
	| _ -> ()
	      ) (!random_supply);
      let mapped_t' = Terms.copy_term Terms.Links_RI_Vars t' in
      List.iter (fun (t1,t1') ->
	match t1'.t_desc with
	  Var(b,_) -> b.link <- NoLink
	| ReplIndex b -> b.ri_link <- NoLink
	| _ -> Parsing_helper.internal_error "Mergebranches.equal_terms_ren: map should contain only Var/ReplIndex") map;
      List.iter (fun (b_ref,b_ref') ->
	match !b_ref, !b_ref' with
	| Some b, Some b' ->  b'.link <- NoLink
	| _ -> ()
	      ) (!random_supply);
      (* We test the equality of processes by first testing that
	 they have the same structure, and collecting all needed 
	 equalities of terms in eq_oblig. When the processes have
	 the same structure, we will later verify that the terms are
	 indeed equal. This is because testing equality of terms
	 is more costly. *)
      eq_oblig := (DTerm t0, t0.t_occ, t, t0'.t_occ, mapped_t') :: (!eq_oblig);
      RTrue
    with Failed ->
      diff_message t0.t_occ t0'.t_occ
	"terms cannot be proved equal"

(* [eq_deflist map dl dl'] records in [eq_oblig_def_list] the constraint
   that the defined condition [dl] must be equal to the inverse image by [map],
   [random_supply], and [global_map] of [dl'], similarly to [equal_terms_ren] above.  *)

let eq_deflist pp map occ dl occ' dl' = 
  try
    let dl = List.filter_map (br_follow_bitlink 1) dl in
    let dl' = List.filter_map (br_follow_bitlink 2) dl' in    
    List.iter (fun (t1,t1') ->
      match t1'.t_desc with
	Var(b,_) -> b.link <- TLink t1
      | ReplIndex b -> b.ri_link <- TLink t1
      | _ -> Parsing_helper.internal_error "Mergebranches.eq_deflist: map should contain only Var/ReplIndex") map;
    List.iter (fun (b_ref,b_ref') ->
      match !b_ref, !b_ref' with
      | Some b, Some b' ->  b'.link <- TLink (Terms.term_from_binder b)
      | _ -> ()
	    ) (!random_supply);
    let mapped_dl' = Terms.copy_def_list Terms.Links_RI_Vars dl' in
    List.iter (fun (t1,t1') ->
      match t1'.t_desc with
	Var(b,_) -> b.link <- NoLink
      | ReplIndex b -> b.ri_link <- NoLink
      | _ -> Parsing_helper.internal_error "Mergebranches.eq_deflist: map should contain only Var/ReplIndex") map;
    List.iter (fun (b_ref,b_ref') ->
      match !b_ref, !b_ref' with
      | Some b, Some b' ->  b'.link <- NoLink
      | _ -> ()
	    ) (!random_supply);
  (* We test the equality of processes by first testing that
     they have the same structure, and collecting all needed 
     equalities of def lists in eq_oblig_def_list. When the processes have
     the same structure, we will later verify that the def lists are
     indeed equal. This is because testing equality of terms
     is more costly. *)
    eq_oblig_def_list := (pp, occ, dl, occ', mapped_dl') :: (!eq_oblig_def_list);
    RTrue
  with Failed ->
    diff_message occ occ'
      "defined conditions cannot be proved equal"

(* [similar_var b b'] is true when the variables [b] and [b'] may be
   merged. [b] is known to have array references [has_array_ref b] *)
let similar_var b b' =
  b == b' ||
  (b.btype == b'.btype && (* has_array_ref b && *) has_array_ref b' &&
   (* when [b != b'], we must be able to rename [b] to [b'] *)
   ((!advise_merge_arrays) ||
   ((List.memq b (!ok_arrays_first_branch)) &&
    (List.memq b' (!ok_arrays_second_branch)) &&
    not (List.exists (fun (b1, b1') ->
      (b == b1 && b' != b1') || (b != b1 && b' == b1')
	) (!global_map)))))
	
let rec similar_pat pat pat' =
  match pat,pat' with
  | PatVar b, PatVar b' -> b.btype == b'.btype
  | PatTuple(f,l), PatTuple(f',l') -> f == f' && List.for_all2 similar_pat l l'
  | PatEqual t, PatEqual t' -> t.t_type = t'.t_type
  | _ -> false

(* [similar_let pat t pat' t'] is true when we want to synchronize
   [let pat = t] with [let pat' = t']. When [pat] is a variable,
   it has array accesses or [t] is not simple.
   (In the case without array access and [t] is simple,
   we replace the assignment with a link.)*)
let similar_let pat t pat' t' =
  t.t_type == t'.t_type && similar_pat pat pat' &&
  let simple = Terms.check_simple_term t in
  let simple' = Terms.check_simple_term t' in
  simple == simple' &&
  (match pat' with
     (* When [not (has_array_ref b') && simple'],
	we replace the assignment with a link, we do not synchronize the lets.
	When [!allow_a_posteriori_array_ref_removal && simple],
	[pat'] is never a variable, because if it were, [pat] would also be
	since [similar_pat pat pat'] and that case is handled earlier. *)
  | PatVar b' -> has_array_ref b' || not simple'
  | _ -> true)


(* [similar_find_branch br br'] returns either
   - [None] when the branches [br] and [br'] have different number/types of indices
   - [Some br2'] where [br2'] is [br'] up to the ordering of find indices,
   and the indices in [br] and [br2'] have the same types in the same order.
   The indices are reordered in [br2'] only when there is a unique index of each type,
   so that the order can be uniquely determined. *)
let similar_find_branch (bl, def_list, t, t1) (bl', def_list', t', t1') =
  if List.length bl != List.length bl' then None else
  (* First try without reordering the indices *)
  if List.for_all2 (fun (b,_) (b',_) -> b.btype == b'.btype) bl bl' then
    Some (bl', def_list', t', t1')
  else
    (* If it does not work, try reordering the indices *)
    try
      let bl'' =
	List.map (fun (b,_) ->
	  let candidates_b' = List.filter (fun (b', _) -> b.btype == b'.btype) bl' in
	  match candidates_b' with
	  | [b'] -> b'
	  | _ -> raise Not_found
		) bl
      in
      Some (bl'', def_list', t', t1')
    with Not_found ->
      None

(* [similar_find pp l0 find_info l0' find_info'] returns either
   - [None] when the finds [l0,find_info] and [l0',find_info'] cannot be considered similar
   - [Some l02'] where [l02'] is [l0'] up to the ordering of find indices and branches,
   and the branches in [l0] and [l02'] have the same number and types of indices in the same order.
   The branches are reordered in [l02'] only when each branch can
   be uniquely determined from the number and types of indices
   so that the order can be uniquely determined. *)
let similar_find pp l0 find_info l0' find_info' =
  if not 
      (Terms.equal_find_info
	 (Terms.is_unique (Some (!whole_game)) l0 find_info)
	 (Terms.is_unique (Some (!whole_game)) l0' find_info') &&
       List.length l0 == List.length l0')
  then None else
    (* First try without reordering the branches *)
    try 
      let l02' = List.map2 (fun br br' ->
	match similar_find_branch br br' with
	| None -> raise Not_found
	| Some br2' -> br2') l0 l0'
      in
      Some l02'
    with Not_found ->
      (* If it does not work, try reordering the branches *)
      try
	let l02' = List.map (fun br ->
	  let candidates_br2' =
	    List.filter_map (similar_find_branch br) l0'
	  in
	  match candidates_br2' with
	  | [br2'] -> br2'
	  | _ -> raise Not_found
		) l0
	in
	(* For safety, check that each branch of l0' is present
	   once in l02' *)
	List.iter (fun (_,def_list,t,p) ->
	  let eq_br2' = List.filter (fun (_,def_list',t',p') ->
	    def_list == def_list' && t == t' && p == p') l02'
	  in
	  match eq_br2' with
	  | [_] -> (* ok *) ()
	  | _ -> raise Not_found
		) l0';
	let cur_array =
	  match Incompatible.get_facts pp with
	  | None -> assert false
	  | Some ppi -> ppi.ppi_cur_array
	in
	Proba.add_proba_find cur_array l0' find_info';
	Some l02'
      with Not_found ->
	None
    
(* [equal_terms map t t'] records that the image by
   by [map] and [global_map] of the term [t] must be equal to
   [t']. It returns false when the equality is impossible.
   The constraints needed to have equality
   are collected in [eq_oblig] and [eq_oblig_def_list].

   [equal_process] and [equal_oprocess] are similar, for
   input and output processes respectively.

   [equal_pat map map_ref pat pat'] is similar for patterns.
   [map] is the initial correspondence between variables;
   [map_ref] is initially equal to [map] and is updated by 
   adding variables bound by the patterns [pat] and [pat']. *)

let add_bitlink side b t =
  if side = 1 then 
    match b.link with
    | NoLink -> b.link <- BiTLink(Some t, None)
    | BiTLink(None, l) -> b.link <- BiTLink(Some t, l)
    | _ -> assert false
	(* Since each variable can be defined at most once in each branch,
           [b] must not have been linked (or added to [map]) before on the same side *)
  else
    match b.link with
    | NoLink -> b.link <- BiTLink(None, Some t)
    | BiTLink(l, None) -> b.link <- BiTLink(l, Some t)
    | _ -> assert false
	(* Since each variable can be defined at most once in each branch,
           [b] must not have been linked (or added to [map]) before on the same side *)

let assign_to_link side b t f =
  if !allow_a_posteriori_array_ref_removal && has_array_ref b then
    var_no_array_ref := b :: (!var_no_array_ref);
  let old_link = b.link in
  add_bitlink side b t;
  let r = f() in
  b.link <- old_link;
  r
	  
let assign_to_link_catch_exception side b t f =
  let old_var_no_array_ref = !var_no_array_ref in
  let old_link = b.link in
  if !allow_a_posteriori_array_ref_removal && has_array_ref b then
    var_no_array_ref := b :: (!var_no_array_ref);
  add_bitlink side b t;
  try
    let r = f() in
    b.link <- old_link;
    r
  with Failed ->
    var_no_array_ref := old_var_no_array_ref;
    b.link <- old_link;
    raise Failed

let find_random_var side ty args =
  let rec aux = function
    | [] ->
	let ref1 = ref None in
	let ref2 = ref None in
	random_supply := (ref1, ref2) :: (!random_supply);
	let b_ref = if side = 1 then ref1 else ref2 in
	let b = Terms.create_binder "rand" ty args in
	b_ref := Some b;
	b, b_ref
    | (ref1, ref2) :: r ->
	let b_ref = if side = 1 then ref1 else ref2 in
	let other_ref = if side = 1 then ref2 else ref1 in
	(* There is no risk that the args_at_creation do not match,
	   because we match the structure of replications.
	   We still allow renaming replication indices, so the args_at_creation
	   may not be exactly equal. *)
	match !other_ref, !b_ref with
	| Some b', None when b'.btype == ty ->
	    let b = Terms.create_binder "rand" ty args in
	    b_ref := Some b;
	    b, b_ref
	| _ ->
	    aux r
  in
  aux (List.rev (!random_supply))

let restr_to_link side b f =
  if !allow_a_posteriori_array_ref_removal && has_array_ref b then
    var_no_array_ref := b :: (!var_no_array_ref);
  let old_random_supply = !random_supply in
  let old_link = b.link in
  let rand_var, rand_var_ref = find_random_var side b.btype b.args_at_creation in
  add_bitlink side b (Terms.term_from_binder rand_var);
  let r = f() in
  rand_var_ref := None;
  random_supply := old_random_supply;
  b.link <- old_link;
  r
  
let restr_to_link_catch_exception side b f =
  let old_var_no_array_ref = !var_no_array_ref in
  if !allow_a_posteriori_array_ref_removal && has_array_ref b then
    var_no_array_ref := b :: (!var_no_array_ref);
  let old_random_supply = !random_supply in
  let old_link = b.link in
  let rand_var, rand_var_ref = find_random_var side b.btype b.args_at_creation in
  add_bitlink side b (Terms.term_from_binder rand_var);
  try 
    let r = f() in
    rand_var_ref := None;
    random_supply := old_random_supply;
    b.link <- old_link;
    r
  with Failed ->
    var_no_array_ref := old_var_no_array_ref;
    rand_var_ref := None;
    random_supply := old_random_supply;
    b.link <- old_link;
    raise Failed

let merge_term t =
  match t.t_desc with
  | LetE(_, _, _, Some t3) | TestE (_,_,t3) ->
      begin
	match List.find_opt (function
	  | { m_merge = MergeTerm (t',_) } -> t' == t
	  | _ -> false) (!merges_to_do)
	with
	| Some merge -> Some ([merge], t3)
	| None -> None
      end
  | FindE(l0,t3,find_info) ->
      begin
	match List.find_opt (function
	  | { m_merge = MergeTerm(t',l') } ->
	      t' == t && (List.length l0 + 1 = List.length l')
	  | _ -> false) (!merges_to_do)
	with
	| Some ({m_merge = MergeTerm(_,merge_result :: _)} as merge) -> Some ([merge], merge_result)
	| Some _ -> assert false
	| None ->
	    if !sure_merges_to_do then
	      (* I allow partial merges for find unique *)
	      let rec part_merge = function
		| [] -> [],[]
		| ((_,_,_,t2) as br)::r ->
		    let merges, branches = part_merge r in 
		    match List.find_opt (function
		      { m_merge = MergeTerm(t',[t3';t2']) } -> (t' == t) && (t3' == t3) && (t2' == t2)
		      | _ -> false) (!merges_to_do) with
		    | Some merge -> merge::merges, branches
		    | None -> merges, br::branches
	      in
	      let (merges, branches) = part_merge l0 in
	      if branches = [] then
		Some(merges, t3)
	      else if merges = [] then
		None
	      else
		Some(merges, Terms.build_term t (FindE(branches,t3,find_info)))
	    else
	      try 
		let l0_merge = List.map (fun (_,_,_,t2) ->
		  List.find (function
		      { m_merge = MergeTerm(t',[t3';t2']) } -> (t' == t) && (t3' == t3) && (t2' == t2)
		    | _ -> false) (!merges_to_do)) l0
		in
		Some (l0_merge, t3)
	      with Not_found ->
		None
      end
  | _ -> None

let merge_term_unsure t =
  if !sure_merges_to_do then None else merge_term t
	
let next_synchronize synchronize t' =
  match t'.t_desc with
  | LetE(PatVar b', t1', t2', _) ->
      if Terms.check_simple_term t1' &&
	(!allow_a_posteriori_array_ref_removal || not (has_array_ref b')) then
	(* We replace the assignment [let b'] with a link, and try to
	   synchronize [let b] with an assignment inside [t2'] *)
	assign_to_link_catch_exception 2 b' t1' (fun () -> synchronize t2')
      else
	raise Failed
  | ResE(b', t1') ->
      if !allow_a_posteriori_array_ref_removal || not (has_array_ref b') then
	restr_to_link_catch_exception 2 b' (fun () -> synchronize t1')
      else
	raise Failed
  | TestE _ |  LetE(_, _, _, Some _) | FindE _ ->
      begin
	match merge_term_unsure t' with
	| Some (merge, res) ->
	    begin
	      let old_required_merges = !required_merges in
	      required_merges := merge @ (!required_merges);
	      try
		synchronize res
	      with Failed ->
		required_merges := old_required_merges;
		raise Failed
	    end
	| None -> raise Failed
      end
  | _ ->
      raise Failed

let rec equal_terms map t t' =
  if Terms.check_simple_term t && Terms.check_simple_term t' then
    equal_terms_ren map t t'
  else
    (* When [!sure_merges_to_do = true], perform merges directly before
       trying to show equality.
       When [!sure_merges_to_do = false], perform merges only when it is
       needed to synchronize the terms, via [merge_term_unsure]. *)
    if !sure_merges_to_do then
      match merge_term t with
      | Some(_,t1) -> equal_terms map t1 t'
      | None ->
	  match merge_term t' with
	  | Some(_,t1') -> equal_terms map t t1'
	  | None ->
	      equal_terms_merged map t t'
    else
      equal_terms_merged map t t'

and equal_terms_merged map t t' = 
  match t.t_desc, t'.t_desc with
  (* Allow merging even if assignments are organized in a different way,
     by storing the value in a link of the variable and ignoring the assignment otherwise *)
  | LetE(PatVar b, t1, t2, _), _ when
    Terms.check_simple_term t1 && not (has_array_ref b) ->
      assign_to_link 1 b t1 (fun () -> equal_terms map t2 t')

  | ResE(b, t1), _ when not (has_array_ref b) ->
      restr_to_link 1 b (fun () -> equal_terms map t1 t')

  | LetE(PatVar b, t1, t2, _), _ when
    Terms.check_simple_term t1 && !allow_a_posteriori_array_ref_removal ->
      (* We have two choices:
         - replace the assignment with a link, but the merge will require 
	 that array accesses to [b] be removed in the final game
         - match the assignment with a similar assignment on the other side
	 We try to find a matching assignment by [synchronize], and if we fail,
	 we replace the assignment with a link.

	 [has_array_ref b] is true because the previous case failed *)
      let rec synchronize t' =
	match t'.t_desc with
	| LetE(PatVar b', t1', t2', _) when similar_var b b' ->
	    (* We synchronize [let b] with [let b'] *)
	    begin
	      match equal_terms map t1 t1' with
	      | RTrue -> 
		  merge_var t.t_occ t'.t_occ
		     (fun map' -> equal_terms map' t2 t2') map b b'
	      | r -> r
	    end
	| _ -> next_synchronize synchronize t'
      in	    
      begin
	try
	  synchronize t'
	with Failed ->
	  (* Synchronization failed, we replace the assignment [let b] with a link *)
	  assign_to_link 1 b t1 (fun () -> equal_terms map t2 t')
      end

  | ResE(b, t1), _ when !allow_a_posteriori_array_ref_removal ->
      (* We have two choices:
         - replace the random generation with a link, but the merge will require 
	 that array accesses to [b] be removed in the final game
         - match the random generation with a similar one on the other side
	 We try to find a matching random generation by [synchronize], and if we fail,
	 we replace the random generation with a link.

	 [has_array_ref b] is true because the previous case failed *)
      let rec synchronize t' =
	match t'.t_desc with
	| ResE(b', t1') when similar_var b b' ->
	    (* We synchronize [new b] with [new b'] *)
	    merge_var t.t_occ t'.t_occ
	      (fun map' -> equal_terms map' t1 t1') map b b'
	| _ -> next_synchronize synchronize t'
      in
      begin
	try
	  synchronize t'
	with Failed ->
	  (* Synchronization failed, we replace the random generation of [b] with a link *)
	  restr_to_link 1 b (fun () -> equal_terms map t1 t')
      end

  | LetE(pat, t1, t2, topt), _ ->
      let rec synchronize t' =
	match t'.t_desc with
	| LetE(pat', t1', t2', topt') when similar_let pat t1 pat' t1' ->
	    (* We synchronize [let pat = t1] with [let pat' = t1'] *)
	    begin
	      match equal_terms map t1 t1' with
	      | RTrue ->
		  begin
		    match
		      (match topt, topt' with
		      | None, None -> RTrue
		      | Some t3, Some t3' ->
			  equal_terms map t3 t3'
		      | _ ->
			  diff_message t.t_occ t'.t_occ "else branch of let present on one side only")
		    with
		    | RTrue ->
			begin
			  let map_ref = ref map in
			  match equal_pats t.t_occ t'.t_occ map map_ref pat pat' with
			  | RTrue ->
			      equal_terms (!map_ref) t2 t2'
			  | r -> r
			end
		    | r -> r
		  end
	      | r -> r
	    end
	| _ -> next_synchronize synchronize t'
      in
      begin
	try
	  synchronize t'
	with Failed ->
	  (* Synchronization failed, we try to remove the let *)
	  match merge_term_unsure t with
	  | Some (merge, res) ->
	      required_merges := merge @ (!required_merges);
	      equal_terms map res t'
	  | None ->
	      diff_message t.t_occ t'.t_occ "could not find a matching let"
      end

  | FindE(l0,t3,find_info),_ ->
      let rec synchronize t' =
	match t'.t_desc with
	| FindE(l0',t3',find_info') ->
	    begin
	      match similar_find (DTerm t') l0 find_info l0' find_info' with
	      | Some l0' -> 
	    (* We synchronize the finds; we already know that the find_info and the number of branches match,
	       and that matching branches have the same number and types of indices *)
		  begin
		    match equal_terms map t3 t3' with
		    | RTrue ->
			for_all2_result (fun (bl, def_list, t, t1) (bl', def_list', t', t1') ->
			  let map' = (List.map2 (fun (_, b) (_,b') -> (Terms.term_from_repl_index b, Terms.term_from_repl_index b')) bl bl') @ map in
			  match eq_deflist (DTerm t) map' t.t_occ def_list t'.t_occ def_list' with
			  | RTrue ->
			      begin
				match equal_terms map' t t' with
				| RTrue ->
				    merge_var_list t.t_occ t'.t_occ
				      (fun map'' -> equal_terms map'' t1 t1') map bl bl'
				| r -> r
			      end
			  | r -> r
				) l0 l0'
		    | r -> r
		  end
	      | None -> next_synchronize synchronize t'
	    end
	| _ -> next_synchronize synchronize t'
      in
      begin
	try
	  synchronize t'
	with Failed ->
	  (* Synchronization failed, we try to remove the find *)
	  match merge_term_unsure t with
	  | Some (merge, res) ->
	      required_merges := merge @ (!required_merges);
	      equal_terms map res t'
	  | None ->
	      match l0 with
	      | [([], def_list, t, t1)] when Terms.is_true t && (match t3.t_desc with
		| FunApp(_,[]) -> true
		| _ -> false) ->
		  (* Merge "if defined(def_list) then ..." such that [def_list]
		     is always defined and is present just to syntactically guarantee that
		     the definition of array references is checked.
		     [eq_deflist ... def_list ... []] checks that [def_list] is always defined.
		     The else branch is unreachable.
		     Applied only when the else branch is a constant, because
		     when the else branch has been found unreachable,
		     it is replaced with a constant.
		     TODO I should update this code if I change the replacement for unreachable code. *)
		    begin
		      match eq_deflist (DTerm t) map t.t_occ def_list t'.t_occ [] with
		      | RTrue -> equal_terms map t1 t'
		      | r -> r
		    end
	      | _ -> 
		  diff_message t.t_occ t'.t_occ "could not find a matching find"
      end

  | TestE(t1, t2, t3), _ ->
      let rec synchronize t' =
	match t'.t_desc with
	| TestE(t1', t2', t3') ->
	    (* try to synchronize the tests, but in case of failure, we try to remove the test *)
	    let old_required_merges = !required_merges in
	    let old_var_no_array_ref = !var_no_array_ref in
	    let old_cur_branch_var_list = !cur_branch_var_list in
	    let old_global_map = !global_map in
	    let old_eq_oblig = !eq_oblig in
	    let old_eq_oblig_def_list = !eq_oblig_def_list in
	    let r =
	      match equal_terms map t1 t1' with
	      | RTrue ->
		  begin
		    match equal_terms map t2 t2' with
		    | RTrue -> equal_terms map t3 t3'
		    | r -> r
		  end
	      | r -> r
	    in
	    if (r <> RTrue) && !merges_to_do != [] then
	      begin
		required_merges := old_required_merges;
		var_no_array_ref := old_var_no_array_ref;
		cur_branch_var_list := old_cur_branch_var_list;
		global_map := old_global_map;
		eq_oblig := old_eq_oblig;
		eq_oblig_def_list := old_eq_oblig_def_list;
		next_synchronize synchronize t'
	      end
	    else
	      r
	| _ -> next_synchronize synchronize t'
      in
      begin
	try
	  synchronize t'
	with Failed ->
	  (* Synchronization failed, we try to remove the test *)
	  match merge_term_unsure t with
	  | Some (merge, res) ->
	      required_merges := merge @ (!required_merges);
	      equal_terms map res t'
	  | None ->
	      diff_message t.t_occ t'.t_occ "could not find a matching if"
      end
	
  | _, LetE(PatVar b, t1, t2, _) when
      Terms.check_simple_term t1 &&
      (!allow_a_posteriori_array_ref_removal || not (has_array_ref b)) ->
      assign_to_link 2 b t1 (fun () -> equal_terms map t t2)
  | _, ResE(b,t1) when !allow_a_posteriori_array_ref_removal || not (has_array_ref b) ->
      restr_to_link 2 b (fun () -> equal_terms map t t1)
  | _, (LetE(_, _, _, Some _) | FindE _ | TestE _) ->
      begin
	(* try to remove the let/find/if *)
	match merge_term_unsure t' with
	| Some (merge, res) ->
	    required_merges := merge @ (!required_merges);
	    equal_terms map t res
	| None ->
	    match t'.t_desc with
	    | FindE([([], def_list, t, t1)], t3, _) when Terms.is_true t && (match t3.t_desc with
	      | FunApp(_,[]) -> true
	      | _ -> false) ->
		  (* Merge "if defined(def_list) then ..." such that [def_list]
		     is always defined and is present just to syntactically guarantee that
		     the definition of array references is checked.
		     [eq_deflist ... [] ... def_list] checks that [def_list] is always defined.
		     The else branch is unreachable.
		     Applied only when the else branch is a constant, because
		     when the else branch has been found unreachable,
		     it is replaced with a constant.
		     TODO I should update this code if I change the replacement for unreachable code. *)
		  begin
		    match eq_deflist (DTerm t) map t.t_occ [] t'.t_occ def_list with
		    | RTrue -> equal_terms map t t1
		    | r -> r
		  end
	    | _ -> 
		diff_message t.t_occ t'.t_occ "could not find a matching if, let, or find"
      end
      
  (* Merge with same syntactic form *)
  | Var(b, l), Var(b', l') ->
      (* This term is not simple! *)
      if b != b' then
	diff_message t.t_occ t'.t_occ "variables differ"
      else
	for_all2_result (equal_terms map) l l'
  | FunApp(f, l), FunApp(f', l') ->
      (* This term is not simple! *)
      if f != f' then
	diff_message t.t_occ t'.t_occ "functions differ"
      else
	for_all2_result (equal_terms map) l l'
  | ReplIndex _, ReplIndex _ -> 
      assert false (* This term is simple, it should be handled before *)
  | ResE(b,t1), ResE(b',t1') ->
      merge_var t.t_occ t'.t_occ
	(fun map' -> equal_terms map' t1 t1') map b b'
  | EventAbortE f, EventAbortE f' ->
      if f != f' then
	diff_message t.t_occ t'.t_occ "events with different names"
      else
	RTrue
  | EventE(t1, t2), EventE(t1', t2') ->
      begin
	match equal_terms map t1 t1' with
	| RTrue -> equal_terms map t2 t2'
	| r -> r
      end
  | (GetE _, GetE _) | (InsertE _, InsertE _) ->
      Parsing_helper.internal_error "Get/Insert should not occur in Transf_merge.equal_terms"
  | _ ->
      diff_message t.t_occ t'.t_occ "terms differ"

and equal_pats occ occ' map map_ref pat pat' =
  match pat, pat' with
    PatVar b, PatVar b' ->
      merge_var occ occ' (fun map' -> map_ref := map'; RTrue) (!map_ref) b b'
  | PatTuple(f,l), PatTuple(f',l') ->
      if f != f' then
	diff_message occ occ' "patterns have different function symbols"
      else
	for_all2_result (equal_pats occ occ' map map_ref) l l'
  | PatEqual t, PatEqual t' -> 
      equal_terms map t t' 
  | _ ->
      diff_message occ occ' "patterns do not match"


	
let same_oracle occ occ' map (o:oracle_decl) (o':oracle_decl) =
  if o.ooracle != o'.ooracle then
    diff_message occ occ' "oracles differ"
  else if (List.length o.oindices != List.length o'.oindices) then
    diff_message occ occ' "oracles with different numbers of indices"
  else
    for_all2_result (equal_terms_ren map)
      (List.map Terms.term_from_repl_index o.oindices) 
      (List.map Terms.term_from_repl_index o'.oindices)
	
let merge_process p =
  match p.p_desc with
  | Let(_,_,_,p2) | Test(_,_,p2) ->
      begin
	match List.find_opt (function
	  | { m_merge = MergeProcess (p',_) } -> p' == p
	  | _ -> false) (!merges_to_do)
	with
	| Some merge -> Some ([merge], p2)
	| None -> None
      end
  | Find(l0,p3,find_info) ->
      begin
	match List.find_opt (function
	  | { m_merge = MergeProcess(p',l') } ->
	      p' == p && (List.length l0 + 1 = List.length l')
	  | _ -> false) (!merges_to_do)
	with
	| Some ({m_merge = MergeProcess(_,merge_result :: _)} as merge) -> Some ([merge], merge_result)
	| Some _ -> assert false
	| None ->
	    if !sure_merges_to_do then
	      (* I allow partial merges for find unique *)
	      let rec part_merge = function
		| [] -> [],[]
		| ((_,_,_,p2) as br)::r ->
		    let merges, branches = part_merge r in 
		    match List.find_opt (function
		      { m_merge = MergeProcess(p',[p3';p2']) } -> (p' == p) && (p3' == p3) && (p2' == p2)
		      | _ -> false) (!merges_to_do) with
		    | Some merge -> merge::merges, branches
		    | None -> merges, br::branches
	      in
	      let (merges, branches) = part_merge l0 in
	      if branches = [] then
		Some(merges, p3)
	      else if merges = [] then
		None
	      else
		Some(merges, Terms.oproc_from_desc_loc p (Find(branches,p3,find_info)))
	    else
	      try 
		let l0_merge = List.map (fun (_,_,_,p2) ->
		  List.find (function
		      { m_merge = MergeProcess(p',[p3';p2']) } -> (p' == p) && (p3' == p3) && (p2' == p2)
		    | _ -> false) (!merges_to_do)) l0
		in
		Some (l0_merge, p3)
	      with Not_found ->
		None
      end
  | _ -> None

let merge_process_unsure p =
  if !sure_merges_to_do then None else merge_process p
	
let next_synchronize synchronize p' =
  match p'.p_desc with
  | Let(PatVar b', t', p1', _) ->
      if Terms.check_simple_term t' &&
	(!allow_a_posteriori_array_ref_removal || not (has_array_ref b')) then
	(* We replace the assignment [let b'] with a link, and try to
	   synchronize [let b] with an assignment inside [p1'] *)
	assign_to_link_catch_exception 2 b' t' (fun () -> synchronize p1')
      else
	raise Failed
  | Restr(b', p1') ->
      if !allow_a_posteriori_array_ref_removal || not (has_array_ref b') then
	restr_to_link_catch_exception 2 b' (fun () -> synchronize p1')
      else
	raise Failed
  | Test _ |  Let _ | Find _ ->
      begin
	match merge_process_unsure p' with
	| Some (merge, p3') ->
	    begin
	      let old_required_merges = !required_merges in
	      required_merges := merge @ (!required_merges);
	      try
		synchronize p3'
	      with Failed ->
		required_merges := old_required_merges;
		raise Failed
	    end
	| None -> raise Failed
      end
  | _ ->
      raise Failed

let rec equal_process map p p' =
  match p.i_desc, p'.i_desc with
    Nil, Nil -> RTrue
  | Par(p1,p2), Par(p1',p2') ->
      begin
	match equal_process map p1 p1' with
	| RTrue -> equal_process map p2 p2'
	| r -> r
      end
  | Repl(b,p1), Repl(b',p1') -> 
      if b == b' then
	equal_process map p1 p1'
      else if b.ri_type != b'.ri_type then
	diff_message p.i_occ p'.i_occ "replications with different bounds"
      else
	equal_process ((Terms.term_from_repl_index b, Terms.term_from_repl_index b')::map) p1 p1'
  | OracleDecl(o, patl, p1), OracleDecl(o', patl', p1') ->
      begin
	match same_oracle p.i_occ p'.i_occ map o o' with
	| RTrue ->
	    begin
	      let map_ref = ref map in
	      match for_all2_result (equal_pats p.i_occ p'.i_occ map map_ref) patl patl' with
	      | RTrue -> equal_oprocess (!map_ref) p1 p1'
	      | r -> r
	    end
	| r -> r
      end
  | _ ->
      diff_message p.i_occ p'.i_occ "processes differ"

and equal_oprocess map p p' =
  (* When [!sure_merges_to_do = true], perform merges directly before
     trying to show equality.
     When [!sure_merges_to_do = false], perform merges only when it is
     needed to synchronize the processes, via [merge_process_unsure]. *)
  if !sure_merges_to_do then
    match merge_process p with
      | Some(_,p1) -> equal_oprocess map p1 p'
      | None ->
	  match merge_process p' with
	  | Some(_,p1') -> equal_oprocess map p p1'
	  | None ->
	      equal_oprocess_merged map p p'
    else
      equal_oprocess_merged map p p'

and equal_oprocess_merged map p p' =
  match p.p_desc, p'.p_desc with
  (* Allow merging even if assignments are organized in a different way,
     by storing the value in a link of the variable and ignoring the assignment otherwise *)
  | Let(PatVar b, t, p1, _), _ when
    Terms.check_simple_term t && not (has_array_ref b) ->
      assign_to_link 1 b t (fun () -> equal_oprocess map p1 p')
      
  | Restr(b, p1), _ when not (has_array_ref b) ->
      restr_to_link 1 b (fun () -> equal_oprocess map p1 p')

  | Let(PatVar b, t, p1, _), _ when
    Terms.check_simple_term t && !allow_a_posteriori_array_ref_removal ->
      (* We have two choices:
         - replace the assignment with a link, but the merge will require 
	 that array accesses to [b] be removed in the final game
         - match the assignment with a similar assignment on the other side
	 We try to find a matching assignment by [synchronize], and if we fail,
	 we replace the assignment with a link.

	 [has_array_ref b] is true because the previous case failed *)
      let rec synchronize p' =
	match p'.p_desc with
	| Let(PatVar b', t', p1', _) when similar_var b b' ->
	    (* We synchronize [let b] with [let b'] *)
	    begin
	      match equal_terms map t t' with
	      | RTrue -> 
		  merge_var p.p_occ p'.p_occ
		    (fun map' -> equal_oprocess map' p1 p1') map b b'
	      | r -> r
	    end
	| _ -> next_synchronize synchronize p'
      in
      begin
	try
	  synchronize p'
	with Failed ->
	  (* Synchronization failed, we replace the assignment [let b] with a link *)
          (* print_string ("Left link for "^(Display.binder_to_string b)^"\n"); *)
	  assign_to_link 1 b t (fun () -> equal_oprocess map p1 p')
      end
	
  | Restr(b, p1), _ when (!allow_a_posteriori_array_ref_removal) ->
      (* We have two choices:
         - replace the random generation with a link, but the merge will require 
	 that array accesses to [b] be removed in the final game
         - match the random generation with a similar one on the other side
	 We try to find a matching random generation by [synchronize], and if we fail,
	 we replace the random generation with a link.

	 [has_array_ref b] is true because the previous case failed *)
      let rec synchronize p' =
	match p'.p_desc with
	| Restr(b', p1') when similar_var b b' ->
	    (* We synchronize [new b] with [new b'] *)
	    merge_var p.p_occ p'.p_occ
	      (fun map' -> equal_oprocess map' p1 p1') map b b'
	| _ -> next_synchronize synchronize p'
      in	    
      begin
	try
	  synchronize p'
	with Failed ->
	  (* Synchronization failed, we replace the random generation of [b] with a link *)
	  restr_to_link 1 b (fun () ->  equal_oprocess map p1 p')
      end

  | Let(pat, t, p1, p2), _ ->
      let rec synchronize p' =
	match p'.p_desc with
	| Let(pat', t', p1', p2') when similar_let pat t pat' t' ->
	    (* We synchronize [let pat = t1] with [let pat' = t1'] *)
	    begin
	      match equal_terms map t t' with
	      | RTrue ->
		  begin
		    match equal_oprocess map p2 p2' with
		    | RTrue ->
			begin
			  let map_ref = ref map in
			  match equal_pats p.p_occ p'.p_occ map map_ref pat pat' with
			  | RTrue -> equal_oprocess (!map_ref) p1 p1'
			  | r -> r
			end
		    | r -> r
		  end
	      | r -> r
	    end
	| _ -> next_synchronize synchronize p'
      in
      begin
	try
	  synchronize p'
	with Failed ->
	  match merge_process_unsure p with
	  | Some (merge, res) ->
	      required_merges := merge @ (!required_merges);
	      equal_oprocess map res p'
	  | None ->
	      diff_message p.p_occ p'.p_occ "could not find a matching let"
      end

  | Find(l, p1, find_info), _ ->
      let rec synchronize p' =
	match p'.p_desc with
      	| Find(l',p1',find_info') ->
	    begin
	      match similar_find (DProcess p') l find_info l' find_info' with
	      | Some l' -> 
	    (* We synchronize the finds; we already know that the find_info and the number of branches match,
	       and that matching branches have the same number and types of indices *)
		  begin
		    match equal_oprocess map p1 p1' with
		    | RTrue ->
			for_all2_result (fun (bl, def_list, t, p1) (bl', def_list', t', p1') ->
			  let map' = (List.map2 (fun (_, b) (_,b') -> (Terms.term_from_repl_index b, Terms.term_from_repl_index b')) bl bl') @ map in
			  match eq_deflist (DProcess p) map' p.p_occ def_list p'.p_occ def_list' with
			  | RTrue ->
			      begin
				match equal_terms map' t t' with
				| RTrue -> 
				    merge_var_list p.p_occ p'.p_occ
				      (fun map'' -> equal_oprocess map'' p1 p1') map bl bl'
				| r -> r
			      end
			  | r -> r
				) l l'
		    | r -> r
		  end
	      | None -> next_synchronize synchronize p'
	    end
	| _ -> next_synchronize synchronize p'
      in
      begin
	try
	  synchronize p'
	with Failed ->
	  (* Synchronization failed, we try to remove the find *)
	  match merge_process_unsure p
	  with
	  | Some (merge, res) ->
	      required_merges := merge @ (!required_merges);
	      equal_oprocess map res p'
	  | None ->
	      match l, p1.p_desc with
	      | [([], def_list, t, p2)], Yield when Terms.is_true t ->
		  (* Merge "if defined(def_list) then ..." such that [def_list]
		     is always defined and is present just to syntactically guarantee that
		     the definition of array references is checked.
		     [eq_deflist ... def_list ... []] checks that [def_list] is always defined.
		     The else branch is unreachable, hence is Yield.
		     TODO I should update this code if I change the replacement for unreachable code. *)
		  begin
		    match eq_deflist (DProcess p) map p.p_occ def_list p'.p_occ [] with
		    | RTrue -> equal_oprocess map p2 p'
		    | r -> r
		  end
	      | _ -> 
		  diff_message p.p_occ p'.p_occ "could not find a matching find"
      end

  | Test(t,p1,p2),_ ->
      let rec synchronize p' =
	match p'.p_desc with
	| Test(t', p1', p2') ->
	    (* try to synchronize the tests, but in case of failure, we try to remove the test *)
	    let old_required_merges = !required_merges in
	    let old_var_no_array_ref = !var_no_array_ref in
	    let old_cur_branch_var_list = !cur_branch_var_list in
	    let old_global_map = !global_map in
	    let old_eq_oblig = !eq_oblig in
	    let old_eq_oblig_def_list = !eq_oblig_def_list in
	    let r =
	      match equal_terms map t t' with
	      | RTrue ->
		  begin
		    match equal_oprocess map p1 p1' with
		    | RTrue -> equal_oprocess map p2 p2'
		    | r -> r
		  end
	      | r -> r
	    in
	    if r <> RTrue && !merges_to_do != [] then
	      begin
		required_merges := old_required_merges;
		var_no_array_ref := old_var_no_array_ref;
		cur_branch_var_list := old_cur_branch_var_list;
		global_map := old_global_map;
		eq_oblig := old_eq_oblig;
		eq_oblig_def_list := old_eq_oblig_def_list;
		next_synchronize synchronize p'
	      end
	    else
	      r
	| _ -> next_synchronize synchronize p'
      in
      begin
	try
	  synchronize p'
	with Failed ->
	  (* Synchronization failed, we try to remove the test *)
	  match merge_process_unsure p with
	  | Some (merge, res) ->
	      required_merges := merge @ (!required_merges);
	      equal_oprocess map res p'
	  | None ->
	      diff_message p.p_occ p'.p_occ "could not find a matching if"
      end
      
  | _, Let(PatVar b, t, p1, _) when
      Terms.check_simple_term t &&
      (!allow_a_posteriori_array_ref_removal || not (has_array_ref b)) ->
      (* print_string ("Right link for "^(Display.binder_to_string b)^"\n"); *)
      assign_to_link 2 b t (fun () -> equal_oprocess map p p1)
  | _, Restr(b,p1) when !allow_a_posteriori_array_ref_removal || not (has_array_ref b) ->
      restr_to_link 2 b (fun () -> equal_oprocess map p p1)
  | _, (Let _ | Find _ | Test _) ->
      begin
	(* try to remove the let/find/if *)
	match merge_process_unsure p' with
	| Some (merge, res) ->
	    required_merges := merge @ (!required_merges);
	    equal_oprocess map p res
	| None ->
	    match p'.p_desc with
	    | Find([([], def_list, t, p2)], {p_desc = Yield}, _) when Terms.is_true t ->
		(* Merge "if defined(def_list) then ..." such that [def_list]
		   is always defined and is present just to syntactically guarantee that
		   the definition of array references is checked.
		   [eq_deflist ... [] ... def_list] checks that [def_list] is always defined.
		   The else branch is unreachable, hence is Yield.
		   TODO I should update this code if I change the replacement for unreachable code. *)
		begin
		  match eq_deflist (DProcess p) map p.p_occ [] p'.p_occ def_list with
		  | RTrue -> equal_oprocess map p p2
		  | r -> r
		end
	    | _ -> 
		diff_message p.p_occ p'.p_occ "could not find a matching if, let, or find"
      end
	
  (* Merge with same syntactic form *)
  | Yield, Yield -> RTrue
  | EventAbort f, EventAbort f' ->
      if f != f' then
	diff_message p.p_occ p'.p_occ "events with different names"
      else
	RTrue
  | Restr(b,p1), Restr(b',p1') ->
      merge_var p.p_occ p'.p_occ
	(fun map' -> equal_oprocess map' p1 p1') map b b'
  | Return(tl,p1), Return(tl',p1') ->
      begin
	match for_all2_result (equal_terms map) tl tl' with
	| RTrue -> equal_process map p1 p1'
	| r -> r
      end
  | EventP(t,p), EventP(t',p') ->
      begin
	match equal_terms map t t' with
	| RTrue -> equal_oprocess map p p'
	| r -> r
      end
  | (Get _, Get _) | (Insert _, Insert _) ->
      Parsing_helper.internal_error "Get/Insert should not occur in Transf_merge.equal_oprocess"
  | _ ->
      diff_message p.p_occ p'.p_occ "processes differ"

let equal_groups map gl gr =
  match for_all2_result (equal_terms map) gl.merge_candidates_t gr.merge_candidates_t with
  | RTrue ->
      for_all2_result (equal_oprocess map) gl.merge_candidates_p gr.merge_candidates_p
  | r -> r
	
(* [collect_def_vars_term def_vars t] collects variables defined in a term [t]
   in the list [def_vars]. On return, the list contains [(b, ref n, ref 0)] for each
   variable [b] defined in the term [t], where [n] is the number of definitions of [b] in [t].

   [collect_def_vars_pattern], [collect_def_vars_def_list], [collect_def_vars_process], 
   and [collect_def_vars_oprocess] are similar for patterns, defined conditions, input processes,
   and output processes respectively. *)

let add def_vars b =
  try 
    let (n_def, _) = List.assq b (!def_vars) in
    incr n_def
  with Not_found ->
    def_vars := (b, (ref 1, ref 0)) :: (!def_vars)

let rec collect_def_vars_term def_vars t =
  begin
    match t.t_desc with
    | FindE(l0,t3,_) ->
	List.iter (fun (bl,def_list, t1,t2) ->
	  List.iter (fun (b,_) -> add def_vars b) bl
	    ) l0
    | ResE(b,t) -> add def_vars b
    | _ -> ()
  end;
  Terms.iter_subterm (collect_def_vars_term def_vars)
    (collect_def_vars_def_list def_vars)
    (collect_def_vars_pattern def_vars) t
  
and collect_def_vars_pattern def_vars = function
  | PatVar b -> add def_vars b
  | pat ->
      Terms.iter_subpat (collect_def_vars_term def_vars)
	(collect_def_vars_pattern def_vars) pat

and collect_def_vars_def_list def_vars def_list =
  List.iter (fun (_,l) -> 
    List.iter (collect_def_vars_term def_vars) l
    ) def_list

let rec collect_def_vars_process def_vars p =
  Terms.iter_subiproc (collect_def_vars_process def_vars)
    (fun o patl p ->
      List.iter (collect_def_vars_pattern def_vars) patl;
      collect_def_vars_oprocess def_vars p) p

and collect_def_vars_oprocess def_vars p =
  begin
    match p.p_desc with
    | Restr(b,p) -> add def_vars b
    | Find(l0,p2,_) ->
	List.iter (fun (bl,def_list,t,p1) ->
	  List.iter (fun (b,_) -> add def_vars b) bl
	    ) l0
    | _ -> ()
  end;
  Terms.iter_suboproc (collect_def_vars_oprocess def_vars)
    (collect_def_vars_term def_vars)
    (collect_def_vars_def_list def_vars)
    (collect_def_vars_pattern def_vars)
    (collect_def_vars_process def_vars) p

(* [check_array_ref_term in_scope curarray_suffix ok_vars t] removes from
   [ok_vars] all variables that have array accesses with arguments that do not
   contain [curarray_suffix] as a suffix. 
   [in_scope] is the list of variables that are in scope at [t].
   (Variables not defined in the branch that we want to merge can be ignored.)
   [ok_vars] initially contains [(b, (ref n, ref 0))] for each variable [b]
   defined [n] times (n >= 1) in the branch that we want to merge.
   The component [ref 0] is updated to contain the number array accesses
   to [b] in the term [t]. 

   [check_array_ref_pattern], [check_array_ref_def_list],
   [check_array_ref_process], and [check_array_ref_oprocess] are
   similar for patterns, defined conditions, input processes, and
   output processes respectively.  *)

(*    [remove b l] returns the list [l] without the element [(b,_)]
      when it is present *)

let rec remove b = function
    [] -> []
  | ((b',_) as a)::l ->
      if b == b' then l else a::(remove b l)

(*    [is_suffix curarray_suffix l] returns true when [curarray_suffix] 
      is a suffix of [l] *)

let is_suffix curarray_suffix l =
  let ls = List.length curarray_suffix in
  let ll = List.length l in
  (ll >= ls) && (List.for_all2 (fun ri t -> 
    match t.t_desc with
      ReplIndex ri' -> ri == ri'
    | _ -> false) curarray_suffix (Terms.skip (ll - ls) l))
  
let array_access curarray_suffix ok_vars b l =
  (* There is an array reference b[l]
     If curarray_suffix not suffix of l, remove b from ok_vars if it was in.
     Otherwise, increment the number of accesses to b stored in ok_vars *)
  if is_suffix curarray_suffix l then
    try
      let (_, n_array_access) = List.assq b (!ok_vars) in
      incr n_array_access
    with Not_found -> ()
  else
    ok_vars := remove b (!ok_vars)

let rec check_array_ref_term in_scope curarray_suffix ok_vars t =
  match t.t_desc with
    Var(b, l) -> 
      if not (Terms.is_args_at_creation b l && List.memq b in_scope) then
	array_access curarray_suffix ok_vars b l;
      List.iter (check_array_ref_term in_scope curarray_suffix ok_vars) l
  | LetE(pat, t1, t2, topt) ->
      check_array_ref_pattern in_scope curarray_suffix ok_vars pat;
      check_array_ref_term in_scope curarray_suffix ok_vars t1;
      check_array_ref_term (Terms.vars_from_pat in_scope pat) curarray_suffix ok_vars t2;
      begin
	match topt with
	  None -> ()
	| Some t3 -> check_array_ref_term in_scope curarray_suffix ok_vars t3
      end
  | FindE(l0,t3,_) ->
      List.iter (fun (bl,def_list, t1,t2) ->
	let in_scope' = (List.map fst bl) @ in_scope in
	check_array_ref_def_list in_scope curarray_suffix ok_vars def_list;
	check_array_ref_term in_scope curarray_suffix ok_vars t1;
	check_array_ref_term in_scope' curarray_suffix ok_vars t2) l0;
      check_array_ref_term in_scope curarray_suffix ok_vars t3
  | ResE(b,t) ->
      check_array_ref_term (b::in_scope) curarray_suffix ok_vars t
  | GetE _ | InsertE _ ->
      Parsing_helper.internal_error "Get/Insert should not appear in Transf_merge.check_array_ref_term"
  | _ ->
      Terms.iter_subterm
	(check_array_ref_term in_scope curarray_suffix ok_vars)
	(check_array_ref_def_list in_scope curarray_suffix ok_vars)
	(check_array_ref_pattern in_scope curarray_suffix ok_vars)
	t

and check_array_ref_pattern in_scope curarray_suffix ok_vars pat =
  Terms.iter_subpat
    (check_array_ref_term in_scope curarray_suffix ok_vars)
    (check_array_ref_pattern in_scope curarray_suffix ok_vars) pat

and check_array_ref_def_list in_scope curarray_suffix ok_vars def_list =
  List.iter (fun (b,l) -> 
    List.iter (check_array_ref_term in_scope curarray_suffix ok_vars) l;
    if not (Terms.is_args_at_creation b l && List.memq b in_scope) then
      array_access curarray_suffix ok_vars b l 
	) def_list

let rec check_array_ref_process in_scope curarray_suffix ok_vars p =
  Terms.iter_subiproc
    (check_array_ref_process in_scope curarray_suffix ok_vars)
    (fun o patl p ->
      List.iter (check_array_ref_pattern in_scope curarray_suffix ok_vars) patl;
      check_array_ref_oprocess (Terms.vars_from_pat_list in_scope patl) curarray_suffix ok_vars p)
    p

and check_array_ref_oprocess in_scope curarray_suffix ok_vars p = 
  match p.p_desc with
  | Restr(b,p) ->
      check_array_ref_oprocess (b::in_scope) curarray_suffix ok_vars p
  | Find(l0,p2,_) ->
      List.iter (fun (bl,def_list,t,p1) ->
	let in_scope' = (List.map fst bl) @ in_scope in
	check_array_ref_def_list in_scope curarray_suffix ok_vars def_list;
	check_array_ref_term in_scope curarray_suffix ok_vars t;      
	check_array_ref_oprocess in_scope' curarray_suffix ok_vars p1) l0;
      check_array_ref_oprocess in_scope curarray_suffix ok_vars p2
  | Let(pat, t, p1, p2) ->
      check_array_ref_pattern in_scope curarray_suffix ok_vars pat;
      check_array_ref_term in_scope curarray_suffix ok_vars t;      
      check_array_ref_oprocess (Terms.vars_from_pat in_scope pat) curarray_suffix ok_vars p1;
      check_array_ref_oprocess in_scope curarray_suffix ok_vars p2
  | Get(tbl,patl,topt,p1,p2,_) ->
      List.iter (check_array_ref_pattern in_scope curarray_suffix ok_vars) patl;
      let in_scope' = Terms.vars_from_pat_list in_scope patl in
      (match topt with 
         | Some t -> check_array_ref_term in_scope' curarray_suffix ok_vars t
         | None -> ());
      check_array_ref_oprocess in_scope' curarray_suffix ok_vars p1;
      check_array_ref_oprocess in_scope curarray_suffix ok_vars p2
  | _ ->
      Terms.iter_suboproc
	(check_array_ref_oprocess in_scope curarray_suffix ok_vars)
	(check_array_ref_term in_scope curarray_suffix ok_vars)
	(check_array_ref_def_list in_scope curarray_suffix ok_vars)
	(check_array_ref_pattern in_scope curarray_suffix ok_vars)
	(check_array_ref_process in_scope curarray_suffix ok_vars)
	p

(* [filter_good_vars l] starts from a list containing
   [(b, (n_def, n_array_access))] for variable [b] defined in a branch
   we want to merge, with [n_def] definitions of [b] and [n_array_access]
   array accesses to [b] in that branch. It returns a sub-list containing
   [b] for each variable [b] defined and accessed only in that branch. *)

let rec filter_good_vars = function
    [] -> []
  | (b, (n_def, n_array_access))::l ->
      if b.count_array_ref < b.count_exclude_array_ref + !n_array_access then
	begin
	  print_string ((Display.binder_to_string b) ^ ": " ^
			(string_of_int b.count_array_ref) ^ " total array ref; " ^
			(string_of_int b.count_exclude_array_ref) ^ " excluded array ref; " ^
			(string_of_int (!n_array_access)) ^ " array ref in branch\n");
	end;
      assert (b.count_array_ref >= b.count_exclude_array_ref + !n_array_access);
      assert (b.count_def >= !n_def);
      if (b.count_array_ref = b.count_exclude_array_ref + !n_array_access) &&
	 (b.count_def = !n_def)
      then
	(* All array accesses to [b] are excluded or in the considered branch;
	   All definitions of [b] are in the considered branch. *)
	b::(filter_good_vars l)
      else
	filter_good_vars l

(* [collect_good_vars curarray_suffix_opt t] returns the list of variables
   defined in [t], accessed only in the term [t], and such that [curarray_suffix]
   is a suffix of the arguments of all accesses to these variables,
   when [curarray_suffix_opt = Some curarray_suffix].
   When [curarray_suffix_opt = None], it returns the empty list.

   [collect_good_vars_oprocess] is similar for processes. *)

let collect_good_vars_group_side curarray_suffix_opt gs =
  match curarray_suffix_opt with
    None -> []
  | Some curarray_suffix ->
      let ok_vars = ref [] in
      List.iter (collect_def_vars_term ok_vars) gs.merge_candidates_t;
      List.iter (collect_def_vars_oprocess ok_vars) gs.merge_candidates_p;
      let in_scope = [] (*get_in_scope t.t_facts*) in
      List.iter (check_array_ref_term in_scope curarray_suffix ok_vars)  gs.merge_candidates_t;
      List.iter (check_array_ref_oprocess in_scope curarray_suffix ok_vars) gs.merge_candidates_p;
      filter_good_vars (!ok_vars)

let collect_good_vars curarray_suffix_opt t =
  match curarray_suffix_opt with
    None -> []
  | Some curarray_suffix ->
      let ok_vars = ref [] in
      collect_def_vars_term ok_vars t;
      let in_scope = [] (*get_in_scope t.t_facts*) in
      check_array_ref_term in_scope curarray_suffix ok_vars t;
      filter_good_vars (!ok_vars)
  
let collect_good_vars_oprocess curarray_suffix_opt p =
  match curarray_suffix_opt with
    None -> []
  | Some curarray_suffix ->
      let ok_vars = ref [] in
      collect_def_vars_oprocess ok_vars p;
      let in_scope = [] (*get_in_scope p.p_facts*) in
      check_array_ref_oprocess in_scope curarray_suffix ok_vars p;
      filter_good_vars (!ok_vars)

let collect_good_vars_fullprocess _ p =
  let ok_vars = ref [] in
  collect_def_vars_process ok_vars p;
  List.map fst (!ok_vars)
	
(* For simplification of terms *)

(* Applying a substitution *)

let reduced_subst = ref false

let rec apply_subst1 t tsubst =
     match tsubst.t_desc with
       FunApp(f,[redl;redr]) when f.f_cat == Equal || f.f_cat == LetEqual ->
         begin
           if Terms.equal_terms t redl then 
	     begin
	       reduced_subst := true;
	       redr
	     end
           else
             match t.t_desc with
               Var(b,l) ->
	         Terms.build_term t (Var(b, List.map (fun t' -> apply_subst1 t' tsubst) l))
             | FunApp(f,l) when f.f_cat != LetEqual ->
	         Terms.build_term t (FunApp(f, List.map (fun t' -> apply_subst1 t' tsubst) l))
             | _ -> t
         end
     | _ -> Parsing_helper.internal_error "substitutions should be Equal or LetEqual terms"

let rec apply_all_subst t = function
    [] -> t
  | (a::l) ->
      let t' = apply_subst1 t a in
      if !reduced_subst then t' else apply_all_subst t l

let rec reduce depth ((subst2, _, _) as simp_facts) t =
  if (!Settings.max_depth_add_fact > 0) && (depth > !Settings.max_depth_add_fact) then 
    begin
      print_string "Reducing "; Display.display_term t;
      print_string " stopped because too deep."; print_newline();
      t
    end
  else
    begin
      reduced_subst := false;
      let t' = apply_all_subst t subst2 in
      if !reduced_subst then 
	reduce (depth+1) simp_facts t' 
      else
	t
    end

(* simp_equal_terms tests equality between t and t', modulo rewrite rules in 
   simp_facts. Returns true when equal, false otherwise.  *)

let simp_equal_terms simp_facts t t' =
  let t = reduce 0 simp_facts t in
  let t' = reduce 0 simp_facts t' in
  Terms.equal_terms t t'

(* simp_equal_def_list tests that two defined conditions are equal.
   It allows reordering elements of the defined conditions.
   Rewriting of terms using simp_facts is allowed because the facts
   in simp_facts anyway deal only with variables that are already
   known to be defined. 

   simp_equal_binderref does the equality test for one binder reference. *)

let simp_equal_binderref simp_facts br br' =
  simp_equal_terms simp_facts (Terms.term_from_binderref br) (Terms.term_from_binderref br')

let simp_equal_def_list simp_facts pps def_vars history dl dl' =
  (try 
    let (_, dl_implied) = Facts.def_vars_from_defined pps def_vars history dl in
    List.for_all (fun br' -> List.exists (fun br -> simp_equal_binderref simp_facts br br') (dl_implied @ def_vars)) dl'
  with Contradiction -> true) &&
  (try
    let (_, dl_implied') = Facts.def_vars_from_defined pps def_vars history dl' in
    List.for_all (fun br -> List.exists (fun br' -> simp_equal_binderref simp_facts br br') (dl_implied' @ def_vars)) dl
  with Contradiction -> true) 

let rec orient t1 t2 = 
  match t1.t_desc, t2.t_desc with
    (Var(b,l), _) when
    (not (Terms.refers_to b t2)) && 
    (not (Terms.is_restr b)) -> true
  | (Var(b1,l1), Var(b2,l2)) when
    (b1 == b2) && (List.for_all2 orient l1 l2) -> true
  | (ReplIndex b1, ReplIndex b2) -> true
  | (FunApp(f1,l1), FunApp(f2,l2)) when
    (f1 == f2) && (List.for_all2 orient l1 l2) -> true
  | _ -> false
    
(* Apply reduction rules defined by statements to term t *)

let reduced = Facts.reduced

let rec apply_reds depth simp_facts t =
  let t = reduce (depth+1) simp_facts t in
  reduced := false;
  let t' = Facts.apply_eq_statements_and_collisions_subterms_once (reduce_rec (depth+1) simp_facts) Facts.no_dependency_anal Terms.simp_facts_id t in
  if !reduced then 
    apply_reds (depth+1) simp_facts t' 
  else
    t

(* [reduce_rec simp_facts f t] simplifies the term [t] knowing the fact [f] 
   in addition to the already known facts [simp_facts]. It returns
   the reduced term as well as a boolean that is true 
   when [t] has really been modified. *)

and reduce_rec depth simp_facts f t =
  let reduced_tmp = !reduced in
  reduced := false;
  let t'' =
    Terms.auto_cleanup (fun () ->
      let simp_facts' = simplif_add (depth+1) simp_facts f in
      let t' = reduce (depth+1) simp_facts' t in
      Facts.apply_eq_statements_subterms_once Terms.simp_facts_id t')
  in
  let red = !reduced in
  reduced := reduced_tmp;
  (t'', red)
      
and add_fact depth ((subst2, facts, elsefind) as simp_facts) fact =
  if (!Settings.max_depth_add_fact > 0) && (depth > !Settings.max_depth_add_fact) then 
    begin
      print_string "Adding "; Display.display_term fact;
      print_string " stopped because too deep."; print_newline();
      simp_facts 
    end
  else
  (* print_string "Adding "; Display.display_term fact; print_newline(); *)
  match fact.t_desc with
    FunApp(f,[t1;t2]) when f.f_cat == LetEqual ->
      begin
	match t1.t_desc with
	  Var(b,l) -> 
	    let t1' = Terms.build_term t1 (Var(b, List.map (reduce (depth+1) simp_facts) l))
	    in
	    let t2' = reduce (depth+1) simp_facts t2 in
	    let rec try_red_t1 = function
		[] -> (* Could not reduce t1' *)
		  subst_simplify2 (depth+1) simp_facts (Terms.make_let_equal t1' t2')
	      | { t_desc = FunApp(f'',[t1'';t2''])}::l when f''.f_cat == LetEqual ->
		  if Terms.equal_terms t1'' t1' then 
		    simplif_add (depth+1) simp_facts (Terms.make_equal t2' t2'')
		  else
		    try_red_t1 l
	      | _::l -> try_red_t1 l
	    in
	    try_red_t1 subst2
	| _ ->
	    Display.display_term fact;
	    Parsing_helper.internal_error "LetEqual terms should have a variable in the left-hand side"
      end
  | FunApp(f,[t1;t2]) when f.f_cat == Equal ->
      begin
	try
	  let (l1,l2) = Facts.simplify_equal t1 t2 in
	  simplif_add_list (depth+1) simp_facts (List.map2 Terms.make_equal l1 l2)
	with Facts.Unchanged ->
	  if orient t1 t2 then
	    subst_simplify2 (depth+1) simp_facts fact
	  else if orient t2 t1 then
	    subst_simplify2 (depth+1) simp_facts (Terms.make_equal t2 t1)
	  else
	    (subst2, fact::facts, elsefind)
      end
  | FunApp(f,[t1;t2]) when f == Settings.f_and ->
      simplif_add (depth+1) (add_fact (depth+1) simp_facts t1) t2
  | _ -> 
      if Terms.is_false fact then raise Contradiction else
      if Terms.is_true fact then simp_facts else
      (subst2, fact::facts, elsefind)

and subst_simplify2 depth (subst2, facts, elsefind) link =
  let subst2'' = ref [] in
  let not_subst2_facts = ref [] in
  List.iter (fun t0 ->
    match t0.t_desc with
      FunApp(f, [t;t']) when f.f_cat == Equal || f.f_cat == LetEqual ->
	(* When f.f_cat == LetEqual, t itself cannot be reduced by link,
	   since otherwise the left-hand side of link is t, and this
           term should have been reduced into t' by t0 before.
	   However, subterms of t may be reduced by link.
	   
	   When f.f_cat == LetEqual and we reduce only t' (not t),
	   we might directly add 
	   Terms.make_let_equal t (try_no_var simp_facts t1') to subst2''
	   However, it is not clear what "simp_facts" should really be...
         *)
	let (t1, t1', reduced) = 
	  match t'.t_desc with
	    Var _ | ReplIndex _ ->
	      reduced_subst := false;
	      let t1 = apply_subst1 t link in
	      let t1' = apply_subst1 t' link in
	      (t1,t1',!reduced_subst)
	  | FunApp _ ->
	      reduced_subst := false;
	      let t1 = apply_subst1 t link in
	      let red = !reduced_subst in
	      (* Applying reductions here slows down simplification *)
	      reduced := false;
	      let simp_facts_tmp = (link :: (!subst2''), facts, elsefind) in
	      let t1' = Facts.apply_eq_statements_and_collisions_subterms_once (reduce_rec (depth+1) simp_facts_tmp) Facts.no_dependency_anal Terms.simp_facts_id (reduce (depth+1) simp_facts_tmp t') in
	      (t1, t1', red || (!reduced) || (!reduced_subst))
	  | _ -> Parsing_helper.internal_error "If/let/find/new not allowed in subst_simplify2"
	in
	if reduced then
	  not_subst2_facts := (Terms.app f [t1; t1']) :: (!not_subst2_facts)
	else
	  subst2'' := t0 :: (!subst2'')
    | _ -> Parsing_helper.internal_error "substitutions should be Equal or LetEqual terms"
    ) subst2;
  simplif_add_list (depth+1) (link :: (!subst2''),[], elsefind) ((!not_subst2_facts) @ facts)

and simplif_add depth ((subst2, facts, elsefind) as simp_facts) fact =
(*  print_string "simplif_add "; Display.display_term fact; 
  print_string " knowing\n"; display_facts simp_facts; print_newline();*)
  let fact' = apply_reds (depth+1) simp_facts fact in
  add_fact (depth+1) simp_facts fact'

and simplif_add_list depth simp_facts = function
    [] -> simp_facts
  | (a::l) -> simplif_add_list depth (simplif_add depth simp_facts a) l

let simplif_add = simplif_add 0
let simplif_add_list = simplif_add_list 0

(* [rename map t] replaces variables in the term [t] according
   to the reverse of [map]:
   [map] is a list of pairs of variables (b,b'); each variable
   b' is then replaced with b. 

   [rename_br] and [rename_def_list] are similar, for binder references
   (b,l) and defined conditions of find respectively. *)

let rec rev_assq b = function
  | [] -> b
  | (b1,b2)::r ->
      if b2 == b then
	b1
      else
	rev_assq b r

let rec rename map t =
  Terms.build_term t (
  match t.t_desc with
    Var(b,l) -> 
      let b' = rev_assq b map in
      Var(b', List.map (rename map) l)
  | FunApp(f,l) ->
      FunApp(f, List.map (rename map) l)
  | (ReplIndex i) as x -> x
  | _ -> Parsing_helper.internal_error "if/let/find/new/... should have been expanded in Transf_merge.rename")

let rename_br map (b,l) =
  let b' = rev_assq b map in
  (b', List.map (rename map) l)

let rename_def_list map def_list =
  List.map (rename_br map) def_list


let equal_store_arrays (collect_good_vars, eq_test) curarray_suffix_opt p p' =
  assert (!cur_branch_var_list == []);
  assert (!eq_oblig == []);
  assert (!eq_oblig_def_list == []);
  assert (!global_map == []);
  ok_arrays_first_branch := collect_good_vars curarray_suffix_opt p;
  ok_arrays_second_branch := collect_good_vars curarray_suffix_opt p';
    (* [ok_arrays_first_branch] contains the list of variables 
       defined in [p], such that all array accesses are in [p] (or excluded)
       and all array accesses have [curarray_suffix] as suffix of indices.
       [ok_arrays_second_branch] is similar for [p']. *)
  let r = eq_test [] p p' in
  if r <> RTrue then
    begin
      cur_branch_var_list := [];
      eq_oblig := [];
      eq_oblig_def_list := [];
      global_map := [];
      ok_arrays_first_branch := [];
      ok_arrays_second_branch := [];
      r
    end
  else
    begin
      let proba_state = Depanal.get_current_state() in
      try
	let r =
	  match
	    for_all_result (fun (pp,occ,t,occ',t') ->
	    (* Use the facts known in the first branch, at [t], to prove
	       the equality.
	       For this reason, we are careful to rename [t'] and leave
	       [t] unchanged, so that the facts [t] are valid in the comparison. *)
	      let (true_facts,_,_,_) = Facts.get_facts_at pp in
	    (* We use [Facts.simplif_add_list] first because [simplif_add_list]
	       sometimes loops otherwise. *)
	      let true_facts = Facts.simplif_add_list Facts.no_dependency_anal ([], [], []) true_facts in
	      let (subst, facts, elsefind) = true_facts in
	      let true_facts' = simplif_add_list (subst, [], []) facts in
	      if simp_equal_terms true_facts' t (rename (!global_map) t') then
		RTrue
	      else
		diff_message occ occ' "terms cannot be proved equal"
		  ) (!eq_oblig) with
	  | RTrue -> 
	      for_all_result (fun (pp,occ,dl,occ',dl') ->
	    (* Use the facts known in the first branch, at the find above
	       [dl], to prove the equality.
	       For this reason, we are careful to rename [t'] and leave
	       [t] unchanged, so that the facts [t] are valid in the comparison. *)
		let (true_facts,pps,def_vars,history) = Facts.get_facts_at pp in
	    (* We use [Facts.simplif_add_list] first because [simplif_add_list]
	       sometimes loops otherwise. *)
		let true_facts = Facts.simplif_add_list Facts.no_dependency_anal ([], [], []) true_facts in
		let (subst, facts, elsefind) = true_facts in
		let true_facts' = simplif_add_list (subst, [], []) facts in
		if simp_equal_def_list true_facts' pps def_vars history dl (rename_def_list (!global_map) dl') then
		  RTrue
		else
		  diff_message occ occ' "defined conditions differ in a branch of find"
		    ) (!eq_oblig_def_list)
	  | r -> r
	in
	if r <> RTrue then
	  Depanal.restore_state proba_state;
	all_branches_var_list := (!cur_branch_var_list) :: (!all_branches_var_list);
	cur_branch_var_list := [];
	eq_oblig := [];
	eq_oblig_def_list := [];
	global_map := [];
	ok_arrays_first_branch := [];
	ok_arrays_second_branch := [];
	r
      with Contradiction ->
	(* A contradiction is discovered when adding the facts in true_facts.
	   This means that the current program point is in fact not reachable.
           This may happen because the addition procedure is not exactly the same
           as that used in the rest of simplification, so it may discover some
           new information, but it should be extremely rare. For simplicity, 
	   we ignore the information that the current program point is unreachable. *)
	Depanal.restore_state proba_state;
	cur_branch_var_list := [];
	eq_oblig := [];
	eq_oblig_def_list := [];
	global_map := [];
	ok_arrays_first_branch := [];
	ok_arrays_second_branch := [];
	RFalse "program point unreachable"
    end

let terms = equal_store_arrays (collect_good_vars, equal_terms)
let processes = equal_store_arrays (collect_good_vars_oprocess, equal_oprocess)
let fullprocesses = equal_store_arrays (collect_good_vars_fullprocess, equal_process)

let group g =
  match g.result with
  | None ->
      let r = equal_store_arrays (collect_good_vars_group_side, equal_groups) g.curarray_suffix_opt g.left g.right in
      g.result <- Some r;
      r
  | Some r -> r
	
  end

open Equal
    
(* Transformation MergeArrays with merging of array references *)

let has_done_merge = ref false

(* Fct to compare processes or terms in MergeArrays *)
    
let equal eqtest p p' =
  allow_a_posteriori_array_ref_removal := false;
  assert (!merges_to_do == []);
  assert (!required_merges == []);  
  assert (!all_branches_var_list == []);
  assert (!var_no_array_ref == []);
  let r = (eqtest None p p' = RTrue) in
  (* When [allow_a_posteriori_array_ref_removal = false],
     [var_no_array_ref] and [all_branches_var_list] are not used. *)
  assert (!var_no_array_ref == []);
  assert (List.for_all (fun bl -> bl == []) (!all_branches_var_list));
  all_branches_var_list := [];
  Array_ref.cleanup_exclude_array_ref();
  r

(* We may use variables to distinguish the branches, and still merge
the arrays even if in some cases we need to know from which branch
they come *)

type new_branch_var_t =
    NoBranchVar
  | CreateBranchVar of binder list
  | CreateBranchVarAtProc of process list * binder list
  | CreateBranchVarAtTerm of term list * binder list

let rename_var (_, _, source_to_target_list, _) b =
  let rec ren = function
      [] -> b
    | (source_vars, target_var)::r ->
	if List.memq b source_vars then 
	  target_var
	else
	  ren r
  in
  ren source_to_target_list

let rec swap_rows_columns l =
  if List.hd l == [] then
    []
  else
    (List.map List.hd l)::(swap_rows_columns (List.map List.tl l))

let rec assq2 l1 l2 b =
  match (l1,l2) with
    [],[] -> raise Not_found
  | (b1::r1,b2::r2) ->
      if b1 == b then
	b2
      else
	assq2 r1 r2 b
  | _ -> Parsing_helper.internal_error "Lists should have same length in assq2"

let rec assq2l source_to_target_list l2 b =
  match source_to_target_list with
    [] -> raise Not_found 
  | (source_vars,_)::r ->
      try
	assq2 source_vars l2 b
      with Not_found ->
	assq2l r l2 b

let rec apply_list f max_dep_suffix_length source_to_target_list target_new_def target_sv_brl sv_brl v =
  match target_new_def with
    [] -> v
  | (target_b, target_l)::r ->
      let v' = apply_list f max_dep_suffix_length source_to_target_list r target_sv_brl sv_brl v in
      let source_vars = List.map fst source_to_target_list in
      let exclude_binders = List.find (fun bl -> List.memq target_b bl) source_vars in
      f (Terms.RenameIdxSuffix(Terms.lsuffix max_dep_suffix_length target_l, target_b, assq2 target_sv_brl sv_brl target_b, exclude_binders)) v'

let add_def_var_term rename_instr t b =
  match rename_instr with
    _, _, ((source_vars, target_var)::_), CreateBranchVar brl ->
      begin
	try
	  let b2 = assq2 source_vars brl b in
	  Terms.build_term t (LetE(PatVar b2, Stringmap.cst_for_type b2.btype, t, None))
	with Not_found -> 
	  t
      end
  | _ -> t

let add_def_var_proc rename_instr p b =
  match rename_instr with
    _, _, ((source_vars, target_var)::_), CreateBranchVar brl ->
      begin
	try
	  let b2 = assq2 source_vars brl b in
	  Terms.oproc_from_desc (Let(PatVar b2, Stringmap.cst_for_type b2.btype, p, Terms.oproc_from_desc Yield))
	with Not_found -> 
	  p
      end
  | _ -> p

let merge_find_branches proc_display proc_subst proc_rename proc_equal proc_merge proc_add_def_var merge_term pp 
    rename_instr l0 p3 find_info =
  let rec_merge_find_branch rename_instr (bl, def_list, t, p) =
    let bl' = List.map (fun (b,b') -> (rename_var rename_instr b, b')) bl in
    let def_list' = List.map (fun (b,l) -> (rename_var rename_instr b, 
					    List.map (merge_term rename_instr) l)) def_list in
    let p' = proc_merge rename_instr p in
    let t' = merge_term rename_instr t in
    (bl', def_list', t', List.fold_left (proc_add_def_var rename_instr) p' (List.map fst bl))
  in
  let (max_dep_suffix_length, already_merged, source_to_target_list, br_vars) = rename_instr in
  let already_defined = 
    match Incompatible.get_facts pp with
      Some ppi ->
        ppi.ppi_def_vars @ ppi.ppi_above_node.def_vars_at_def @ 
	(List.map Terms.binderref_from_binder
	   (Terms.add_def_vars_node [] ppi.ppi_above_node))
    | None -> Parsing_helper.internal_error "p_facts should have been defined"
  in
  let branches_to_merge = ref [] in
  let branches_to_leave_unchanged = ref [] in
  List.iter (function ((bl, def_list, t, p) as branch) ->
    let accu = ref [] in
    List.iter (Terms.close_def_subterm accu) def_list;
    let new_def_conditions = Terms.setminus_binderref (!accu) already_defined in
    let new_def_conditions_to_rename = List.filter (fun (b,l) -> 
      List.exists (fun (source_vars, _) -> 
	List.memq b source_vars) source_to_target_list
	&& not (List.exists (fun merge ->
	  List.exists (fun (bl, suffix_idx) ->
	    List.memq b bl && List.for_all2 Terms.equal_terms (Terms.lsuffix (List.length suffix_idx) l) suffix_idx
	      ) merge
	    ) already_merged)
	) new_def_conditions 
    in
    match new_def_conditions_to_rename with
      [] -> 
	(* The branch should be left as it is *)
	branches_to_leave_unchanged := branch :: (!branches_to_leave_unchanged)
    | x ->
        (* The branch should be merged with other branches of that find *)
	branches_to_merge := (x, branch) :: (!branches_to_merge)
					      ) l0;
  let l0' = 
    if (!branches_to_merge) == [] then 
      (* Ok, done, just rename as below *)
      List.map (rec_merge_find_branch rename_instr) l0
    else
      begin
	(*
	print_string "Branches to merge:\n";
	List.iter (function new_def,(bl, def_list, t, p) ->
	  print_string "new_def: ";
	  Display.display_def_list new_def;
	  print_string " find ";
	  Display.display_list (fun (b,b') -> 
	    Display.display_binder b; print_string " = "; Display.display_repl_index b') bl;
	  print_string " suchthat defined(";
	  Display.display_def_list def_list;
	  print_string ") && ";
	  Display.display_term t;
	  print_string " then\n";
	  proc_display p
	    ) (!branches_to_merge);
	*)
	try
	  let branches_to_merge = !branches_to_merge in
	  
	  (* choose one of branches_to_merge as target branch (the one that 
	     uses target_var as new_def_conditions_to_rename, if any; otherwise
	     just take one branch at random) *)
	  let (target_new_def, ((target_bl, target_def_list, target_t, target_p) as target_branch)) =
	    try
	      List.find (fun (new_def,_) -> 
		List.exists (fun (b,_) -> 
		  List.exists (fun (_, target_var) -> b == target_var) source_to_target_list
		    ) new_def) branches_to_merge
	    with Not_found ->
              List.hd branches_to_merge
          in
          (*
	    The candidate branches are obtained by renaming target_b[target_l] to
	    b[target_l] for each b in source_vars. We should check that the branches
	    of branches_to_merge are equivalent to those. If this is true, we
	    can replace them with target_branch after renaming all elements of
	    source_vars to target_var. 
	    
	    - Check that the new_def_conditions_to_rename of these
	    branches consist of (b,l) for b that belong to the same
	    "source_vars" branch in the same branch and to distinct
	    "source_vars" branches in distinct branches.  *)
	  let source_vars = List.map fst source_to_target_list in
	  let source_vars_by_branches = swap_rows_columns source_vars in
	  let (target_b0, target_l) = List.hd target_new_def in
	  let target_sv_brl =
	    List.find (fun bl -> List.memq target_b0 bl) source_vars_by_branches
	  in
	  let remaining_source_vars_by_branches = ref source_vars_by_branches in
	  let branches_to_merge =
	    List.map (fun (new_def, branch) ->
	      let (b0,_) = List.hd new_def in
	      let rec find_b0 seen = function
		  [] -> 
                    (* b0 not found: b0 belongs to a branch that was already found before,
		       so two branches use a variable that belongs to the same "source_vars" branch *) 
		    raise Failed
		| (sv_brl::r) ->
		    if List.memq b0 sv_brl then
		      begin
		        (* b0 found in sv_brl -> all other vars of new_def should also be
			   in sv_brl *)
			List.iter (fun (b,_) -> if not (List.memq b sv_brl) then raise Failed) new_def;
			remaining_source_vars_by_branches := List.rev_append seen r;
			sv_brl
		      end
		    else
		      find_b0 (sv_brl::seen) r
	      in
	      (find_b0 [] (!remaining_source_vars_by_branches), new_def, branch)
		) branches_to_merge
	  in
	  (* branches_to_merge_remain = branches_to_merge with the target branch removed *)
	  let branches_to_merge_remain = 
	    List.filter (function _,new_def,_ -> new_def != target_new_def) branches_to_merge 
	  in
          (*
	    - Check that the new_def_conditions_to_rename of the target branch
	    consists of (b,l) for the same l (modulo known equalities)
	    (checked for the other branches below)
	    *)
	  List.iter (fun (b,l) ->
	    if not (Terms.equal_lists (equal Equal.terms) l target_l) then
	      raise Failed
		) (List.tl target_new_def);

          (*
	    - If not all branches of source_vars appear as new_def_conditions_to_rename,
	    check that the remaining branches are not needed, i.e.
	    check that 
	         let def_list' be obtained by renaming target_b[target_l] to b[target_l] 
                 in the "def_list" of target_branch (use Terms.copy_binder (Terms.Rename(target_l, target_b, b)))
	         b[target_l] cannot be defined when def_list' is defined
	    where target_b[target_l] is an element of target_new_def and b is the variable
	    corresponding to target_b in the missing branch (i.e. b = assq2 target_sv_brl sv_brl target_b).
	    *)
	  let (true_facts,pps,def_vars,history) = Facts.get_facts_at pp in
	  let simp_facts = simplif_add_list ([],[],[]) true_facts in
          List.iter (fun sv_brl ->
            (* sv_brl is a missing branch *)
	    try
	      let def_list' = List.map (apply_list Terms.copy_binder max_dep_suffix_length source_to_target_list target_new_def target_sv_brl sv_brl) target_def_list in
	      let accu = ref [] in
	      List.iter (Terms.close_def_subterm accu) def_list';
	      let (facts, _, _) = Facts.facts_from_defined pps def_vars history def_list' in
	      let fact_accu = 
		List.fold_left (fun accu br -> 
		  List.fold_left (fun accu' (target_b,target_l) -> 
		    let b = assq2 target_sv_brl sv_brl target_b in 
		    Incompatible.both_def_add_fact accu' br (b,target_l)
		      ) accu target_new_def
		  ) facts (!accu)
	      in
	      let simp_facts' = simplif_add_list simp_facts fact_accu in
	      let t' = apply_list Terms.copy_term max_dep_suffix_length source_to_target_list target_new_def target_sv_brl sv_brl target_t in
	      let _ = simplif_add simp_facts' t' in
		(* The condition deflist' & t' does not imply a contradiction, I would need
		   a branch "deflist' & t' then ..." to be present in order to be able to 
		   merge the branches, so I raise Failed. *)
	      raise Failed
	    with
	    | Contradiction -> ()
	    | Terms.Bad_copy -> raise Failed
		) (!remaining_source_vars_by_branches);

         (*
	     - Check that all branches_to_merge are "equal" modulo known equalities, i.e.
	       for each element of branches_to_merge except the target branch, 
	       rename target_b[target_l] to b[target_l] in target_branch 
               (use Terms.copy_term/binder/oprocess (Terms.Rename(target_l, target_b, b)))
	       where target_b[target_l] is an element of target_new_def and b is the variable
	       corresponding to target_b in the current branch (i.e. b = assq2 target_sv_brl sv_brl target_b). 
	       Check that, for the obtained branch,
	         def_list of branch is defined iff def_list of renamed_target_branch is defined;
	   when they are defined, the condition and process are equal (modulo known equalities)

	   We are careful not to copy the branches_to_merge_remain,
	   because we use the facts at program points in these branches,
	   and they are deleted by copies.
	   *)
          List.iter (function sv_brl,new_def,(bl, def_list, t, p) ->
	    if List.exists has_array_ref (List.map fst bl) then 
	      raise Failed;
	    if List.length bl != List.length target_bl then
	      raise Failed;
	    try 
	      let new_def_list = List.map (apply_list Terms.copy_binder max_dep_suffix_length source_to_target_list target_new_def target_sv_brl sv_brl) target_def_list in
	      let new_t = apply_list Terms.copy_term max_dep_suffix_length source_to_target_list target_new_def target_sv_brl sv_brl target_t in
	      let target_new_def' = Terms.subst_def_list (List.map snd target_bl) (List.map (fun (b,_) -> Terms.term_from_binder b) target_bl) target_new_def in
	      let new_p = apply_list proc_rename max_dep_suffix_length source_to_target_list target_new_def' target_sv_brl sv_brl target_p in

	      (* rename the find indices in the target branch to the find
		 indices in the considered branch to merge *)
	      let subst_cond_source = List.map snd target_bl in
	      let subst_cond_dest = List.map (fun (_,b) -> Terms.term_from_repl_index b) bl in
	      let subst_proc = List.map2 (fun (b,_) (b',_) -> 
	    (* TO DO Instead of failing when the variables do not have
	       corresponding types, we could try to reorder them so that
	       they have matching types, or even to satisfy the
	       constraint that l = target_l below. However, it seems
	       difficult to guarantee that the right order will always be
	       found if there is one, since these criteria do not provide 
	       a unique order. *)
		if b.btype != b'.btype then raise Failed;
		(b, Terms.term_from_binder b')) target_bl bl in
	      
	      let target_l = List.map (Terms.subst subst_cond_source subst_cond_dest) target_l in
	      let new_def_list = Terms.subst_def_list subst_cond_source subst_cond_dest new_def_list in
	      let new_t = Terms.subst subst_cond_source subst_cond_dest new_t in
	      let new_p = proc_subst subst_proc new_p in

              (*
	         - Check that the new_def_conditions_to_rename of the branches to merge
		consist of (b,l) for the same l (modulo known equalities)
	      *)
	      List.iter (fun (b,l) ->
		if not (Terms.equal_lists (equal Equal.terms) l target_l) then
		  raise Failed
		  ) new_def;

	      if not (Equal.simp_equal_def_list simp_facts pps def_vars history def_list new_def_list) then
		raise Failed;
	      if not (equal Equal.terms t new_t) then
		raise Failed;
	      (* print_string "p = \n";
		 proc_display p;
		 print_string "new_p = \n";
		 proc_display new_p; *)
	      if not (equal proc_equal p new_p) then
		raise Failed
	    with Terms.Bad_copy -> raise Failed
	      ) branches_to_merge_remain;
	  
	  has_done_merge := true;
	  let l0' = target_branch :: (!branches_to_leave_unchanged) in
	  (* This transformation may reorder elements in the list of successful
	     branches and indices of find, hence we need to add eps_find. *)
	  let cur_array = 
	    match Incompatible.get_facts pp with
	      Some ppi -> ppi.ppi_cur_array
	    | None -> Parsing_helper.internal_error "p_facts should have been defined"
	  in
	  Proba.add_proba_find cur_array l0' find_info;
	  let done_merge =
	    List.map (fun (target_b,l) ->
	      (List.find (fun bl -> List.memq target_b bl) source_vars, l)
		) target_new_def
	  in
	  let already_merged' = done_merge :: already_merged in
	  let rename_instr' = (max_dep_suffix_length, already_merged', source_to_target_list, br_vars) in
	  let l0' =
	    (rec_merge_find_branch rename_instr' target_branch) ::
	    (List.map (rec_merge_find_branch rename_instr) (!branches_to_leave_unchanged))
	  in
	  l0'
	with Failed ->
	  match br_vars with
	    NoBranchVar -> raise Failed
	  | CreateBranchVar brl | CreateBranchVarAtProc(_,brl) | CreateBranchVarAtTerm(_,brl) ->
	      (* When the merging fails, we can still succeed by keeping each branch, 
		 adding a test defined(bi[l]) for each (b,l) in new_def_conditions_to_rename 
		 where bi is the variable of br_vars that corresponds to the element b of source_vars.
		 Then we rename the branch as other branches (bi will remain) *)
	      List.map (rec_merge_find_branch rename_instr) ((List.map (fun (new_def, (bl, def_list, t, p)) ->
		(bl, (List.map (fun (b,l) -> 
		  let b' = assq2l source_to_target_list brl b in 
		  (b', Terms.lsuffix (List.length b'.args_at_creation) l)) new_def) @ def_list, t, p)
		  ) (!branches_to_merge)) @ (!branches_to_leave_unchanged))
      end
  in
  let p3' = proc_merge rename_instr p3 in
  (l0',p3')
    
let rec merge_term rename_instr t =
  let t' = 
  match t.t_desc with
    (* call [add_def_var_term rename_instr ... b] when [b] is defined;
       rename variables by [rename_var rename_instr] *)
  | ResE(b,p) ->
      Terms.build_term t (ResE(rename_var rename_instr b, 
			       add_def_var_term rename_instr (merge_term rename_instr p) b))
  | GetE _ | InsertE _ ->
      Parsing_helper.internal_error "Get/Insert should not appear in Transf_merge.merge_term"
  | LetE(pat,t1,t2,topt) ->
      let pat' = merge_pat rename_instr pat in
      let t1' = merge_term rename_instr t1 in      
      let t2' = merge_term rename_instr t2 in
      let topt' = 
	match topt with
	  None -> None
	| Some t3 -> Some (merge_term rename_instr t3)
      in
      let pat_vars = Terms.vars_from_pat [] pat in
      Terms.build_term t (LetE(pat',t1', List.fold_left (add_def_var_term rename_instr) t2' pat_vars,topt'))
  | Var(b,l) ->
      Terms.build_term t (Var(rename_var rename_instr b,
                              List.map (merge_term rename_instr) l))
  (* case find is the main merge_arrays case *)
  | FindE(l0,t3, find_info) ->
      begin
	try
	  let (l0', t3') = merge_find_branches Display.display_term 
	      Terms.subst3 Terms.copy_term Equal.terms
	      merge_term add_def_var_term merge_term (DTerm t) rename_instr l0 t3 find_info
	  in
	  Terms.build_term t (FindE(l0',t3',find_info))
	with Contradiction ->
	  (* When there is a contradiction here, the Find is in fact unreachable *)
	  t3
      end
  | _ ->
      Terms.build_term t (Terms.map_subterm (merge_term rename_instr) (fun def_list -> assert false (*case find handled above*)) (merge_pat rename_instr) t)
  in
  let (_, _, _, br_vars) = rename_instr in
  match br_vars with
  | CreateBranchVarAtTerm(tl,bl) ->
      begin
	try
	  let b = assq2 tl bl t in
	  Terms.build_term t (LetE(PatVar b, Stringmap.cst_for_type b.btype, t', None))
	with Not_found ->
	  t'
      end
  | _ -> t'

   
and merge_pat rename_instr = function
  | PatVar b -> PatVar (rename_var rename_instr b)
  | pat -> Terms.map_subpat (merge_term rename_instr) (merge_pat rename_instr) pat

let rec merge_i rename_instr p =
  let p_desc' =
    Terms.map_subiproc (merge_i rename_instr)
      (fun o patl p ->
	let patl' = List.map (merge_pat rename_instr) patl in
	let p' = merge_o rename_instr p in
	let pat_vars = Terms.vars_from_pat_list [] patl in
	let p'' = List.fold_left (add_def_var_proc rename_instr) p' pat_vars in
	(o,patl',p'')) p
  in
  Terms.iproc_from_desc_loc p p_desc'

and merge_o rename_instr p =
  let p_desc' =
    match p.p_desc with
    (* call [add_def_var_proc rename_instr ... b] when [b] is defined;
       rename variables by [rename_var rename_instr] *)
    | Restr(b,p) ->
	Restr(rename_var rename_instr b, 
	      add_def_var_proc rename_instr (merge_o rename_instr p) b)
    | Let(pat,t,p1,p2) ->
	let pat' = merge_pat rename_instr pat in
	let t' = merge_term rename_instr t in      
	let p1' = merge_o rename_instr p1 in
	let p2' = merge_o rename_instr p2 in
	let pat_vars = Terms.vars_from_pat [] pat in
	Let(pat',t', List.fold_left (add_def_var_proc rename_instr) p1' pat_vars,p2')
    (* case find is the main merge_arrays case *)
    | Find(l0,p3,find_info) ->
	begin
	  try
	    let (l0', p3') = merge_find_branches (Display.display_oprocess "  ") 
		Terms.subst_oprocess3 Terms.copy_oprocess Equal.processes
		merge_o add_def_var_proc merge_term (DProcess p) rename_instr l0 p3 find_info
	    in
	    Find(l0',p3',find_info)
	  with Contradiction ->
	    (* When there is a contradiction here, the Find is in fact unreachable *)
	    Yield
	end
    | Get _ | Insert _ -> Parsing_helper.internal_error "Get/Insert should not appear here"
    | _ ->
	Terms.map_suboproc (merge_o rename_instr) (merge_term rename_instr)
	  (fun def_list -> assert false (*case find handled above*)) (merge_pat rename_instr)
	  (merge_i rename_instr) p
  in
  let p' = Terms.oproc_from_desc_loc p p_desc' in
  let (_, _, _, br_vars) = rename_instr in
  match br_vars with
    CreateBranchVarAtProc(pl,bl) ->
      begin
	try
	  let b = assq2 pl bl p in
	  Terms.oproc_from_desc (Let(PatVar b, Stringmap.cst_for_type b.btype, p', Terms.oproc_from_desc Yield))
	with Not_found ->
	  p'
      end
  | _ -> p'

let is_def_before (b1,_) (b,_) =
  match b.def with
    [n] -> List.memq b1 (Terms.add_def_vars_node [] n)
  | _ -> Parsing_helper.internal_error "Variable should have exactly one definition in Mergebranches.is_def_before"

let check_distinct_branch (b,ext) (b', ext') =
  try 
    Incompatible.incompatible_suffix_length_var_var b b'
  with Not_found -> 
    raise(Error("For merging arrays, variable " ^
		(Display.binder_to_string b) ^ 
		" should not be defined for the same indices as " ^ 
		(Display.binder_to_string b'), ext))

(*
merge_arrays merges arrays contained in bll. bll is a list of list of variables, say
bll = [[b11, ..., b1n],[b21, ..., b2n], ..., [bk1, ..., bkn]]
(Each list must contain the same number of variables; this MUST be checked before
calling merge_arrays.)

- each list [bi1,...,bin] corresponds to variables to merge together, they
are merged to bi1. Heuristic: the chances of success are probably higher if
bi1 comes from the "else" branch; indeed, the code of the various branches
is merged towards the code of the branch that contains bi1, and the code of 
the "else" branch is more generic because other branches can take advantage
of the tested conditions to use a different code.

- the variables bij for all i at the same position j in the various lists 
are expected to belong to the same branch. bij for i > 1 should preferably
be defined under the definition of b1j; this allows the algorithm to introduce
a new variable b'j defined when b1j is defined, and to use defined(b'j) to test
whether one is in branch j.

merge_arrays has several modes of operation, selected by the argument "mode":
- one in which br_vars are never introduced (MNoBranchVar)
- one in which br_vars may be introduced by the transformation at the point where
the first variable of each branch b1j is defined, if bij for i > 1 is 
defined under b1j (MCreateBranchVar)
- one in which br_vars are introduced at a program point specified in argument
(MCreateBranchVarAtProc / MCreateBranchVarAtTerm). The caller MUST make sure
bij for all i is defined under the j-th program point pj, and that these
program points cannot be executed for the same value of the replication indices.
So this mode can be used in advised instructions, but not for instructions
given by the user.

Note: if merge_arrays introduces new variables b'j to distinguish branches, and
later we could merge the branches that were still distinguished, we can
do that by calling merge_arrays again with argument the b'j.  
*)

let merge_arrays bll mode g =
  let g_proc = Terms.get_process g in
  whole_game := g;
  Array_ref.array_ref_process g_proc;
  Improved_def.improved_def_game None g;
  Depanal.reset [] g;
  allow_a_posteriori_array_ref_removal := false;
  advise_merge_arrays := false;
  sure_merges_to_do := false;
  branch1_name := "in the target branch";
  branch2_name := "in the other branch";
  has_done_merge := false;
  let cleanup() =
    Array_ref.cleanup_array_ref();
    Improved_def.empty_improved_def_game g;
    whole_game := Terms.empty_game
  in
  try 
    List.iter (fun bl ->
      match bl with
	[] -> Parsing_helper.internal_error "List of binder to merge should not be empty"
      | ((b1,ext1)::br) ->
	  List.iter (fun (b,ext) -> 
	    if b.btype != b1.btype then
	      raise(Error("For merging arrays, variable " ^
			  (Display.binder_to_string b) ^ 
			  " should have the same type as " ^
			  (Display.binder_to_string b1), ext));
	    if not (Terms.equal_lists (==) b.args_at_creation b1.args_at_creation) then
	      raise(Error("For merging arrays, variable " ^
			  (Display.binder_to_string b) ^ 
			  " should have the same indices as " ^
			  (Display.binder_to_string b1), ext))
		) br;
	  List.iter (fun (b, ext) -> 
	    if Settings.occurs_in_queries b (!whole_game).current_queries then
	      raise(Error("For merging arrays, variable " ^
			  (Display.binder_to_string b) ^ 
			  " should not occur in queries", ext));
	    if b.count_def > 1 then
	      raise(Error("For merging arrays, variable " ^
			  (Display.binder_to_string b) ^ 
			  " should have a single definition", ext));
	    if b.count_def = 0 then
	      raise(Error("Variable " ^ (Display.binder_to_string b) ^ 
			  " should be defined", ext))
		) bl;
	  ) bll;

    let bll_br = swap_rows_columns bll in
    let rec check_pairwise_distinct_branches = function
	[] -> 0
      | bl::r ->
	  max (check_pairwise_distinct_branches r)
	    (Incompatible.map_max (fun b -> 
	      Incompatible.map_max (Incompatible.map_max (check_distinct_branch b)) r
		) bl)
    in
    (* [max_dep_suffix_length] is the length of the suffix of [cur_array] on which
       the condition that determines which of the variables to merge is defined depends.
       When the suffix of length [max_dep_suffix_length] of [cur_array] has the same
       value, we are sure that the same variables to merge are defined.
       We exploit that information in the renaming of variables in function [apply_list]
       above, via [RenameIdxSuffix]. *)
    let max_dep_suffix_length = check_pairwise_distinct_branches bll_br in
    match bll with
      [] -> Parsing_helper.internal_error "List of list of binders to merge should not be empty"
    | bl1::blr ->
	let branch_vars =
	  match mode with
	    MNoBranchVar -> NoBranchVar
	  | MCreateBranchVar ->
	      if List.for_all (fun bl -> 
		List.for_all2 is_def_before bl1 bl
		  ) blr then
		CreateBranchVar (List.map (fun (b,_) -> Terms.new_binder b) bl1)
	      else
		NoBranchVar
	  | MCreateBranchVarAtProc(pl, cur_array) ->
	      CreateBranchVarAtProc(pl, List.map (fun (b,_) -> 
		Terms.create_binder "br" b.btype cur_array) bl1)
	  | MCreateBranchVarAtTerm(tl, cur_array) ->
	      CreateBranchVarAtTerm(tl, List.map (fun (b,_) -> 
		Terms.create_binder "br" b.btype cur_array) bl1)
	in
	let bll_no_ext = List.map (List.map fst) bll in
	let p' = merge_i (max_dep_suffix_length, [], List.map (fun bl -> bl, List.hd bl) bll_no_ext, branch_vars) g_proc in
	(* If the variables have array references only at defined conditions,
	   and no real merge has been done, the transformation is useless: 
	   I would just use different variables to distinguish the branches. 
	   So in this case, I cancel the transformation.
	   Still allow merging when there are no array references at all.
	   That's a fairly trivial case. *)
	if (!has_done_merge) ||
	(List.exists (fun bl ->
	  List.exists (fun (b,_) -> b.array_ref) bl
	    ) bll) ||
	not (List.exists (fun bl ->
	  List.exists (fun (b,_) -> Array_ref.has_array_ref b) bl
	    ) bll)then
	  begin
	    Settings.changed := true;
	    (* Display.display_process p'; *)
	    let proba = Depanal.final_add_proba () in
	    cleanup();
	    (Terms.build_transformed_game p' g, proba, [DMergeArrays(bll,mode)])
	  end
	else
	  begin
	    cleanup();
	    Depanal.final_empty_state();
	    (g, [], [])
	  end
  with 
  | Failed ->
      cleanup();
      Depanal.final_empty_state();
      (g, [], [])
  | Error(mess,ext) ->
      cleanup();
      Depanal.final_empty_state();
      if mode = MNoBranchVar then
	(* When the transformation merge_arrays is advised, its mode is [MNoBranchVar].
	   In this case, we do not want to fail with an error, because that would stop
	   the whole proof. *)
	begin
	  Parsing_helper.display_error mess ext;
	  (g, [], [])
	end
      else
	raise (Error(mess,ext))
      
(* Merge as many branches of if/let/find as possible.
   Simplify already does a bit of this, but this function is more powerful
1st step: store the merges that may be done if array accesses are removed
2nd step: iterate, removing merges that cannot be done because the desired
array accesses cannot be removed
3rd step: 
   if some merges can be done, do them
   if some merges can be done and some have been excluded, iterate
   if no merges can be done, advise MergeBranches for the excluded merges.
 *)

let create_merge merge cur_array =
  { m_merge = merge;
    m_cur_array = cur_array;
    m_all_branches_var_list = !all_branches_var_list;
    m_var_no_array_ref = !var_no_array_ref;
    m_required_merges = !required_merges;
    m_remove_array_ref = List.map (fun b -> (b, b.count_exclude_array_ref)) (!Array_ref.all_vars_exclude);
    m_feasible = true }
      
let merges_cannot_be_done = ref ([] : merge_tt list)

(* f is a function that compares processes; if in different branches 
   of these processes with have two variables (b,b') with arrays accesses,
   it stores (b,b') in cur_branch_var_list.
   If f returns false, the comparison failed. 
   If diff_var_list is not empty, the comparison also failed, but we advise
   merging of arrays so that cur_branch_var_list becomes empty on the next try.
*)

(* Exception CannotFormAdvice is raised when the variable pairs
   stored in cur_branch_var_list do not have the same variables
   in the same order in the second component (corresponding to the "else" branch)
   in all branches that we want to merge. This means that the merging
   we should do is not the same for all branches. This is not handled
   by MergeArrays, so we simply give up and do not give advice. *)

exception CannotFormAdvice

let rec form_advise all_branches =
  let first_branch = List.hd all_branches in
  List.iter (fun bl ->
    if List.length bl != List.length first_branch then
      raise CannotFormAdvice
      (*Parsing_helper.internal_error "All branches should have the same number of variables to merge"*)) all_branches;
  match first_branch with
    [] -> []
  | (_,b0)::_ ->
      let first_vars = List.map List.hd all_branches in
      List.iter (fun (_,b0') ->
	if b0 != b0' then
	  raise CannotFormAdvice
	  (*Parsing_helper.internal_error "The variables should be in the same order in all branches"*)) first_vars;
      let first_elem = (b0, Parsing_helper.dummy_ext) :: 
	(List.map (fun (b,_) -> (b, Parsing_helper.dummy_ext)) first_vars) 
      in
      first_elem :: (form_advise (List.map List.tl all_branches))
  
let add_advice merge = 
  (* If I want to give an explicit location for variable creations, 
     I can give only one "MergeArrays" instruction, because after the first one,
     the location will no longer be up-to-date, and I should run it directly
     without giving it as advice, because if I give it as advice, I am not
     sure that it will be immediately executed, so the location may not be
     up-to-date when I execute it.

  let var_loc = 
    match merge.m_merge with
      MergeTerm(_, tl) -> MCreateBranchVarAtTerm(tl, merge.m_cur_array)
    | MergeProcess(_,pl) -> MCreateBranchVarAtProc(pl, merge.m_cur_array)
  in

     Furthermore, the advice is not always good! (r_362,r_404 in EKE)
     (when I advise MergeArrays in mode MCreateBranchVar).

     To avoid the risk of giving bad advice, I choose to advise
     MergeArrays in mode "MNoBranchVar", so that MergeArrays succeeds perhaps
     less often, but when MergeArrays succeeds, it has really simplified the game.
  *)
  if not (List.for_all (fun l -> l == []) merge.m_all_branches_var_list) then
    try
      Settings.advise := Terms.add_eq (MergeArrays(List.rev (form_advise merge.m_all_branches_var_list), MNoBranchVar)) (!Settings.advise)
    with CannotFormAdvice -> 
      ()


(* First step *) 

let no_array_ref occ b =
  if !allow_a_posteriori_array_ref_removal then
    begin
      var_no_array_ref := b :: (!var_no_array_ref);
      RTrue
    end
  else if has_array_ref b then
    RFalse ("At "^string_of_int occ^", variable "^Display.binder_to_string b^" has an array access.\n")
  else
    RTrue
      
(* [ok_cond t] checks that [t] does not execute events, abort, or
   define a variable that has an array access

   [ok_cond_pat pat] is similar for patterns. *)
let rec ok_cond t =
  match t.t_desc with
  | EventAbortE _ | EventE _ -> RFalse ("At "^string_of_int t.t_occ^", term is an event.\n")
  | GetE _ | InsertE _ -> assert false
  | Var(_,l) | FunApp(_,l) -> for_all_result ok_cond l
  | ReplIndex _ -> RTrue
  | ResE(b,t1) ->
      begin
	match no_array_ref t.t_occ b with
	| RTrue -> ok_cond t1
	| r -> r
      end
  | TestE(t1,t2,t3) ->
      begin
	match ok_cond t1 with
	| RTrue ->
	    begin
	      match ok_cond t2 with
	      | RTrue -> ok_cond t3
	      | r -> r
	    end
	| r -> r
      end
  | LetE(pat, t1, t2, topt) ->
      begin
	match ok_cond_pat t.t_occ pat with
	| RTrue ->
	    begin
	      match ok_cond t1 with
	      | RTrue ->
		  begin
		    match ok_cond t2 with
		    | RTrue ->
			begin
			  match topt with
			  | None -> RTrue
			  | Some t3 -> ok_cond t3
			end
		    | r -> r
		  end
	      | r -> r
	    end
	| r -> r
      end
  | FindE(l0,t3,find_info) ->
      (* find[unique] may abort. It is a problem only when [unique]
	 is still prove, because when [unique] has been proved,
	 the traces in which the find[unique] aborts are already excluded. *)
      begin
	match Terms.is_unique (Some (!whole_game)) l0 find_info with
	| UniqueToProve _ -> RFalse ("At "^string_of_int t.t_occ^", find may abort.\n")
	| _ -> 
	    match ok_cond t3 with
	    | RTrue -> 
		for_all_result (fun (bl, def_list, t1, t2) ->
		  match for_all_result (fun (b,_) -> no_array_ref t.t_occ b) bl with
		  | RTrue ->
	(* a condition of find cannot contain events and
	   its defined variables cannot have array accesses *)
		      if Terms.may_abort_counted (Some (!whole_game)) t1 then
			RFalse ("At "^string_of_int t1.t_occ^", condition of find may abort.\n")
		      else
			ok_cond t2
		  | r -> r
			) l0
	    | r -> r
      end
	
and ok_cond_pat occ = function
  | PatVar b -> no_array_ref occ b
  | PatTuple(_,l) -> for_all_result (ok_cond_pat occ) l
  | PatEqual t -> ok_cond t
	
let get_curarray_suffix cur_array curarray_suffix i =
  if List.memq i (!curarray_suffix) then () else
  let rec suffix_rec = function
      [] -> Parsing_helper.internal_error "Replication index not found in curarray"
    | (i'::l) as l' -> if i == i' then l' else suffix_rec l
  in
  curarray_suffix := suffix_rec cur_array

let rec get_curarray_suffix_t cur_array curarray_suffix t =
  match t.t_desc with
  | ReplIndex i -> get_curarray_suffix cur_array curarray_suffix i
  | FindE _ -> curarray_suffix := cur_array (* For simplicity *)
  | _ ->
      Terms.iter_subterm
	(get_curarray_suffix_t cur_array curarray_suffix)
	(fun def_list -> ())
	(get_curarray_suffix_pat cur_array curarray_suffix) t

and get_curarray_suffix_pat cur_array curarray_suffix pat =
  Terms.iter_subpat
    (get_curarray_suffix_t cur_array curarray_suffix)
    (get_curarray_suffix_pat cur_array curarray_suffix) pat

let get_curarray_suffix_term cur_array t =
  let curarray_suffix = ref [] in
  get_curarray_suffix_t cur_array curarray_suffix t;
  Some (!curarray_suffix)

let get_curarray_suffix_pat_term cur_array pat t = 
  let curarray_suffix = ref [] in
  get_curarray_suffix_pat cur_array curarray_suffix pat;
  get_curarray_suffix_t cur_array curarray_suffix t;
  Some (!curarray_suffix)
  
(* [get_in_scope fact_info] returns the list of variables currently
   in scope at [fact_info]. *)

let get_in_scope fact_info =
  match fact_info with
    Some ppi -> Terms.add_def_vars_node [] ppi.ppi_above_node
  | None -> Parsing_helper.internal_error "facts should have been set"

let can_merge_all_branches_store_arrays exclude_array_ref eqtest curarray occ above_p_facts l0 p3 =
  if exclude_array_ref then
    begin
      let in_scope = get_in_scope above_p_facts in
      List.iter (fun (bl, def_list, t1, p2) ->
	Array_ref.exclude_array_ref_def_list in_scope def_list;
	Array_ref.exclude_array_ref_term in_scope t1) l0
    end;
  let proba_state = Depanal.get_current_state() in
  let r = 
    for_all_result (fun (bl, def_list, t1, p2) ->
      match for_all_result (fun (b,_) -> no_array_ref occ b) bl with
      | RTrue ->
	  if Terms.may_abort_counted (Some (!whole_game)) t1 then
	    RFalse ("At "^string_of_int t1.t_occ^", condition of find may abort.\n")
	  else
	    (eqtest (Some curarray) p2 p3)
      | r -> r) l0
  in
  if r <> RTrue then
    Depanal.restore_state proba_state;
  r

let can_merge_one_branch_store_arrays exclude_array_ref eqtest curarray occ above_p_facts (bl, def_list, t1, p2) p3 =
  if exclude_array_ref then
    begin
      let in_scope = get_in_scope above_p_facts in
      Array_ref.exclude_array_ref_def_list in_scope def_list;
      Array_ref.exclude_array_ref_term in_scope t1
    end;
  match for_all_result (fun (b,_) -> no_array_ref occ b) bl with
  | RTrue -> eqtest (Some curarray) p2 p3
  | r -> r

let add_if_defined_term t telse def_list tthen = 
  Terms.build_term_at t (FindE([([], def_list, Terms.make_true(), tthen)], telse, Nothing))

let add_if_defined_proc p pelse def_list pthen =
  Terms.oproc_from_desc_at p (Find([([], def_list, Terms.make_true(), pthen)], pelse, Nothing))

let add_if_defined_if_needed (add_if_defined, get_needed_deflist) target_branch =
  let (bl, def_list, t1, target_merge) = target_branch in
  if def_list == [] then
    target_merge
  else
    (* Add defined conditions if they are needed for the syntactic invariant
       that guarantees that variables are always defined.
       These defined conditions are always true, because the else
       branch is never taken and all other branches are equal to [target_merge]. *)
    let needed_deflist = ref [] in
    get_needed_deflist [] needed_deflist target_merge;
    (* Compute the subterms of [needed_deflist] *)
    let needed_deflist_subterm = ref [] in
    List.iter (Terms.close_def_subterm needed_deflist_subterm) (!needed_deflist);
    (* Compute the subterms of [deflist] *)
    let deflist_subterm = ref [] in
    List.iter (Terms.close_def_subterm deflist_subterm) def_list;
    let deflist_subterm' = Terms.inter_binderref (!deflist_subterm) (!needed_deflist_subterm) in
    let def_list' = Facts.remove_subterms [] deflist_subterm' in
    if def_list' == [] then
      target_merge
    else
      add_if_defined def_list' target_merge

let is_unreachable pp =
  try
    let (true_facts,_,def_vars,_) = Facts.get_facts_at pp in
    let simp_facts = Facts.simplif_add_list Facts.no_dependency_anal ([], [], []) true_facts in
    let _ = Facts.convert_elsefind Facts.no_dependency_anal def_vars simp_facts in
    false
  with Contradiction ->
    true

(* [start_reset] and [reset] keep the excluded array references local
   to each attempted merge. This is what we want for the automatic
   merge_branches, but not for the manually guided one, which
   determines the excluded array references globally. Hence, the latter
   uses [Equal.start_reset] and [Equal.reset]. *)
      
let start_reset() =
  assert (!Array_ref.all_vars_exclude == []);
  Equal.start_reset()
      
let reset() =
  Array_ref.cleanup_exclude_array_ref();
  Equal.reset()

let rec collect_merges_term cur_array t =
  match t.t_desc with
  | GetE _ | InsertE _ -> 
      Parsing_helper.internal_error "Get/Insert should not appear in Transf_merge.collect_merges_term"
  | TestE(t1,t2,t3) ->
      collect_merges_term cur_array t2;
      collect_merges_term cur_array t3;
      begin
	start_reset();
	let in_scope = get_in_scope t.t_facts in
	Array_ref.exclude_array_ref_term in_scope t1;
	let r =
	  (ok_cond t1 = RTrue) &&
	  (Equal.terms (get_curarray_suffix_term cur_array t1) t2 t3 = RTrue)
	in
	if r then
	  merges_to_do := (create_merge (MergeTerm(t, [t3;t2])) cur_array) :: (!merges_to_do);
	reset();
	  (* collect merges in the condition [t1] only when the whole
	     [if t1 then t2 else t3] cannot be merged, to make sure
	     that we do not count several times the same array references
	     to exclude (in [t1] as a whole and in a merged subterm of [t1]) *)
	if not r then
	  collect_merges_term cur_array t1
      end
  | LetE(pat,t1,t2,Some t3) ->
      collect_merges_term cur_array t2;
      collect_merges_term cur_array t3;
      begin
	start_reset();
	let in_scope = get_in_scope t.t_facts in
	Array_ref.exclude_array_ref_pattern in_scope pat;
	Array_ref.exclude_array_ref_term in_scope t1;
	let curarray_suffix = get_curarray_suffix_pat_term cur_array pat t in
	let r =
	  (ok_cond_pat t.t_occ pat = RTrue) && (ok_cond t1 = RTrue) &&
	  (Equal.terms curarray_suffix t2 t3 = RTrue)
	in
	if r then
	  merges_to_do := (create_merge (MergeTerm(t, [t3;t2])) cur_array) :: (!merges_to_do);
	reset();
	  (* collect merges in [pat = t1] only when the whole
	     [let pat = t1 in t2 else t3] cannot be merged, to make sure
	     that we do not count several times the same array references
	     to exclude (in [pat = t1] as a whole and in a merged subterm of
	     [pat] or [t1]) *)
	if not r then
	  begin
	    collect_merges_pat cur_array pat;
	    collect_merges_term cur_array t1
	  end	      
      end
  | FindE(l0,t3,find_info) -> 
      collect_merges_term cur_array t3;
      List.iter (fun (_,_,_,t2) -> collect_merges_term cur_array t2) l0;
      begin
	let proba_state = Depanal.get_current_state() in
	let merge_else_unreachable =
	    (* When the "else" branch of the "find" is unreachable, all "then"
	       branches execute equivalent code, and at least one "then" branch does
	       not use indices defined in the "find", then we merge
	       the branches of "find" into that branch. *)
	  if Terms.is_not_unique_to_prove find_info &&
	      (* When the find has a single then branch, it is not really a merge,
		 and simplify does the job anyway *)
	    List.length l0 > 1 &&
	    not (List.exists (fun (_, _, t1, _) ->
	      Terms.may_abort_counted (Some (!whole_game)) t1) l0) &&
	      (* When the else branch has been found unreachable,
		 it is replaced with a constant
		 TODO I should update this code if I change the replacement for unreachable code. *)
	    match t3.t_desc with
	    | FunApp(_,[]) -> true
	    | _ -> false
	  then
	    try
	      (* The indices in the target branch must not be used *)
	      let (known_else_unreachable, target_branch) =
		try
		  (* In priority, take a branch that always succeeds.
		     If we find one, we know that the else branch is unreachable.
		     TODO we could be more precise in determining that a branch always succeeds,
		     but that would be more costly. *)
		  (true, List.find (function
		    | ([], [], t, _) -> Terms.is_true t
		    | _ -> false) l0)
		with Not_found ->
		  (false, List.find (fun (bl, def_list, t1,t2) ->
		    List.for_all (fun (b,_) ->
		      not (has_array_ref b) && not (Terms.refers_to b t2)) bl
		      ) l0)
	      in
	      (* check that the else branch is actually unreachable;
		 costly, so I try to test other things first *)
	      (known_else_unreachable || is_unreachable (DTerm t3)) &&
	      (let (_,_,_,target_merge) = target_branch in
	      let other_branches = List.filter (fun br -> br != target_branch) l0 in
	      (* Check that all branches execute the same code as the target branch *)
	      start_reset();
	      let r = (can_merge_all_branches_store_arrays true Equal.terms cur_array t.t_occ t.t_facts other_branches target_merge = RTrue) in
	      if r then
		begin
		  let merge_result =
		    add_if_defined_if_needed (add_if_defined_term t t3, Terms.get_needed_deflist_term) target_branch
		  in
		  merges_to_do :=
		     (create_merge (MergeTerm(t, merge_result :: t3 :: List.map (fun (_,_,_,t2) -> t2) other_branches)) cur_array)
		     :: (!merges_to_do);
		end;
	      reset();
	      r)
	    with Not_found ->
	      false
	  else
	    false
	in
	if not merge_else_unreachable then
	  begin
	    Depanal.restore_state proba_state;
	    if Terms.is_unique_no_abort (Some(!whole_game)) l0 find_info then
	      List.iter (fun ((bl, def_list, t1, t2) as br) ->
		start_reset();
		let r = (can_merge_one_branch_store_arrays true Equal.terms cur_array t.t_occ t.t_facts br t3 = RTrue) in
		if r then
		  merges_to_do :=
		     (create_merge (MergeTerm(t, [t3;t2])) cur_array)
		     :: (!merges_to_do);
		reset();
	        (* collect merges in [t1] only when the whole [find]
		   cannot be merged, to make sure that we do not count
		   several times the same array references to exclude
		   (in [t1] as a whole and in a merged subterm of [t1]) *)
		if not r then
		  collect_merges_term ((List.map snd bl) @ cur_array) t1
		    ) l0
	    else if Terms.is_not_unique_to_prove find_info then
	      begin
		start_reset();
		let r = (can_merge_all_branches_store_arrays true Equal.terms cur_array t.t_occ t.t_facts l0 t3 = RTrue) in
		if r then
		  merges_to_do :=
		     (create_merge (MergeTerm(t, t3 :: List.map (fun (_,_,_,t2) -> t2) l0)) cur_array)
		     :: (!merges_to_do);
		reset();
	        (* collect merges in [t1] only when the whole [find]
		   cannot be merged, to make sure that we do not count
		   several times the same array references to exclude
		   (in [t1] as a whole and in a merged subterm of [t1]) *)
		if not r then
		  List.iter (fun (bl,_,t1,_) -> collect_merges_term ((List.map snd bl) @ cur_array) t1) l0
	      end
	  end
      end
  | _ -> 
      Terms.iter_subterm
	(collect_merges_term cur_array)
	(fun def_list -> ())
	(collect_merges_pat cur_array) t

and collect_merges_pat cur_array pat =
  Terms.iter_subpat
    (collect_merges_term cur_array)
    (collect_merges_pat cur_array) pat
    
let rec collect_merges_i cur_array p =
  match p.i_desc with
    Nil -> ()
  | Par(p1,p2) ->
      collect_merges_i cur_array p1;
      collect_merges_i cur_array p2
  | Repl(b,p) ->
      collect_merges_i (b::cur_array) p
  | OracleDecl(_,patl, p) ->
      List.iter (collect_merges_pat cur_array) patl;
      collect_merges_o cur_array p
    
and collect_merges_o cur_array p =
  match p.p_desc with
  | Test(t,p1,p2) ->
      collect_merges_o cur_array p1;
      collect_merges_o cur_array p2;
      begin
	start_reset();
	let in_scope = get_in_scope p.p_facts in
	Array_ref.exclude_array_ref_term in_scope t;
	let r = (ok_cond t = RTrue) &&
	  (Equal.processes (get_curarray_suffix_term cur_array t) p1 p2 = RTrue)
	in
	if r then
	  merges_to_do := (create_merge (MergeProcess(p, [p2;p1])) cur_array) :: (!merges_to_do);
	reset();
	  (* collect merges in the condition [t] only when the whole
	     [if t then p1 else p2] cannot be merged, to make sure
	     that we do not count several times the same array references
	     to exclude (in [t] as a whole and in a merged subterm of [t]) *)
	if not r then
	  collect_merges_term cur_array t
      end
  | Let(pat,t,p1,p2) ->
      collect_merges_o cur_array p1;
      collect_merges_o cur_array p2;
      begin
	start_reset();
	let in_scope = get_in_scope p.p_facts in
	Array_ref.exclude_array_ref_pattern in_scope pat;
	Array_ref.exclude_array_ref_term in_scope t;
	let curarray_suffix = get_curarray_suffix_pat_term cur_array pat t in
	let r = (ok_cond_pat p.p_occ pat = RTrue) && (ok_cond t = RTrue) &&
	  (Equal.processes curarray_suffix p1 p2 = RTrue)
	in
	if r then
	  merges_to_do := (create_merge (MergeProcess(p, [p2;p1])) cur_array) :: (!merges_to_do);
	reset();
	  (* collect merges in [pat = t] only when the whole
	     [let pat = t in p1 else p2] cannot be merged, to make sure
	     that we do not count several times the same array references
	     to exclude (in [pat = t] as a whole and in a merged subterm of
	     [pat] or [t]) *)
	if not r then
	  begin
	    collect_merges_pat cur_array pat;
	    collect_merges_term cur_array t
	  end
      end
  | Find(l0,p3,find_info) ->
      collect_merges_o cur_array p3;
      List.iter (fun (_,_,_,p2) -> collect_merges_o cur_array p2) l0;
      begin
	let proba_state = Depanal.get_current_state() in
	let merge_else_unreachable =
	(* When the "else" branch of the "find" is unreachable, all "then"
	   branches execute equivalent code, and at least one "then" branch does
	   not use indices defined in the "find", then we merge
	   the branches of "find" into that branch. *)
	  if Terms.is_not_unique_to_prove find_info &&
	    (* When the find has a single then branch, it is not really a merge,
	       and simplify does the job anyway *)
	    List.length l0 > 1 &&
	    not (List.exists (fun (_, _, t1, _) ->
	      Terms.may_abort_counted (Some (!whole_game)) t1) l0) &&
	      (* When the else branch has been found unreachable,
		 it is replaced with Yield
		 TODO I should update this code if I change the replacement for unreachable code. *)
	    match p3.p_desc with
	    | Yield -> true
	    | _ -> false
	  then
	    try
	      (* The indices in the target branch must not be used *)
	      let (known_else_unreachable, target_branch) =
		try
		  (* In priority, take a branch that always succeeds.
		     If we find one, we know that the else branch is unreachable.
		     TODO we could be more precise in determining that a branch always succeeds,
		     but that would be more costly. *)
		  (true, List.find (function
		    | ([], [], t, _) -> Terms.is_true t
		    | _ -> false) l0)
		with Not_found ->
		  (false, List.find (fun (bl, def_list, t1,p2) ->
		    List.for_all (fun (b,_) ->
		      not (has_array_ref b) && not (Terms.refers_to_oprocess b p2)) bl
		      ) l0)
	      in
	      (* check that the else branch is actually unreachable;
		 costly, so I try to test other things first *)
	      (known_else_unreachable || is_unreachable (DProcess p3)) &&
	      (let (_,_,_,target_merge) = target_branch in
	      let other_branches = List.filter (fun br -> br != target_branch) l0 in
	      (* Check that all branches execute the same code as the target branch *)
	      start_reset();
	      let r = (can_merge_all_branches_store_arrays true Equal.processes cur_array p.p_occ p.p_facts other_branches target_merge = RTrue) in
	      if r then
		begin
		  let merge_result =
		    add_if_defined_if_needed (add_if_defined_proc p p3, Terms.get_needed_deflist_oprocess) target_branch
		  in
		  merges_to_do :=
		     (create_merge (MergeProcess(p, merge_result :: p3 :: List.map (fun (_,_,_,p2) -> p2) other_branches)) cur_array)
		     :: (!merges_to_do);
		end;
	      reset();
	      r)
	    with Not_found ->
	      false
	  else
	    false
	in
	if not merge_else_unreachable then
	  begin
	    Depanal.restore_state proba_state;
	    if Terms.is_unique_no_abort (Some(!whole_game)) l0 find_info then
	      List.iter (fun ((bl, def_list, t1, p2) as br) ->
		start_reset();
		let r = (can_merge_one_branch_store_arrays true Equal.processes cur_array p.p_occ p.p_facts br p3 = RTrue) in
		if r then
		  merges_to_do :=
		     (create_merge (MergeProcess(p, [p3;p2])) cur_array)
		     :: (!merges_to_do);
		reset();
	        (* collect merges in [t1] only when the whole [find]
		   cannot be merged, to make sure that we do not count
		   several times the same array references to exclude
		   (in [t1] as a whole and in a merged subterm of [t1]) *)
		if not r then
		  collect_merges_term ((List.map snd bl) @ cur_array) t1
		    ) l0
	    else if Terms.is_not_unique_to_prove find_info then
	      begin
		start_reset();
		let r = (can_merge_all_branches_store_arrays true Equal.processes cur_array p.p_occ p.p_facts l0 p3 = RTrue) in
		if r then
		  merges_to_do :=
		     (create_merge (MergeProcess(p, p3 :: List.map (fun (_,_,_,p2) -> p2) l0)) cur_array)
		     :: (!merges_to_do);
		reset();
	        (* collect merges in [t1] only when the whole [find]
		   cannot be merged, to make sure that we do not count
		   several times the same array references to exclude
		   (in [t1] as a whole and in a merged subterm of [t1]) *)
		if not r then
		  List.iter (fun (bl,_,t1,_) -> collect_merges_term ((List.map snd bl) @ cur_array) t1) l0
	      end
	  end
      end
  | Get _ |Insert _ -> Parsing_helper.internal_error "Get/Insert should not appear here"
  | _ ->
      Terms.iter_suboproc
	(collect_merges_o cur_array)
	(collect_merges_term cur_array)
	(fun def_list -> ())
	(collect_merges_pat cur_array)
	(collect_merges_i cur_array)
	p
	
(* Second step *)

let rec remove_impossible_merges() =
  assert (!Array_ref.all_vars_exclude = []);
  List.iter (fun merge ->
    List.iter (fun (b,n) -> 
      b.count_exclude_array_ref <- b.count_exclude_array_ref + n;
      Array_ref.all_vars_exclude := b :: (!Array_ref.all_vars_exclude)
				       ) merge.m_remove_array_ref
      ) (!merges_to_do);
  let need_to_iterate = ref false in
  merges_to_do := List.filter (fun merge ->
    let r =
      List.exists has_array_ref merge.m_var_no_array_ref ||
      List.exists (fun m -> not m.m_feasible) merge.m_required_merges
    in
    if r then
      begin
	need_to_iterate := true;
	merge.m_feasible <- false;
	merges_cannot_be_done := merge :: (!merges_cannot_be_done)
      end;
    not r) (!merges_to_do);
  Array_ref.cleanup_exclude_array_ref();
  if !need_to_iterate then
    remove_impossible_merges()

(* Third step *)

let rec do_merges_term t =
  let default() =
    Terms.build_term t
      (Terms.map_subterm do_merges_term (fun def_list -> def_list) do_merges_pat t)
  in
  match t.t_desc with
  | TestE(t1,t2,t3) ->
      if List.exists (function
	  { m_merge = MergeTerm(t',_) } -> t' == t
	| _ -> false) (!merges_to_do)
      then
	(* Merge the test *)
	do_merges_term t3
      else
	default()
  | LetE(pat,t1,t2,Some t3) ->
      if List.exists (function
	  { m_merge = MergeTerm(t',_) } -> t' == t
	| _ -> false) (!merges_to_do)
      then
	(* Merge the let *)
	do_merges_term t3
      else
	default()
  | FindE(l0,t3, find_info) ->
      begin
      try
	let merge = List.find (function
	  { m_merge = MergeTerm(t',l) } -> (t' == t) && (List.length l0 + 1 = List.length l)
	  | _ -> false) (!merges_to_do)
	in
	(* Merge all branches of the find *)
	match merge.m_merge with
	| MergeTerm(_,merge_result :: _) -> do_merges_term merge_result
	| _ -> assert false
      with Not_found ->
	let t3' = do_merges_term t3 in
	(* May merge some branches of the find
	   l0' = list with the merged branches removed *)
	let l0' = List.filter (fun (_,_,_,t2) ->
	  not (List.exists (function
	      { m_merge = MergeTerm(t',[t3';t2']) } -> (t' == t) && (t3' == t3) && (t2' == t2)
	    | _ -> false) (!merges_to_do))) l0
	in
	if l0' == [] then
	  t3'
	else
	  let l0'' = List.map (fun (bl, def_list, t1, t2) ->
	    (bl, def_list, do_merges_term t1, do_merges_term t2)) l0' in
	  Terms.build_term t (FindE(l0'',t3',find_info))
      end
  | GetE _ | InsertE _ -> 
      Parsing_helper.internal_error "Get/Insert should not appear in Transf_merge.do_merges_term"
  | _ -> default()

and do_merges_pat pat =
  Terms.map_subpat do_merges_term do_merges_pat pat
	
let rec do_merges_i p =
  Terms.iproc_from_desc_loc p
    (Terms.map_subiproc do_merges_i
       (fun o patl p -> (o, patl, do_merges_o p)) p)

and do_merges_o p =
  let default() =
    Terms.oproc_from_desc_loc p
      (Terms.map_suboproc
	 do_merges_o do_merges_term (fun def_list -> def_list)
	 do_merges_pat do_merges_i p)
  in
  match p.p_desc with
  | Test(t,p1,p2) ->
      if List.exists (function
	  { m_merge = MergeProcess(p',_) } -> p' == p
	| _ -> false) (!merges_to_do)
      then
	(* Merge the test *)
	do_merges_o p2
      else
	default()
  | Let(pat,t,p1,p2) ->
      if List.exists (function
	  { m_merge = MergeProcess(p',_) } -> p' == p
	| _ -> false) (!merges_to_do)
      then
	(* Merge the let *)
	do_merges_o p2
      else
	default()
  | Find(l0,p3,find_info) ->
      begin
      try
	let merge = List.find (function
	    { m_merge = MergeProcess(p',l) } -> (p' == p) && (List.length l0 + 1 = List.length l)
	  | _ -> false) (!merges_to_do)
	in
	(* Merge all branches of the find *)
	match merge.m_merge with
	| MergeProcess(_,merge_result :: _) -> do_merges_o merge_result
	| _ -> assert false
      with Not_found ->
	let p3' = do_merges_o p3 in
	(* May merge some branches of the find
	   l0' = list with the merged branches removed *)
	let l0' = List.filter (fun (_,_,_,p2) ->
	  not (List.exists (function
	      { m_merge = MergeProcess(p',[p3';p2']) } -> (p' == p) && (p3' == p3) && (p2' == p2)
	    | _ -> false) (!merges_to_do))) l0
	in
	if l0' == [] then
	  p3'
	else
	  let l0'' = List.map (fun (bl, def_list, t1, p2) ->
	    (bl, def_list, do_merges_term t1, do_merges_o p2)) l0' in
	  Terms.oproc_from_desc_loc p (Find(l0'',p3',find_info))
      end
  | Get _ | Insert _ -> Parsing_helper.internal_error "Get/Insert should not appear here"
  | _ -> default()

(* Manually guided merge_branches *)

(* Step 1: exclude array references for all candidate merges
   Also set [merges_to_do] with the desired merges.
   We do that in this pass to make sure that we can exploit performed
   merges in equality tests of processes, even in groups of merges,
   which are not always tested in bottom-up order. *)

let merge_groups = ref ([] : merge_group_t list)
    (* Group of tests to merge that have the same constant condition.
       We can compute the sets [ok_arrays_first_branch] and
       [ok_arrays_second_branch] together for such a group of merges
       instead of separately for each merge, which may allow to have
       more variables in [ok_arrays_...]. *)	

let rec has_find t =
  match t.t_desc with
  | FindE _ -> true
  | _ ->
      Terms.exists_subterm
	has_find
	(fun def_list -> true)
	has_find_pat t

and has_find_pat pat =
  Terms.exists_subpat has_find has_find_pat pat

let equal_cond c1 c2 =
  match c1,c2 with
  | CIf t1, CIf t2 -> Terms.equal_terms t1 t2
  | CLet(pat1,t1), CLet(pat2,t2) ->
      Terms.equal_pats pat1 pat2 && Terms.equal_terms t1 t2
  | _ -> false

let get_curarray_suffix_cond cur_array = function
  | CIf t -> get_curarray_suffix_term cur_array t
  | CLet(pat,t) -> get_curarray_suffix_pat_term cur_array pat t
	
let add_group_t cur_array cond t2 t3 = 
  try
    let merge_group = List.find (fun g ->
      equal_cond g.merge_cond cond) (!merge_groups)
    in
    merge_group.left.merge_candidates_t <- t2 :: merge_group.left.merge_candidates_t;
    merge_group.right.merge_candidates_t <- t3 :: merge_group.right.merge_candidates_t
  with Not_found ->
    let new_merge_group =
      { merge_cond = cond;
	curarray_suffix_opt = get_curarray_suffix_cond cur_array cond;
	left = { merge_candidates_t = [t2];
		 merge_candidates_p = [] };
	right = { merge_candidates_t = [t3];
		  merge_candidates_p = [] };
	result = None
      }
    in
    merge_groups := new_merge_group :: (!merge_groups)

let add_group_p cur_array cond p1 p2 =
  try
    let merge_group = List.find (fun g ->
      equal_cond g.merge_cond cond) (!merge_groups)
    in
    merge_group.left.merge_candidates_p <- p1 :: merge_group.left.merge_candidates_p;
    merge_group.right.merge_candidates_p <- p2 :: merge_group.right.merge_candidates_p
  with Not_found ->
    let new_merge_group =
      { merge_cond = cond;
	curarray_suffix_opt = get_curarray_suffix_cond cur_array cond;
	left = { merge_candidates_t = [];
		 merge_candidates_p = [p1] };
	right = { merge_candidates_t = [];
		  merge_candidates_p = [p2] };
	result = None
      }
    in
    merge_groups := new_merge_group :: (!merge_groups)

let rec exclude_array_ref_merges_term l cur_array t =
  match t.t_desc with
  | GetE _ | InsertE _ -> 
      Parsing_helper.internal_error "Get/Insert should not appear in Transf_merge.exclude_array_ref_merges_term"
  | TestE(t1,t2,t3) ->
      exclude_array_ref_merges_term l cur_array t2;
      exclude_array_ref_merges_term l cur_array t3;
      begin
	try
	  let (status,_,_) = List.assq t.t_occ l in
	  assert(!status = 0);
	  status := 1;
	  (* We want to merge this test *)
	  let in_scope = get_in_scope t.t_facts in
	  Array_ref.exclude_array_ref_term in_scope t1;
	  merges_to_do := (create_merge (MergeTerm(t, [t3;t2])) cur_array) :: (!merges_to_do);
	  (* If the test does not contain find, add the merge to a group
	     that uses the same test. The result of the test depends
	     only on the replication indices it contains. *)
	  if not (has_find t1) then
	    add_group_t cur_array (CIf t1) t2 t3
	with Not_found -> 
	  exclude_array_ref_merges_term l cur_array t1
      end
  | LetE(pat,t1,t2,Some t3) ->
      exclude_array_ref_merges_term l cur_array t2;
      exclude_array_ref_merges_term l cur_array t3;
      begin
	try
	  let (status,_,_) = List.assq t.t_occ l in
	  assert(!status = 0);
	  status := 1;
	  (* We want to merge this let *)
	  let in_scope = get_in_scope t.t_facts in
	  Array_ref.exclude_array_ref_pattern in_scope pat;
	  Array_ref.exclude_array_ref_term in_scope t1;
	  merges_to_do := (create_merge (MergeTerm(t, [t3;t2])) cur_array) :: (!merges_to_do);
	  (* If the test does not contain find, add the merge to a group
	     that uses the same test. The result of the test depends
	     only on the replication indices it contains. *)
	  if not (has_find_pat pat || has_find t1) then
	    add_group_t cur_array (CLet(pat,t1)) t2 t3
	with Not_found -> 
	  exclude_array_ref_merges_pat l cur_array pat;
	  exclude_array_ref_merges_term l cur_array t1
      end
  | FindE(l0,t3,find_info) -> 
      exclude_array_ref_merges_term l cur_array t3;
      List.iter (fun (_,_,_,t2) -> exclude_array_ref_merges_term l cur_array t2) l0;
      begin
	try
	  let (status,ext,comm) = List.assq t.t_occ l in
	  assert(!status = 0);
	  status := 1;
	  let in_scope = get_in_scope t.t_facts in
	  match comm with
	  | MC_None | MC_Target BSElse ->
	      (* We want to merge all branches of this find into the else branch *)
	      List.iter (fun (bl, def_list, t1, _) ->
		Array_ref.exclude_array_ref_def_list in_scope def_list;
		Array_ref.exclude_array_ref_term in_scope t1) l0;
	      merges_to_do :=
		 (create_merge (MergeTerm(t, t3 :: List.map (fun (_,_,_,t2) -> t2) l0)) cur_array)
		 :: (!merges_to_do)
	  | MC_Target (BSThen n) ->
	      (* We want to merge all branches of this find into the [n]-th then branch;
		 the else branch must be unreachable *)
	      List.iter (fun (bl, def_list, t1, _) ->
		Array_ref.exclude_array_ref_def_list in_scope def_list;
		Array_ref.exclude_array_ref_term in_scope t1) l0;
	      if n < 1 || n > List.length l0 then
		raise (Error("Cannot merge find: branch "^string_of_int n^" not found, the branch number should be between 1 and the number of branches of the find, "^string_of_int (List.length l0), ext));
	      let target_branch = List.nth l0 (n-1) in
	      let other_branches = List.filter (fun br -> br != target_branch) l0 in
	      let merge_result =
		add_if_defined_if_needed (add_if_defined_term t t3, Terms.get_needed_deflist_term) target_branch
	      in
	      merges_to_do :=
		 (create_merge (MergeTerm(t, merge_result :: t3 :: List.map (fun (_,_,_,t2) -> t2) other_branches)) cur_array)
		 :: (!merges_to_do)
	  | MC_SourceTarget(lsource, BSElse) ->
	      (* We want to merge branches lsource of this find into target *)
	      List.iteri (fun i (bl, def_list, t1, t2) ->
		if List.mem (i+1) lsource then
		  begin
		    Array_ref.exclude_array_ref_def_list in_scope def_list;
		    Array_ref.exclude_array_ref_term in_scope t1;
		    merges_to_do :=
		       (create_merge (MergeTerm(t, [t3;t2])) cur_array)
		       :: (!merges_to_do)
		  end
		else
		  exclude_array_ref_merges_term l ((List.map snd bl) @ cur_array) t1
		    ) l0
	  | MC_SourceTarget(bl, BSThen _) ->
	      (* TODO possible extension *)
	      raise (Error("Cannot merge find: cannot merge some branches into a then branch", ext))
	with Not_found -> 
	  List.iter (fun (bl,_,t1,_) -> exclude_array_ref_merges_term l ((List.map snd bl) @ cur_array) t1) l0
      end
  | _ -> 
      Terms.iter_subterm
	(exclude_array_ref_merges_term l cur_array)
	(fun def_list -> ())
	(exclude_array_ref_merges_pat l cur_array) t

and exclude_array_ref_merges_pat l cur_array pat =
  Terms.iter_subpat
    (exclude_array_ref_merges_term l cur_array)
    (exclude_array_ref_merges_pat l cur_array) pat
    
let rec exclude_array_ref_merges_i l cur_array p =
  match p.i_desc with
    Nil -> ()
  | Par(p1,p2) ->
      exclude_array_ref_merges_i l cur_array p1;
      exclude_array_ref_merges_i l cur_array p2
  | Repl(b,p) ->
      exclude_array_ref_merges_i l (b::cur_array) p
  | OracleDecl(_,patl, p) ->
      List.iter (exclude_array_ref_merges_pat l cur_array) patl;
      exclude_array_ref_merges_o l cur_array p
    
and exclude_array_ref_merges_o l cur_array p =
  match p.p_desc with
  | Test(t,p1,p2) ->
      exclude_array_ref_merges_o l cur_array p1;
      exclude_array_ref_merges_o l cur_array p2;
      begin
	try
	  let (status,_,_) = List.assq p.p_occ l in
	  assert(!status = 0);
	  status := 1;
	  (* We want to merge this test *)
	  let in_scope = get_in_scope p.p_facts in
	  Array_ref.exclude_array_ref_term in_scope t;
	  merges_to_do := (create_merge (MergeProcess(p, [p2;p1])) cur_array) :: (!merges_to_do);
	  (* If the test does not contain find, add the merge to a group
	     that uses the same test. The result of the test depends
	     only on the replication indices it contains. *)
	  if not (has_find t) then
	    add_group_p cur_array (CIf t) p1 p2
	with Not_found ->
	  exclude_array_ref_merges_term l cur_array t
      end
  | Let(pat,t,p1,p2) ->
      exclude_array_ref_merges_o l cur_array p1;
      exclude_array_ref_merges_o l cur_array p2;
      begin
	try
	  let (status,_,_) = List.assq p.p_occ l in
	  assert(!status = 0);
	  status := 1;
	  (* We want to merge this let *)
	  let in_scope = get_in_scope p.p_facts in
	  Array_ref.exclude_array_ref_pattern in_scope pat;
	  Array_ref.exclude_array_ref_term in_scope t;
	  merges_to_do := (create_merge (MergeProcess(p, [p2;p1])) cur_array) :: (!merges_to_do);
	  (* If the test does not contain find, add the merge to a group
	     that uses the same test. The result of the test depends
	     only on the replication indices it contains. *)
	  if not (has_find_pat pat || has_find t) then
	    add_group_p cur_array (CLet(pat,t)) p1 p2
	with Not_found ->
	  exclude_array_ref_merges_pat l cur_array pat;
	  exclude_array_ref_merges_term l cur_array t
      end
  | Find(l0,p3,find_info) ->
      exclude_array_ref_merges_o l cur_array p3;
      List.iter (fun (_,_,_,p2) -> exclude_array_ref_merges_o l cur_array p2) l0;
      begin
	try 
	  let (status,ext,comm) = List.assq p.p_occ l in
	  assert(!status = 0);
	  status := 1;
	  let in_scope = get_in_scope p.p_facts in
	  match comm with
	  | MC_None | MC_Target BSElse ->
	      (* We want to merge all branches of this find into the else branch *)
	      List.iter (fun (bl, def_list, t1, _) ->
		Array_ref.exclude_array_ref_def_list in_scope def_list;
		Array_ref.exclude_array_ref_term in_scope t1) l0;
	      merges_to_do :=
		 (create_merge (MergeProcess(p, p3 :: List.map (fun (_,_,_,p2) -> p2) l0)) cur_array)
		 :: (!merges_to_do)
	  | MC_Target (BSThen n) ->
	      (* We want to merge all branches of this find into the [n]-th then branch;
		 the else branch must be unreachable *)
	      List.iter (fun (bl, def_list, t1, _) ->
		Array_ref.exclude_array_ref_def_list in_scope def_list;
		Array_ref.exclude_array_ref_term in_scope t1) l0;
	      if n < 1 || n > List.length l0 then
		raise (Error("Cannot merge find: branch "^string_of_int n^" not found, the branch number should be between 1 and the number of branches of the find, "^string_of_int (List.length l0), ext));
	      let target_branch = List.nth l0 (n-1) in
	      let other_branches = List.filter (fun br -> br != target_branch) l0 in
	      let merge_result =
		add_if_defined_if_needed (add_if_defined_proc p p3, Terms.get_needed_deflist_oprocess) target_branch
	      in
	      merges_to_do :=
		 (create_merge (MergeProcess(p, merge_result :: p3 :: List.map (fun (_,_,_,p2) -> p2) other_branches)) cur_array)
		 :: (!merges_to_do)
	  | MC_SourceTarget(lsource, BSElse) ->
	      (* We want to merge branches lsource of this find into the else branch *)
	      List.iteri (fun i (bl, def_list, t1, p2) ->
		if List.mem (i+1) lsource then
		  begin
		    Array_ref.exclude_array_ref_def_list in_scope def_list;
		    Array_ref.exclude_array_ref_term in_scope t1;
		    merges_to_do :=
		       (create_merge (MergeProcess(p, [p3;p2])) cur_array)
		       :: (!merges_to_do)
		  end
		else
		  exclude_array_ref_merges_term l ((List.map snd bl) @ cur_array) t1
		    ) l0
	  | MC_SourceTarget(bl, BSThen _) ->
	      (* TODO possible extension *)
	      raise (Error("Cannot merge find: cannot merge some branches into a then branch", ext))
	with Not_found -> 
	  List.iter (fun (bl,_,t1,_) -> exclude_array_ref_merges_term l ((List.map snd bl) @ cur_array) t1) l0
      end
  | Get _ |Insert _ -> Parsing_helper.internal_error "Get/Insert should not appear here"
  | _ ->
      Terms.iter_suboproc
	(exclude_array_ref_merges_o l cur_array)
	(exclude_array_ref_merges_term l cur_array)
	(fun def_list -> ())
	(exclude_array_ref_merges_pat l cur_array)
	(exclude_array_ref_merges_i l cur_array)
	p

(* Step 2: check that the merges given by the user are possible *)

let eq_curarray_suffix_opt o1 o2 =
  match o1,o2 with
  | None, None -> true
  | Some l1, Some l2 -> Terms.equal_lists (==) l1 l2
  | _ -> false
	
let equal_terms_maybe_group curarray_suffix_opt t t' =
  try
    let g = List.find (fun g -> List.memq t g.left.merge_candidates_t) (!merge_groups) in
    (* group found *)
    assert (eq_curarray_suffix_opt curarray_suffix_opt g.curarray_suffix_opt);
    assert (List.memq t' g.right.merge_candidates_t);
    Equal.group g
  with Not_found ->
    (* group not found *)
    Equal.terms curarray_suffix_opt t t'

let equal_processes_maybe_group curarray_suffix_opt p p' =
  try
    let g = List.find (fun g -> List.memq p g.left.merge_candidates_p) (!merge_groups) in
    (* group found *)
    assert (eq_curarray_suffix_opt curarray_suffix_opt g.curarray_suffix_opt);
    assert (List.memq p' g.right.merge_candidates_p);
    Equal.group g
  with Not_found ->
    (* group not found *)
    Equal.processes curarray_suffix_opt p p'

let rec check_merges_manual_term l cur_array t =
  match t.t_desc with
  | GetE _ | InsertE _ -> 
      Parsing_helper.internal_error "Get/Insert should not appear in Transf_merge.check_merges_manual_term"
  | TestE(t1,t2,t3) ->
      check_merges_manual_term l cur_array t2;
      check_merges_manual_term l cur_array t3;
      begin
	try
	  let (status, ext, comm) = List.assq t.t_occ l in
	  assert(!status = 1);
	  status := 2;
          if comm != MC_None then
            raise (Error("When merging an if, no specific merge command should be given", ext));
	  (* We want to merge this test *)
	  Equal.start_reset();
	  let r =
	    match ok_cond t1 with 
	    | RTrue -> equal_terms_maybe_group (get_curarray_suffix_term cur_array t1) t2 t3
	    | r -> r
	  in
	  Equal.reset();
	  match r with
	  | RTrue -> ()
	  | RFalse msg -> 
	      raise (Error("Cannot merge if:\n"^msg, ext))
	with Not_found ->
	  check_merges_manual_term l cur_array t1
      end

  | LetE(pat,t1,t2,Some t3) ->
      check_merges_manual_term l cur_array t2;
      check_merges_manual_term l cur_array t3;
      begin
	try
	  let (status, ext, comm) = List.assq t.t_occ l in
	  assert(!status = 1);
	  status := 2;
          if comm != MC_None then
            raise (Error("When merging a let, no specific merge command should be given", ext));
	  (* We want to merge this let *)
	  Equal.start_reset();
	  let curarray_suffix = get_curarray_suffix_pat_term cur_array pat t in
	  let r =
	    match ok_cond_pat t.t_occ pat with
	    | RTrue -> 
		begin
		  match ok_cond t1 with
		  | RTrue -> equal_terms_maybe_group curarray_suffix t2 t3 
		  | r -> r
		end
	    | r -> r 
	  in
	  Equal.reset();
	  match r with
	  | RTrue -> ()
	  | RFalse msg -> 
	      raise (Error("Cannot merge let:\n"^msg, ext))
	with Not_found -> 
	  check_merges_manual_pat l cur_array pat;
	  check_merges_manual_term l cur_array t1
      end
  | FindE(l0,t3,find_info) -> 
      check_merges_manual_term l cur_array t3;
      List.iter (fun (_,_,_,t2) -> check_merges_manual_term l cur_array t2) l0;
      begin
	try
	  let (status,ext,comm) = List.assq t.t_occ l in
	  assert(!status = 1);
	  status := 2;
	  match comm with
	  | MC_None | MC_Target BSElse ->
	      (* Merge all branches into the else branch *)
	      if not (Terms.is_not_unique_to_prove find_info) then
		raise (Error("Cannot merge find: it may abort", ext));
	      Equal.start_reset();
	      let r = can_merge_all_branches_store_arrays false Equal.terms cur_array t.t_occ t.t_facts l0 t3 in
	      Equal.reset();
	      begin
		match r with
		| RTrue -> ()
		| RFalse msg ->
		    raise (Error("Cannot merge find:\n"^msg, ext));
	      end
	  | MC_Target (BSThen n) ->
	      (* Merge all branches into the [n]-th then branch.
                 The else branch must be unreachable *)
	      if n < 1 || n > List.length l0 then
		raise (Error("Cannot merge find: branch "^string_of_int n^" not found, the branch number should be between 1 and the number of branches of the find, "^string_of_int (List.length l0), ext));
	      if not(Terms.is_not_unique_to_prove find_info) then
		raise (Error("Cannot merge find: it may abort", ext));
	      if (List.length l0 <= 1) then
		raise (Error("Cannot merge find: it has a single then branch", ext));
	      if List.exists (fun (_, _, t1, _) ->
		Terms.may_abort_counted (Some (!whole_game)) t1) l0 then
		raise (Error("Cannot merge find: a condition may abort", ext));
	      let (bl, def_list, t1, target_merge) as target_branch = List.nth l0 (n-1) in
	      List.iter (fun (b,_) ->
		if has_array_ref b || Terms.refers_to b target_merge then
		  raise (Error("Cannot merge find: index "^Display.binder_to_string b^" defined in the target branch is used", ext))
		    ) bl;
	      (* Check that the else branch is unreachable.
                 A trivial and common case is when the target branch is always executed *)
	      if (not (bl = [] && def_list = [] && Terms.is_true t1)) &&
		(not (is_unreachable (DTerm t3))) then
		raise (Error("Cannot merge find into a then branch: the else branch may be reachable", ext));
	      let other_branches = List.filter (fun br -> br != target_branch) l0 in
	      (* Check that all branches execute the same code as the target branch *)
	      Equal.start_reset();
	      let r = can_merge_all_branches_store_arrays false Equal.terms cur_array t.t_occ t.t_facts other_branches target_merge in
	      Equal.reset();
	      begin
		match r with
		| RTrue -> ()
		| RFalse msg ->
		    raise (Error("Cannot merge find:"^msg, ext))
	      end
	  | MC_SourceTarget(brl, BSElse) ->
	      (* Merge then branches [brl] into the else branch.
                 The find must be unique *)
	      if not (Terms.is_unique_no_abort (Some(!whole_game)) l0 find_info) then
		raise (Error("Cannot merge some branches of find: the find must be unique and never abort", ext));
	      (* Check that all branch numbers are in the right interval *)
	      let nbranches = List.length l0 in
	      List.iter (fun n ->
		if n < 1 || n > nbranches then
		  raise (Error("Cannot merge find: branch "^string_of_int n^" not found, the branch number should be between 1 and the number of branches of the find, "^string_of_int nbranches, ext));
		) brl;
	      (* Check that branch numbers are pairwise distinct *)
	      let used = Array.make nbranches false in
	      List.iter (fun n ->
		if used.(n-1) then
		  raise (Error("Cannot merge find: branch number "^(string_of_int n)^" listed several times", ext));
		used.(n-1) <- true
		     ) brl;
	      List.iteri (fun i ((bl, def_list, t1, t2) as br) ->
		if List.mem (i+1) brl then
		  begin
		    Equal.start_reset();
		    let r = can_merge_one_branch_store_arrays false Equal.terms cur_array t.t_occ t.t_facts br t3 in
		    Equal.reset();
		    begin
		      match r with
		      | RTrue -> ()
		      | RFalse msg ->
			  raise (Error("Cannot merge branch "^(string_of_int (i+1))^" of find with else branch:\n"^msg, ext));
		    end
		  end
		else
	          (* We can perform merges in remaining conditions of find *)
		  check_merges_manual_term l ((List.map snd bl) @ cur_array) t1
		    ) l0
	  | MC_SourceTarget(bl, BSThen _) ->
	      (* TODO I could extend to perform such a merge when the find is unique and the
		 else branch is unreachable. The target branch becomes an else branch of the
		 find that keeps the unmerged branches.
		 More generally, in a find unique in which the else branch is unreachable,
		 if a then branch has no used index, it can be moved to the else branch. *)
	      raise (Error("Cannot merge find: cannot merge some branches into a then branch", ext))
	with Not_found -> 
	  List.iter (fun (bl,_,t1,_) -> check_merges_manual_term l ((List.map snd bl) @ cur_array) t1) l0
      end
  | _ -> 
      Terms.iter_subterm
	(check_merges_manual_term l cur_array)
	(fun def_list -> ())
	(check_merges_manual_pat l cur_array) t

and check_merges_manual_pat l cur_array pat =
  Terms.iter_subpat
    (check_merges_manual_term l cur_array)
    (check_merges_manual_pat l cur_array) pat
    
let rec check_merges_manual_i l cur_array p =
  match p.i_desc with
    Nil -> ()
  | Par(p1,p2) ->
      check_merges_manual_i l cur_array p1;
      check_merges_manual_i l cur_array p2
  | Repl(b,p) ->
      check_merges_manual_i l (b::cur_array) p
  | OracleDecl(_,patl, p) ->
      List.iter (check_merges_manual_pat l cur_array) patl;
      check_merges_manual_o l cur_array p
    
and check_merges_manual_o l cur_array p =
  match p.p_desc with
  | Test(t,p1,p2) ->
      check_merges_manual_o l cur_array p1;
      check_merges_manual_o l cur_array p2;
      begin
	try
	  let (status,ext,comm) = List.assq p.p_occ l in
	  assert(!status = 1);
	  status := 2;
          if comm != MC_None then
            raise (Error("When merging an if, no specific merge command should be given", ext));
	  (* We want to merge this test *)
	  Equal.start_reset();
	  let r =
	     match ok_cond t with 
	     | RTrue -> equal_processes_maybe_group (get_curarray_suffix_term cur_array t) p1 p2
	     | r -> r
	  in
	  Equal.reset();
	  match r with
	  | RTrue -> ()
	  | RFalse msg -> 
	      raise (Error("Cannot merge if:\n"^msg, ext))
	with Not_found ->
	  check_merges_manual_term l cur_array t
      end
  | Let(pat,t,p1,p2) ->
      check_merges_manual_o l cur_array p1;
      check_merges_manual_o l cur_array p2;
      begin
	try
	  let (status, ext, comm) = List.assq p.p_occ l in
	  assert(!status = 1);
	  status := 2;
          if comm != MC_None then
            raise (Error("When merging a let, no specific merge command should be given", ext));
	  (* We want to merge this let *)
	  Equal.start_reset();
	  let curarray_suffix = get_curarray_suffix_pat_term cur_array pat t in
	  let r =
	    match ok_cond_pat p.p_occ pat with
	    | RTrue -> 
		begin
		  match ok_cond t with
		  | RTrue -> equal_processes_maybe_group curarray_suffix p1 p2
		  | r -> r
		end
	    | r -> r 
	  in
	  Equal.reset();
	  match r with
	  | RTrue -> ()
	  | RFalse msg -> 
	      raise (Error("Cannot merge let:\n"^msg, ext))
	with Not_found -> 
	  check_merges_manual_pat l cur_array pat;
	  check_merges_manual_term l cur_array t
      end
  | Find(l0,p3,find_info) ->
      check_merges_manual_o l cur_array p3;
      List.iter (fun (_,_,_,p2) -> check_merges_manual_o l cur_array p2) l0;
      begin
	try 
	  let (status,ext,comm) = List.assq p.p_occ l in
	  assert(!status = 1);
	  status := 2;
	  match comm with
	  | MC_None | MC_Target BSElse ->
	      (* Merge all branches into the else branch *)
	      if not (Terms.is_not_unique_to_prove find_info) then
		raise (Error("Cannot merge find: it may abort", ext));
	      Equal.start_reset();
	      let r = can_merge_all_branches_store_arrays false Equal.processes cur_array p.p_occ p.p_facts l0 p3 in
	      Equal.reset();
	      begin
		match r with
		| RTrue -> ()
		| RFalse msg ->
		    raise (Error("Cannot merge find:\n"^msg, ext));
	      end
	  | MC_Target (BSThen n) ->
	      (* Merge all branches into the [n]-th then branch.
                 The else branch must be unreachable *)
	      if n < 1 || n > List.length l0 then
		raise (Error("Cannot merge find: branch "^string_of_int n^" not found, the branch number should be between 1 and the number of branches of the find, "^string_of_int (List.length l0), ext));
	      if not(Terms.is_not_unique_to_prove find_info) then
		raise (Error("Cannot merge find: it may abort", ext));
	      if (List.length l0 <= 1) then
		raise (Error("Cannot merge find: it has a single then branch", ext));
	      if List.exists (fun (_, _, t1, _) ->
		Terms.may_abort_counted (Some (!whole_game)) t1) l0 then
		raise (Error("Cannot merge find: a condition may abort", ext));
	      let (bl, def_list, t1, target_merge) as target_branch = List.nth l0 (n-1) in
	      List.iter (fun (b,_) ->
		if has_array_ref b || Terms.refers_to_oprocess b target_merge then
		  raise (Error("Cannot merge find: index "^Display.binder_to_string b^" defined in the target branch is used", ext))
		    ) bl;
	      (* Check that the else branch is unreachable.
                 A trivial and common case is when the target branch is always executed *)
	      if (not (bl = [] && def_list = [] && Terms.is_true t1)) &&
		(not (is_unreachable (DProcess p3))) then
		raise (Error("Cannot merge find into a then branch: the else branch may be reachable", ext));
	      let other_branches = List.filter (fun br -> br != target_branch) l0 in
	      (* Check that all branches execute the same code as the target branch *)
	      Equal.start_reset();
	      let r = can_merge_all_branches_store_arrays false Equal.processes cur_array p.p_occ p.p_facts other_branches target_merge in
	      Equal.reset();
	      begin
		match r with
		| RTrue -> ()
		| RFalse msg ->
		    raise (Error("Cannot merge find:"^msg, ext))
	      end
	  | MC_SourceTarget(brl, BSElse) ->
	      (* Merge then branches [brl] into the else branch.
                 The find must be unique *)
	      if not (Terms.is_unique_no_abort (Some(!whole_game)) l0 find_info) then
		raise (Error("Cannot merge some branches of find: the find must be unique and never abort", ext));
	      (* Check that all branch numbers are in the right interval *)
	      let nbranches = List.length l0 in
	      List.iter (fun n ->
		if n < 1 || n > nbranches then
		  raise (Error("Cannot merge find: branch "^string_of_int n^" not found, the branch number should be between 1 and the number of branches of the find, "^string_of_int nbranches, ext));
		) brl;
	      (* Check that branch numbers are pairwise distinct *)
	      let used = Array.make nbranches false in
	      List.iter (fun n ->
		if used.(n-1) then
		  raise (Error("Cannot merge find: branch number "^(string_of_int n)^" listed several times", ext));
		used.(n-1) <- true
		     ) brl;
	      List.iteri (fun i ((bl, def_list, t1, p2) as br) ->
		if List.mem (i+1) brl then
		  begin
		    Equal.start_reset();
		    let r = can_merge_one_branch_store_arrays false Equal.processes cur_array p.p_occ p.p_facts br p3 in
		    Equal.reset();
		    begin
		      match r with
		      | RTrue -> ()
		      | RFalse msg ->
			  raise (Error("Cannot merge branch "^(string_of_int (i+1))^" of find with else branch:\n"^msg, ext));
		    end
		  end
		else
	          (* We can perform merges in remaining conditions of find *)
		  check_merges_manual_term l ((List.map snd bl) @ cur_array) t1
		    ) l0
	  | MC_SourceTarget(bl, BSThen _) ->
	      (* TODO I could extend to perform such a merge when the find is unique and the
		 else branch is unreachable. The target branch becomes an else branch of the
		 find that keeps the unmerged branches.
		 More generally, in a find unique in which the else branch is unreachable,
		 if a then branch has no used index, it can be moved to the else branch. *)
	      raise (Error("Cannot merge find: cannot merge some branches into a then branch", ext))
	with Not_found -> 
	  List.iter (fun (bl,_,t1,_) -> check_merges_manual_term l ((List.map snd bl) @ cur_array) t1) l0
      end
  | Get _ |Insert _ -> Parsing_helper.internal_error "Get/Insert should not appear here"
  | _ ->
      Terms.iter_suboproc
	(check_merges_manual_o l cur_array)
	(check_merges_manual_term l cur_array)
	(fun def_list -> ())
	(check_merges_manual_pat l cur_array)
	(check_merges_manual_i l cur_array)
	p
	
(* TODO [done, to test]
   for the manually guided merge, group together the merges that
   have the same constant condition (term without replication index),
   and compute the ok_vars for the group instead of for each merge
   individually. *)

	
let display_merge = function
    (MergeProcess(p,l),_,_,_,_) ->
      print_string "Merging ";
      Display.display_oprocess "" p;
      print_string "Branches ";
      Display.display_list (fun p -> Display.display_oprocess "" p) l;
      print_newline()
  | (MergeTerm(t,l),_,_,_,_) ->
      print_string "Merging ";
      Display.display_term t;
      print_string "Branches ";
      Display.display_list Display.display_term l;
      print_newline()
      

let merge_branches l g =
  let g_proc = Terms.get_process g in
  whole_game := g;
  Array_ref.array_ref_process g_proc;
  Improved_def.improved_def_game None g;
  Depanal.reset [] g;
  merges_to_do := [];
  merges_cannot_be_done := [];
  allow_a_posteriori_array_ref_removal := true;
  advise_merge_arrays := !Settings.merge_arrays;
  sure_merges_to_do := false;
  assert(!merge_groups = []);
  branch1_name := "in the target branch";
  branch2_name := "in the other branch";
  let cleanup() =
    Array_ref.cleanup_array_ref();
    Improved_def.empty_improved_def_game g;
    whole_game := Terms.empty_game;
    merges_to_do := [];
    merges_cannot_be_done := [];
    merge_groups := []
  in
  let result =
    if l == [] then
      begin
	(* Automatic merge *)
	collect_merges_i [] g_proc;
	if (!merges_to_do) == [] then
          (* No merge can be done *)
	  begin
	    Depanal.final_empty_state();
	    (g, [], [])
	  end
	else
	  begin
            (* See which merges can be done, if we remove enough array references *)
	    remove_impossible_merges();
            (* List.iter display_merge (!merges_to_do); *)
	    if (!merges_to_do) != [] then
              (* Perform the possible merges *)
	      let p' = do_merges_i g_proc in
	      Settings.changed := true;
              (* TO DO if (!merges_cannot_be_done) != [], I should iterate to get up-to-date advice *)
	      let done_transfos = 
		List.map (fun m ->
		  match m.m_merge with
		  | MergeProcess(p,l) -> DMergeBranches(p,l)
		  | MergeTerm(t,l) -> DMergeBranchesE(t,l)) (!merges_to_do)
	      in
	      let proba = Depanal.final_add_proba () in
	      (Terms.build_transformed_game p' g, proba, done_transfos)
	    else
	      begin
	        (* No change, but may advise MergeArrays *)
		List.iter add_advice (!merges_cannot_be_done);
		Depanal.final_empty_state();
		(g, [], [])
	      end
	  end
      end
    else
      begin
	(* Manually-guided merge *)
	allow_a_posteriori_array_ref_removal := false;
	sure_merges_to_do := true;
	let l = List.map (fun (occ, ext, comm) -> (occ, (ref 0, ext, comm))) l in
	try
	  exclude_array_ref_merges_i l [] g_proc;
	  List.iter (fun (occ, (status, ext, comm)) ->
	    assert (!status <= 1);
	    if !status = 0 then
	      raise (Error("Merge command at program point "^string_of_int occ^" not used (program point not found, listed several times, or inside code removed by another merge)", ext))
		) l;
	  check_merges_manual_i l [] g_proc;
          (* Perform the possible merges *)
	  let p' = do_merges_i g_proc in
	  Settings.changed := true;
	  let done_transfos = 
	    List.map (fun m ->
	      match m.m_merge with
	      | MergeProcess(p,l) -> DMergeBranches(p,l)
	      | MergeTerm(t,l) -> DMergeBranchesE(t,l)) (!merges_to_do)
	  in
	  let proba = Depanal.final_add_proba () in
	  (Terms.build_transformed_game p' g, proba, done_transfos)
	with (Error _) as e ->
	  Depanal.final_empty_state();
	  cleanup();
	  raise e
      end
  in
  cleanup();
  result
      
(**************** Test equality between two independent processes *****************)
(* Used for testing success of the equivalence query *)
    
let equal_games g1 g2 =
  let g1_proc = Terms.get_process g1 in
  let g2_proc = Terms.get_process g2 in
  whole_game := g1;
  allow_a_posteriori_array_ref_removal := false;
  advise_merge_arrays := false;
  branch1_name := "in this process";
  branch2_name := "on the other end";
  Array_ref.array_ref_processes g1_proc g2_proc;
  Depanal.reset [] g1;
  let r = 
    match Equal.fullprocesses (Some []) g1_proc g2_proc with
    | RTrue -> true
    | RFalse msg -> print_string msg; false
  in
  let proba = Depanal.final_add_proba () in
  Array_ref.cleanup_array_ref();
  all_branches_var_list := [];
  whole_game := Terms.empty_game;
  (r, proba)
